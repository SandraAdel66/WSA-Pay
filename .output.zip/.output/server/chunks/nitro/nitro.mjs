import process from 'node:process';globalThis._importMeta_=globalThis._importMeta_||{url:"file:///_entry.js",env:process.env};import http, { Server as Server$1 } from 'node:http';
import https, { Server } from 'node:https';
import { EventEmitter } from 'node:events';
import { Buffer as Buffer$1 } from 'node:buffer';
import { promises, existsSync, mkdirSync } from 'node:fs';
import { resolve as resolve$1, dirname as dirname$1, join } from 'node:path';
import { createHash } from 'node:crypto';
import { fileURLToPath } from 'node:url';
import { getIcons } from '@iconify/utils';
import { consola } from 'consola';
import Database from 'better-sqlite3';
import { ipxFSStorage, ipxHttpStorage, createIPX, createIPXH3Handler } from 'ipx';

const suspectProtoRx = /"(?:_|\\u0{2}5[Ff]){2}(?:p|\\u0{2}70)(?:r|\\u0{2}72)(?:o|\\u0{2}6[Ff])(?:t|\\u0{2}74)(?:o|\\u0{2}6[Ff])(?:_|\\u0{2}5[Ff]){2}"\s*:/;
const suspectConstructorRx = /"(?:c|\\u0063)(?:o|\\u006[Ff])(?:n|\\u006[Ee])(?:s|\\u0073)(?:t|\\u0074)(?:r|\\u0072)(?:u|\\u0075)(?:c|\\u0063)(?:t|\\u0074)(?:o|\\u006[Ff])(?:r|\\u0072)"\s*:/;
const JsonSigRx = /^\s*["[{]|^\s*-?\d{1,16}(\.\d{1,17})?([Ee][+-]?\d+)?\s*$/;
function jsonParseTransform(key, value) {
  if (key === "__proto__" || key === "constructor" && value && typeof value === "object" && "prototype" in value) {
    warnKeyDropped(key);
    return;
  }
  return value;
}
function warnKeyDropped(key) {
  console.warn(`[destr] Dropping "${key}" key to prevent prototype pollution.`);
}
function destr(value, options = {}) {
  if (typeof value !== "string") {
    return value;
  }
  if (value[0] === '"' && value[value.length - 1] === '"' && value.indexOf("\\") === -1) {
    return value.slice(1, -1);
  }
  const _value = value.trim();
  if (_value.length <= 9) {
    switch (_value.toLowerCase()) {
      case "true": {
        return true;
      }
      case "false": {
        return false;
      }
      case "undefined": {
        return void 0;
      }
      case "null": {
        return null;
      }
      case "nan": {
        return Number.NaN;
      }
      case "infinity": {
        return Number.POSITIVE_INFINITY;
      }
      case "-infinity": {
        return Number.NEGATIVE_INFINITY;
      }
    }
  }
  if (!JsonSigRx.test(value)) {
    if (options.strict) {
      throw new SyntaxError("[destr] Invalid JSON");
    }
    return value;
  }
  try {
    if (suspectProtoRx.test(value) || suspectConstructorRx.test(value)) {
      if (options.strict) {
        throw new Error("[destr] Possible prototype pollution");
      }
      return JSON.parse(value, jsonParseTransform);
    }
    return JSON.parse(value);
  } catch (error) {
    if (options.strict) {
      throw error;
    }
    return value;
  }
}

const HASH_RE = /#/g;
const AMPERSAND_RE = /&/g;
const SLASH_RE = /\//g;
const EQUAL_RE = /=/g;
const IM_RE = /\?/g;
const PLUS_RE = /\+/g;
const ENC_CARET_RE = /%5e/gi;
const ENC_BACKTICK_RE = /%60/gi;
const ENC_PIPE_RE = /%7c/gi;
const ENC_SPACE_RE = /%20/gi;
const ENC_SLASH_RE = /%2f/gi;
const ENC_ENC_SLASH_RE = /%252f/gi;
function encode(text) {
  return encodeURI("" + text).replace(ENC_PIPE_RE, "|");
}
function encodeQueryValue(input) {
  return encode(typeof input === "string" ? input : JSON.stringify(input)).replace(PLUS_RE, "%2B").replace(ENC_SPACE_RE, "+").replace(HASH_RE, "%23").replace(AMPERSAND_RE, "%26").replace(ENC_BACKTICK_RE, "`").replace(ENC_CARET_RE, "^").replace(SLASH_RE, "%2F");
}
function encodeQueryKey(text) {
  return encodeQueryValue(text).replace(EQUAL_RE, "%3D");
}
function encodePath(text) {
  return encode(text).replace(HASH_RE, "%23").replace(IM_RE, "%3F").replace(ENC_ENC_SLASH_RE, "%2F").replace(AMPERSAND_RE, "%26").replace(PLUS_RE, "%2B");
}
function encodeParam(text) {
  return encodePath(text).replace(SLASH_RE, "%2F");
}
function decode$2(text = "") {
  try {
    return decodeURIComponent("" + text);
  } catch {
    return "" + text;
  }
}
function decodePath(text) {
  return decode$2(text.replace(ENC_SLASH_RE, "%252F"));
}
function decodeQueryKey(text) {
  return decode$2(text.replace(PLUS_RE, " "));
}
function decodeQueryValue(text) {
  return decode$2(text.replace(PLUS_RE, " "));
}

function parseQuery(parametersString = "") {
  const object = {};
  if (parametersString[0] === "?") {
    parametersString = parametersString.slice(1);
  }
  for (const parameter of parametersString.split("&")) {
    const s = parameter.match(/([^=]+)=?(.*)/) || [];
    if (s.length < 2) {
      continue;
    }
    const key = decodeQueryKey(s[1]);
    if (key === "__proto__" || key === "constructor") {
      continue;
    }
    const value = decodeQueryValue(s[2] || "");
    if (object[key] === void 0) {
      object[key] = value;
    } else if (Array.isArray(object[key])) {
      object[key].push(value);
    } else {
      object[key] = [object[key], value];
    }
  }
  return object;
}
function encodeQueryItem(key, value) {
  if (typeof value === "number" || typeof value === "boolean") {
    value = String(value);
  }
  if (!value) {
    return encodeQueryKey(key);
  }
  if (Array.isArray(value)) {
    return value.map((_value) => `${encodeQueryKey(key)}=${encodeQueryValue(_value)}`).join("&");
  }
  return `${encodeQueryKey(key)}=${encodeQueryValue(value)}`;
}
function stringifyQuery(query) {
  return Object.keys(query).filter((k) => query[k] !== void 0).map((k) => encodeQueryItem(k, query[k])).filter(Boolean).join("&");
}

const PROTOCOL_STRICT_REGEX = /^[\s\w\0+.-]{2,}:([/\\]{1,2})/;
const PROTOCOL_REGEX = /^[\s\w\0+.-]{2,}:([/\\]{2})?/;
const PROTOCOL_RELATIVE_REGEX = /^([/\\]\s*){2,}[^/\\]/;
const PROTOCOL_SCRIPT_RE = /^[\s\0]*(blob|data|javascript|vbscript):$/i;
const TRAILING_SLASH_RE = /\/$|\/\?|\/#/;
const JOIN_LEADING_SLASH_RE = /^\.?\//;
function hasProtocol(inputString, opts = {}) {
  if (typeof opts === "boolean") {
    opts = { acceptRelative: opts };
  }
  if (opts.strict) {
    return PROTOCOL_STRICT_REGEX.test(inputString);
  }
  return PROTOCOL_REGEX.test(inputString) || (opts.acceptRelative ? PROTOCOL_RELATIVE_REGEX.test(inputString) : false);
}
function isScriptProtocol(protocol) {
  return !!protocol && PROTOCOL_SCRIPT_RE.test(protocol);
}
function hasTrailingSlash(input = "", respectQueryAndFragment) {
  if (!respectQueryAndFragment) {
    return input.endsWith("/");
  }
  return TRAILING_SLASH_RE.test(input);
}
function withoutTrailingSlash(input = "", respectQueryAndFragment) {
  if (!respectQueryAndFragment) {
    return (hasTrailingSlash(input) ? input.slice(0, -1) : input) || "/";
  }
  if (!hasTrailingSlash(input, true)) {
    return input || "/";
  }
  let path = input;
  let fragment = "";
  const fragmentIndex = input.indexOf("#");
  if (fragmentIndex >= 0) {
    path = input.slice(0, fragmentIndex);
    fragment = input.slice(fragmentIndex);
  }
  const [s0, ...s] = path.split("?");
  const cleanPath = s0.endsWith("/") ? s0.slice(0, -1) : s0;
  return (cleanPath || "/") + (s.length > 0 ? `?${s.join("?")}` : "") + fragment;
}
function withTrailingSlash(input = "", respectQueryAndFragment) {
  if (!respectQueryAndFragment) {
    return input.endsWith("/") ? input : input + "/";
  }
  if (hasTrailingSlash(input, true)) {
    return input || "/";
  }
  let path = input;
  let fragment = "";
  const fragmentIndex = input.indexOf("#");
  if (fragmentIndex >= 0) {
    path = input.slice(0, fragmentIndex);
    fragment = input.slice(fragmentIndex);
    if (!path) {
      return fragment;
    }
  }
  const [s0, ...s] = path.split("?");
  return s0 + "/" + (s.length > 0 ? `?${s.join("?")}` : "") + fragment;
}
function hasLeadingSlash(input = "") {
  return input.startsWith("/");
}
function withLeadingSlash(input = "") {
  return hasLeadingSlash(input) ? input : "/" + input;
}
function withBase(input, base) {
  if (isEmptyURL(base) || hasProtocol(input)) {
    return input;
  }
  const _base = withoutTrailingSlash(base);
  if (input.startsWith(_base)) {
    return input;
  }
  return joinURL(_base, input);
}
function withoutBase(input, base) {
  if (isEmptyURL(base)) {
    return input;
  }
  const _base = withoutTrailingSlash(base);
  if (!input.startsWith(_base)) {
    return input;
  }
  const trimmed = input.slice(_base.length);
  return trimmed[0] === "/" ? trimmed : "/" + trimmed;
}
function withQuery(input, query) {
  const parsed = parseURL(input);
  const mergedQuery = { ...parseQuery(parsed.search), ...query };
  parsed.search = stringifyQuery(mergedQuery);
  return stringifyParsedURL(parsed);
}
function getQuery$1(input) {
  return parseQuery(parseURL(input).search);
}
function isEmptyURL(url) {
  return !url || url === "/";
}
function isNonEmptyURL(url) {
  return url && url !== "/";
}
function joinURL(base, ...input) {
  let url = base || "";
  for (const segment of input.filter((url2) => isNonEmptyURL(url2))) {
    if (url) {
      const _segment = segment.replace(JOIN_LEADING_SLASH_RE, "");
      url = withTrailingSlash(url) + _segment;
    } else {
      url = segment;
    }
  }
  return url;
}
function joinRelativeURL(..._input) {
  const JOIN_SEGMENT_SPLIT_RE = /\/(?!\/)/;
  const input = _input.filter(Boolean);
  const segments = [];
  let segmentsDepth = 0;
  for (const i of input) {
    if (!i || i === "/") {
      continue;
    }
    for (const [sindex, s] of i.split(JOIN_SEGMENT_SPLIT_RE).entries()) {
      if (!s || s === ".") {
        continue;
      }
      if (s === "..") {
        if (segments.length === 1 && hasProtocol(segments[0])) {
          continue;
        }
        segments.pop();
        segmentsDepth--;
        continue;
      }
      if (sindex === 1 && segments[segments.length - 1]?.endsWith(":/")) {
        segments[segments.length - 1] += "/" + s;
        continue;
      }
      segments.push(s);
      segmentsDepth++;
    }
  }
  let url = segments.join("/");
  if (segmentsDepth >= 0) {
    if (input[0]?.startsWith("/") && !url.startsWith("/")) {
      url = "/" + url;
    } else if (input[0]?.startsWith("./") && !url.startsWith("./")) {
      url = "./" + url;
    }
  } else {
    url = "../".repeat(-1 * segmentsDepth) + url;
  }
  if (input[input.length - 1]?.endsWith("/") && !url.endsWith("/")) {
    url += "/";
  }
  return url;
}

const protocolRelative = Symbol.for("ufo:protocolRelative");
function parseURL(input = "", defaultProto) {
  const _specialProtoMatch = input.match(
    /^[\s\0]*(blob:|data:|javascript:|vbscript:)(.*)/i
  );
  if (_specialProtoMatch) {
    const [, _proto, _pathname = ""] = _specialProtoMatch;
    return {
      protocol: _proto.toLowerCase(),
      pathname: _pathname,
      href: _proto + _pathname,
      auth: "",
      host: "",
      search: "",
      hash: ""
    };
  }
  if (!hasProtocol(input, { acceptRelative: true })) {
    return parsePath(input);
  }
  const [, protocol = "", auth, hostAndPath = ""] = input.replace(/\\/g, "/").match(/^[\s\0]*([\w+.-]{2,}:)?\/\/([^/@]+@)?(.*)/) || [];
  let [, host = "", path = ""] = hostAndPath.match(/([^#/?]*)(.*)?/) || [];
  if (protocol === "file:") {
    path = path.replace(/\/(?=[A-Za-z]:)/, "");
  }
  const { pathname, search, hash } = parsePath(path);
  return {
    protocol: protocol.toLowerCase(),
    auth: auth ? auth.slice(0, Math.max(0, auth.length - 1)) : "",
    host,
    pathname,
    search,
    hash,
    [protocolRelative]: !protocol
  };
}
function parsePath(input = "") {
  const [pathname = "", search = "", hash = ""] = (input.match(/([^#?]*)(\?[^#]*)?(#.*)?/) || []).splice(1);
  return {
    pathname,
    search,
    hash
  };
}
function stringifyParsedURL(parsed) {
  const pathname = parsed.pathname || "";
  const search = parsed.search ? (parsed.search.startsWith("?") ? "" : "?") + parsed.search : "";
  const hash = parsed.hash || "";
  const auth = parsed.auth ? parsed.auth + "@" : "";
  const host = parsed.host || "";
  const proto = parsed.protocol || parsed[protocolRelative] ? (parsed.protocol || "") + "//" : "";
  return proto + auth + host + pathname + search + hash;
}

function parse$1(str, options) {
  if (typeof str !== "string") {
    throw new TypeError("argument str must be a string");
  }
  const obj = {};
  const opt = {};
  const dec = opt.decode || decode$1;
  let index = 0;
  while (index < str.length) {
    const eqIdx = str.indexOf("=", index);
    if (eqIdx === -1) {
      break;
    }
    let endIdx = str.indexOf(";", index);
    if (endIdx === -1) {
      endIdx = str.length;
    } else if (endIdx < eqIdx) {
      index = str.lastIndexOf(";", eqIdx - 1) + 1;
      continue;
    }
    const key = str.slice(index, eqIdx).trim();
    if (opt?.filter && !opt?.filter(key)) {
      index = endIdx + 1;
      continue;
    }
    if (void 0 === obj[key]) {
      let val = str.slice(eqIdx + 1, endIdx).trim();
      if (val.codePointAt(0) === 34) {
        val = val.slice(1, -1);
      }
      obj[key] = tryDecode$1(val, dec);
    }
    index = endIdx + 1;
  }
  return obj;
}
function decode$1(str) {
  return str.includes("%") ? decodeURIComponent(str) : str;
}
function tryDecode$1(str, decode2) {
  try {
    return decode2(str);
  } catch {
    return str;
  }
}

const fieldContentRegExp = /^[\u0009\u0020-\u007E\u0080-\u00FF]+$/;
function serialize$2(name, value, options) {
  const opt = options || {};
  const enc = opt.encode || encodeURIComponent;
  if (typeof enc !== "function") {
    throw new TypeError("option encode is invalid");
  }
  if (!fieldContentRegExp.test(name)) {
    throw new TypeError("argument name is invalid");
  }
  const encodedValue = enc(value);
  if (encodedValue && !fieldContentRegExp.test(encodedValue)) {
    throw new TypeError("argument val is invalid");
  }
  let str = name + "=" + encodedValue;
  if (void 0 !== opt.maxAge && opt.maxAge !== null) {
    const maxAge = opt.maxAge - 0;
    if (Number.isNaN(maxAge) || !Number.isFinite(maxAge)) {
      throw new TypeError("option maxAge is invalid");
    }
    str += "; Max-Age=" + Math.floor(maxAge);
  }
  if (opt.domain) {
    if (!fieldContentRegExp.test(opt.domain)) {
      throw new TypeError("option domain is invalid");
    }
    str += "; Domain=" + opt.domain;
  }
  if (opt.path) {
    if (!fieldContentRegExp.test(opt.path)) {
      throw new TypeError("option path is invalid");
    }
    str += "; Path=" + opt.path;
  }
  if (opt.expires) {
    if (!isDate(opt.expires) || Number.isNaN(opt.expires.valueOf())) {
      throw new TypeError("option expires is invalid");
    }
    str += "; Expires=" + opt.expires.toUTCString();
  }
  if (opt.httpOnly) {
    str += "; HttpOnly";
  }
  if (opt.secure) {
    str += "; Secure";
  }
  if (opt.priority) {
    const priority = typeof opt.priority === "string" ? opt.priority.toLowerCase() : opt.priority;
    switch (priority) {
      case "low": {
        str += "; Priority=Low";
        break;
      }
      case "medium": {
        str += "; Priority=Medium";
        break;
      }
      case "high": {
        str += "; Priority=High";
        break;
      }
      default: {
        throw new TypeError("option priority is invalid");
      }
    }
  }
  if (opt.sameSite) {
    const sameSite = typeof opt.sameSite === "string" ? opt.sameSite.toLowerCase() : opt.sameSite;
    switch (sameSite) {
      case true: {
        str += "; SameSite=Strict";
        break;
      }
      case "lax": {
        str += "; SameSite=Lax";
        break;
      }
      case "strict": {
        str += "; SameSite=Strict";
        break;
      }
      case "none": {
        str += "; SameSite=None";
        break;
      }
      default: {
        throw new TypeError("option sameSite is invalid");
      }
    }
  }
  if (opt.partitioned) {
    str += "; Partitioned";
  }
  return str;
}
function isDate(val) {
  return Object.prototype.toString.call(val) === "[object Date]" || val instanceof Date;
}

function parseSetCookie(setCookieValue, options) {
  const parts = (setCookieValue || "").split(";").filter((str) => typeof str === "string" && !!str.trim());
  const nameValuePairStr = parts.shift() || "";
  const parsed = _parseNameValuePair(nameValuePairStr);
  const name = parsed.name;
  let value = parsed.value;
  try {
    value = options?.decode === false ? value : (options?.decode || decodeURIComponent)(value);
  } catch {
  }
  const cookie = {
    name,
    value
  };
  for (const part of parts) {
    const sides = part.split("=");
    const partKey = (sides.shift() || "").trimStart().toLowerCase();
    const partValue = sides.join("=");
    switch (partKey) {
      case "expires": {
        cookie.expires = new Date(partValue);
        break;
      }
      case "max-age": {
        cookie.maxAge = Number.parseInt(partValue, 10);
        break;
      }
      case "secure": {
        cookie.secure = true;
        break;
      }
      case "httponly": {
        cookie.httpOnly = true;
        break;
      }
      case "samesite": {
        cookie.sameSite = partValue;
        break;
      }
      default: {
        cookie[partKey] = partValue;
      }
    }
  }
  return cookie;
}
function _parseNameValuePair(nameValuePairStr) {
  let name = "";
  let value = "";
  const nameValueArr = nameValuePairStr.split("=");
  if (nameValueArr.length > 1) {
    name = nameValueArr.shift();
    value = nameValueArr.join("=");
  } else {
    value = nameValuePairStr;
  }
  return { name, value };
}

const NODE_TYPES = {
  NORMAL: 0,
  WILDCARD: 1,
  PLACEHOLDER: 2
};

function createRouter$1(options = {}) {
  const ctx = {
    options,
    rootNode: createRadixNode(),
    staticRoutesMap: {}
  };
  const normalizeTrailingSlash = (p) => options.strictTrailingSlash ? p : p.replace(/\/$/, "") || "/";
  if (options.routes) {
    for (const path in options.routes) {
      insert(ctx, normalizeTrailingSlash(path), options.routes[path]);
    }
  }
  return {
    ctx,
    lookup: (path) => lookup(ctx, normalizeTrailingSlash(path)),
    insert: (path, data) => insert(ctx, normalizeTrailingSlash(path), data),
    remove: (path) => remove(ctx, normalizeTrailingSlash(path))
  };
}
function lookup(ctx, path) {
  const staticPathNode = ctx.staticRoutesMap[path];
  if (staticPathNode) {
    return staticPathNode.data;
  }
  const sections = path.split("/");
  const params = {};
  let paramsFound = false;
  let wildcardNode = null;
  let node = ctx.rootNode;
  let wildCardParam = null;
  for (let i = 0; i < sections.length; i++) {
    const section = sections[i];
    if (node.wildcardChildNode !== null) {
      wildcardNode = node.wildcardChildNode;
      wildCardParam = sections.slice(i).join("/");
    }
    const nextNode = node.children.get(section);
    if (nextNode === void 0) {
      if (node && node.placeholderChildren.length > 1) {
        const remaining = sections.length - i;
        node = node.placeholderChildren.find((c) => c.maxDepth === remaining) || null;
      } else {
        node = node.placeholderChildren[0] || null;
      }
      if (!node) {
        break;
      }
      if (node.paramName) {
        params[node.paramName] = section;
      }
      paramsFound = true;
    } else {
      node = nextNode;
    }
  }
  if ((node === null || node.data === null) && wildcardNode !== null) {
    node = wildcardNode;
    params[node.paramName || "_"] = wildCardParam;
    paramsFound = true;
  }
  if (!node) {
    return null;
  }
  if (paramsFound) {
    return {
      ...node.data,
      params: paramsFound ? params : void 0
    };
  }
  return node.data;
}
function insert(ctx, path, data) {
  let isStaticRoute = true;
  const sections = path.split("/");
  let node = ctx.rootNode;
  let _unnamedPlaceholderCtr = 0;
  const matchedNodes = [node];
  for (const section of sections) {
    let childNode;
    if (childNode = node.children.get(section)) {
      node = childNode;
    } else {
      const type = getNodeType(section);
      childNode = createRadixNode({ type, parent: node });
      node.children.set(section, childNode);
      if (type === NODE_TYPES.PLACEHOLDER) {
        childNode.paramName = section === "*" ? `_${_unnamedPlaceholderCtr++}` : section.slice(1);
        node.placeholderChildren.push(childNode);
        isStaticRoute = false;
      } else if (type === NODE_TYPES.WILDCARD) {
        node.wildcardChildNode = childNode;
        childNode.paramName = section.slice(
          3
          /* "**:" */
        ) || "_";
        isStaticRoute = false;
      }
      matchedNodes.push(childNode);
      node = childNode;
    }
  }
  for (const [depth, node2] of matchedNodes.entries()) {
    node2.maxDepth = Math.max(matchedNodes.length - depth, node2.maxDepth || 0);
  }
  node.data = data;
  if (isStaticRoute === true) {
    ctx.staticRoutesMap[path] = node;
  }
  return node;
}
function remove(ctx, path) {
  let success = false;
  const sections = path.split("/");
  let node = ctx.rootNode;
  for (const section of sections) {
    node = node.children.get(section);
    if (!node) {
      return success;
    }
  }
  if (node.data) {
    const lastSection = sections.at(-1) || "";
    node.data = null;
    if (Object.keys(node.children).length === 0 && node.parent) {
      node.parent.children.delete(lastSection);
      node.parent.wildcardChildNode = null;
      node.parent.placeholderChildren = [];
    }
    success = true;
  }
  return success;
}
function createRadixNode(options = {}) {
  return {
    type: options.type || NODE_TYPES.NORMAL,
    maxDepth: 0,
    parent: options.parent || null,
    children: /* @__PURE__ */ new Map(),
    data: options.data || null,
    paramName: options.paramName || null,
    wildcardChildNode: null,
    placeholderChildren: []
  };
}
function getNodeType(str) {
  if (str.startsWith("**")) {
    return NODE_TYPES.WILDCARD;
  }
  if (str[0] === ":" || str === "*") {
    return NODE_TYPES.PLACEHOLDER;
  }
  return NODE_TYPES.NORMAL;
}

function toRouteMatcher(router) {
  const table = _routerNodeToTable("", router.ctx.rootNode);
  return _createMatcher(table, router.ctx.options.strictTrailingSlash);
}
function _createMatcher(table, strictTrailingSlash) {
  return {
    ctx: { table },
    matchAll: (path) => _matchRoutes(path, table, strictTrailingSlash)
  };
}
function _createRouteTable() {
  return {
    static: /* @__PURE__ */ new Map(),
    wildcard: /* @__PURE__ */ new Map(),
    dynamic: /* @__PURE__ */ new Map()
  };
}
function _matchRoutes(path, table, strictTrailingSlash) {
  if (strictTrailingSlash !== true && path.endsWith("/")) {
    path = path.slice(0, -1) || "/";
  }
  const matches = [];
  for (const [key, value] of _sortRoutesMap(table.wildcard)) {
    if (path === key || path.startsWith(key + "/")) {
      matches.push(value);
    }
  }
  for (const [key, value] of _sortRoutesMap(table.dynamic)) {
    if (path.startsWith(key + "/")) {
      const subPath = "/" + path.slice(key.length).split("/").splice(2).join("/");
      matches.push(..._matchRoutes(subPath, value));
    }
  }
  const staticMatch = table.static.get(path);
  if (staticMatch) {
    matches.push(staticMatch);
  }
  return matches.filter(Boolean);
}
function _sortRoutesMap(m) {
  return [...m.entries()].sort((a, b) => a[0].length - b[0].length);
}
function _routerNodeToTable(initialPath, initialNode) {
  const table = _createRouteTable();
  function _addNode(path, node) {
    if (path) {
      if (node.type === NODE_TYPES.NORMAL && !(path.includes("*") || path.includes(":"))) {
        if (node.data) {
          table.static.set(path, node.data);
        }
      } else if (node.type === NODE_TYPES.WILDCARD) {
        table.wildcard.set(path.replace("/**", ""), node.data);
      } else if (node.type === NODE_TYPES.PLACEHOLDER) {
        const subTable = _routerNodeToTable("", node);
        if (node.data) {
          subTable.static.set("/", node.data);
        }
        table.dynamic.set(path.replace(/\/\*|\/:\w+/, ""), subTable);
        return;
      }
    }
    for (const [childPath, child] of node.children.entries()) {
      _addNode(`${path}/${childPath}`.replace("//", "/"), child);
    }
  }
  _addNode(initialPath, initialNode);
  return table;
}

function isPlainObject(value) {
  if (value === null || typeof value !== "object") {
    return false;
  }
  const prototype = Object.getPrototypeOf(value);
  if (prototype !== null && prototype !== Object.prototype && Object.getPrototypeOf(prototype) !== null) {
    return false;
  }
  if (Symbol.iterator in value) {
    return false;
  }
  if (Symbol.toStringTag in value) {
    return Object.prototype.toString.call(value) === "[object Module]";
  }
  return true;
}

function _defu(baseObject, defaults, namespace = ".", merger) {
  if (!isPlainObject(defaults)) {
    return _defu(baseObject, {}, namespace, merger);
  }
  const object = Object.assign({}, defaults);
  for (const key in baseObject) {
    if (key === "__proto__" || key === "constructor") {
      continue;
    }
    const value = baseObject[key];
    if (value === null || value === void 0) {
      continue;
    }
    if (merger && merger(object, key, value, namespace)) {
      continue;
    }
    if (Array.isArray(value) && Array.isArray(object[key])) {
      object[key] = [...value, ...object[key]];
    } else if (isPlainObject(value) && isPlainObject(object[key])) {
      object[key] = _defu(
        value,
        object[key],
        (namespace ? `${namespace}.` : "") + key.toString(),
        merger
      );
    } else {
      object[key] = value;
    }
  }
  return object;
}
function createDefu(merger) {
  return (...arguments_) => (
    // eslint-disable-next-line unicorn/no-array-reduce
    arguments_.reduce((p, c) => _defu(p, c, "", merger), {})
  );
}
const defu = createDefu();
const defuFn = createDefu((object, key, currentValue) => {
  if (object[key] !== void 0 && typeof currentValue === "function") {
    object[key] = currentValue(object[key]);
    return true;
  }
});

function o(n){throw new Error(`${n} is not implemented yet!`)}let i$1 = class i extends EventEmitter{__unenv__={};readableEncoding=null;readableEnded=true;readableFlowing=false;readableHighWaterMark=0;readableLength=0;readableObjectMode=false;readableAborted=false;readableDidRead=false;closed=false;errored=null;readable=false;destroyed=false;static from(e,t){return new i(t)}constructor(e){super();}_read(e){}read(e){}setEncoding(e){return this}pause(){return this}resume(){return this}isPaused(){return  true}unpipe(e){return this}unshift(e,t){}wrap(e){return this}push(e,t){return  false}_destroy(e,t){this.removeAllListeners();}destroy(e){return this.destroyed=true,this._destroy(e),this}pipe(e,t){return {}}compose(e,t){throw new Error("Method not implemented.")}[Symbol.asyncDispose](){return this.destroy(),Promise.resolve()}async*[Symbol.asyncIterator](){throw o("Readable.asyncIterator")}iterator(e){throw o("Readable.iterator")}map(e,t){throw o("Readable.map")}filter(e,t){throw o("Readable.filter")}forEach(e,t){throw o("Readable.forEach")}reduce(e,t,r){throw o("Readable.reduce")}find(e,t){throw o("Readable.find")}findIndex(e,t){throw o("Readable.findIndex")}some(e,t){throw o("Readable.some")}toArray(e){throw o("Readable.toArray")}every(e,t){throw o("Readable.every")}flatMap(e,t){throw o("Readable.flatMap")}drop(e,t){throw o("Readable.drop")}take(e,t){throw o("Readable.take")}asIndexedPairs(e){throw o("Readable.asIndexedPairs")}};let l$1 = class l extends EventEmitter{__unenv__={};writable=true;writableEnded=false;writableFinished=false;writableHighWaterMark=0;writableLength=0;writableObjectMode=false;writableCorked=0;closed=false;errored=null;writableNeedDrain=false;destroyed=false;_data;_encoding="utf8";constructor(e){super();}pipe(e,t){return {}}_write(e,t,r){if(this.writableEnded){r&&r();return}if(this._data===void 0)this._data=e;else {const s=typeof this._data=="string"?Buffer$1.from(this._data,this._encoding||t||"utf8"):this._data,a=typeof e=="string"?Buffer$1.from(e,t||this._encoding||"utf8"):e;this._data=Buffer$1.concat([s,a]);}this._encoding=t,r&&r();}_writev(e,t){}_destroy(e,t){}_final(e){}write(e,t,r){const s=typeof t=="string"?this._encoding:"utf8",a=typeof t=="function"?t:typeof r=="function"?r:void 0;return this._write(e,s,a),true}setDefaultEncoding(e){return this}end(e,t,r){const s=typeof e=="function"?e:typeof t=="function"?t:typeof r=="function"?r:void 0;if(this.writableEnded)return s&&s(),this;const a=e===s?void 0:e;if(a){const u=t===s?void 0:t;this.write(a,u,s);}return this.writableEnded=true,this.writableFinished=true,this.emit("close"),this.emit("finish"),this}cork(){}uncork(){}destroy(e){return this.destroyed=true,delete this._data,this.removeAllListeners(),this}compose(e,t){throw new Error("Method not implemented.")}};const c$1=class c{allowHalfOpen=true;_destroy;constructor(e=new i$1,t=new l$1){Object.assign(this,e),Object.assign(this,t),this._destroy=g(e._destroy,t._destroy);}};function _(){return Object.assign(c$1.prototype,i$1.prototype),Object.assign(c$1.prototype,l$1.prototype),c$1}function g(...n){return function(...e){for(const t of n)t(...e);}}const m=_();class A extends m{__unenv__={};bufferSize=0;bytesRead=0;bytesWritten=0;connecting=false;destroyed=false;pending=false;localAddress="";localPort=0;remoteAddress="";remoteFamily="";remotePort=0;autoSelectFamilyAttemptedAddresses=[];readyState="readOnly";constructor(e){super();}write(e,t,r){return  false}connect(e,t,r){return this}end(e,t,r){return this}setEncoding(e){return this}pause(){return this}resume(){return this}setTimeout(e,t){return this}setNoDelay(e){return this}setKeepAlive(e,t){return this}address(){return {}}unref(){return this}ref(){return this}destroySoon(){this.destroy();}resetAndDestroy(){const e=new Error("ERR_SOCKET_CLOSED");return e.code="ERR_SOCKET_CLOSED",this.destroy(e),this}}class y extends i$1{aborted=false;httpVersion="1.1";httpVersionMajor=1;httpVersionMinor=1;complete=true;connection;socket;headers={};trailers={};method="GET";url="/";statusCode=200;statusMessage="";closed=false;errored=null;readable=false;constructor(e){super(),this.socket=this.connection=e||new A;}get rawHeaders(){const e=this.headers,t=[];for(const r in e)if(Array.isArray(e[r]))for(const s of e[r])t.push(r,s);else t.push(r,e[r]);return t}get rawTrailers(){return []}setTimeout(e,t){return this}get headersDistinct(){return p(this.headers)}get trailersDistinct(){return p(this.trailers)}}function p(n){const e={};for(const[t,r]of Object.entries(n))t&&(e[t]=(Array.isArray(r)?r:[r]).filter(Boolean));return e}class w extends l$1{statusCode=200;statusMessage="";upgrading=false;chunkedEncoding=false;shouldKeepAlive=false;useChunkedEncodingByDefault=false;sendDate=false;finished=false;headersSent=false;strictContentLength=false;connection=null;socket=null;req;_headers={};constructor(e){super(),this.req=e;}assignSocket(e){e._httpMessage=this,this.socket=e,this.connection=e,this.emit("socket",e),this._flush();}_flush(){this.flushHeaders();}detachSocket(e){}writeContinue(e){}writeHead(e,t,r){e&&(this.statusCode=e),typeof t=="string"&&(this.statusMessage=t,t=void 0);const s=r||t;if(s&&!Array.isArray(s))for(const a in s)this.setHeader(a,s[a]);return this.headersSent=true,this}writeProcessing(){}setTimeout(e,t){return this}appendHeader(e,t){e=e.toLowerCase();const r=this._headers[e],s=[...Array.isArray(r)?r:[r],...Array.isArray(t)?t:[t]].filter(Boolean);return this._headers[e]=s.length>1?s:s[0],this}setHeader(e,t){return this._headers[e.toLowerCase()]=t,this}setHeaders(e){for(const[t,r]of Object.entries(e))this.setHeader(t,r);return this}getHeader(e){return this._headers[e.toLowerCase()]}getHeaders(){return this._headers}getHeaderNames(){return Object.keys(this._headers)}hasHeader(e){return e.toLowerCase()in this._headers}removeHeader(e){delete this._headers[e.toLowerCase()];}addTrailers(e){}flushHeaders(){}writeEarlyHints(e,t){typeof t=="function"&&t();}}const E=(()=>{const n=function(){};return n.prototype=Object.create(null),n})();function R(n={}){const e=new E,t=Array.isArray(n)||H(n)?n:Object.entries(n);for(const[r,s]of t)if(s){if(e[r]===void 0){e[r]=s;continue}e[r]=[...Array.isArray(e[r])?e[r]:[e[r]],...Array.isArray(s)?s:[s]];}return e}function H(n){return typeof n?.entries=="function"}function S(n={}){if(n instanceof Headers)return n;const e=new Headers;for(const[t,r]of Object.entries(n))if(r!==void 0){if(Array.isArray(r)){for(const s of r)e.append(t,String(s));continue}e.set(t,String(r));}return e}const C=new Set([101,204,205,304]);async function b(n,e){const t=new y,r=new w(t);t.url=e.url?.toString()||"/";let s;if(!t.url.startsWith("/")){const d=new URL(t.url);s=d.host,t.url=d.pathname+d.search+d.hash;}t.method=e.method||"GET",t.headers=R(e.headers||{}),t.headers.host||(t.headers.host=e.host||s||"localhost"),t.connection.encrypted=t.connection.encrypted||e.protocol==="https",t.body=e.body||null,t.__unenv__=e.context,await n(t,r);let a=r._data;(C.has(r.statusCode)||t.method.toUpperCase()==="HEAD")&&(a=null,delete r._headers["content-length"]);const u={status:r.statusCode,statusText:r.statusMessage,headers:r._headers,body:a};return t.destroy(),r.destroy(),u}async function O(n,e,t={}){try{const r=await b(n,{url:e,...t});return new Response(r.body,{status:r.status,statusText:r.statusText,headers:S(r.headers)})}catch(r){return new Response(r.toString(),{status:Number.parseInt(r.statusCode||r.code)||500,statusText:r.statusText})}}

function useBase(base, handler) {
  base = withoutTrailingSlash(base);
  if (!base || base === "/") {
    return handler;
  }
  return eventHandler(async (event) => {
    event.node.req.originalUrl = event.node.req.originalUrl || event.node.req.url || "/";
    const _path = event._path || event.node.req.url || "/";
    event._path = withoutBase(event.path || "/", base);
    event.node.req.url = event._path;
    try {
      return await handler(event);
    } finally {
      event._path = event.node.req.url = _path;
    }
  });
}

function hasProp(obj, prop) {
  try {
    return prop in obj;
  } catch {
    return false;
  }
}

class H3Error extends Error {
  static __h3_error__ = true;
  statusCode = 500;
  fatal = false;
  unhandled = false;
  statusMessage;
  data;
  cause;
  constructor(message, opts = {}) {
    super(message, opts);
    if (opts.cause && !this.cause) {
      this.cause = opts.cause;
    }
  }
  toJSON() {
    const obj = {
      message: this.message,
      statusCode: sanitizeStatusCode(this.statusCode, 500)
    };
    if (this.statusMessage) {
      obj.statusMessage = sanitizeStatusMessage(this.statusMessage);
    }
    if (this.data !== undefined) {
      obj.data = this.data;
    }
    return obj;
  }
}
function createError$1(input) {
  if (typeof input === "string") {
    return new H3Error(input);
  }
  if (isError(input)) {
    return input;
  }
  const err = new H3Error(input.message ?? input.statusMessage ?? "", {
    cause: input.cause || input
  });
  if (hasProp(input, "stack")) {
    try {
      Object.defineProperty(err, "stack", {
        get() {
          return input.stack;
        }
      });
    } catch {
      try {
        err.stack = input.stack;
      } catch {
      }
    }
  }
  if (input.data) {
    err.data = input.data;
  }
  if (input.statusCode) {
    err.statusCode = sanitizeStatusCode(input.statusCode, err.statusCode);
  } else if (input.status) {
    err.statusCode = sanitizeStatusCode(input.status, err.statusCode);
  }
  if (input.statusMessage) {
    err.statusMessage = input.statusMessage;
  } else if (input.statusText) {
    err.statusMessage = input.statusText;
  }
  if (err.statusMessage) {
    const originalMessage = err.statusMessage;
    const sanitizedMessage = sanitizeStatusMessage(err.statusMessage);
    if (sanitizedMessage !== originalMessage) {
      console.warn(
        "[h3] Please prefer using `message` for longer error messages instead of `statusMessage`. In the future, `statusMessage` will be sanitized by default."
      );
    }
  }
  if (input.fatal !== undefined) {
    err.fatal = input.fatal;
  }
  if (input.unhandled !== undefined) {
    err.unhandled = input.unhandled;
  }
  return err;
}
function sendError(event, error, debug) {
  if (event.handled) {
    return;
  }
  const h3Error = isError(error) ? error : createError$1(error);
  const responseBody = {
    statusCode: h3Error.statusCode,
    statusMessage: h3Error.statusMessage,
    stack: [],
    data: h3Error.data
  };
  if (debug) {
    responseBody.stack = (h3Error.stack || "").split("\n").map((l) => l.trim());
  }
  if (event.handled) {
    return;
  }
  const _code = Number.parseInt(h3Error.statusCode);
  setResponseStatus(event, _code, h3Error.statusMessage);
  event.node.res.setHeader("content-type", MIMES.json);
  event.node.res.end(JSON.stringify(responseBody, undefined, 2));
}
function isError(input) {
  return input?.constructor?.__h3_error__ === true;
}

function getQuery(event) {
  return getQuery$1(event.path || "");
}
function getRouterParams(event, opts = {}) {
  let params = event.context.params || {};
  if (opts.decode) {
    params = { ...params };
    for (const key in params) {
      params[key] = decode$2(params[key]);
    }
  }
  return params;
}
function getRouterParam(event, name, opts = {}) {
  const params = getRouterParams(event, opts);
  return params[name];
}
function isMethod(event, expected, allowHead) {
  if (typeof expected === "string") {
    if (event.method === expected) {
      return true;
    }
  } else if (expected.includes(event.method)) {
    return true;
  }
  return false;
}
function assertMethod(event, expected, allowHead) {
  if (!isMethod(event, expected)) {
    throw createError$1({
      statusCode: 405,
      statusMessage: "HTTP method is not allowed."
    });
  }
}
function getRequestHeaders(event) {
  const _headers = {};
  for (const key in event.node.req.headers) {
    const val = event.node.req.headers[key];
    _headers[key] = Array.isArray(val) ? val.filter(Boolean).join(", ") : val;
  }
  return _headers;
}
function getRequestHeader(event, name) {
  const headers = getRequestHeaders(event);
  const value = headers[name.toLowerCase()];
  return value;
}
function getRequestHost(event, opts = {}) {
  if (opts.xForwardedHost) {
    const xForwardedHost = event.node.req.headers["x-forwarded-host"];
    if (xForwardedHost) {
      return xForwardedHost;
    }
  }
  return event.node.req.headers.host || "localhost";
}
function getRequestProtocol(event, opts = {}) {
  if (opts.xForwardedProto !== false && event.node.req.headers["x-forwarded-proto"] === "https") {
    return "https";
  }
  return event.node.req.connection?.encrypted ? "https" : "http";
}
function getRequestURL(event, opts = {}) {
  const host = getRequestHost(event, opts);
  const protocol = getRequestProtocol(event, opts);
  const path = (event.node.req.originalUrl || event.path).replace(
    /^[/\\]+/g,
    "/"
  );
  return new URL(path, `${protocol}://${host}`);
}

const RawBodySymbol = Symbol.for("h3RawBody");
const ParsedBodySymbol = Symbol.for("h3ParsedBody");
const PayloadMethods$1 = ["PATCH", "POST", "PUT", "DELETE"];
function readRawBody(event, encoding = "utf8") {
  assertMethod(event, PayloadMethods$1);
  const _rawBody = event._requestBody || event.web?.request?.body || event.node.req[RawBodySymbol] || event.node.req.rawBody || event.node.req.body;
  if (_rawBody) {
    const promise2 = Promise.resolve(_rawBody).then((_resolved) => {
      if (Buffer.isBuffer(_resolved)) {
        return _resolved;
      }
      if (typeof _resolved.pipeTo === "function") {
        return new Promise((resolve, reject) => {
          const chunks = [];
          _resolved.pipeTo(
            new WritableStream({
              write(chunk) {
                chunks.push(chunk);
              },
              close() {
                resolve(Buffer.concat(chunks));
              },
              abort(reason) {
                reject(reason);
              }
            })
          ).catch(reject);
        });
      } else if (typeof _resolved.pipe === "function") {
        return new Promise((resolve, reject) => {
          const chunks = [];
          _resolved.on("data", (chunk) => {
            chunks.push(chunk);
          }).on("end", () => {
            resolve(Buffer.concat(chunks));
          }).on("error", reject);
        });
      }
      if (_resolved.constructor === Object) {
        return Buffer.from(JSON.stringify(_resolved));
      }
      if (_resolved instanceof URLSearchParams) {
        return Buffer.from(_resolved.toString());
      }
      return Buffer.from(_resolved);
    });
    return encoding ? promise2.then((buff) => buff.toString(encoding)) : promise2;
  }
  if (!Number.parseInt(event.node.req.headers["content-length"] || "") && !String(event.node.req.headers["transfer-encoding"] ?? "").split(",").map((e) => e.trim()).filter(Boolean).includes("chunked")) {
    return Promise.resolve(undefined);
  }
  const promise = event.node.req[RawBodySymbol] = new Promise(
    (resolve, reject) => {
      const bodyData = [];
      event.node.req.on("error", (err) => {
        reject(err);
      }).on("data", (chunk) => {
        bodyData.push(chunk);
      }).on("end", () => {
        resolve(Buffer.concat(bodyData));
      });
    }
  );
  const result = encoding ? promise.then((buff) => buff.toString(encoding)) : promise;
  return result;
}
async function readBody(event, options = {}) {
  const request = event.node.req;
  if (hasProp(request, ParsedBodySymbol)) {
    return request[ParsedBodySymbol];
  }
  const contentType = request.headers["content-type"] || "";
  const body = await readRawBody(event);
  let parsed;
  if (contentType === "application/json") {
    parsed = _parseJSON(body, options.strict ?? true);
  } else if (contentType.startsWith("application/x-www-form-urlencoded")) {
    parsed = _parseURLEncodedBody(body);
  } else if (contentType.startsWith("text/")) {
    parsed = body;
  } else {
    parsed = _parseJSON(body, options.strict ?? false);
  }
  request[ParsedBodySymbol] = parsed;
  return parsed;
}
function getRequestWebStream(event) {
  if (!PayloadMethods$1.includes(event.method)) {
    return;
  }
  const bodyStream = event.web?.request?.body || event._requestBody;
  if (bodyStream) {
    return bodyStream;
  }
  const _hasRawBody = RawBodySymbol in event.node.req || "rawBody" in event.node.req || "body" in event.node.req || "__unenv__" in event.node.req;
  if (_hasRawBody) {
    return new ReadableStream({
      async start(controller) {
        const _rawBody = await readRawBody(event, false);
        if (_rawBody) {
          controller.enqueue(_rawBody);
        }
        controller.close();
      }
    });
  }
  return new ReadableStream({
    start: (controller) => {
      event.node.req.on("data", (chunk) => {
        controller.enqueue(chunk);
      });
      event.node.req.on("end", () => {
        controller.close();
      });
      event.node.req.on("error", (err) => {
        controller.error(err);
      });
    }
  });
}
function _parseJSON(body = "", strict) {
  if (!body) {
    return undefined;
  }
  try {
    return destr(body, { strict });
  } catch {
    throw createError$1({
      statusCode: 400,
      statusMessage: "Bad Request",
      message: "Invalid JSON body"
    });
  }
}
function _parseURLEncodedBody(body) {
  const form = new URLSearchParams(body);
  const parsedForm = /* @__PURE__ */ Object.create(null);
  for (const [key, value] of form.entries()) {
    if (hasProp(parsedForm, key)) {
      if (!Array.isArray(parsedForm[key])) {
        parsedForm[key] = [parsedForm[key]];
      }
      parsedForm[key].push(value);
    } else {
      parsedForm[key] = value;
    }
  }
  return parsedForm;
}

function handleCacheHeaders(event, opts) {
  const cacheControls = ["public", ...opts.cacheControls || []];
  let cacheMatched = false;
  if (opts.maxAge !== undefined) {
    cacheControls.push(`max-age=${+opts.maxAge}`, `s-maxage=${+opts.maxAge}`);
  }
  if (opts.modifiedTime) {
    const modifiedTime = new Date(opts.modifiedTime);
    const ifModifiedSince = event.node.req.headers["if-modified-since"];
    event.node.res.setHeader("last-modified", modifiedTime.toUTCString());
    if (ifModifiedSince && new Date(ifModifiedSince) >= opts.modifiedTime) {
      cacheMatched = true;
    }
  }
  if (opts.etag) {
    event.node.res.setHeader("etag", opts.etag);
    const ifNonMatch = event.node.req.headers["if-none-match"];
    if (ifNonMatch === opts.etag) {
      cacheMatched = true;
    }
  }
  event.node.res.setHeader("cache-control", cacheControls.join(", "));
  if (cacheMatched) {
    event.node.res.statusCode = 304;
    if (!event.handled) {
      event.node.res.end();
    }
    return true;
  }
  return false;
}

const MIMES = {
  html: "text/html",
  json: "application/json"
};

const DISALLOWED_STATUS_CHARS = /[^\u0009\u0020-\u007E]/g;
function sanitizeStatusMessage(statusMessage = "") {
  return statusMessage.replace(DISALLOWED_STATUS_CHARS, "");
}
function sanitizeStatusCode(statusCode, defaultStatusCode = 200) {
  if (!statusCode) {
    return defaultStatusCode;
  }
  if (typeof statusCode === "string") {
    statusCode = Number.parseInt(statusCode, 10);
  }
  if (statusCode < 100 || statusCode > 999) {
    return defaultStatusCode;
  }
  return statusCode;
}

function getDistinctCookieKey(name, opts) {
  return [
    name,
    opts.domain || "",
    opts.path || "/",
    Boolean(opts.secure),
    Boolean(opts.httpOnly),
    Boolean(opts.sameSite)
  ].join(";");
}

function parseCookies(event) {
  return parse$1(event.node.req.headers.cookie || "");
}
function getCookie(event, name) {
  return parseCookies(event)[name];
}
function setCookie(event, name, value, serializeOptions = {}) {
  if (!serializeOptions.path) {
    serializeOptions = { path: "/", ...serializeOptions };
  }
  const newCookie = serialize$2(name, value, serializeOptions);
  const currentCookies = splitCookiesString(
    event.node.res.getHeader("set-cookie")
  );
  if (currentCookies.length === 0) {
    event.node.res.setHeader("set-cookie", newCookie);
    return;
  }
  const newCookieKey = getDistinctCookieKey(name, serializeOptions);
  event.node.res.removeHeader("set-cookie");
  for (const cookie of currentCookies) {
    const parsed = parseSetCookie(cookie);
    const key = getDistinctCookieKey(parsed.name, parsed);
    if (key === newCookieKey) {
      continue;
    }
    event.node.res.appendHeader("set-cookie", cookie);
  }
  event.node.res.appendHeader("set-cookie", newCookie);
}
function deleteCookie(event, name, serializeOptions) {
  setCookie(event, name, "", {
    ...serializeOptions,
    maxAge: 0
  });
}
function splitCookiesString(cookiesString) {
  if (Array.isArray(cookiesString)) {
    return cookiesString.flatMap((c) => splitCookiesString(c));
  }
  if (typeof cookiesString !== "string") {
    return [];
  }
  const cookiesStrings = [];
  let pos = 0;
  let start;
  let ch;
  let lastComma;
  let nextStart;
  let cookiesSeparatorFound;
  const skipWhitespace = () => {
    while (pos < cookiesString.length && /\s/.test(cookiesString.charAt(pos))) {
      pos += 1;
    }
    return pos < cookiesString.length;
  };
  const notSpecialChar = () => {
    ch = cookiesString.charAt(pos);
    return ch !== "=" && ch !== ";" && ch !== ",";
  };
  while (pos < cookiesString.length) {
    start = pos;
    cookiesSeparatorFound = false;
    while (skipWhitespace()) {
      ch = cookiesString.charAt(pos);
      if (ch === ",") {
        lastComma = pos;
        pos += 1;
        skipWhitespace();
        nextStart = pos;
        while (pos < cookiesString.length && notSpecialChar()) {
          pos += 1;
        }
        if (pos < cookiesString.length && cookiesString.charAt(pos) === "=") {
          cookiesSeparatorFound = true;
          pos = nextStart;
          cookiesStrings.push(cookiesString.slice(start, lastComma));
          start = pos;
        } else {
          pos = lastComma + 1;
        }
      } else {
        pos += 1;
      }
    }
    if (!cookiesSeparatorFound || pos >= cookiesString.length) {
      cookiesStrings.push(cookiesString.slice(start));
    }
  }
  return cookiesStrings;
}

const defer = typeof setImmediate === "undefined" ? (fn) => fn() : setImmediate;
function send(event, data, type) {
  if (type) {
    defaultContentType(event, type);
  }
  return new Promise((resolve) => {
    defer(() => {
      if (!event.handled) {
        event.node.res.end(data);
      }
      resolve();
    });
  });
}
function sendNoContent(event, code) {
  if (event.handled) {
    return;
  }
  if (!code && event.node.res.statusCode !== 200) {
    code = event.node.res.statusCode;
  }
  const _code = sanitizeStatusCode(code, 204);
  if (_code === 204) {
    event.node.res.removeHeader("content-length");
  }
  event.node.res.writeHead(_code);
  event.node.res.end();
}
function setResponseStatus(event, code, text) {
  if (code) {
    event.node.res.statusCode = sanitizeStatusCode(
      code,
      event.node.res.statusCode
    );
  }
  if (text) {
    event.node.res.statusMessage = sanitizeStatusMessage(text);
  }
}
function getResponseStatus(event) {
  return event.node.res.statusCode;
}
function getResponseStatusText(event) {
  return event.node.res.statusMessage;
}
function defaultContentType(event, type) {
  if (type && event.node.res.statusCode !== 304 && !event.node.res.getHeader("content-type")) {
    event.node.res.setHeader("content-type", type);
  }
}
function sendRedirect(event, location, code = 302) {
  event.node.res.statusCode = sanitizeStatusCode(
    code,
    event.node.res.statusCode
  );
  event.node.res.setHeader("location", location);
  const encodedLoc = location.replace(/"/g, "%22");
  const html = `<!DOCTYPE html><html><head><meta http-equiv="refresh" content="0; url=${encodedLoc}"></head></html>`;
  return send(event, html, MIMES.html);
}
function getResponseHeader(event, name) {
  return event.node.res.getHeader(name);
}
function setResponseHeaders(event, headers) {
  for (const [name, value] of Object.entries(headers)) {
    event.node.res.setHeader(
      name,
      value
    );
  }
}
const setHeaders = setResponseHeaders;
function setResponseHeader(event, name, value) {
  event.node.res.setHeader(name, value);
}
function appendResponseHeader(event, name, value) {
  let current = event.node.res.getHeader(name);
  if (!current) {
    event.node.res.setHeader(name, value);
    return;
  }
  if (!Array.isArray(current)) {
    current = [current.toString()];
  }
  event.node.res.setHeader(name, [...current, value]);
}
function removeResponseHeader(event, name) {
  return event.node.res.removeHeader(name);
}
function isStream(data) {
  if (!data || typeof data !== "object") {
    return false;
  }
  if (typeof data.pipe === "function") {
    if (typeof data._read === "function") {
      return true;
    }
    if (typeof data.abort === "function") {
      return true;
    }
  }
  if (typeof data.pipeTo === "function") {
    return true;
  }
  return false;
}
function isWebResponse(data) {
  return typeof Response !== "undefined" && data instanceof Response;
}
function sendStream(event, stream) {
  if (!stream || typeof stream !== "object") {
    throw new Error("[h3] Invalid stream provided.");
  }
  event.node.res._data = stream;
  if (!event.node.res.socket) {
    event._handled = true;
    return Promise.resolve();
  }
  if (hasProp(stream, "pipeTo") && typeof stream.pipeTo === "function") {
    return stream.pipeTo(
      new WritableStream({
        write(chunk) {
          event.node.res.write(chunk);
        }
      })
    ).then(() => {
      event.node.res.end();
    });
  }
  if (hasProp(stream, "pipe") && typeof stream.pipe === "function") {
    return new Promise((resolve, reject) => {
      stream.pipe(event.node.res);
      if (stream.on) {
        stream.on("end", () => {
          event.node.res.end();
          resolve();
        });
        stream.on("error", (error) => {
          reject(error);
        });
      }
      event.node.res.on("close", () => {
        if (stream.abort) {
          stream.abort();
        }
      });
    });
  }
  throw new Error("[h3] Invalid or incompatible stream provided.");
}
function sendWebResponse(event, response) {
  for (const [key, value] of response.headers) {
    if (key === "set-cookie") {
      event.node.res.appendHeader(key, splitCookiesString(value));
    } else {
      event.node.res.setHeader(key, value);
    }
  }
  if (response.status) {
    event.node.res.statusCode = sanitizeStatusCode(
      response.status,
      event.node.res.statusCode
    );
  }
  if (response.statusText) {
    event.node.res.statusMessage = sanitizeStatusMessage(response.statusText);
  }
  if (response.redirected) {
    event.node.res.setHeader("location", response.url);
  }
  if (!response.body) {
    event.node.res.end();
    return;
  }
  return sendStream(event, response.body);
}

const PayloadMethods = /* @__PURE__ */ new Set(["PATCH", "POST", "PUT", "DELETE"]);
const ignoredHeaders = /* @__PURE__ */ new Set([
  "transfer-encoding",
  "accept-encoding",
  "connection",
  "keep-alive",
  "upgrade",
  "expect",
  "host",
  "accept"
]);
async function proxyRequest(event, target, opts = {}) {
  let body;
  let duplex;
  if (PayloadMethods.has(event.method)) {
    if (opts.streamRequest) {
      body = getRequestWebStream(event);
      duplex = "half";
    } else {
      body = await readRawBody(event, false).catch(() => undefined);
    }
  }
  const method = opts.fetchOptions?.method || event.method;
  const fetchHeaders = mergeHeaders$1(
    getProxyRequestHeaders(event, { host: target.startsWith("/") }),
    opts.fetchOptions?.headers,
    opts.headers
  );
  return sendProxy(event, target, {
    ...opts,
    fetchOptions: {
      method,
      body,
      duplex,
      ...opts.fetchOptions,
      headers: fetchHeaders
    }
  });
}
async function sendProxy(event, target, opts = {}) {
  let response;
  try {
    response = await _getFetch(opts.fetch)(target, {
      headers: opts.headers,
      ignoreResponseError: true,
      // make $ofetch.raw transparent
      ...opts.fetchOptions
    });
  } catch (error) {
    throw createError$1({
      status: 502,
      statusMessage: "Bad Gateway",
      cause: error
    });
  }
  event.node.res.statusCode = sanitizeStatusCode(
    response.status,
    event.node.res.statusCode
  );
  event.node.res.statusMessage = sanitizeStatusMessage(response.statusText);
  const cookies = [];
  for (const [key, value] of response.headers.entries()) {
    if (key === "content-encoding") {
      continue;
    }
    if (key === "content-length") {
      continue;
    }
    if (key === "set-cookie") {
      cookies.push(...splitCookiesString(value));
      continue;
    }
    event.node.res.setHeader(key, value);
  }
  if (cookies.length > 0) {
    event.node.res.setHeader(
      "set-cookie",
      cookies.map((cookie) => {
        if (opts.cookieDomainRewrite) {
          cookie = rewriteCookieProperty(
            cookie,
            opts.cookieDomainRewrite,
            "domain"
          );
        }
        if (opts.cookiePathRewrite) {
          cookie = rewriteCookieProperty(
            cookie,
            opts.cookiePathRewrite,
            "path"
          );
        }
        return cookie;
      })
    );
  }
  if (opts.onResponse) {
    await opts.onResponse(event, response);
  }
  if (response._data !== undefined) {
    return response._data;
  }
  if (event.handled) {
    return;
  }
  if (opts.sendStream === false) {
    const data = new Uint8Array(await response.arrayBuffer());
    return event.node.res.end(data);
  }
  if (response.body) {
    for await (const chunk of response.body) {
      event.node.res.write(chunk);
    }
  }
  return event.node.res.end();
}
function getProxyRequestHeaders(event, opts) {
  const headers = /* @__PURE__ */ Object.create(null);
  const reqHeaders = getRequestHeaders(event);
  for (const name in reqHeaders) {
    if (!ignoredHeaders.has(name) || name === "host" && opts?.host) {
      headers[name] = reqHeaders[name];
    }
  }
  return headers;
}
function fetchWithEvent(event, req, init, options) {
  return _getFetch(options?.fetch)(req, {
    ...init,
    context: init?.context || event.context,
    headers: {
      ...getProxyRequestHeaders(event, {
        host: typeof req === "string" && req.startsWith("/")
      }),
      ...init?.headers
    }
  });
}
function _getFetch(_fetch) {
  if (_fetch) {
    return _fetch;
  }
  if (globalThis.fetch) {
    return globalThis.fetch;
  }
  throw new Error(
    "fetch is not available. Try importing `node-fetch-native/polyfill` for Node.js."
  );
}
function rewriteCookieProperty(header, map, property) {
  const _map = typeof map === "string" ? { "*": map } : map;
  return header.replace(
    new RegExp(`(;\\s*${property}=)([^;]+)`, "gi"),
    (match, prefix, previousValue) => {
      let newValue;
      if (previousValue in _map) {
        newValue = _map[previousValue];
      } else if ("*" in _map) {
        newValue = _map["*"];
      } else {
        return match;
      }
      return newValue ? prefix + newValue : "";
    }
  );
}
function mergeHeaders$1(defaults, ...inputs) {
  const _inputs = inputs.filter(Boolean);
  if (_inputs.length === 0) {
    return defaults;
  }
  const merged = new Headers(defaults);
  for (const input of _inputs) {
    for (const [key, value] of Object.entries(input)) {
      if (value !== undefined) {
        merged.set(key, value);
      }
    }
  }
  return merged;
}

class H3Event {
  "__is_event__" = true;
  // Context
  node;
  // Node
  web;
  // Web
  context = {};
  // Shared
  // Request
  _method;
  _path;
  _headers;
  _requestBody;
  // Response
  _handled = false;
  // Hooks
  _onBeforeResponseCalled;
  _onAfterResponseCalled;
  constructor(req, res) {
    this.node = { req, res };
  }
  // --- Request ---
  get method() {
    if (!this._method) {
      this._method = (this.node.req.method || "GET").toUpperCase();
    }
    return this._method;
  }
  get path() {
    return this._path || this.node.req.url || "/";
  }
  get headers() {
    if (!this._headers) {
      this._headers = _normalizeNodeHeaders(this.node.req.headers);
    }
    return this._headers;
  }
  // --- Respoonse ---
  get handled() {
    return this._handled || this.node.res.writableEnded || this.node.res.headersSent;
  }
  respondWith(response) {
    return Promise.resolve(response).then(
      (_response) => sendWebResponse(this, _response)
    );
  }
  // --- Utils ---
  toString() {
    return `[${this.method}] ${this.path}`;
  }
  toJSON() {
    return this.toString();
  }
  // --- Deprecated ---
  /** @deprecated Please use `event.node.req` instead. */
  get req() {
    return this.node.req;
  }
  /** @deprecated Please use `event.node.res` instead. */
  get res() {
    return this.node.res;
  }
}
function isEvent(input) {
  return hasProp(input, "__is_event__");
}
function createEvent(req, res) {
  return new H3Event(req, res);
}
function _normalizeNodeHeaders(nodeHeaders) {
  const headers = new Headers();
  for (const [name, value] of Object.entries(nodeHeaders)) {
    if (Array.isArray(value)) {
      for (const item of value) {
        headers.append(name, item);
      }
    } else if (value) {
      headers.set(name, value);
    }
  }
  return headers;
}

function defineEventHandler(handler) {
  if (typeof handler === "function") {
    handler.__is_handler__ = true;
    return handler;
  }
  const _hooks = {
    onRequest: _normalizeArray(handler.onRequest),
    onBeforeResponse: _normalizeArray(handler.onBeforeResponse)
  };
  const _handler = (event) => {
    return _callHandler(event, handler.handler, _hooks);
  };
  _handler.__is_handler__ = true;
  _handler.__resolve__ = handler.handler.__resolve__;
  _handler.__websocket__ = handler.websocket;
  return _handler;
}
function _normalizeArray(input) {
  return input ? Array.isArray(input) ? input : [input] : undefined;
}
async function _callHandler(event, handler, hooks) {
  if (hooks.onRequest) {
    for (const hook of hooks.onRequest) {
      await hook(event);
      if (event.handled) {
        return;
      }
    }
  }
  const body = await handler(event);
  const response = { body };
  if (hooks.onBeforeResponse) {
    for (const hook of hooks.onBeforeResponse) {
      await hook(event, response);
    }
  }
  return response.body;
}
const eventHandler = defineEventHandler;
function isEventHandler(input) {
  return hasProp(input, "__is_handler__");
}
function toEventHandler(input, _, _route) {
  if (!isEventHandler(input)) {
    console.warn(
      "[h3] Implicit event handler conversion is deprecated. Use `eventHandler()` or `fromNodeMiddleware()` to define event handlers.",
      _route && _route !== "/" ? `
     Route: ${_route}` : "",
      `
     Handler: ${input}`
    );
  }
  return input;
}
function defineLazyEventHandler(factory) {
  let _promise;
  let _resolved;
  const resolveHandler = () => {
    if (_resolved) {
      return Promise.resolve(_resolved);
    }
    if (!_promise) {
      _promise = Promise.resolve(factory()).then((r) => {
        const handler2 = r.default || r;
        if (typeof handler2 !== "function") {
          throw new TypeError(
            "Invalid lazy handler result. It should be a function:",
            handler2
          );
        }
        _resolved = { handler: toEventHandler(r.default || r) };
        return _resolved;
      });
    }
    return _promise;
  };
  const handler = eventHandler((event) => {
    if (_resolved) {
      return _resolved.handler(event);
    }
    return resolveHandler().then((r) => r.handler(event));
  });
  handler.__resolve__ = resolveHandler;
  return handler;
}
const lazyEventHandler = defineLazyEventHandler;

function createApp(options = {}) {
  const stack = [];
  const handler = createAppEventHandler(stack, options);
  const resolve = createResolver(stack);
  handler.__resolve__ = resolve;
  const getWebsocket = cachedFn(() => websocketOptions(resolve, options));
  const app = {
    // @ts-expect-error
    use: (arg1, arg2, arg3) => use(app, arg1, arg2, arg3),
    resolve,
    handler,
    stack,
    options,
    get websocket() {
      return getWebsocket();
    }
  };
  return app;
}
function use(app, arg1, arg2, arg3) {
  if (Array.isArray(arg1)) {
    for (const i of arg1) {
      use(app, i, arg2, arg3);
    }
  } else if (Array.isArray(arg2)) {
    for (const i of arg2) {
      use(app, arg1, i, arg3);
    }
  } else if (typeof arg1 === "string") {
    app.stack.push(
      normalizeLayer({ ...arg3, route: arg1, handler: arg2 })
    );
  } else if (typeof arg1 === "function") {
    app.stack.push(normalizeLayer({ ...arg2, handler: arg1 }));
  } else {
    app.stack.push(normalizeLayer({ ...arg1 }));
  }
  return app;
}
function createAppEventHandler(stack, options) {
  const spacing = options.debug ? 2 : undefined;
  return eventHandler(async (event) => {
    event.node.req.originalUrl = event.node.req.originalUrl || event.node.req.url || "/";
    const _reqPath = event._path || event.node.req.url || "/";
    let _layerPath;
    if (options.onRequest) {
      await options.onRequest(event);
    }
    for (const layer of stack) {
      if (layer.route.length > 1) {
        if (!_reqPath.startsWith(layer.route)) {
          continue;
        }
        _layerPath = _reqPath.slice(layer.route.length) || "/";
      } else {
        _layerPath = _reqPath;
      }
      if (layer.match && !layer.match(_layerPath, event)) {
        continue;
      }
      event._path = _layerPath;
      event.node.req.url = _layerPath;
      const val = await layer.handler(event);
      const _body = val === undefined ? undefined : await val;
      if (_body !== undefined) {
        const _response = { body: _body };
        if (options.onBeforeResponse) {
          event._onBeforeResponseCalled = true;
          await options.onBeforeResponse(event, _response);
        }
        await handleHandlerResponse(event, _response.body, spacing);
        if (options.onAfterResponse) {
          event._onAfterResponseCalled = true;
          await options.onAfterResponse(event, _response);
        }
        return;
      }
      if (event.handled) {
        if (options.onAfterResponse) {
          event._onAfterResponseCalled = true;
          await options.onAfterResponse(event, undefined);
        }
        return;
      }
    }
    if (!event.handled) {
      throw createError$1({
        statusCode: 404,
        statusMessage: `Cannot find any path matching ${event.path || "/"}.`
      });
    }
    if (options.onAfterResponse) {
      event._onAfterResponseCalled = true;
      await options.onAfterResponse(event, undefined);
    }
  });
}
function createResolver(stack) {
  return async (path) => {
    let _layerPath;
    for (const layer of stack) {
      if (layer.route === "/" && !layer.handler.__resolve__) {
        continue;
      }
      if (!path.startsWith(layer.route)) {
        continue;
      }
      _layerPath = path.slice(layer.route.length) || "/";
      if (layer.match && !layer.match(_layerPath, undefined)) {
        continue;
      }
      let res = { route: layer.route, handler: layer.handler };
      if (res.handler.__resolve__) {
        const _res = await res.handler.__resolve__(_layerPath);
        if (!_res) {
          continue;
        }
        res = {
          ...res,
          ..._res,
          route: joinURL(res.route || "/", _res.route || "/")
        };
      }
      return res;
    }
  };
}
function normalizeLayer(input) {
  let handler = input.handler;
  if (handler.handler) {
    handler = handler.handler;
  }
  if (input.lazy) {
    handler = lazyEventHandler(handler);
  } else if (!isEventHandler(handler)) {
    handler = toEventHandler(handler, undefined, input.route);
  }
  return {
    route: withoutTrailingSlash(input.route),
    match: input.match,
    handler
  };
}
function handleHandlerResponse(event, val, jsonSpace) {
  if (val === null) {
    return sendNoContent(event);
  }
  if (val) {
    if (isWebResponse(val)) {
      return sendWebResponse(event, val);
    }
    if (isStream(val)) {
      return sendStream(event, val);
    }
    if (val.buffer) {
      return send(event, val);
    }
    if (val.arrayBuffer && typeof val.arrayBuffer === "function") {
      return val.arrayBuffer().then((arrayBuffer) => {
        return send(event, Buffer.from(arrayBuffer), val.type);
      });
    }
    if (val instanceof Error) {
      throw createError$1(val);
    }
    if (typeof val.end === "function") {
      return true;
    }
  }
  const valType = typeof val;
  if (valType === "string") {
    return send(event, val, MIMES.html);
  }
  if (valType === "object" || valType === "boolean" || valType === "number") {
    return send(event, JSON.stringify(val, undefined, jsonSpace), MIMES.json);
  }
  if (valType === "bigint") {
    return send(event, val.toString(), MIMES.json);
  }
  throw createError$1({
    statusCode: 500,
    statusMessage: `[h3] Cannot send ${valType} as response.`
  });
}
function cachedFn(fn) {
  let cache;
  return () => {
    if (!cache) {
      cache = fn();
    }
    return cache;
  };
}
function websocketOptions(evResolver, appOptions) {
  return {
    ...appOptions.websocket,
    async resolve(info) {
      const url = info.request?.url || info.url || "/";
      const { pathname } = typeof url === "string" ? parseURL(url) : url;
      const resolved = await evResolver(pathname);
      return resolved?.handler?.__websocket__ || {};
    }
  };
}

const RouterMethods = [
  "connect",
  "delete",
  "get",
  "head",
  "options",
  "post",
  "put",
  "trace",
  "patch"
];
function createRouter(opts = {}) {
  const _router = createRouter$1({});
  const routes = {};
  let _matcher;
  const router = {};
  const addRoute = (path, handler, method) => {
    let route = routes[path];
    if (!route) {
      routes[path] = route = { path, handlers: {} };
      _router.insert(path, route);
    }
    if (Array.isArray(method)) {
      for (const m of method) {
        addRoute(path, handler, m);
      }
    } else {
      route.handlers[method] = toEventHandler(handler, undefined, path);
    }
    return router;
  };
  router.use = router.add = (path, handler, method) => addRoute(path, handler, method || "all");
  for (const method of RouterMethods) {
    router[method] = (path, handle) => router.add(path, handle, method);
  }
  const matchHandler = (path = "/", method = "get") => {
    const qIndex = path.indexOf("?");
    if (qIndex !== -1) {
      path = path.slice(0, Math.max(0, qIndex));
    }
    const matched = _router.lookup(path);
    if (!matched || !matched.handlers) {
      return {
        error: createError$1({
          statusCode: 404,
          name: "Not Found",
          statusMessage: `Cannot find any route matching ${path || "/"}.`
        })
      };
    }
    let handler = matched.handlers[method] || matched.handlers.all;
    if (!handler) {
      if (!_matcher) {
        _matcher = toRouteMatcher(_router);
      }
      const _matches = _matcher.matchAll(path).reverse();
      for (const _match of _matches) {
        if (_match.handlers[method]) {
          handler = _match.handlers[method];
          matched.handlers[method] = matched.handlers[method] || handler;
          break;
        }
        if (_match.handlers.all) {
          handler = _match.handlers.all;
          matched.handlers.all = matched.handlers.all || handler;
          break;
        }
      }
    }
    if (!handler) {
      return {
        error: createError$1({
          statusCode: 405,
          name: "Method Not Allowed",
          statusMessage: `Method ${method} is not allowed on this route.`
        })
      };
    }
    return { matched, handler };
  };
  const isPreemptive = opts.preemptive || opts.preemtive;
  router.handler = eventHandler((event) => {
    const match = matchHandler(
      event.path,
      event.method.toLowerCase()
    );
    if ("error" in match) {
      if (isPreemptive) {
        throw match.error;
      } else {
        return;
      }
    }
    event.context.matchedRoute = match.matched;
    const params = match.matched.params || {};
    event.context.params = params;
    return Promise.resolve(match.handler(event)).then((res) => {
      if (res === undefined && isPreemptive) {
        return null;
      }
      return res;
    });
  });
  router.handler.__resolve__ = async (path) => {
    path = withLeadingSlash(path);
    const match = matchHandler(path);
    if ("error" in match) {
      return;
    }
    let res = {
      route: match.matched.path,
      handler: match.handler
    };
    if (match.handler.__resolve__) {
      const _res = await match.handler.__resolve__(path);
      if (!_res) {
        return;
      }
      res = { ...res, ..._res };
    }
    return res;
  };
  return router;
}
function toNodeListener(app) {
  const toNodeHandle = async function(req, res) {
    const event = createEvent(req, res);
    try {
      await app.handler(event);
    } catch (_error) {
      const error = createError$1(_error);
      if (!isError(_error)) {
        error.unhandled = true;
      }
      setResponseStatus(event, error.statusCode, error.statusMessage);
      if (app.options.onError) {
        await app.options.onError(error, event);
      }
      if (event.handled) {
        return;
      }
      if (error.unhandled || error.fatal) {
        console.error("[h3]", error.fatal ? "[fatal]" : "[unhandled]", error);
      }
      if (app.options.onBeforeResponse && !event._onBeforeResponseCalled) {
        await app.options.onBeforeResponse(event, { body: error });
      }
      await sendError(event, error, !!app.options.debug);
      if (app.options.onAfterResponse && !event._onAfterResponseCalled) {
        await app.options.onAfterResponse(event, { body: error });
      }
    }
  };
  return toNodeHandle;
}

function flatHooks(configHooks, hooks = {}, parentName) {
  for (const key in configHooks) {
    const subHook = configHooks[key];
    const name = parentName ? `${parentName}:${key}` : key;
    if (typeof subHook === "object" && subHook !== null) {
      flatHooks(subHook, hooks, name);
    } else if (typeof subHook === "function") {
      hooks[name] = subHook;
    }
  }
  return hooks;
}
const defaultTask = { run: (function_) => function_() };
const _createTask = () => defaultTask;
const createTask = typeof console.createTask !== "undefined" ? console.createTask : _createTask;
function serialTaskCaller(hooks, args) {
  const name = args.shift();
  const task = createTask(name);
  return hooks.reduce(
    (promise, hookFunction) => promise.then(() => task.run(() => hookFunction(...args))),
    Promise.resolve()
  );
}
function parallelTaskCaller(hooks, args) {
  const name = args.shift();
  const task = createTask(name);
  return Promise.all(hooks.map((hook) => task.run(() => hook(...args))));
}
function callEachWith(callbacks, arg0) {
  for (const callback of [...callbacks]) {
    callback(arg0);
  }
}

class Hookable {
  constructor() {
    this._hooks = {};
    this._before = void 0;
    this._after = void 0;
    this._deprecatedMessages = void 0;
    this._deprecatedHooks = {};
    this.hook = this.hook.bind(this);
    this.callHook = this.callHook.bind(this);
    this.callHookWith = this.callHookWith.bind(this);
  }
  hook(name, function_, options = {}) {
    if (!name || typeof function_ !== "function") {
      return () => {
      };
    }
    const originalName = name;
    let dep;
    while (this._deprecatedHooks[name]) {
      dep = this._deprecatedHooks[name];
      name = dep.to;
    }
    if (dep && !options.allowDeprecated) {
      let message = dep.message;
      if (!message) {
        message = `${originalName} hook has been deprecated` + (dep.to ? `, please use ${dep.to}` : "");
      }
      if (!this._deprecatedMessages) {
        this._deprecatedMessages = /* @__PURE__ */ new Set();
      }
      if (!this._deprecatedMessages.has(message)) {
        console.warn(message);
        this._deprecatedMessages.add(message);
      }
    }
    if (!function_.name) {
      try {
        Object.defineProperty(function_, "name", {
          get: () => "_" + name.replace(/\W+/g, "_") + "_hook_cb",
          configurable: true
        });
      } catch {
      }
    }
    this._hooks[name] = this._hooks[name] || [];
    this._hooks[name].push(function_);
    return () => {
      if (function_) {
        this.removeHook(name, function_);
        function_ = void 0;
      }
    };
  }
  hookOnce(name, function_) {
    let _unreg;
    let _function = (...arguments_) => {
      if (typeof _unreg === "function") {
        _unreg();
      }
      _unreg = void 0;
      _function = void 0;
      return function_(...arguments_);
    };
    _unreg = this.hook(name, _function);
    return _unreg;
  }
  removeHook(name, function_) {
    if (this._hooks[name]) {
      const index = this._hooks[name].indexOf(function_);
      if (index !== -1) {
        this._hooks[name].splice(index, 1);
      }
      if (this._hooks[name].length === 0) {
        delete this._hooks[name];
      }
    }
  }
  deprecateHook(name, deprecated) {
    this._deprecatedHooks[name] = typeof deprecated === "string" ? { to: deprecated } : deprecated;
    const _hooks = this._hooks[name] || [];
    delete this._hooks[name];
    for (const hook of _hooks) {
      this.hook(name, hook);
    }
  }
  deprecateHooks(deprecatedHooks) {
    Object.assign(this._deprecatedHooks, deprecatedHooks);
    for (const name in deprecatedHooks) {
      this.deprecateHook(name, deprecatedHooks[name]);
    }
  }
  addHooks(configHooks) {
    const hooks = flatHooks(configHooks);
    const removeFns = Object.keys(hooks).map(
      (key) => this.hook(key, hooks[key])
    );
    return () => {
      for (const unreg of removeFns.splice(0, removeFns.length)) {
        unreg();
      }
    };
  }
  removeHooks(configHooks) {
    const hooks = flatHooks(configHooks);
    for (const key in hooks) {
      this.removeHook(key, hooks[key]);
    }
  }
  removeAllHooks() {
    for (const key in this._hooks) {
      delete this._hooks[key];
    }
  }
  callHook(name, ...arguments_) {
    arguments_.unshift(name);
    return this.callHookWith(serialTaskCaller, name, ...arguments_);
  }
  callHookParallel(name, ...arguments_) {
    arguments_.unshift(name);
    return this.callHookWith(parallelTaskCaller, name, ...arguments_);
  }
  callHookWith(caller, name, ...arguments_) {
    const event = this._before || this._after ? { name, args: arguments_, context: {} } : void 0;
    if (this._before) {
      callEachWith(this._before, event);
    }
    const result = caller(
      name in this._hooks ? [...this._hooks[name]] : [],
      arguments_
    );
    if (result instanceof Promise) {
      return result.finally(() => {
        if (this._after && event) {
          callEachWith(this._after, event);
        }
      });
    }
    if (this._after && event) {
      callEachWith(this._after, event);
    }
    return result;
  }
  beforeEach(function_) {
    this._before = this._before || [];
    this._before.push(function_);
    return () => {
      if (this._before !== void 0) {
        const index = this._before.indexOf(function_);
        if (index !== -1) {
          this._before.splice(index, 1);
        }
      }
    };
  }
  afterEach(function_) {
    this._after = this._after || [];
    this._after.push(function_);
    return () => {
      if (this._after !== void 0) {
        const index = this._after.indexOf(function_);
        if (index !== -1) {
          this._after.splice(index, 1);
        }
      }
    };
  }
}
function createHooks() {
  return new Hookable();
}

const s$1=globalThis.Headers,i=globalThis.AbortController,l=globalThis.fetch||(()=>{throw new Error("[node-fetch-native] Failed to fetch: `globalThis.fetch` is not available!")});

class FetchError extends Error {
  constructor(message, opts) {
    super(message, opts);
    this.name = "FetchError";
    if (opts?.cause && !this.cause) {
      this.cause = opts.cause;
    }
  }
}
function createFetchError(ctx) {
  const errorMessage = ctx.error?.message || ctx.error?.toString() || "";
  const method = ctx.request?.method || ctx.options?.method || "GET";
  const url = ctx.request?.url || String(ctx.request) || "/";
  const requestStr = `[${method}] ${JSON.stringify(url)}`;
  const statusStr = ctx.response ? `${ctx.response.status} ${ctx.response.statusText}` : "<no response>";
  const message = `${requestStr}: ${statusStr}${errorMessage ? ` ${errorMessage}` : ""}`;
  const fetchError = new FetchError(
    message,
    ctx.error ? { cause: ctx.error } : void 0
  );
  for (const key of ["request", "options", "response"]) {
    Object.defineProperty(fetchError, key, {
      get() {
        return ctx[key];
      }
    });
  }
  for (const [key, refKey] of [
    ["data", "_data"],
    ["status", "status"],
    ["statusCode", "status"],
    ["statusText", "statusText"],
    ["statusMessage", "statusText"]
  ]) {
    Object.defineProperty(fetchError, key, {
      get() {
        return ctx.response && ctx.response[refKey];
      }
    });
  }
  return fetchError;
}

const payloadMethods = new Set(
  Object.freeze(["PATCH", "POST", "PUT", "DELETE"])
);
function isPayloadMethod(method = "GET") {
  return payloadMethods.has(method.toUpperCase());
}
function isJSONSerializable(value) {
  if (value === void 0) {
    return false;
  }
  const t = typeof value;
  if (t === "string" || t === "number" || t === "boolean" || t === null) {
    return true;
  }
  if (t !== "object") {
    return false;
  }
  if (Array.isArray(value)) {
    return true;
  }
  if (value.buffer) {
    return false;
  }
  return value.constructor && value.constructor.name === "Object" || typeof value.toJSON === "function";
}
const textTypes = /* @__PURE__ */ new Set([
  "image/svg",
  "application/xml",
  "application/xhtml",
  "application/html"
]);
const JSON_RE = /^application\/(?:[\w!#$%&*.^`~-]*\+)?json(;.+)?$/i;
function detectResponseType(_contentType = "") {
  if (!_contentType) {
    return "json";
  }
  const contentType = _contentType.split(";").shift() || "";
  if (JSON_RE.test(contentType)) {
    return "json";
  }
  if (textTypes.has(contentType) || contentType.startsWith("text/")) {
    return "text";
  }
  return "blob";
}
function resolveFetchOptions(request, input, defaults, Headers) {
  const headers = mergeHeaders(
    input?.headers ?? request?.headers,
    defaults?.headers,
    Headers
  );
  let query;
  if (defaults?.query || defaults?.params || input?.params || input?.query) {
    query = {
      ...defaults?.params,
      ...defaults?.query,
      ...input?.params,
      ...input?.query
    };
  }
  return {
    ...defaults,
    ...input,
    query,
    params: query,
    headers
  };
}
function mergeHeaders(input, defaults, Headers) {
  if (!defaults) {
    return new Headers(input);
  }
  const headers = new Headers(defaults);
  if (input) {
    for (const [key, value] of Symbol.iterator in input || Array.isArray(input) ? input : new Headers(input)) {
      headers.set(key, value);
    }
  }
  return headers;
}
async function callHooks(context, hooks) {
  if (hooks) {
    if (Array.isArray(hooks)) {
      for (const hook of hooks) {
        await hook(context);
      }
    } else {
      await hooks(context);
    }
  }
}

const retryStatusCodes = /* @__PURE__ */ new Set([
  408,
  // Request Timeout
  409,
  // Conflict
  425,
  // Too Early (Experimental)
  429,
  // Too Many Requests
  500,
  // Internal Server Error
  502,
  // Bad Gateway
  503,
  // Service Unavailable
  504
  // Gateway Timeout
]);
const nullBodyResponses = /* @__PURE__ */ new Set([101, 204, 205, 304]);
function createFetch(globalOptions = {}) {
  const {
    fetch = globalThis.fetch,
    Headers = globalThis.Headers,
    AbortController = globalThis.AbortController
  } = globalOptions;
  async function onError(context) {
    const isAbort = context.error && context.error.name === "AbortError" && !context.options.timeout || false;
    if (context.options.retry !== false && !isAbort) {
      let retries;
      if (typeof context.options.retry === "number") {
        retries = context.options.retry;
      } else {
        retries = isPayloadMethod(context.options.method) ? 0 : 1;
      }
      const responseCode = context.response && context.response.status || 500;
      if (retries > 0 && (Array.isArray(context.options.retryStatusCodes) ? context.options.retryStatusCodes.includes(responseCode) : retryStatusCodes.has(responseCode))) {
        const retryDelay = typeof context.options.retryDelay === "function" ? context.options.retryDelay(context) : context.options.retryDelay || 0;
        if (retryDelay > 0) {
          await new Promise((resolve) => setTimeout(resolve, retryDelay));
        }
        return $fetchRaw(context.request, {
          ...context.options,
          retry: retries - 1
        });
      }
    }
    const error = createFetchError(context);
    if (Error.captureStackTrace) {
      Error.captureStackTrace(error, $fetchRaw);
    }
    throw error;
  }
  const $fetchRaw = async function $fetchRaw2(_request, _options = {}) {
    const context = {
      request: _request,
      options: resolveFetchOptions(
        _request,
        _options,
        globalOptions.defaults,
        Headers
      ),
      response: void 0,
      error: void 0
    };
    if (context.options.method) {
      context.options.method = context.options.method.toUpperCase();
    }
    if (context.options.onRequest) {
      await callHooks(context, context.options.onRequest);
    }
    if (typeof context.request === "string") {
      if (context.options.baseURL) {
        context.request = withBase(context.request, context.options.baseURL);
      }
      if (context.options.query) {
        context.request = withQuery(context.request, context.options.query);
        delete context.options.query;
      }
      if ("query" in context.options) {
        delete context.options.query;
      }
      if ("params" in context.options) {
        delete context.options.params;
      }
    }
    if (context.options.body && isPayloadMethod(context.options.method)) {
      if (isJSONSerializable(context.options.body)) {
        context.options.body = typeof context.options.body === "string" ? context.options.body : JSON.stringify(context.options.body);
        context.options.headers = new Headers(context.options.headers || {});
        if (!context.options.headers.has("content-type")) {
          context.options.headers.set("content-type", "application/json");
        }
        if (!context.options.headers.has("accept")) {
          context.options.headers.set("accept", "application/json");
        }
      } else if (
        // ReadableStream Body
        "pipeTo" in context.options.body && typeof context.options.body.pipeTo === "function" || // Node.js Stream Body
        typeof context.options.body.pipe === "function"
      ) {
        if (!("duplex" in context.options)) {
          context.options.duplex = "half";
        }
      }
    }
    let abortTimeout;
    if (!context.options.signal && context.options.timeout) {
      const controller = new AbortController();
      abortTimeout = setTimeout(() => {
        const error = new Error(
          "[TimeoutError]: The operation was aborted due to timeout"
        );
        error.name = "TimeoutError";
        error.code = 23;
        controller.abort(error);
      }, context.options.timeout);
      context.options.signal = controller.signal;
    }
    try {
      context.response = await fetch(
        context.request,
        context.options
      );
    } catch (error) {
      context.error = error;
      if (context.options.onRequestError) {
        await callHooks(
          context,
          context.options.onRequestError
        );
      }
      return await onError(context);
    } finally {
      if (abortTimeout) {
        clearTimeout(abortTimeout);
      }
    }
    const hasBody = (context.response.body || // https://github.com/unjs/ofetch/issues/324
    // https://github.com/unjs/ofetch/issues/294
    // https://github.com/JakeChampion/fetch/issues/1454
    context.response._bodyInit) && !nullBodyResponses.has(context.response.status) && context.options.method !== "HEAD";
    if (hasBody) {
      const responseType = (context.options.parseResponse ? "json" : context.options.responseType) || detectResponseType(context.response.headers.get("content-type") || "");
      switch (responseType) {
        case "json": {
          const data = await context.response.text();
          const parseFunction = context.options.parseResponse || destr;
          context.response._data = parseFunction(data);
          break;
        }
        case "stream": {
          context.response._data = context.response.body || context.response._bodyInit;
          break;
        }
        default: {
          context.response._data = await context.response[responseType]();
        }
      }
    }
    if (context.options.onResponse) {
      await callHooks(
        context,
        context.options.onResponse
      );
    }
    if (!context.options.ignoreResponseError && context.response.status >= 400 && context.response.status < 600) {
      if (context.options.onResponseError) {
        await callHooks(
          context,
          context.options.onResponseError
        );
      }
      return await onError(context);
    }
    return context.response;
  };
  const $fetch = async function $fetch2(request, options) {
    const r = await $fetchRaw(request, options);
    return r._data;
  };
  $fetch.raw = $fetchRaw;
  $fetch.native = (...args) => fetch(...args);
  $fetch.create = (defaultOptions = {}, customGlobalOptions = {}) => createFetch({
    ...globalOptions,
    ...customGlobalOptions,
    defaults: {
      ...globalOptions.defaults,
      ...customGlobalOptions.defaults,
      ...defaultOptions
    }
  });
  return $fetch;
}

function createNodeFetch() {
  const useKeepAlive = JSON.parse(process.env.FETCH_KEEP_ALIVE || "false");
  if (!useKeepAlive) {
    return l;
  }
  const agentOptions = { keepAlive: true };
  const httpAgent = new http.Agent(agentOptions);
  const httpsAgent = new https.Agent(agentOptions);
  const nodeFetchOptions = {
    agent(parsedURL) {
      return parsedURL.protocol === "http:" ? httpAgent : httpsAgent;
    }
  };
  return function nodeFetchWithKeepAlive(input, init) {
    return l(input, { ...nodeFetchOptions, ...init });
  };
}
const fetch$1 = globalThis.fetch ? (...args) => globalThis.fetch(...args) : createNodeFetch();
const Headers$1 = globalThis.Headers || s$1;
const AbortController = globalThis.AbortController || i;
createFetch({ fetch: fetch$1, Headers: Headers$1, AbortController });

function wrapToPromise(value) {
  if (!value || typeof value.then !== "function") {
    return Promise.resolve(value);
  }
  return value;
}
function asyncCall(function_, ...arguments_) {
  try {
    return wrapToPromise(function_(...arguments_));
  } catch (error) {
    return Promise.reject(error);
  }
}
function isPrimitive(value) {
  const type = typeof value;
  return value === null || type !== "object" && type !== "function";
}
function isPureObject(value) {
  const proto = Object.getPrototypeOf(value);
  return !proto || proto.isPrototypeOf(Object);
}
function stringify(value) {
  if (isPrimitive(value)) {
    return String(value);
  }
  if (isPureObject(value) || Array.isArray(value)) {
    return JSON.stringify(value);
  }
  if (typeof value.toJSON === "function") {
    return stringify(value.toJSON());
  }
  throw new Error("[unstorage] Cannot stringify value!");
}
const BASE64_PREFIX = "base64:";
function serializeRaw(value) {
  if (typeof value === "string") {
    return value;
  }
  return BASE64_PREFIX + base64Encode(value);
}
function deserializeRaw(value) {
  if (typeof value !== "string") {
    return value;
  }
  if (!value.startsWith(BASE64_PREFIX)) {
    return value;
  }
  return base64Decode(value.slice(BASE64_PREFIX.length));
}
function base64Decode(input) {
  if (globalThis.Buffer) {
    return Buffer.from(input, "base64");
  }
  return Uint8Array.from(
    globalThis.atob(input),
    (c) => c.codePointAt(0)
  );
}
function base64Encode(input) {
  if (globalThis.Buffer) {
    return Buffer.from(input).toString("base64");
  }
  return globalThis.btoa(String.fromCodePoint(...input));
}

const storageKeyProperties = [
  "has",
  "hasItem",
  "get",
  "getItem",
  "getItemRaw",
  "set",
  "setItem",
  "setItemRaw",
  "del",
  "remove",
  "removeItem",
  "getMeta",
  "setMeta",
  "removeMeta",
  "getKeys",
  "clear",
  "mount",
  "unmount"
];
function prefixStorage(storage, base) {
  base = normalizeBaseKey(base);
  if (!base) {
    return storage;
  }
  const nsStorage = { ...storage };
  for (const property of storageKeyProperties) {
    nsStorage[property] = (key = "", ...args) => (
      // @ts-ignore
      storage[property](base + key, ...args)
    );
  }
  nsStorage.getKeys = (key = "", ...arguments_) => storage.getKeys(base + key, ...arguments_).then((keys) => keys.map((key2) => key2.slice(base.length)));
  return nsStorage;
}
function normalizeKey$1(key) {
  if (!key) {
    return "";
  }
  return key.split("?")[0]?.replace(/[/\\]/g, ":").replace(/:+/g, ":").replace(/^:|:$/g, "") || "";
}
function joinKeys(...keys) {
  return normalizeKey$1(keys.join(":"));
}
function normalizeBaseKey(base) {
  base = normalizeKey$1(base);
  return base ? base + ":" : "";
}
function filterKeyByDepth(key, depth) {
  if (depth === void 0) {
    return true;
  }
  let substrCount = 0;
  let index = key.indexOf(":");
  while (index > -1) {
    substrCount++;
    index = key.indexOf(":", index + 1);
  }
  return substrCount <= depth;
}
function filterKeyByBase(key, base) {
  if (base) {
    return key.startsWith(base) && key[key.length - 1] !== "$";
  }
  return key[key.length - 1] !== "$";
}

function defineDriver$1(factory) {
  return factory;
}

const DRIVER_NAME$1 = "memory";
const memory = defineDriver$1(() => {
  const data = /* @__PURE__ */ new Map();
  return {
    name: DRIVER_NAME$1,
    getInstance: () => data,
    hasItem(key) {
      return data.has(key);
    },
    getItem(key) {
      return data.get(key) ?? null;
    },
    getItemRaw(key) {
      return data.get(key) ?? null;
    },
    setItem(key, value) {
      data.set(key, value);
    },
    setItemRaw(key, value) {
      data.set(key, value);
    },
    removeItem(key) {
      data.delete(key);
    },
    getKeys() {
      return [...data.keys()];
    },
    clear() {
      data.clear();
    },
    dispose() {
      data.clear();
    }
  };
});

function createStorage(options = {}) {
  const context = {
    mounts: { "": options.driver || memory() },
    mountpoints: [""],
    watching: false,
    watchListeners: [],
    unwatch: {}
  };
  const getMount = (key) => {
    for (const base of context.mountpoints) {
      if (key.startsWith(base)) {
        return {
          base,
          relativeKey: key.slice(base.length),
          driver: context.mounts[base]
        };
      }
    }
    return {
      base: "",
      relativeKey: key,
      driver: context.mounts[""]
    };
  };
  const getMounts = (base, includeParent) => {
    return context.mountpoints.filter(
      (mountpoint) => mountpoint.startsWith(base) || includeParent && base.startsWith(mountpoint)
    ).map((mountpoint) => ({
      relativeBase: base.length > mountpoint.length ? base.slice(mountpoint.length) : void 0,
      mountpoint,
      driver: context.mounts[mountpoint]
    }));
  };
  const onChange = (event, key) => {
    if (!context.watching) {
      return;
    }
    key = normalizeKey$1(key);
    for (const listener of context.watchListeners) {
      listener(event, key);
    }
  };
  const startWatch = async () => {
    if (context.watching) {
      return;
    }
    context.watching = true;
    for (const mountpoint in context.mounts) {
      context.unwatch[mountpoint] = await watch(
        context.mounts[mountpoint],
        onChange,
        mountpoint
      );
    }
  };
  const stopWatch = async () => {
    if (!context.watching) {
      return;
    }
    for (const mountpoint in context.unwatch) {
      await context.unwatch[mountpoint]();
    }
    context.unwatch = {};
    context.watching = false;
  };
  const runBatch = (items, commonOptions, cb) => {
    const batches = /* @__PURE__ */ new Map();
    const getBatch = (mount) => {
      let batch = batches.get(mount.base);
      if (!batch) {
        batch = {
          driver: mount.driver,
          base: mount.base,
          items: []
        };
        batches.set(mount.base, batch);
      }
      return batch;
    };
    for (const item of items) {
      const isStringItem = typeof item === "string";
      const key = normalizeKey$1(isStringItem ? item : item.key);
      const value = isStringItem ? void 0 : item.value;
      const options2 = isStringItem || !item.options ? commonOptions : { ...commonOptions, ...item.options };
      const mount = getMount(key);
      getBatch(mount).items.push({
        key,
        value,
        relativeKey: mount.relativeKey,
        options: options2
      });
    }
    return Promise.all([...batches.values()].map((batch) => cb(batch))).then(
      (r) => r.flat()
    );
  };
  const storage = {
    // Item
    hasItem(key, opts = {}) {
      key = normalizeKey$1(key);
      const { relativeKey, driver } = getMount(key);
      return asyncCall(driver.hasItem, relativeKey, opts);
    },
    getItem(key, opts = {}) {
      key = normalizeKey$1(key);
      const { relativeKey, driver } = getMount(key);
      return asyncCall(driver.getItem, relativeKey, opts).then(
        (value) => destr(value)
      );
    },
    getItems(items, commonOptions = {}) {
      return runBatch(items, commonOptions, (batch) => {
        if (batch.driver.getItems) {
          return asyncCall(
            batch.driver.getItems,
            batch.items.map((item) => ({
              key: item.relativeKey,
              options: item.options
            })),
            commonOptions
          ).then(
            (r) => r.map((item) => ({
              key: joinKeys(batch.base, item.key),
              value: destr(item.value)
            }))
          );
        }
        return Promise.all(
          batch.items.map((item) => {
            return asyncCall(
              batch.driver.getItem,
              item.relativeKey,
              item.options
            ).then((value) => ({
              key: item.key,
              value: destr(value)
            }));
          })
        );
      });
    },
    getItemRaw(key, opts = {}) {
      key = normalizeKey$1(key);
      const { relativeKey, driver } = getMount(key);
      if (driver.getItemRaw) {
        return asyncCall(driver.getItemRaw, relativeKey, opts);
      }
      return asyncCall(driver.getItem, relativeKey, opts).then(
        (value) => deserializeRaw(value)
      );
    },
    async setItem(key, value, opts = {}) {
      if (value === void 0) {
        return storage.removeItem(key);
      }
      key = normalizeKey$1(key);
      const { relativeKey, driver } = getMount(key);
      if (!driver.setItem) {
        return;
      }
      await asyncCall(driver.setItem, relativeKey, stringify(value), opts);
      if (!driver.watch) {
        onChange("update", key);
      }
    },
    async setItems(items, commonOptions) {
      await runBatch(items, commonOptions, async (batch) => {
        if (batch.driver.setItems) {
          return asyncCall(
            batch.driver.setItems,
            batch.items.map((item) => ({
              key: item.relativeKey,
              value: stringify(item.value),
              options: item.options
            })),
            commonOptions
          );
        }
        if (!batch.driver.setItem) {
          return;
        }
        await Promise.all(
          batch.items.map((item) => {
            return asyncCall(
              batch.driver.setItem,
              item.relativeKey,
              stringify(item.value),
              item.options
            );
          })
        );
      });
    },
    async setItemRaw(key, value, opts = {}) {
      if (value === void 0) {
        return storage.removeItem(key, opts);
      }
      key = normalizeKey$1(key);
      const { relativeKey, driver } = getMount(key);
      if (driver.setItemRaw) {
        await asyncCall(driver.setItemRaw, relativeKey, value, opts);
      } else if (driver.setItem) {
        await asyncCall(driver.setItem, relativeKey, serializeRaw(value), opts);
      } else {
        return;
      }
      if (!driver.watch) {
        onChange("update", key);
      }
    },
    async removeItem(key, opts = {}) {
      if (typeof opts === "boolean") {
        opts = { removeMeta: opts };
      }
      key = normalizeKey$1(key);
      const { relativeKey, driver } = getMount(key);
      if (!driver.removeItem) {
        return;
      }
      await asyncCall(driver.removeItem, relativeKey, opts);
      if (opts.removeMeta || opts.removeMata) {
        await asyncCall(driver.removeItem, relativeKey + "$", opts);
      }
      if (!driver.watch) {
        onChange("remove", key);
      }
    },
    // Meta
    async getMeta(key, opts = {}) {
      if (typeof opts === "boolean") {
        opts = { nativeOnly: opts };
      }
      key = normalizeKey$1(key);
      const { relativeKey, driver } = getMount(key);
      const meta = /* @__PURE__ */ Object.create(null);
      if (driver.getMeta) {
        Object.assign(meta, await asyncCall(driver.getMeta, relativeKey, opts));
      }
      if (!opts.nativeOnly) {
        const value = await asyncCall(
          driver.getItem,
          relativeKey + "$",
          opts
        ).then((value_) => destr(value_));
        if (value && typeof value === "object") {
          if (typeof value.atime === "string") {
            value.atime = new Date(value.atime);
          }
          if (typeof value.mtime === "string") {
            value.mtime = new Date(value.mtime);
          }
          Object.assign(meta, value);
        }
      }
      return meta;
    },
    setMeta(key, value, opts = {}) {
      return this.setItem(key + "$", value, opts);
    },
    removeMeta(key, opts = {}) {
      return this.removeItem(key + "$", opts);
    },
    // Keys
    async getKeys(base, opts = {}) {
      base = normalizeBaseKey(base);
      const mounts = getMounts(base, true);
      let maskedMounts = [];
      const allKeys = [];
      let allMountsSupportMaxDepth = true;
      for (const mount of mounts) {
        if (!mount.driver.flags?.maxDepth) {
          allMountsSupportMaxDepth = false;
        }
        const rawKeys = await asyncCall(
          mount.driver.getKeys,
          mount.relativeBase,
          opts
        );
        for (const key of rawKeys) {
          const fullKey = mount.mountpoint + normalizeKey$1(key);
          if (!maskedMounts.some((p) => fullKey.startsWith(p))) {
            allKeys.push(fullKey);
          }
        }
        maskedMounts = [
          mount.mountpoint,
          ...maskedMounts.filter((p) => !p.startsWith(mount.mountpoint))
        ];
      }
      const shouldFilterByDepth = opts.maxDepth !== void 0 && !allMountsSupportMaxDepth;
      return allKeys.filter(
        (key) => (!shouldFilterByDepth || filterKeyByDepth(key, opts.maxDepth)) && filterKeyByBase(key, base)
      );
    },
    // Utils
    async clear(base, opts = {}) {
      base = normalizeBaseKey(base);
      await Promise.all(
        getMounts(base, false).map(async (m) => {
          if (m.driver.clear) {
            return asyncCall(m.driver.clear, m.relativeBase, opts);
          }
          if (m.driver.removeItem) {
            const keys = await m.driver.getKeys(m.relativeBase || "", opts);
            return Promise.all(
              keys.map((key) => m.driver.removeItem(key, opts))
            );
          }
        })
      );
    },
    async dispose() {
      await Promise.all(
        Object.values(context.mounts).map((driver) => dispose(driver))
      );
    },
    async watch(callback) {
      await startWatch();
      context.watchListeners.push(callback);
      return async () => {
        context.watchListeners = context.watchListeners.filter(
          (listener) => listener !== callback
        );
        if (context.watchListeners.length === 0) {
          await stopWatch();
        }
      };
    },
    async unwatch() {
      context.watchListeners = [];
      await stopWatch();
    },
    // Mount
    mount(base, driver) {
      base = normalizeBaseKey(base);
      if (base && context.mounts[base]) {
        throw new Error(`already mounted at ${base}`);
      }
      if (base) {
        context.mountpoints.push(base);
        context.mountpoints.sort((a, b) => b.length - a.length);
      }
      context.mounts[base] = driver;
      if (context.watching) {
        Promise.resolve(watch(driver, onChange, base)).then((unwatcher) => {
          context.unwatch[base] = unwatcher;
        }).catch(console.error);
      }
      return storage;
    },
    async unmount(base, _dispose = true) {
      base = normalizeBaseKey(base);
      if (!base || !context.mounts[base]) {
        return;
      }
      if (context.watching && base in context.unwatch) {
        context.unwatch[base]?.();
        delete context.unwatch[base];
      }
      if (_dispose) {
        await dispose(context.mounts[base]);
      }
      context.mountpoints = context.mountpoints.filter((key) => key !== base);
      delete context.mounts[base];
    },
    getMount(key = "") {
      key = normalizeKey$1(key) + ":";
      const m = getMount(key);
      return {
        driver: m.driver,
        base: m.base
      };
    },
    getMounts(base = "", opts = {}) {
      base = normalizeKey$1(base);
      const mounts = getMounts(base, opts.parents);
      return mounts.map((m) => ({
        driver: m.driver,
        base: m.mountpoint
      }));
    },
    // Aliases
    keys: (base, opts = {}) => storage.getKeys(base, opts),
    get: (key, opts = {}) => storage.getItem(key, opts),
    set: (key, value, opts = {}) => storage.setItem(key, value, opts),
    has: (key, opts = {}) => storage.hasItem(key, opts),
    del: (key, opts = {}) => storage.removeItem(key, opts),
    remove: (key, opts = {}) => storage.removeItem(key, opts)
  };
  return storage;
}
function watch(driver, onChange, base) {
  return driver.watch ? driver.watch((event, key) => onChange(event, base + key)) : () => {
  };
}
async function dispose(driver) {
  if (typeof driver.dispose === "function") {
    await asyncCall(driver.dispose);
  }
}

const _assets = {

};

const normalizeKey = function normalizeKey(key) {
  if (!key) {
    return "";
  }
  return key.split("?")[0]?.replace(/[/\\]/g, ":").replace(/:+/g, ":").replace(/^:|:$/g, "") || "";
};

const assets$1 = {
  getKeys() {
    return Promise.resolve(Object.keys(_assets))
  },
  hasItem (id) {
    id = normalizeKey(id);
    return Promise.resolve(id in _assets)
  },
  getItem (id) {
    id = normalizeKey(id);
    return Promise.resolve(_assets[id] ? _assets[id].import() : null)
  },
  getMeta (id) {
    id = normalizeKey(id);
    return Promise.resolve(_assets[id] ? _assets[id].meta : {})
  }
};

function defineDriver(factory) {
  return factory;
}
function createError(driver, message, opts) {
  const err = new Error(`[unstorage] [${driver}] ${message}`, opts);
  if (Error.captureStackTrace) {
    Error.captureStackTrace(err, createError);
  }
  return err;
}
function createRequiredError(driver, name) {
  if (Array.isArray(name)) {
    return createError(
      driver,
      `Missing some of the required options ${name.map((n) => "`" + n + "`").join(", ")}`
    );
  }
  return createError(driver, `Missing required option \`${name}\`.`);
}

function ignoreNotfound(err) {
  return err.code === "ENOENT" || err.code === "EISDIR" ? null : err;
}
function ignoreExists(err) {
  return err.code === "EEXIST" ? null : err;
}
async function writeFile(path, data, encoding) {
  await ensuredir(dirname$1(path));
  return promises.writeFile(path, data, encoding);
}
function readFile(path, encoding) {
  return promises.readFile(path, encoding).catch(ignoreNotfound);
}
function unlink(path) {
  return promises.unlink(path).catch(ignoreNotfound);
}
function readdir(dir) {
  return promises.readdir(dir, { withFileTypes: true }).catch(ignoreNotfound).then((r) => r || []);
}
async function ensuredir(dir) {
  if (existsSync(dir)) {
    return;
  }
  await ensuredir(dirname$1(dir)).catch(ignoreExists);
  await promises.mkdir(dir).catch(ignoreExists);
}
async function readdirRecursive(dir, ignore, maxDepth) {
  if (ignore && ignore(dir)) {
    return [];
  }
  const entries = await readdir(dir);
  const files = [];
  await Promise.all(
    entries.map(async (entry) => {
      const entryPath = resolve$1(dir, entry.name);
      if (entry.isDirectory()) {
        if (maxDepth === void 0 || maxDepth > 0) {
          const dirFiles = await readdirRecursive(
            entryPath,
            ignore,
            maxDepth === void 0 ? void 0 : maxDepth - 1
          );
          files.push(...dirFiles.map((f) => entry.name + "/" + f));
        }
      } else {
        if (!(ignore && ignore(entry.name))) {
          files.push(entry.name);
        }
      }
    })
  );
  return files;
}
async function rmRecursive(dir) {
  const entries = await readdir(dir);
  await Promise.all(
    entries.map((entry) => {
      const entryPath = resolve$1(dir, entry.name);
      if (entry.isDirectory()) {
        return rmRecursive(entryPath).then(() => promises.rmdir(entryPath));
      } else {
        return promises.unlink(entryPath);
      }
    })
  );
}

const PATH_TRAVERSE_RE = /\.\.:|\.\.$/;
const DRIVER_NAME = "fs-lite";
const unstorage_47drivers_47fs_45lite = defineDriver((opts = {}) => {
  if (!opts.base) {
    throw createRequiredError(DRIVER_NAME, "base");
  }
  opts.base = resolve$1(opts.base);
  const r = (key) => {
    if (PATH_TRAVERSE_RE.test(key)) {
      throw createError(
        DRIVER_NAME,
        `Invalid key: ${JSON.stringify(key)}. It should not contain .. segments`
      );
    }
    const resolved = join(opts.base, key.replace(/:/g, "/"));
    return resolved;
  };
  return {
    name: DRIVER_NAME,
    options: opts,
    flags: {
      maxDepth: true
    },
    hasItem(key) {
      return existsSync(r(key));
    },
    getItem(key) {
      return readFile(r(key), "utf8");
    },
    getItemRaw(key) {
      return readFile(r(key));
    },
    async getMeta(key) {
      const { atime, mtime, size, birthtime, ctime } = await promises.stat(r(key)).catch(() => ({}));
      return { atime, mtime, size, birthtime, ctime };
    },
    setItem(key, value) {
      if (opts.readOnly) {
        return;
      }
      return writeFile(r(key), value, "utf8");
    },
    setItemRaw(key, value) {
      if (opts.readOnly) {
        return;
      }
      return writeFile(r(key), value);
    },
    removeItem(key) {
      if (opts.readOnly) {
        return;
      }
      return unlink(r(key));
    },
    getKeys(_base, topts) {
      return readdirRecursive(r("."), opts.ignore, topts?.maxDepth);
    },
    async clear() {
      if (opts.readOnly || opts.noClear) {
        return;
      }
      await rmRecursive(r("."));
    }
  };
});

const storage = createStorage({});

storage.mount('/assets', assets$1);

storage.mount('data', unstorage_47drivers_47fs_45lite({"driver":"fsLite","base":"./.data/kv"}));

function useStorage(base = "") {
  return base ? prefixStorage(storage, base) : storage;
}

function serialize$1(o){return typeof o=="string"?`'${o}'`:new c().serialize(o)}const c=/*@__PURE__*/function(){class o{#t=new Map;compare(t,r){const e=typeof t,n=typeof r;return e==="string"&&n==="string"?t.localeCompare(r):e==="number"&&n==="number"?t-r:String.prototype.localeCompare.call(this.serialize(t,true),this.serialize(r,true))}serialize(t,r){if(t===null)return "null";switch(typeof t){case "string":return r?t:`'${t}'`;case "bigint":return `${t}n`;case "object":return this.$object(t);case "function":return this.$function(t)}return String(t)}serializeObject(t){const r=Object.prototype.toString.call(t);if(r!=="[object Object]")return this.serializeBuiltInType(r.length<10?`unknown:${r}`:r.slice(8,-1),t);const e=t.constructor,n=e===Object||e===void 0?"":e.name;if(n!==""&&globalThis[n]===e)return this.serializeBuiltInType(n,t);if(typeof t.toJSON=="function"){const i=t.toJSON();return n+(i!==null&&typeof i=="object"?this.$object(i):`(${this.serialize(i)})`)}return this.serializeObjectEntries(n,Object.entries(t))}serializeBuiltInType(t,r){const e=this["$"+t];if(e)return e.call(this,r);if(typeof r?.entries=="function")return this.serializeObjectEntries(t,r.entries());throw new Error(`Cannot serialize ${t}`)}serializeObjectEntries(t,r){const e=Array.from(r).sort((i,a)=>this.compare(i[0],a[0]));let n=`${t}{`;for(let i=0;i<e.length;i++){const[a,l]=e[i];n+=`${this.serialize(a,true)}:${this.serialize(l)}`,i<e.length-1&&(n+=",");}return n+"}"}$object(t){let r=this.#t.get(t);return r===void 0&&(this.#t.set(t,`#${this.#t.size}`),r=this.serializeObject(t),this.#t.set(t,r)),r}$function(t){const r=Function.prototype.toString.call(t);return r.slice(-15)==="[native code] }"?`${t.name||""}()[native]`:`${t.name}(${t.length})${r.replace(/\s*\n\s*/g,"")}`}$Array(t){let r="[";for(let e=0;e<t.length;e++)r+=this.serialize(t[e]),e<t.length-1&&(r+=",");return r+"]"}$Date(t){try{return `Date(${t.toISOString()})`}catch{return "Date(null)"}}$ArrayBuffer(t){return `ArrayBuffer[${new Uint8Array(t).join(",")}]`}$Set(t){return `Set${this.$Array(Array.from(t).sort((r,e)=>this.compare(r,e)))}`}$Map(t){return this.serializeObjectEntries("Map",t.entries())}}for(const s of ["Error","RegExp","URL"])o.prototype["$"+s]=function(t){return `${s}(${t})`};for(const s of ["Int8Array","Uint8Array","Uint8ClampedArray","Int16Array","Uint16Array","Int32Array","Uint32Array","Float32Array","Float64Array"])o.prototype["$"+s]=function(t){return `${s}[${t.join(",")}]`};for(const s of ["BigInt64Array","BigUint64Array"])o.prototype["$"+s]=function(t){return `${s}[${t.join("n,")}${t.length>0?"n":""}]`};return o}();

function isEqual(object1, object2) {
  if (object1 === object2) {
    return true;
  }
  if (serialize$1(object1) === serialize$1(object2)) {
    return true;
  }
  return false;
}

const e=globalThis.process?.getBuiltinModule?.("crypto")?.hash,r="sha256",s="base64url";function digest(t){if(e)return e(r,t,s);const o=createHash(r).update(t);return globalThis.process?.versions?.webcontainer?o.digest().toString(s):o.digest(s)}

function hash$1(input) {
  return digest(serialize$1(input));
}

const Hasher = /* @__PURE__ */ (() => {
  class Hasher2 {
    buff = "";
    #context = /* @__PURE__ */ new Map();
    write(str) {
      this.buff += str;
    }
    dispatch(value) {
      const type = value === null ? "null" : typeof value;
      return this[type](value);
    }
    object(object) {
      if (object && typeof object.toJSON === "function") {
        return this.object(object.toJSON());
      }
      const objString = Object.prototype.toString.call(object);
      let objType = "";
      const objectLength = objString.length;
      objType = objectLength < 10 ? "unknown:[" + objString + "]" : objString.slice(8, objectLength - 1);
      objType = objType.toLowerCase();
      let objectNumber = null;
      if ((objectNumber = this.#context.get(object)) === void 0) {
        this.#context.set(object, this.#context.size);
      } else {
        return this.dispatch("[CIRCULAR:" + objectNumber + "]");
      }
      if (typeof Buffer !== "undefined" && Buffer.isBuffer && Buffer.isBuffer(object)) {
        this.write("buffer:");
        return this.write(object.toString("utf8"));
      }
      if (objType !== "object" && objType !== "function" && objType !== "asyncfunction") {
        if (this[objType]) {
          this[objType](object);
        } else {
          this.unknown(object, objType);
        }
      } else {
        const keys = Object.keys(object).sort();
        const extraKeys = [];
        this.write("object:" + (keys.length + extraKeys.length) + ":");
        const dispatchForKey = (key) => {
          this.dispatch(key);
          this.write(":");
          this.dispatch(object[key]);
          this.write(",");
        };
        for (const key of keys) {
          dispatchForKey(key);
        }
        for (const key of extraKeys) {
          dispatchForKey(key);
        }
      }
    }
    array(arr, unordered) {
      unordered = unordered === void 0 ? false : unordered;
      this.write("array:" + arr.length + ":");
      if (!unordered || arr.length <= 1) {
        for (const entry of arr) {
          this.dispatch(entry);
        }
        return;
      }
      const contextAdditions = /* @__PURE__ */ new Map();
      const entries = arr.map((entry) => {
        const hasher = new Hasher2();
        hasher.dispatch(entry);
        for (const [key, value] of hasher.#context) {
          contextAdditions.set(key, value);
        }
        return hasher.toString();
      });
      this.#context = contextAdditions;
      entries.sort();
      return this.array(entries, false);
    }
    date(date) {
      return this.write("date:" + date.toJSON());
    }
    symbol(sym) {
      return this.write("symbol:" + sym.toString());
    }
    unknown(value, type) {
      this.write(type);
      if (!value) {
        return;
      }
      this.write(":");
      if (value && typeof value.entries === "function") {
        return this.array(
          [...value.entries()],
          true
          /* ordered */
        );
      }
    }
    error(err) {
      return this.write("error:" + err.toString());
    }
    boolean(bool) {
      return this.write("bool:" + bool);
    }
    string(string) {
      this.write("string:" + string.length + ":");
      this.write(string);
    }
    function(fn) {
      this.write("fn:");
      if (isNativeFunction(fn)) {
        this.dispatch("[native]");
      } else {
        this.dispatch(fn.toString());
      }
    }
    number(number) {
      return this.write("number:" + number);
    }
    null() {
      return this.write("Null");
    }
    undefined() {
      return this.write("Undefined");
    }
    regexp(regex) {
      return this.write("regex:" + regex.toString());
    }
    arraybuffer(arr) {
      this.write("arraybuffer:");
      return this.dispatch(new Uint8Array(arr));
    }
    url(url) {
      return this.write("url:" + url.toString());
    }
    map(map) {
      this.write("map:");
      const arr = [...map];
      return this.array(arr, false);
    }
    set(set) {
      this.write("set:");
      const arr = [...set];
      return this.array(arr, false);
    }
    bigint(number) {
      return this.write("bigint:" + number.toString());
    }
  }
  for (const type of [
    "uint8array",
    "uint8clampedarray",
    "unt8array",
    "uint16array",
    "unt16array",
    "uint32array",
    "unt32array",
    "float32array",
    "float64array"
  ]) {
    Hasher2.prototype[type] = function(arr) {
      this.write(type + ":");
      return this.array([...arr], false);
    };
  }
  function isNativeFunction(f) {
    if (typeof f !== "function") {
      return false;
    }
    return Function.prototype.toString.call(f).slice(
      -15
      /* "[native code] }".length */
    ) === "[native code] }";
  }
  return Hasher2;
})();
function serialize(object) {
  const hasher = new Hasher();
  hasher.dispatch(object);
  return hasher.buff;
}
function hash(value) {
  return digest(typeof value === "string" ? value : serialize(value)).replace(/[-_]/g, "").slice(0, 10);
}

function defaultCacheOptions() {
  return {
    name: "_",
    base: "/cache",
    swr: true,
    maxAge: 1
  };
}
function defineCachedFunction(fn, opts = {}) {
  opts = { ...defaultCacheOptions(), ...opts };
  const pending = {};
  const group = opts.group || "nitro/functions";
  const name = opts.name || fn.name || "_";
  const integrity = opts.integrity || hash([fn, opts]);
  const validate = opts.validate || ((entry) => entry.value !== void 0);
  async function get(key, resolver, shouldInvalidateCache, event) {
    const cacheKey = [opts.base, group, name, key + ".json"].filter(Boolean).join(":").replace(/:\/$/, ":index");
    let entry = await useStorage().getItem(cacheKey).catch((error) => {
      console.error(`[cache] Cache read error.`, error);
      useNitroApp().captureError(error, { event, tags: ["cache"] });
    }) || {};
    if (typeof entry !== "object") {
      entry = {};
      const error = new Error("Malformed data read from cache.");
      console.error("[cache]", error);
      useNitroApp().captureError(error, { event, tags: ["cache"] });
    }
    const ttl = (opts.maxAge ?? 0) * 1e3;
    if (ttl) {
      entry.expires = Date.now() + ttl;
    }
    const expired = shouldInvalidateCache || entry.integrity !== integrity || ttl && Date.now() - (entry.mtime || 0) > ttl || validate(entry) === false;
    const _resolve = async () => {
      const isPending = pending[key];
      if (!isPending) {
        if (entry.value !== void 0 && (opts.staleMaxAge || 0) >= 0 && opts.swr === false) {
          entry.value = void 0;
          entry.integrity = void 0;
          entry.mtime = void 0;
          entry.expires = void 0;
        }
        pending[key] = Promise.resolve(resolver());
      }
      try {
        entry.value = await pending[key];
      } catch (error) {
        if (!isPending) {
          delete pending[key];
        }
        throw error;
      }
      if (!isPending) {
        entry.mtime = Date.now();
        entry.integrity = integrity;
        delete pending[key];
        if (validate(entry) !== false) {
          let setOpts;
          if (opts.maxAge && !opts.swr) {
            setOpts = { ttl: opts.maxAge };
          }
          const promise = useStorage().setItem(cacheKey, entry, setOpts).catch((error) => {
            console.error(`[cache] Cache write error.`, error);
            useNitroApp().captureError(error, { event, tags: ["cache"] });
          });
          if (event?.waitUntil) {
            event.waitUntil(promise);
          }
        }
      }
    };
    const _resolvePromise = expired ? _resolve() : Promise.resolve();
    if (entry.value === void 0) {
      await _resolvePromise;
    } else if (expired && event && event.waitUntil) {
      event.waitUntil(_resolvePromise);
    }
    if (opts.swr && validate(entry) !== false) {
      _resolvePromise.catch((error) => {
        console.error(`[cache] SWR handler error.`, error);
        useNitroApp().captureError(error, { event, tags: ["cache"] });
      });
      return entry;
    }
    return _resolvePromise.then(() => entry);
  }
  return async (...args) => {
    const shouldBypassCache = await opts.shouldBypassCache?.(...args);
    if (shouldBypassCache) {
      return fn(...args);
    }
    const key = await (opts.getKey || getKey)(...args);
    const shouldInvalidateCache = await opts.shouldInvalidateCache?.(...args);
    const entry = await get(
      key,
      () => fn(...args),
      shouldInvalidateCache,
      args[0] && isEvent(args[0]) ? args[0] : void 0
    );
    let value = entry.value;
    if (opts.transform) {
      value = await opts.transform(entry, ...args) || value;
    }
    return value;
  };
}
function cachedFunction(fn, opts = {}) {
  return defineCachedFunction(fn, opts);
}
function getKey(...args) {
  return args.length > 0 ? hash(args) : "";
}
function escapeKey(key) {
  return String(key).replace(/\W/g, "");
}
function defineCachedEventHandler(handler, opts = defaultCacheOptions()) {
  const variableHeaderNames = (opts.varies || []).filter(Boolean).map((h) => h.toLowerCase()).sort();
  const _opts = {
    ...opts,
    getKey: async (event) => {
      const customKey = await opts.getKey?.(event);
      if (customKey) {
        return escapeKey(customKey);
      }
      const _path = event.node.req.originalUrl || event.node.req.url || event.path;
      let _pathname;
      try {
        _pathname = escapeKey(decodeURI(parseURL(_path).pathname)).slice(0, 16) || "index";
      } catch {
        _pathname = "-";
      }
      const _hashedPath = `${_pathname}.${hash(_path)}`;
      const _headers = variableHeaderNames.map((header) => [header, event.node.req.headers[header]]).map(([name, value]) => `${escapeKey(name)}.${hash(value)}`);
      return [_hashedPath, ..._headers].join(":");
    },
    validate: (entry) => {
      if (!entry.value) {
        return false;
      }
      if (entry.value.code >= 400) {
        return false;
      }
      if (entry.value.body === void 0) {
        return false;
      }
      if (entry.value.headers.etag === "undefined" || entry.value.headers["last-modified"] === "undefined") {
        return false;
      }
      return true;
    },
    group: opts.group || "nitro/handlers",
    integrity: opts.integrity || hash([handler, opts])
  };
  const _cachedHandler = cachedFunction(
    async (incomingEvent) => {
      const variableHeaders = {};
      for (const header of variableHeaderNames) {
        const value = incomingEvent.node.req.headers[header];
        if (value !== void 0) {
          variableHeaders[header] = value;
        }
      }
      const reqProxy = cloneWithProxy(incomingEvent.node.req, {
        headers: variableHeaders
      });
      const resHeaders = {};
      let _resSendBody;
      const resProxy = cloneWithProxy(incomingEvent.node.res, {
        statusCode: 200,
        writableEnded: false,
        writableFinished: false,
        headersSent: false,
        closed: false,
        getHeader(name) {
          return resHeaders[name];
        },
        setHeader(name, value) {
          resHeaders[name] = value;
          return this;
        },
        getHeaderNames() {
          return Object.keys(resHeaders);
        },
        hasHeader(name) {
          return name in resHeaders;
        },
        removeHeader(name) {
          delete resHeaders[name];
        },
        getHeaders() {
          return resHeaders;
        },
        end(chunk, arg2, arg3) {
          if (typeof chunk === "string") {
            _resSendBody = chunk;
          }
          if (typeof arg2 === "function") {
            arg2();
          }
          if (typeof arg3 === "function") {
            arg3();
          }
          return this;
        },
        write(chunk, arg2, arg3) {
          if (typeof chunk === "string") {
            _resSendBody = chunk;
          }
          if (typeof arg2 === "function") {
            arg2(void 0);
          }
          if (typeof arg3 === "function") {
            arg3();
          }
          return true;
        },
        writeHead(statusCode, headers2) {
          this.statusCode = statusCode;
          if (headers2) {
            if (Array.isArray(headers2) || typeof headers2 === "string") {
              throw new TypeError("Raw headers  is not supported.");
            }
            for (const header in headers2) {
              const value = headers2[header];
              if (value !== void 0) {
                this.setHeader(
                  header,
                  value
                );
              }
            }
          }
          return this;
        }
      });
      const event = createEvent(reqProxy, resProxy);
      event.fetch = (url, fetchOptions) => fetchWithEvent(event, url, fetchOptions, {
        fetch: useNitroApp().localFetch
      });
      event.$fetch = (url, fetchOptions) => fetchWithEvent(event, url, fetchOptions, {
        fetch: globalThis.$fetch
      });
      event.waitUntil = incomingEvent.waitUntil;
      event.context = incomingEvent.context;
      event.context.cache = {
        options: _opts
      };
      const body = await handler(event) || _resSendBody;
      const headers = event.node.res.getHeaders();
      headers.etag = String(
        headers.Etag || headers.etag || `W/"${hash(body)}"`
      );
      headers["last-modified"] = String(
        headers["Last-Modified"] || headers["last-modified"] || (/* @__PURE__ */ new Date()).toUTCString()
      );
      const cacheControl = [];
      if (opts.swr) {
        if (opts.maxAge) {
          cacheControl.push(`s-maxage=${opts.maxAge}`);
        }
        if (opts.staleMaxAge) {
          cacheControl.push(`stale-while-revalidate=${opts.staleMaxAge}`);
        } else {
          cacheControl.push("stale-while-revalidate");
        }
      } else if (opts.maxAge) {
        cacheControl.push(`max-age=${opts.maxAge}`);
      }
      if (cacheControl.length > 0) {
        headers["cache-control"] = cacheControl.join(", ");
      }
      const cacheEntry = {
        code: event.node.res.statusCode,
        headers,
        body
      };
      return cacheEntry;
    },
    _opts
  );
  return defineEventHandler(async (event) => {
    if (opts.headersOnly) {
      if (handleCacheHeaders(event, { maxAge: opts.maxAge })) {
        return;
      }
      return handler(event);
    }
    const response = await _cachedHandler(
      event
    );
    if (event.node.res.headersSent || event.node.res.writableEnded) {
      return response.body;
    }
    if (handleCacheHeaders(event, {
      modifiedTime: new Date(response.headers["last-modified"]),
      etag: response.headers.etag,
      maxAge: opts.maxAge
    })) {
      return;
    }
    event.node.res.statusCode = response.code;
    for (const name in response.headers) {
      const value = response.headers[name];
      if (name === "set-cookie") {
        event.node.res.appendHeader(
          name,
          splitCookiesString(value)
        );
      } else {
        if (value !== void 0) {
          event.node.res.setHeader(name, value);
        }
      }
    }
    return response.body;
  });
}
function cloneWithProxy(obj, overrides) {
  return new Proxy(obj, {
    get(target, property, receiver) {
      if (property in overrides) {
        return overrides[property];
      }
      return Reflect.get(target, property, receiver);
    },
    set(target, property, value, receiver) {
      if (property in overrides) {
        overrides[property] = value;
        return true;
      }
      return Reflect.set(target, property, value, receiver);
    }
  });
}
const cachedEventHandler = defineCachedEventHandler;

function klona(x) {
	if (typeof x !== 'object') return x;

	var k, tmp, str=Object.prototype.toString.call(x);

	if (str === '[object Object]') {
		if (x.constructor !== Object && typeof x.constructor === 'function') {
			tmp = new x.constructor();
			for (k in x) {
				if (x.hasOwnProperty(k) && tmp[k] !== x[k]) {
					tmp[k] = klona(x[k]);
				}
			}
		} else {
			tmp = {}; // null
			for (k in x) {
				if (k === '__proto__') {
					Object.defineProperty(tmp, k, {
						value: klona(x[k]),
						configurable: true,
						enumerable: true,
						writable: true,
					});
				} else {
					tmp[k] = klona(x[k]);
				}
			}
		}
		return tmp;
	}

	if (str === '[object Array]') {
		k = x.length;
		for (tmp=Array(k); k--;) {
			tmp[k] = klona(x[k]);
		}
		return tmp;
	}

	if (str === '[object Set]') {
		tmp = new Set;
		x.forEach(function (val) {
			tmp.add(klona(val));
		});
		return tmp;
	}

	if (str === '[object Map]') {
		tmp = new Map;
		x.forEach(function (val, key) {
			tmp.set(klona(key), klona(val));
		});
		return tmp;
	}

	if (str === '[object Date]') {
		return new Date(+x);
	}

	if (str === '[object RegExp]') {
		tmp = new RegExp(x.source, x.flags);
		tmp.lastIndex = x.lastIndex;
		return tmp;
	}

	if (str === '[object DataView]') {
		return new x.constructor( klona(x.buffer) );
	}

	if (str === '[object ArrayBuffer]') {
		return x.slice(0);
	}

	// ArrayBuffer.isView(x)
	// ~> `new` bcuz `Buffer.slice` => ref
	if (str.slice(-6) === 'Array]') {
		return new x.constructor(x);
	}

	return x;
}

const inlineAppConfig = {
  "nuxt": {},
  "icon": {
    "provider": "server",
    "class": "",
    "aliases": {},
    "iconifyApiEndpoint": "https://api.iconify.design",
    "localApiEndpoint": "/api/_nuxt_icon",
    "fallbackToApi": true,
    "cssSelectorPrefix": "i-",
    "cssWherePseudo": true,
    "mode": "css",
    "attrs": {
      "aria-hidden": true
    },
    "collections": [
      "academicons",
      "akar-icons",
      "ant-design",
      "arcticons",
      "basil",
      "bi",
      "bitcoin-icons",
      "bpmn",
      "brandico",
      "bx",
      "bxl",
      "bxs",
      "bytesize",
      "carbon",
      "catppuccin",
      "cbi",
      "charm",
      "ci",
      "cib",
      "cif",
      "cil",
      "circle-flags",
      "circum",
      "clarity",
      "codicon",
      "covid",
      "cryptocurrency",
      "cryptocurrency-color",
      "dashicons",
      "devicon",
      "devicon-plain",
      "ei",
      "el",
      "emojione",
      "emojione-monotone",
      "emojione-v1",
      "entypo",
      "entypo-social",
      "eos-icons",
      "ep",
      "et",
      "eva",
      "f7",
      "fa",
      "fa-brands",
      "fa-regular",
      "fa-solid",
      "fa6-brands",
      "fa6-regular",
      "fa6-solid",
      "fad",
      "fe",
      "feather",
      "file-icons",
      "flag",
      "flagpack",
      "flat-color-icons",
      "flat-ui",
      "flowbite",
      "fluent",
      "fluent-emoji",
      "fluent-emoji-flat",
      "fluent-emoji-high-contrast",
      "fluent-mdl2",
      "fontelico",
      "fontisto",
      "formkit",
      "foundation",
      "fxemoji",
      "gala",
      "game-icons",
      "geo",
      "gg",
      "gis",
      "gravity-ui",
      "gridicons",
      "grommet-icons",
      "guidance",
      "healthicons",
      "heroicons",
      "heroicons-outline",
      "heroicons-solid",
      "hugeicons",
      "humbleicons",
      "ic",
      "icomoon-free",
      "icon-park",
      "icon-park-outline",
      "icon-park-solid",
      "icon-park-twotone",
      "iconamoon",
      "iconoir",
      "icons8",
      "il",
      "ion",
      "iwwa",
      "jam",
      "la",
      "lets-icons",
      "line-md",
      "logos",
      "ls",
      "lucide",
      "lucide-lab",
      "mage",
      "majesticons",
      "maki",
      "map",
      "marketeq",
      "material-symbols",
      "material-symbols-light",
      "mdi",
      "mdi-light",
      "medical-icon",
      "memory",
      "meteocons",
      "mi",
      "mingcute",
      "mono-icons",
      "mynaui",
      "nimbus",
      "nonicons",
      "noto",
      "noto-v1",
      "octicon",
      "oi",
      "ooui",
      "openmoji",
      "oui",
      "pajamas",
      "pepicons",
      "pepicons-pencil",
      "pepicons-pop",
      "pepicons-print",
      "ph",
      "pixelarticons",
      "prime",
      "ps",
      "quill",
      "radix-icons",
      "raphael",
      "ri",
      "rivet-icons",
      "si-glyph",
      "simple-icons",
      "simple-line-icons",
      "skill-icons",
      "solar",
      "streamline",
      "streamline-emojis",
      "subway",
      "svg-spinners",
      "system-uicons",
      "tabler",
      "tdesign",
      "teenyicons",
      "token",
      "token-branded",
      "topcoat",
      "twemoji",
      "typcn",
      "uil",
      "uim",
      "uis",
      "uit",
      "uiw",
      "unjs",
      "vaadin",
      "vs",
      "vscode-icons",
      "websymbol",
      "weui",
      "whh",
      "wi",
      "wpf",
      "zmdi",
      "zondicons"
    ],
    "fetchTimeout": 1500
  }
};



const appConfig = defuFn(inlineAppConfig);

const NUMBER_CHAR_RE = /\d/;
const STR_SPLITTERS = ["-", "_", "/", "."];
function isUppercase(char = "") {
  if (NUMBER_CHAR_RE.test(char)) {
    return void 0;
  }
  return char !== char.toLowerCase();
}
function splitByCase(str, separators) {
  const splitters = STR_SPLITTERS;
  const parts = [];
  if (!str || typeof str !== "string") {
    return parts;
  }
  let buff = "";
  let previousUpper;
  let previousSplitter;
  for (const char of str) {
    const isSplitter = splitters.includes(char);
    if (isSplitter === true) {
      parts.push(buff);
      buff = "";
      previousUpper = void 0;
      continue;
    }
    const isUpper = isUppercase(char);
    if (previousSplitter === false) {
      if (previousUpper === false && isUpper === true) {
        parts.push(buff);
        buff = char;
        previousUpper = isUpper;
        continue;
      }
      if (previousUpper === true && isUpper === false && buff.length > 1) {
        const lastChar = buff.at(-1);
        parts.push(buff.slice(0, Math.max(0, buff.length - 1)));
        buff = lastChar + char;
        previousUpper = isUpper;
        continue;
      }
    }
    buff += char;
    previousUpper = isUpper;
    previousSplitter = isSplitter;
  }
  parts.push(buff);
  return parts;
}
function kebabCase(str, joiner) {
  return str ? (Array.isArray(str) ? str : splitByCase(str)).map((p) => p.toLowerCase()).join(joiner) : "";
}
function snakeCase(str) {
  return kebabCase(str || "", "_");
}

function getEnv(key, opts) {
  const envKey = snakeCase(key).toUpperCase();
  return destr(
    process.env[opts.prefix + envKey] ?? process.env[opts.altPrefix + envKey]
  );
}
function _isObject(input) {
  return typeof input === "object" && !Array.isArray(input);
}
function applyEnv(obj, opts, parentKey = "") {
  for (const key in obj) {
    const subKey = parentKey ? `${parentKey}_${key}` : key;
    const envValue = getEnv(subKey, opts);
    if (_isObject(obj[key])) {
      if (_isObject(envValue)) {
        obj[key] = { ...obj[key], ...envValue };
        applyEnv(obj[key], opts, subKey);
      } else if (envValue === void 0) {
        applyEnv(obj[key], opts, subKey);
      } else {
        obj[key] = envValue ?? obj[key];
      }
    } else {
      obj[key] = envValue ?? obj[key];
    }
    if (opts.envExpansion && typeof obj[key] === "string") {
      obj[key] = _expandFromEnv(obj[key]);
    }
  }
  return obj;
}
const envExpandRx = /\{\{([^{}]*)\}\}/g;
function _expandFromEnv(value) {
  return value.replace(envExpandRx, (match, key) => {
    return process.env[key] || match;
  });
}

const _inlineRuntimeConfig = {
  "app": {
    "baseURL": "/",
    "buildId": "0ebc614b-2d19-480c-bf98-99328c20ff90",
    "buildAssetsDir": "/_nuxt/",
    "cdnURL": ""
  },
  "nitro": {
    "envPrefix": "NUXT_",
    "routeRules": {
      "/__nuxt_error": {
        "cache": false
      },
      "/backend/**": {
        "proxy": {
          "to": "http://127.0.0.1:8000/**",
          "_proxyStripBase": "/backend"
        }
      },
      "/get-geoip/**": {
        "proxy": {
          "to": "http://ip-api.com/json/**",
          "_proxyStripBase": "/get-geoip"
        }
      },
      "/__nuxt_content/content/sql_dump": {
        "prerender": true
      },
      "/_nuxt/builds/meta/**": {
        "headers": {
          "cache-control": "public, max-age=31536000, immutable"
        }
      },
      "/_nuxt/builds/**": {
        "headers": {
          "cache-control": "public, max-age=1, immutable"
        }
      },
      "/_fonts/**": {
        "headers": {
          "cache-control": "public, max-age=31536000, immutable"
        }
      },
      "/_scripts/**": {
        "headers": {
          "cache-control": "public, max-age=31536000, immutable"
        }
      },
      "/_nuxt/**": {
        "headers": {
          "cache-control": "public, max-age=31536000, immutable"
        }
      }
    }
  },
  "public": {
    "appUrl": "http://localhost:3300",
    "apiUrl": "http://localhost:3300/backend",
    "content": {
      "wsUrl": ""
    },
    "mdc": {
      "components": {
        "prose": true,
        "map": {}
      },
      "headings": {
        "anchorLinks": {
          "h1": false,
          "h2": true,
          "h3": true,
          "h4": true,
          "h5": false,
          "h6": false
        }
      }
    },
    "nuxt-scripts": {
      "version": "",
      "defaultScriptOptions": {
        "trigger": "onNuxtReady"
      }
    }
  },
  "content": {
    "databaseVersion": "v3.3.0",
    "version": "3.4.0",
    "database": {
      "type": "sqlite",
      "filename": "./contents.sqlite"
    },
    "localDatabase": {
      "type": "sqlite",
      "filename": "/Users/mac/Desktop/work/front_wsapay/.data/content/contents.sqlite"
    },
    "integrityCheck": true
  },
  "icon": {
    "serverKnownCssClasses": []
  },
  "nuxt-scripts": {
    "version": "0.11.5"
  },
  "ipx": {
    "baseURL": "/_ipx",
    "alias": {},
    "fs": {
      "dir": "../public"
    },
    "http": {
      "domains": []
    }
  }
};
const envOptions = {
  prefix: "NITRO_",
  altPrefix: _inlineRuntimeConfig.nitro.envPrefix ?? process.env.NITRO_ENV_PREFIX ?? "_",
  envExpansion: _inlineRuntimeConfig.nitro.envExpansion ?? process.env.NITRO_ENV_EXPANSION ?? false
};
const _sharedRuntimeConfig = _deepFreeze(
  applyEnv(klona(_inlineRuntimeConfig), envOptions)
);
function useRuntimeConfig(event) {
  if (!event) {
    return _sharedRuntimeConfig;
  }
  if (event.context.nitro.runtimeConfig) {
    return event.context.nitro.runtimeConfig;
  }
  const runtimeConfig = klona(_inlineRuntimeConfig);
  applyEnv(runtimeConfig, envOptions);
  event.context.nitro.runtimeConfig = runtimeConfig;
  return runtimeConfig;
}
const _sharedAppConfig = _deepFreeze(klona(appConfig));
function useAppConfig(event) {
  {
    return _sharedAppConfig;
  }
}
function _deepFreeze(object) {
  const propNames = Object.getOwnPropertyNames(object);
  for (const name of propNames) {
    const value = object[name];
    if (value && typeof value === "object") {
      _deepFreeze(value);
    }
  }
  return Object.freeze(object);
}
new Proxy(/* @__PURE__ */ Object.create(null), {
  get: (_, prop) => {
    console.warn(
      "Please use `useRuntimeConfig()` instead of accessing config directly."
    );
    const runtimeConfig = useRuntimeConfig();
    if (prop in runtimeConfig) {
      return runtimeConfig[prop];
    }
    return void 0;
  }
});

function createContext(opts = {}) {
  let currentInstance;
  let isSingleton = false;
  const checkConflict = (instance) => {
    if (currentInstance && currentInstance !== instance) {
      throw new Error("Context conflict");
    }
  };
  let als;
  if (opts.asyncContext) {
    const _AsyncLocalStorage = opts.AsyncLocalStorage || globalThis.AsyncLocalStorage;
    if (_AsyncLocalStorage) {
      als = new _AsyncLocalStorage();
    } else {
      console.warn("[unctx] `AsyncLocalStorage` is not provided.");
    }
  }
  const _getCurrentInstance = () => {
    if (als) {
      const instance = als.getStore();
      if (instance !== void 0) {
        return instance;
      }
    }
    return currentInstance;
  };
  return {
    use: () => {
      const _instance = _getCurrentInstance();
      if (_instance === void 0) {
        throw new Error("Context is not available");
      }
      return _instance;
    },
    tryUse: () => {
      return _getCurrentInstance();
    },
    set: (instance, replace) => {
      if (!replace) {
        checkConflict(instance);
      }
      currentInstance = instance;
      isSingleton = true;
    },
    unset: () => {
      currentInstance = void 0;
      isSingleton = false;
    },
    call: (instance, callback) => {
      checkConflict(instance);
      currentInstance = instance;
      try {
        return als ? als.run(instance, callback) : callback();
      } finally {
        if (!isSingleton) {
          currentInstance = void 0;
        }
      }
    },
    async callAsync(instance, callback) {
      currentInstance = instance;
      const onRestore = () => {
        currentInstance = instance;
      };
      const onLeave = () => currentInstance === instance ? onRestore : void 0;
      asyncHandlers.add(onLeave);
      try {
        const r = als ? als.run(instance, callback) : callback();
        if (!isSingleton) {
          currentInstance = void 0;
        }
        return await r;
      } finally {
        asyncHandlers.delete(onLeave);
      }
    }
  };
}
function createNamespace(defaultOpts = {}) {
  const contexts = {};
  return {
    get(key, opts = {}) {
      if (!contexts[key]) {
        contexts[key] = createContext({ ...defaultOpts, ...opts });
      }
      return contexts[key];
    }
  };
}
const _globalThis = typeof globalThis !== "undefined" ? globalThis : typeof self !== "undefined" ? self : typeof global !== "undefined" ? global : {};
const globalKey = "__unctx__";
const defaultNamespace = _globalThis[globalKey] || (_globalThis[globalKey] = createNamespace());
const getContext = (key, opts = {}) => defaultNamespace.get(key, opts);
const asyncHandlersKey = "__unctx_async_handlers__";
const asyncHandlers = _globalThis[asyncHandlersKey] || (_globalThis[asyncHandlersKey] = /* @__PURE__ */ new Set());
function executeAsync(function_) {
  const restores = [];
  for (const leaveHandler of asyncHandlers) {
    const restore2 = leaveHandler();
    if (restore2) {
      restores.push(restore2);
    }
  }
  const restore = () => {
    for (const restore2 of restores) {
      restore2();
    }
  };
  let awaitable = function_();
  if (awaitable && typeof awaitable === "object" && "catch" in awaitable) {
    awaitable = awaitable.catch((error) => {
      restore();
      throw error;
    });
  }
  return [awaitable, restore];
}

getContext("nitro-app", {
  asyncContext: false,
  AsyncLocalStorage: void 0
});

const config = useRuntimeConfig();
const _routeRulesMatcher = toRouteMatcher(
  createRouter$1({ routes: config.nitro.routeRules })
);
function createRouteRulesHandler(ctx) {
  return eventHandler((event) => {
    const routeRules = getRouteRules(event);
    if (routeRules.headers) {
      setHeaders(event, routeRules.headers);
    }
    if (routeRules.redirect) {
      let target = routeRules.redirect.to;
      if (target.endsWith("/**")) {
        let targetPath = event.path;
        const strpBase = routeRules.redirect._redirectStripBase;
        if (strpBase) {
          targetPath = withoutBase(targetPath, strpBase);
        }
        target = joinURL(target.slice(0, -3), targetPath);
      } else if (event.path.includes("?")) {
        const query = getQuery$1(event.path);
        target = withQuery(target, query);
      }
      return sendRedirect(event, target, routeRules.redirect.statusCode);
    }
    if (routeRules.proxy) {
      let target = routeRules.proxy.to;
      if (target.endsWith("/**")) {
        let targetPath = event.path;
        const strpBase = routeRules.proxy._proxyStripBase;
        if (strpBase) {
          targetPath = withoutBase(targetPath, strpBase);
        }
        target = joinURL(target.slice(0, -3), targetPath);
      } else if (event.path.includes("?")) {
        const query = getQuery$1(event.path);
        target = withQuery(target, query);
      }
      return proxyRequest(event, target, {
        fetch: ctx.localFetch,
        ...routeRules.proxy
      });
    }
  });
}
function getRouteRules(event) {
  event.context._nitro = event.context._nitro || {};
  if (!event.context._nitro.routeRules) {
    event.context._nitro.routeRules = getRouteRulesForPath(
      withoutBase(event.path.split("?")[0], useRuntimeConfig().app.baseURL)
    );
  }
  return event.context._nitro.routeRules;
}
function getRouteRulesForPath(path) {
  return defu({}, ..._routeRulesMatcher.matchAll(path).reverse());
}

function _captureError(error, type) {
  console.error(`[${type}]`, error);
  useNitroApp().captureError(error, { tags: [type] });
}
function trapUnhandledNodeErrors() {
  process.on(
    "unhandledRejection",
    (error) => _captureError(error, "unhandledRejection")
  );
  process.on(
    "uncaughtException",
    (error) => _captureError(error, "uncaughtException")
  );
}
function joinHeaders(value) {
  return Array.isArray(value) ? value.join(", ") : String(value);
}
function normalizeFetchResponse(response) {
  if (!response.headers.has("set-cookie")) {
    return response;
  }
  return new Response(response.body, {
    status: response.status,
    statusText: response.statusText,
    headers: normalizeCookieHeaders(response.headers)
  });
}
function normalizeCookieHeader(header = "") {
  return splitCookiesString(joinHeaders(header));
}
function normalizeCookieHeaders(headers) {
  const outgoingHeaders = new Headers();
  for (const [name, header] of headers) {
    if (name === "set-cookie") {
      for (const cookie of normalizeCookieHeader(header)) {
        outgoingHeaders.append("set-cookie", cookie);
      }
    } else {
      outgoingHeaders.set(name, joinHeaders(header));
    }
  }
  return outgoingHeaders;
}

function isJsonRequest(event) {
  if (hasReqHeader(event, "accept", "text/html")) {
    return false;
  }
  return hasReqHeader(event, "accept", "application/json") || hasReqHeader(event, "user-agent", "curl/") || hasReqHeader(event, "user-agent", "httpie/") || hasReqHeader(event, "sec-fetch-mode", "cors") || event.path.startsWith("/api/") || event.path.endsWith(".json");
}
function hasReqHeader(event, name, includes) {
  const value = getRequestHeader(event, name);
  return value && typeof value === "string" && value.toLowerCase().includes(includes);
}

const errorHandler$0 = (async function errorhandler(error, event, { defaultHandler }) {
  if (isJsonRequest(event)) {
    return;
  }
  const defaultRes = await defaultHandler(error, event, { json: true });
  const statusCode = error.statusCode || 500;
  if (statusCode === 404 && defaultRes.status === 302) {
    setResponseHeaders(event, defaultRes.headers);
    setResponseStatus(event, defaultRes.status, defaultRes.statusText);
    return send(event, JSON.stringify(defaultRes.body, null, 2));
  }
  const errorObject = defaultRes.body;
  const url = new URL(errorObject.url);
  errorObject.url = url.pathname + url.search + url.hash;
  errorObject.message ||= "Server Error";
  errorObject.data ||= error.data;
  delete defaultRes.headers["content-type"];
  delete defaultRes.headers["content-security-policy"];
  setResponseHeaders(event, defaultRes.headers);
  const reqHeaders = getRequestHeaders(event);
  const isRenderingError = event.path.startsWith("/__nuxt_error") || !!reqHeaders["x-nuxt-error"];
  const res = isRenderingError ? null : await useNitroApp().localFetch(
    withQuery(joinURL(useRuntimeConfig(event).app.baseURL, "/__nuxt_error"), errorObject),
    {
      headers: { ...reqHeaders, "x-nuxt-error": "true" },
      redirect: "manual"
    }
  ).catch(() => null);
  if (event.handled) {
    return;
  }
  if (!res) {
    const { template } = await import('../_/error-500.mjs');
    setResponseHeader(event, "Content-Type", "text/html;charset=UTF-8");
    return send(event, template(errorObject));
  }
  const html = await res.text();
  for (const [header, value] of res.headers.entries()) {
    setResponseHeader(event, header, value);
  }
  setResponseStatus(event, res.status && res.status !== 200 ? res.status : defaultRes.status, res.statusText || defaultRes.statusText);
  return send(event, html);
});

function defineNitroErrorHandler(handler) {
  return handler;
}

const errorHandler$1 = defineNitroErrorHandler(
  function defaultNitroErrorHandler(error, event) {
    const res = defaultHandler(error, event);
    setResponseHeaders(event, res.headers);
    setResponseStatus(event, res.status, res.statusText);
    return send(event, JSON.stringify(res.body, null, 2));
  }
);
function defaultHandler(error, event, opts) {
  const isSensitive = error.unhandled || error.fatal;
  const statusCode = error.statusCode || 500;
  const statusMessage = error.statusMessage || "Server Error";
  const url = getRequestURL(event, { xForwardedHost: true, xForwardedProto: true });
  if (statusCode === 404) {
    const baseURL = "/";
    if (/^\/[^/]/.test(baseURL) && !url.pathname.startsWith(baseURL)) {
      const redirectTo = `${baseURL}${url.pathname.slice(1)}${url.search}`;
      return {
        status: 302,
        statusText: "Found",
        headers: { location: redirectTo },
        body: `Redirecting...`
      };
    }
  }
  if (isSensitive && !opts?.silent) {
    const tags = [error.unhandled && "[unhandled]", error.fatal && "[fatal]"].filter(Boolean).join(" ");
    console.error(`[request error] ${tags} [${event.method}] ${url}
`, error);
  }
  const headers = {
    "content-type": "application/json",
    // Prevent browser from guessing the MIME types of resources.
    "x-content-type-options": "nosniff",
    // Prevent error page from being embedded in an iframe
    "x-frame-options": "DENY",
    // Prevent browsers from sending the Referer header
    "referrer-policy": "no-referrer",
    // Disable the execution of any js
    "content-security-policy": "script-src 'none'; frame-ancestors 'none';"
  };
  setResponseStatus(event, statusCode, statusMessage);
  if (statusCode === 404 || !getResponseHeader(event, "cache-control")) {
    headers["cache-control"] = "no-cache";
  }
  const body = {
    error: true,
    url: url.href,
    statusCode,
    statusMessage,
    message: isSensitive ? "Server Error" : error.message,
    data: isSensitive ? void 0 : error.data
  };
  return {
    status: statusCode,
    statusText: statusMessage,
    headers,
    body
  };
}

const errorHandlers = [errorHandler$0, errorHandler$1];

async function errorHandler(error, event) {
  for (const handler of errorHandlers) {
    try {
      await handler(error, event, { defaultHandler });
      if (event.handled) {
        return; // Response handled
      }
    } catch(error) {
      // Handler itself thrown, log and continue
      console.error(error);
    }
  }
  // H3 will handle fallback
}

const plugins = [
  
];

const assets = {
  "/favicon.ico": {
    "type": "image/vnd.microsoft.icon",
    "etag": "\"10be-n8egyE9tcb7sKGr/pYCaQ4uWqxI\"",
    "mtime": "2025-04-13T20:04:20.457Z",
    "size": 4286,
    "path": "../public/favicon.ico"
  },
  "/robots.txt": {
    "type": "text/plain; charset=utf-8",
    "etag": "\"1-rcg7GeeTSRscbqD9i0bNnzLlkvw\"",
    "mtime": "2025-04-13T20:04:20.458Z",
    "size": 1,
    "path": "../public/robots.txt"
  },
  "/_nuxt/-HomBlpK.js": {
    "type": "text/javascript; charset=utf-8",
    "etag": "\"2539-kRGRZPDTPTFITJDIm73wcDaaiXE\"",
    "mtime": "2025-04-13T20:04:20.238Z",
    "size": 9529,
    "path": "../public/_nuxt/-HomBlpK.js"
  },
  "/_nuxt/-HomBlpK.js.br": {
    "type": "text/javascript; charset=utf-8",
    "encoding": "br",
    "etag": "\"780-uJmuL9UQavPHF5sw0MtSv8CzSew\"",
    "mtime": "2025-04-13T20:04:28.168Z",
    "size": 1920,
    "path": "../public/_nuxt/-HomBlpK.js.br"
  },
  "/_nuxt/-HomBlpK.js.gz": {
    "type": "text/javascript; charset=utf-8",
    "encoding": "gzip",
    "etag": "\"8d8-prJMFNUvFHF3hjXoF0UuohE+EAg\"",
    "mtime": "2025-04-13T20:04:28.168Z",
    "size": 2264,
    "path": "../public/_nuxt/-HomBlpK.js.gz"
  },
  "/_nuxt/2Ji2hjSP.js": {
    "type": "text/javascript; charset=utf-8",
    "etag": "\"b8-sUjaicoj+IxDK5v1pf3i4348rEU\"",
    "mtime": "2025-04-13T20:04:20.234Z",
    "size": 184,
    "path": "../public/_nuxt/2Ji2hjSP.js"
  },
  "/_nuxt/4dCJMJhO.js": {
    "type": "text/javascript; charset=utf-8",
    "etag": "\"12e-FKoAVDo7kpi0TCiW+WEGnY/Zctw\"",
    "mtime": "2025-04-13T20:04:20.235Z",
    "size": 302,
    "path": "../public/_nuxt/4dCJMJhO.js"
  },
  "/_nuxt/B0ERdj0v.js": {
    "type": "text/javascript; charset=utf-8",
    "etag": "\"bd-I6YRb8uYNqsN6cnrByOnoi5+/QQ\"",
    "mtime": "2025-04-13T20:04:20.234Z",
    "size": 189,
    "path": "../public/_nuxt/B0ERdj0v.js"
  },
  "/_nuxt/B2ZVkHJ9.js": {
    "type": "text/javascript; charset=utf-8",
    "etag": "\"b02-JFK6sqibAAWvRqILjkou6kCl+qE\"",
    "mtime": "2025-04-13T20:04:20.234Z",
    "size": 2818,
    "path": "../public/_nuxt/B2ZVkHJ9.js"
  },
  "/_nuxt/B2ZVkHJ9.js.br": {
    "type": "text/javascript; charset=utf-8",
    "encoding": "br",
    "etag": "\"4bb-7Xu+c/aSUBJOsKMQZ373FRsWgb8\"",
    "mtime": "2025-04-13T20:04:28.168Z",
    "size": 1211,
    "path": "../public/_nuxt/B2ZVkHJ9.js.br"
  },
  "/_nuxt/B2ZVkHJ9.js.gz": {
    "type": "text/javascript; charset=utf-8",
    "encoding": "gzip",
    "etag": "\"558-vmuwdU0HVUQFIauZF+oqGPlfA90\"",
    "mtime": "2025-04-13T20:04:28.168Z",
    "size": 1368,
    "path": "../public/_nuxt/B2ZVkHJ9.js.gz"
  },
  "/_nuxt/BADbGbBq.js": {
    "type": "text/javascript; charset=utf-8",
    "etag": "\"b5-pxYQ87bHUJeRK6aSQZUDpjD0K0Y\"",
    "mtime": "2025-04-13T20:04:20.235Z",
    "size": 181,
    "path": "../public/_nuxt/BADbGbBq.js"
  },
  "/_nuxt/BMS_J1Jh.js": {
    "type": "text/javascript; charset=utf-8",
    "etag": "\"fef-Ab+lELWo5ljjSkfF5PVEWxSyMT4\"",
    "mtime": "2025-04-13T20:04:20.235Z",
    "size": 4079,
    "path": "../public/_nuxt/BMS_J1Jh.js"
  },
  "/_nuxt/BMS_J1Jh.js.br": {
    "type": "text/javascript; charset=utf-8",
    "encoding": "br",
    "etag": "\"5ac-szRgKzSUbD8BayABI+a/5P+067s\"",
    "mtime": "2025-04-13T20:04:28.168Z",
    "size": 1452,
    "path": "../public/_nuxt/BMS_J1Jh.js.br"
  },
  "/_nuxt/BMS_J1Jh.js.gz": {
    "type": "text/javascript; charset=utf-8",
    "encoding": "gzip",
    "etag": "\"648-HLG0ua8xnk3O/eiPawa1Y8YsEz0\"",
    "mtime": "2025-04-13T20:04:28.168Z",
    "size": 1608,
    "path": "../public/_nuxt/BMS_J1Jh.js.gz"
  },
  "/_nuxt/BOsY_fpM.js": {
    "type": "text/javascript; charset=utf-8",
    "etag": "\"90-rn2eBWmd4E2JaKtJUmiGhQKuOPo\"",
    "mtime": "2025-04-13T20:04:20.235Z",
    "size": 144,
    "path": "../public/_nuxt/BOsY_fpM.js"
  },
  "/_nuxt/BRx2FcoZ.js": {
    "type": "text/javascript; charset=utf-8",
    "etag": "\"244-ApDdrTq7rmj0QEaW8SVtsY5LjBM\"",
    "mtime": "2025-04-13T20:04:20.235Z",
    "size": 580,
    "path": "../public/_nuxt/BRx2FcoZ.js"
  },
  "/_nuxt/BSSgtSzF.js": {
    "type": "text/javascript; charset=utf-8",
    "etag": "\"33b0-oHrzww/bdoRi+9jm+yOzv9xjq+U\"",
    "mtime": "2025-04-13T20:04:20.235Z",
    "size": 13232,
    "path": "../public/_nuxt/BSSgtSzF.js"
  },
  "/_nuxt/BSSgtSzF.js.br": {
    "type": "text/javascript; charset=utf-8",
    "encoding": "br",
    "etag": "\"1108-u98sTuwC94wtvGaw7cfjhRIsaDM\"",
    "mtime": "2025-04-13T20:04:28.168Z",
    "size": 4360,
    "path": "../public/_nuxt/BSSgtSzF.js.br"
  },
  "/_nuxt/BSSgtSzF.js.gz": {
    "type": "text/javascript; charset=utf-8",
    "encoding": "gzip",
    "etag": "\"1333-d9p8aQdlvqKP4oQuHugihyYs4GE\"",
    "mtime": "2025-04-13T20:04:28.168Z",
    "size": 4915,
    "path": "../public/_nuxt/BSSgtSzF.js.gz"
  },
  "/_nuxt/B_7cymdU.js": {
    "type": "text/javascript; charset=utf-8",
    "etag": "\"3d53-lS0ZtgdltR8osU5Rt+l+KY0N1G4\"",
    "mtime": "2025-04-13T20:04:20.235Z",
    "size": 15699,
    "path": "../public/_nuxt/B_7cymdU.js"
  },
  "/_nuxt/B_7cymdU.js.br": {
    "type": "text/javascript; charset=utf-8",
    "encoding": "br",
    "etag": "\"156e-gr4t3uavnSXAR6S+MTCB30Dg6H0\"",
    "mtime": "2025-04-13T20:04:28.168Z",
    "size": 5486,
    "path": "../public/_nuxt/B_7cymdU.js.br"
  },
  "/_nuxt/B_7cymdU.js.gz": {
    "type": "text/javascript; charset=utf-8",
    "encoding": "gzip",
    "etag": "\"17f8-nMDSUBEfBxIL74JurzjDTT06PWE\"",
    "mtime": "2025-04-13T20:04:28.168Z",
    "size": 6136,
    "path": "../public/_nuxt/B_7cymdU.js.gz"
  },
  "/_nuxt/Bf0wYg_a.js": {
    "type": "text/javascript; charset=utf-8",
    "etag": "\"68862-uVzaZZs84qxKiDIyzrTI6XrtngE\"",
    "mtime": "2025-04-13T20:04:20.236Z",
    "size": 428130,
    "path": "../public/_nuxt/Bf0wYg_a.js"
  },
  "/_nuxt/Bf0wYg_a.js.br": {
    "type": "text/javascript; charset=utf-8",
    "encoding": "br",
    "etag": "\"1feec-IFe8PHp1sIt5OUAv2849eY4fv8k\"",
    "mtime": "2025-04-13T20:04:28.768Z",
    "size": 130796,
    "path": "../public/_nuxt/Bf0wYg_a.js.br"
  },
  "/_nuxt/Bf0wYg_a.js.gz": {
    "type": "text/javascript; charset=utf-8",
    "encoding": "gzip",
    "etag": "\"24a72-rCUEX43oCYOFD9LyMyavVEaeEfI\"",
    "mtime": "2025-04-13T20:04:28.775Z",
    "size": 150130,
    "path": "../public/_nuxt/Bf0wYg_a.js.gz"
  },
  "/_nuxt/Bi3dL5Qu.js": {
    "type": "text/javascript; charset=utf-8",
    "etag": "\"23e-Pd8b5tagwednerOidgCISxd1yUA\"",
    "mtime": "2025-04-13T20:04:20.235Z",
    "size": 574,
    "path": "../public/_nuxt/Bi3dL5Qu.js"
  },
  "/_nuxt/BlrMpAWF.js": {
    "type": "text/javascript; charset=utf-8",
    "etag": "\"46-Zbt6idrqx+nxAc/Nu0A7qzTH73k\"",
    "mtime": "2025-04-13T20:04:20.235Z",
    "size": 70,
    "path": "../public/_nuxt/BlrMpAWF.js"
  },
  "/_nuxt/Breadcrumb.sI_qvYTB.css": {
    "type": "text/css; charset=utf-8",
    "etag": "\"79-VQs0aJGCRjZJOUbi8FkbZksQ7lY\"",
    "mtime": "2025-04-13T20:04:20.235Z",
    "size": 121,
    "path": "../public/_nuxt/Breadcrumb.sI_qvYTB.css"
  },
  "/_nuxt/BrfcDoz-.js": {
    "type": "text/javascript; charset=utf-8",
    "etag": "\"b5-rM5oqYadQJISArt/0e4bfAase9M\"",
    "mtime": "2025-04-13T20:04:20.235Z",
    "size": 181,
    "path": "../public/_nuxt/BrfcDoz-.js"
  },
  "/_nuxt/C-KbvJuz.js": {
    "type": "text/javascript; charset=utf-8",
    "etag": "\"b5-TV58sQvRv7f1gfYHBdEovuARcDI\"",
    "mtime": "2025-04-13T20:04:20.235Z",
    "size": 181,
    "path": "../public/_nuxt/C-KbvJuz.js"
  },
  "/_nuxt/C5yyholK.js": {
    "type": "text/javascript; charset=utf-8",
    "etag": "\"bf-UOrsS0M7y2nbAckSFFVRdr5hgNo\"",
    "mtime": "2025-04-13T20:04:20.235Z",
    "size": 191,
    "path": "../public/_nuxt/C5yyholK.js"
  },
  "/_nuxt/CAOKANvW.js": {
    "type": "text/javascript; charset=utf-8",
    "etag": "\"b8-sP5Rsd41Sgy21vBSuDERWkgcfvc\"",
    "mtime": "2025-04-13T20:04:20.235Z",
    "size": 184,
    "path": "../public/_nuxt/CAOKANvW.js"
  },
  "/_nuxt/CAOLsjJ0.js": {
    "type": "text/javascript; charset=utf-8",
    "etag": "\"ecb-3FhvQ4SjBkfc17qcHDnbn4dtfI8\"",
    "mtime": "2025-04-13T20:04:20.235Z",
    "size": 3787,
    "path": "../public/_nuxt/CAOLsjJ0.js"
  },
  "/_nuxt/CAOLsjJ0.js.br": {
    "type": "text/javascript; charset=utf-8",
    "encoding": "br",
    "etag": "\"5c5-gSsMSC4Y38PjO2pflkIMevL8jYM\"",
    "mtime": "2025-04-13T20:04:28.168Z",
    "size": 1477,
    "path": "../public/_nuxt/CAOLsjJ0.js.br"
  },
  "/_nuxt/CAOLsjJ0.js.gz": {
    "type": "text/javascript; charset=utf-8",
    "encoding": "gzip",
    "etag": "\"6b4-crS0YutYEIyssB8AKd0WW1J4ryM\"",
    "mtime": "2025-04-13T20:04:28.168Z",
    "size": 1716,
    "path": "../public/_nuxt/CAOLsjJ0.js.gz"
  },
  "/_nuxt/CATQa-ID.js": {
    "type": "text/javascript; charset=utf-8",
    "etag": "\"16b-3Qlxkh9rtbhKX0YqABCclBEO7gw\"",
    "mtime": "2025-04-13T20:04:20.235Z",
    "size": 363,
    "path": "../public/_nuxt/CATQa-ID.js"
  },
  "/_nuxt/CPZJpq_H.js": {
    "type": "text/javascript; charset=utf-8",
    "etag": "\"244-CjmIWz68A7kZlMS7itcvkFxKhKk\"",
    "mtime": "2025-04-13T20:04:20.235Z",
    "size": 580,
    "path": "../public/_nuxt/CPZJpq_H.js"
  },
  "/_nuxt/CZKFgv1H.js": {
    "type": "text/javascript; charset=utf-8",
    "etag": "\"b5-UKABoLjWQv8foCE6Ec9bBiAlI78\"",
    "mtime": "2025-04-13T20:04:20.235Z",
    "size": 181,
    "path": "../public/_nuxt/CZKFgv1H.js"
  },
  "/_nuxt/CdM4lceZ.js": {
    "type": "text/javascript; charset=utf-8",
    "etag": "\"1a4-Xgxvx4K8PP59/KmbkVCAf8xyHT0\"",
    "mtime": "2025-04-13T20:04:20.236Z",
    "size": 420,
    "path": "../public/_nuxt/CdM4lceZ.js"
  },
  "/_nuxt/CzkjWvq9.js": {
    "type": "text/javascript; charset=utf-8",
    "etag": "\"b5-GQdeN0MPIJRQWFzxxpQsx1afzxY\"",
    "mtime": "2025-04-13T20:04:20.236Z",
    "size": 181,
    "path": "../public/_nuxt/CzkjWvq9.js"
  },
  "/_nuxt/D1cYgsm-.js": {
    "type": "text/javascript; charset=utf-8",
    "etag": "\"b5-P94HQ1VSG4n1oCDO5UV9qJkajrQ\"",
    "mtime": "2025-04-13T20:04:20.236Z",
    "size": 181,
    "path": "../public/_nuxt/D1cYgsm-.js"
  },
  "/_nuxt/D2L8iJiY.js": {
    "type": "text/javascript; charset=utf-8",
    "etag": "\"d2-0ahVBTLyKv2eiBd26zIGylg9vSo\"",
    "mtime": "2025-04-13T20:04:20.236Z",
    "size": 210,
    "path": "../public/_nuxt/D2L8iJiY.js"
  },
  "/_nuxt/D4mVw2Tx.js": {
    "type": "text/javascript; charset=utf-8",
    "etag": "\"681-HOl5yEsLxHhUoDQEd95yFBvij1g\"",
    "mtime": "2025-04-13T20:04:20.236Z",
    "size": 1665,
    "path": "../public/_nuxt/D4mVw2Tx.js"
  },
  "/_nuxt/D4mVw2Tx.js.br": {
    "type": "text/javascript; charset=utf-8",
    "encoding": "br",
    "etag": "\"2dc-CMjKoR/qGQelNHwHzsyPN6lStkM\"",
    "mtime": "2025-04-13T20:04:28.168Z",
    "size": 732,
    "path": "../public/_nuxt/D4mVw2Tx.js.br"
  },
  "/_nuxt/D4mVw2Tx.js.gz": {
    "type": "text/javascript; charset=utf-8",
    "encoding": "gzip",
    "etag": "\"33b-o8rbQavCdN0kmFLh+TcY72zOOA8\"",
    "mtime": "2025-04-13T20:04:28.168Z",
    "size": 827,
    "path": "../public/_nuxt/D4mVw2Tx.js.gz"
  },
  "/_nuxt/DAFVMwd_.js": {
    "type": "text/javascript; charset=utf-8",
    "etag": "\"b8-IJ14nEf50EYsK89F9tESMGfUMek\"",
    "mtime": "2025-04-13T20:04:20.236Z",
    "size": 184,
    "path": "../public/_nuxt/DAFVMwd_.js"
  },
  "/_nuxt/DAsx8NZ-.js": {
    "type": "text/javascript; charset=utf-8",
    "etag": "\"60-r/3nApIU8FTwnClZ8KBe/Mdfxjo\"",
    "mtime": "2025-04-13T20:04:20.236Z",
    "size": 96,
    "path": "../public/_nuxt/DAsx8NZ-.js"
  },
  "/_nuxt/DCcbgNMx.js": {
    "type": "text/javascript; charset=utf-8",
    "etag": "\"1cf0-+oBV0HjE0QIDWP57+6HoNhrJSzY\"",
    "mtime": "2025-04-13T20:04:20.236Z",
    "size": 7408,
    "path": "../public/_nuxt/DCcbgNMx.js"
  },
  "/_nuxt/DCcbgNMx.js.br": {
    "type": "text/javascript; charset=utf-8",
    "encoding": "br",
    "etag": "\"a97-Ppvvxt4JaVaDxfjouGTj5dGSh6E\"",
    "mtime": "2025-04-13T20:04:28.168Z",
    "size": 2711,
    "path": "../public/_nuxt/DCcbgNMx.js.br"
  },
  "/_nuxt/DCcbgNMx.js.gz": {
    "type": "text/javascript; charset=utf-8",
    "encoding": "gzip",
    "etag": "\"be7-zUYCpAY+cM36YSr8bc5r1x1ci6Y\"",
    "mtime": "2025-04-13T20:04:28.168Z",
    "size": 3047,
    "path": "../public/_nuxt/DCcbgNMx.js.gz"
  },
  "/_nuxt/DGhvJ2pS.js": {
    "type": "text/javascript; charset=utf-8",
    "etag": "\"1e24-l9s2VNeOh2qjokKVrYIzDZDnFPI\"",
    "mtime": "2025-04-13T20:04:20.236Z",
    "size": 7716,
    "path": "../public/_nuxt/DGhvJ2pS.js"
  },
  "/_nuxt/DGhvJ2pS.js.br": {
    "type": "text/javascript; charset=utf-8",
    "encoding": "br",
    "etag": "\"bc2-8GqznCy3Znj6yxu90ca1EH8uBqo\"",
    "mtime": "2025-04-13T20:04:28.168Z",
    "size": 3010,
    "path": "../public/_nuxt/DGhvJ2pS.js.br"
  },
  "/_nuxt/DGhvJ2pS.js.gz": {
    "type": "text/javascript; charset=utf-8",
    "encoding": "gzip",
    "etag": "\"d0d-LorUWG9uELnVfQ3pkezg3ZhyQIo\"",
    "mtime": "2025-04-13T20:04:28.168Z",
    "size": 3341,
    "path": "../public/_nuxt/DGhvJ2pS.js.gz"
  },
  "/_nuxt/DKHyp5X4.js": {
    "type": "text/javascript; charset=utf-8",
    "etag": "\"244-LukRZkJLFMnIF2Rx44M6HD0C4K8\"",
    "mtime": "2025-04-13T20:04:20.236Z",
    "size": 580,
    "path": "../public/_nuxt/DKHyp5X4.js"
  },
  "/_nuxt/DNnhE-Ez.js": {
    "type": "text/javascript; charset=utf-8",
    "etag": "\"9d2-vt01XmKwrinH6KCKl2Pv0wqQT1Y\"",
    "mtime": "2025-04-13T20:04:20.236Z",
    "size": 2514,
    "path": "../public/_nuxt/DNnhE-Ez.js"
  },
  "/_nuxt/DNnhE-Ez.js.br": {
    "type": "text/javascript; charset=utf-8",
    "encoding": "br",
    "etag": "\"2d5-ONW0XMiuF59+6pi2OP2hywJTIhU\"",
    "mtime": "2025-04-13T20:04:28.168Z",
    "size": 725,
    "path": "../public/_nuxt/DNnhE-Ez.js.br"
  },
  "/_nuxt/DNnhE-Ez.js.gz": {
    "type": "text/javascript; charset=utf-8",
    "encoding": "gzip",
    "etag": "\"35a-58zJYbUhm8DahbuJvemc9uDgwCY\"",
    "mtime": "2025-04-13T20:04:28.168Z",
    "size": 858,
    "path": "../public/_nuxt/DNnhE-Ez.js.gz"
  },
  "/_nuxt/DdN_sZIE.js": {
    "type": "text/javascript; charset=utf-8",
    "etag": "\"186-H0hy4Ut7oCDLAC9OhRj6O1YwLw0\"",
    "mtime": "2025-04-13T20:04:20.236Z",
    "size": 390,
    "path": "../public/_nuxt/DdN_sZIE.js"
  },
  "/_nuxt/Di2dF8BE.js": {
    "type": "text/javascript; charset=utf-8",
    "etag": "\"b4-8SqpMDiFV5xaeemaYr2Vk+OutAU\"",
    "mtime": "2025-04-13T20:04:20.236Z",
    "size": 180,
    "path": "../public/_nuxt/Di2dF8BE.js"
  },
  "/_nuxt/Ht5Sbuk6.js": {
    "type": "text/javascript; charset=utf-8",
    "etag": "\"d54-cOH/m0JLPYJKJ43EmYJYS/axzqQ\"",
    "mtime": "2025-04-13T20:04:20.237Z",
    "size": 3412,
    "path": "../public/_nuxt/Ht5Sbuk6.js"
  },
  "/_nuxt/Ht5Sbuk6.js.br": {
    "type": "text/javascript; charset=utf-8",
    "encoding": "br",
    "etag": "\"526-R4RRzHUda3mfBZuS2L74PiBp8qE\"",
    "mtime": "2025-04-13T20:04:28.168Z",
    "size": 1318,
    "path": "../public/_nuxt/Ht5Sbuk6.js.br"
  },
  "/_nuxt/Ht5Sbuk6.js.gz": {
    "type": "text/javascript; charset=utf-8",
    "encoding": "gzip",
    "etag": "\"604-yJVFN7dvioeJ09trwioG8DWfemY\"",
    "mtime": "2025-04-13T20:04:28.168Z",
    "size": 1540,
    "path": "../public/_nuxt/Ht5Sbuk6.js.gz"
  },
  "/_nuxt/IuOQEkHU.js": {
    "type": "text/javascript; charset=utf-8",
    "etag": "\"b5-WIg9ke8XYDNtqdqbrodRCv2QhtM\"",
    "mtime": "2025-04-13T20:04:20.237Z",
    "size": 181,
    "path": "../public/_nuxt/IuOQEkHU.js"
  },
  "/_nuxt/Oscq2lOj.js": {
    "type": "text/javascript; charset=utf-8",
    "etag": "\"3c08-Z8v/r6nfqx3kduFQNTNZTFBGtJA\"",
    "mtime": "2025-04-13T20:04:20.237Z",
    "size": 15368,
    "path": "../public/_nuxt/Oscq2lOj.js"
  },
  "/_nuxt/Oscq2lOj.js.br": {
    "type": "text/javascript; charset=utf-8",
    "encoding": "br",
    "etag": "\"c53-Rcvurpz+KTIKkd9buOUb/qDOwUA\"",
    "mtime": "2025-04-13T20:04:28.168Z",
    "size": 3155,
    "path": "../public/_nuxt/Oscq2lOj.js.br"
  },
  "/_nuxt/Oscq2lOj.js.gz": {
    "type": "text/javascript; charset=utf-8",
    "encoding": "gzip",
    "etag": "\"eb7-xFu2a2CcYLbP8kdc91JivWibgCM\"",
    "mtime": "2025-04-13T20:04:28.168Z",
    "size": 3767,
    "path": "../public/_nuxt/Oscq2lOj.js.gz"
  },
  "/_nuxt/ProsePre.D5orA6B_.css": {
    "type": "text/css; charset=utf-8",
    "etag": "\"1e-jczvRAVUXbzGL6yotozKFbyMO4s\"",
    "mtime": "2025-04-13T20:04:20.237Z",
    "size": 30,
    "path": "../public/_nuxt/ProsePre.D5orA6B_.css"
  },
  "/_nuxt/QUFgyHbi.js": {
    "type": "text/javascript; charset=utf-8",
    "etag": "\"165c-u8T3D4NOH6rpbt3+xmgjTbS8Pao\"",
    "mtime": "2025-04-13T20:04:20.237Z",
    "size": 5724,
    "path": "../public/_nuxt/QUFgyHbi.js"
  },
  "/_nuxt/QUFgyHbi.js.br": {
    "type": "text/javascript; charset=utf-8",
    "encoding": "br",
    "etag": "\"7f2-cdTFKTSx0YvIJ0fUd0zd8uee+zQ\"",
    "mtime": "2025-04-13T20:04:28.168Z",
    "size": 2034,
    "path": "../public/_nuxt/QUFgyHbi.js.br"
  },
  "/_nuxt/QUFgyHbi.js.gz": {
    "type": "text/javascript; charset=utf-8",
    "encoding": "gzip",
    "etag": "\"8ad-LxObsEQ/LbJwr9ePQx2XtdK6DX8\"",
    "mtime": "2025-04-13T20:04:28.168Z",
    "size": 2221,
    "path": "../public/_nuxt/QUFgyHbi.js.gz"
  },
  "/_nuxt/RRgUVd9G.js": {
    "type": "text/javascript; charset=utf-8",
    "etag": "\"1d6-Sjp7sk7weUcIVEJFXtylT0xGq14\"",
    "mtime": "2025-04-13T20:04:20.237Z",
    "size": 470,
    "path": "../public/_nuxt/RRgUVd9G.js"
  },
  "/_nuxt/VFl0Pz6e.js": {
    "type": "text/javascript; charset=utf-8",
    "etag": "\"244-CUaDl21BLvD9JJZ/5N2nH+6yvGI\"",
    "mtime": "2025-04-13T20:04:20.237Z",
    "size": 580,
    "path": "../public/_nuxt/VFl0Pz6e.js"
  },
  "/_nuxt/_Kr3am-M.js": {
    "type": "text/javascript; charset=utf-8",
    "etag": "\"244-B0quZnfcqq8KX8H1z1gL/SMkBCM\"",
    "mtime": "2025-04-13T20:04:20.237Z",
    "size": 580,
    "path": "../public/_nuxt/_Kr3am-M.js"
  },
  "/_nuxt/entry.CW1aRY9k.css": {
    "type": "text/css; charset=utf-8",
    "etag": "\"1bf2-Dg09G8rtcTe9bhspF0GGgYaO3HU\"",
    "mtime": "2025-04-13T20:04:20.237Z",
    "size": 7154,
    "path": "../public/_nuxt/entry.CW1aRY9k.css"
  },
  "/_nuxt/entry.CW1aRY9k.css.br": {
    "type": "text/css; charset=utf-8",
    "encoding": "br",
    "etag": "\"60c-MP01lozaBwJ2gUPxVW9y4cYB03c\"",
    "mtime": "2025-04-13T20:04:28.168Z",
    "size": 1548,
    "path": "../public/_nuxt/entry.CW1aRY9k.css.br"
  },
  "/_nuxt/entry.CW1aRY9k.css.gz": {
    "type": "text/css; charset=utf-8",
    "encoding": "gzip",
    "etag": "\"6f7-Nk/ZUEroLl15u4Qm/7tss1lDO50\"",
    "mtime": "2025-04-13T20:04:28.168Z",
    "size": 1783,
    "path": "../public/_nuxt/entry.CW1aRY9k.css.gz"
  },
  "/_nuxt/error-404.aNCZ2L4y.css": {
    "type": "text/css; charset=utf-8",
    "etag": "\"de4-d5CwDtpWnHUpXaML+72tom/eiuo\"",
    "mtime": "2025-04-13T20:04:20.237Z",
    "size": 3556,
    "path": "../public/_nuxt/error-404.aNCZ2L4y.css"
  },
  "/_nuxt/error-404.aNCZ2L4y.css.br": {
    "type": "text/css; charset=utf-8",
    "encoding": "br",
    "etag": "\"3aa-CtzKZPMOexZShC6PmQzqIKdZLa4\"",
    "mtime": "2025-04-13T20:04:28.168Z",
    "size": 938,
    "path": "../public/_nuxt/error-404.aNCZ2L4y.css.br"
  },
  "/_nuxt/error-404.aNCZ2L4y.css.gz": {
    "type": "text/css; charset=utf-8",
    "encoding": "gzip",
    "etag": "\"446-pJugiepZlgbJuj+hkKbJLro/QaA\"",
    "mtime": "2025-04-13T20:04:28.168Z",
    "size": 1094,
    "path": "../public/_nuxt/error-404.aNCZ2L4y.css.gz"
  },
  "/_nuxt/error-500.JESWioAZ.css": {
    "type": "text/css; charset=utf-8",
    "etag": "\"75c-fV/Kpv7gKQASn2YR5DW+3G4yaD4\"",
    "mtime": "2025-04-13T20:04:20.238Z",
    "size": 1884,
    "path": "../public/_nuxt/error-500.JESWioAZ.css"
  },
  "/_nuxt/error-500.JESWioAZ.css.br": {
    "type": "text/css; charset=utf-8",
    "encoding": "br",
    "etag": "\"269-/ipgUH/QKz0WeiwMAKSOUJLnqQ4\"",
    "mtime": "2025-04-13T20:04:28.168Z",
    "size": 617,
    "path": "../public/_nuxt/error-500.JESWioAZ.css.br"
  },
  "/_nuxt/error-500.JESWioAZ.css.gz": {
    "type": "text/css; charset=utf-8",
    "encoding": "gzip",
    "etag": "\"2d2-qw6jaUJsijMc18d0xOTsMUjtZWk\"",
    "mtime": "2025-04-13T20:04:28.168Z",
    "size": 722,
    "path": "../public/_nuxt/error-500.JESWioAZ.css.gz"
  },
  "/_nuxt/gHd9nasn.js": {
    "type": "text/javascript; charset=utf-8",
    "etag": "\"b7-Fjz95/I1oSuUfGGxvxfrgSmweNA\"",
    "mtime": "2025-04-13T20:04:20.237Z",
    "size": 183,
    "path": "../public/_nuxt/gHd9nasn.js"
  },
  "/_nuxt/index.COFzBQFV.css": {
    "type": "text/css; charset=utf-8",
    "etag": "\"6c-/v3aVVP6/S7F7WYF2M/u4oTeUhg\"",
    "mtime": "2025-04-13T20:04:20.237Z",
    "size": 108,
    "path": "../public/_nuxt/index.COFzBQFV.css"
  },
  "/_nuxt/login.lmsSB5-T.css": {
    "type": "text/css; charset=utf-8",
    "etag": "\"4a1-JBQR2zI0FVksSaakKFbohwdjXiY\"",
    "mtime": "2025-04-13T20:04:20.237Z",
    "size": 1185,
    "path": "../public/_nuxt/login.lmsSB5-T.css"
  },
  "/_nuxt/login.lmsSB5-T.css.br": {
    "type": "text/css; charset=utf-8",
    "encoding": "br",
    "etag": "\"14a-CSACKvrMU+49XjY0hzW815RNnO4\"",
    "mtime": "2025-04-13T20:04:28.168Z",
    "size": 330,
    "path": "../public/_nuxt/login.lmsSB5-T.css.br"
  },
  "/_nuxt/login.lmsSB5-T.css.gz": {
    "type": "text/css; charset=utf-8",
    "encoding": "gzip",
    "etag": "\"1b2-PRt1OeWnnD1MsRGN/7TnZhaNaMo\"",
    "mtime": "2025-04-13T20:04:28.168Z",
    "size": 434,
    "path": "../public/_nuxt/login.lmsSB5-T.css.gz"
  },
  "/_nuxt/s-8COIhl.js": {
    "type": "text/javascript; charset=utf-8",
    "etag": "\"b9-hPlJc4lnd5u19u98oJDd7EF7aYA\"",
    "mtime": "2025-04-13T20:04:20.237Z",
    "size": 185,
    "path": "../public/_nuxt/s-8COIhl.js"
  },
  "/_nuxt/useApiDelete.OsdN_d7k.css": {
    "type": "text/css; charset=utf-8",
    "etag": "\"180-ikjTMsWiWxmNSeAhdMY8UoQWuag\"",
    "mtime": "2025-04-13T20:04:20.238Z",
    "size": 384,
    "path": "../public/_nuxt/useApiDelete.OsdN_d7k.css"
  },
  "/app-assets/css/bootstrap-extended.min.css": {
    "type": "text/css; charset=utf-8",
    "etag": "\"13fd0-KYGGYojBnOD9QSuC8pMJJnxJmgM\"",
    "mtime": "2025-04-13T20:04:20.322Z",
    "size": 81872,
    "path": "../public/app-assets/css/bootstrap-extended.min.css"
  },
  "/app-assets/css/bootstrap-extended.min.css.br": {
    "type": "text/css; charset=utf-8",
    "encoding": "br",
    "etag": "\"2915-ioweVjfWfaU/1//fOTyfeF7k+hA\"",
    "mtime": "2025-04-13T20:04:28.214Z",
    "size": 10517,
    "path": "../public/app-assets/css/bootstrap-extended.min.css.br"
  },
  "/app-assets/css/bootstrap-extended.min.css.gz": {
    "type": "text/css; charset=utf-8",
    "encoding": "gzip",
    "etag": "\"2f52-Lx8b8oMQZN1IWkA3a9B0hbzY9nE\"",
    "mtime": "2025-04-13T20:04:28.214Z",
    "size": 12114,
    "path": "../public/app-assets/css/bootstrap-extended.min.css.gz"
  },
  "/app-assets/css/bootstrap.min.css": {
    "type": "text/css; charset=utf-8",
    "etag": "\"2e042-Xm9nOYKM/QXG/7ptIJl72kxzQH0\"",
    "mtime": "2025-04-13T20:04:20.332Z",
    "size": 188482,
    "path": "../public/app-assets/css/bootstrap.min.css"
  },
  "/app-assets/css/bootstrap.min.css.br": {
    "type": "text/css; charset=utf-8",
    "encoding": "br",
    "etag": "\"48c9-TG/W1qcwB7kCAGg6Uy/oqOPEryM\"",
    "mtime": "2025-04-13T20:04:28.574Z",
    "size": 18633,
    "path": "../public/app-assets/css/bootstrap.min.css.br"
  },
  "/app-assets/css/bootstrap.min.css.gz": {
    "type": "text/css; charset=utf-8",
    "encoding": "gzip",
    "etag": "\"6612-tTZQTq9yKjneVlRWoQlFDLRXjqI\"",
    "mtime": "2025-04-13T20:04:28.574Z",
    "size": 26130,
    "path": "../public/app-assets/css/bootstrap.min.css.gz"
  },
  "/app-assets/css/colors.min.css": {
    "type": "text/css; charset=utf-8",
    "etag": "\"2ce40-2RGNC/SCby4JGIhz7k29eFA3jyg\"",
    "mtime": "2025-04-13T20:04:20.332Z",
    "size": 183872,
    "path": "../public/app-assets/css/colors.min.css"
  },
  "/app-assets/css/colors.min.css.br": {
    "type": "text/css; charset=utf-8",
    "encoding": "br",
    "etag": "\"2b25-rFVqY4ircTfYk2V8iKNBRt1YeJk\"",
    "mtime": "2025-04-13T20:04:28.215Z",
    "size": 11045,
    "path": "../public/app-assets/css/colors.min.css.br"
  },
  "/app-assets/css/colors.min.css.gz": {
    "type": "text/css; charset=utf-8",
    "encoding": "gzip",
    "etag": "\"3c1c-8G9SW462Ev1Sg7eamR/dazhrsKs\"",
    "mtime": "2025-04-13T20:04:28.215Z",
    "size": 15388,
    "path": "../public/app-assets/css/colors.min.css.gz"
  },
  "/app-assets/css/components.min.css": {
    "type": "text/css; charset=utf-8",
    "etag": "\"13166-upB93rUrZpsiDNSG8IKHJEiPGsM\"",
    "mtime": "2025-04-13T20:04:20.333Z",
    "size": 78182,
    "path": "../public/app-assets/css/components.min.css"
  },
  "/app-assets/css/components.min.css.br": {
    "type": "text/css; charset=utf-8",
    "encoding": "br",
    "etag": "\"279c-QYaSmVV/rL+BGSbZc2PMD4Pr+A0\"",
    "mtime": "2025-04-13T20:04:28.214Z",
    "size": 10140,
    "path": "../public/app-assets/css/components.min.css.br"
  },
  "/app-assets/css/components.min.css.gz": {
    "type": "text/css; charset=utf-8",
    "encoding": "gzip",
    "etag": "\"2eb7-3KIKv6RRxyVNjCmVglHHYVhj+Jc\"",
    "mtime": "2025-04-13T20:04:28.214Z",
    "size": 11959,
    "path": "../public/app-assets/css/components.min.css.gz"
  },
  "/app-assets/data/ajax.php": {
    "type": "application/x-httpd-php",
    "etag": "\"2393-NhMKwNCLV4OIlPsxkZnZ3LHlRvY\"",
    "mtime": "2025-04-13T20:04:20.333Z",
    "size": 9107,
    "path": "../public/app-assets/data/ajax.php"
  },
  "/app-assets/data/invoice-list.json": {
    "type": "application/json",
    "etag": "\"4788-/i79xI+t+royxY9gTbkwqanRVH4\"",
    "mtime": "2025-04-13T20:04:20.332Z",
    "size": 18312,
    "path": "../public/app-assets/data/invoice-list.json"
  },
  "/app-assets/data/invoice-list.json.br": {
    "type": "application/json",
    "encoding": "br",
    "etag": "\"789-efyJdVHoeIqlQT3tWCXRp2BMJ7w\"",
    "mtime": "2025-04-13T20:04:28.214Z",
    "size": 1929,
    "path": "../public/app-assets/data/invoice-list.json.br"
  },
  "/app-assets/data/invoice-list.json.gz": {
    "type": "application/json",
    "encoding": "gzip",
    "etag": "\"922-onCgfIDSO4O1slmlvBmiamt6KYc\"",
    "mtime": "2025-04-13T20:04:28.168Z",
    "size": 2338,
    "path": "../public/app-assets/data/invoice-list.json.gz"
  },
  "/app-assets/data/jstree-data.json": {
    "type": "application/json",
    "etag": "\"2da-ka5nWhzdz31pzacnJAI5L2os750\"",
    "mtime": "2025-04-13T20:04:20.333Z",
    "size": 730,
    "path": "../public/app-assets/data/jstree-data.json"
  },
  "/app-assets/data/kanban.json": {
    "type": "application/json",
    "etag": "\"97a-1AVkEWwHQIo36oAvZh9sJgBJymQ\"",
    "mtime": "2025-04-13T20:04:20.333Z",
    "size": 2426,
    "path": "../public/app-assets/data/kanban.json"
  },
  "/app-assets/data/kanban.json.br": {
    "type": "application/json",
    "encoding": "br",
    "etag": "\"1ce-IOPzMGy78NkSJze8sOdWavW2iq4\"",
    "mtime": "2025-04-13T20:04:28.214Z",
    "size": 462,
    "path": "../public/app-assets/data/kanban.json.br"
  },
  "/app-assets/data/kanban.json.gz": {
    "type": "application/json",
    "encoding": "gzip",
    "etag": "\"23b-Cjz8mt9S5bNaMuwlOEHTMJ20U/g\"",
    "mtime": "2025-04-13T20:04:28.214Z",
    "size": 571,
    "path": "../public/app-assets/data/kanban.json.gz"
  },
  "/app-assets/data/permissions-list.json": {
    "type": "application/json",
    "etag": "\"644-GcF9KyYFoVRlFYc3fsAsBOWzVjA\"",
    "mtime": "2025-04-13T20:04:20.333Z",
    "size": 1604,
    "path": "../public/app-assets/data/permissions-list.json"
  },
  "/app-assets/data/permissions-list.json.br": {
    "type": "application/json",
    "encoding": "br",
    "etag": "\"14c-lPwCsqomy3p8XETB1ufGihR8btA\"",
    "mtime": "2025-04-13T20:04:28.214Z",
    "size": 332,
    "path": "../public/app-assets/data/permissions-list.json.br"
  },
  "/app-assets/data/permissions-list.json.gz": {
    "type": "application/json",
    "encoding": "gzip",
    "etag": "\"194-E4/AFw1eG67cTo5CTnHDYn9M+Ac\"",
    "mtime": "2025-04-13T20:04:28.214Z",
    "size": 404,
    "path": "../public/app-assets/data/permissions-list.json.gz"
  },
  "/app-assets/data/projects-list.json": {
    "type": "application/json",
    "etag": "\"925-X6WtzbGPQvrvQqs6VcVFygmQ/AY\"",
    "mtime": "2025-04-13T20:04:20.333Z",
    "size": 2341,
    "path": "../public/app-assets/data/projects-list.json"
  },
  "/app-assets/data/projects-list.json.br": {
    "type": "application/json",
    "encoding": "br",
    "etag": "\"1a6-Dakw0J9zTlt9hw4yUAdfK0VYexo\"",
    "mtime": "2025-04-13T20:04:28.214Z",
    "size": 422,
    "path": "../public/app-assets/data/projects-list.json.br"
  },
  "/app-assets/data/projects-list.json.gz": {
    "type": "application/json",
    "encoding": "gzip",
    "etag": "\"206-kfWrBoP5jbApew8PY8q750qIbqQ\"",
    "mtime": "2025-04-13T20:04:28.214Z",
    "size": 518,
    "path": "../public/app-assets/data/projects-list.json.gz"
  },
  "/app-assets/data/search.json": {
    "type": "application/json",
    "etag": "\"2adf-IWujYGzutHgPW3nvLE0EdmbT1w8\"",
    "mtime": "2025-04-13T20:04:20.345Z",
    "size": 10975,
    "path": "../public/app-assets/data/search.json"
  },
  "/app-assets/data/search.json.br": {
    "type": "application/json",
    "encoding": "br",
    "etag": "\"780-Ga06a/QYAP1+phCpPLq82LRhjNg\"",
    "mtime": "2025-04-13T20:04:28.214Z",
    "size": 1920,
    "path": "../public/app-assets/data/search.json.br"
  },
  "/app-assets/data/search.json.gz": {
    "type": "application/json",
    "encoding": "gzip",
    "etag": "\"89a-nG7yh9vRcokWPIhM7ZkMiOAbOwI\"",
    "mtime": "2025-04-13T20:04:28.214Z",
    "size": 2202,
    "path": "../public/app-assets/data/search.json.gz"
  },
  "/app-assets/data/table-datatable.json": {
    "type": "application/json",
    "etag": "\"897a-JGrUcAqfkcb2M1gecjcla9aCjQw\"",
    "mtime": "2025-04-13T20:04:20.333Z",
    "size": 35194,
    "path": "../public/app-assets/data/table-datatable.json"
  },
  "/app-assets/data/table-datatable.json.br": {
    "type": "application/json",
    "encoding": "br",
    "etag": "\"142b-vLiA5YCoEXmnk4aAn3hGY00nl28\"",
    "mtime": "2025-04-13T20:04:28.214Z",
    "size": 5163,
    "path": "../public/app-assets/data/table-datatable.json.br"
  },
  "/app-assets/data/table-datatable.json.gz": {
    "type": "application/json",
    "encoding": "gzip",
    "etag": "\"17b6-Pf9DWNQ1jey7MN7aRgP03vdPOTs\"",
    "mtime": "2025-04-13T20:04:28.214Z",
    "size": 6070,
    "path": "../public/app-assets/data/table-datatable.json.gz"
  },
  "/app-assets/data/user-list.json": {
    "type": "application/json",
    "etag": "\"3556-Ifv1JGYucuKB8rm1KhBmlCHmPa0\"",
    "mtime": "2025-04-13T20:04:20.334Z",
    "size": 13654,
    "path": "../public/app-assets/data/user-list.json"
  },
  "/app-assets/data/user-list.json.br": {
    "type": "application/json",
    "encoding": "br",
    "etag": "\"75b-K3/KF1ZQ8pu24xax7ND1ZEpXKY0\"",
    "mtime": "2025-04-13T20:04:28.214Z",
    "size": 1883,
    "path": "../public/app-assets/data/user-list.json.br"
  },
  "/app-assets/data/user-list.json.gz": {
    "type": "application/json",
    "encoding": "gzip",
    "etag": "\"830-KVNkm5iF3hkzkSg8YAW7+lj4+8Y\"",
    "mtime": "2025-04-13T20:04:28.214Z",
    "size": 2096,
    "path": "../public/app-assets/data/user-list.json.gz"
  },
  "/_nuxt/builds/latest.json": {
    "type": "application/json",
    "etag": "\"47-7ck7zwFDeR/IGVAWL8ZhdMtYdNs\"",
    "mtime": "2025-04-13T20:04:20.228Z",
    "size": 71,
    "path": "../public/_nuxt/builds/latest.json"
  },
  "/assets/css/style.css": {
    "type": "text/css; charset=utf-8",
    "etag": "\"20f-ng6uGje7GJYQBNpiq+Idrjn/L1o\"",
    "mtime": "2025-04-13T20:04:20.315Z",
    "size": 527,
    "path": "../public/assets/css/style.css"
  },
  "/__nuxt_content/content/sql_dump/index.html": {
    "type": "text/html; charset=utf-8",
    "etag": "\"224-IJQjf3qZOK7Bj2x3KnhYR+ZCypE\"",
    "mtime": "2025-04-13T20:04:20.212Z",
    "size": 548,
    "path": "../public/__nuxt_content/content/sql_dump/index.html"
  },
  "/app-assets/css/pages/aggrid.min.css": {
    "type": "text/css; charset=utf-8",
    "etag": "\"6ac-C98Vbra4IjgM7BbTAO1En2habWA\"",
    "mtime": "2025-04-13T20:04:20.315Z",
    "size": 1708,
    "path": "../public/app-assets/css/pages/aggrid.min.css"
  },
  "/app-assets/css/pages/aggrid.min.css.br": {
    "type": "text/css; charset=utf-8",
    "encoding": "br",
    "etag": "\"1db-2tZtL36jYrK7yF4fG3J7n1qfopo\"",
    "mtime": "2025-04-13T20:04:28.214Z",
    "size": 475,
    "path": "../public/app-assets/css/pages/aggrid.min.css.br"
  },
  "/app-assets/css/pages/aggrid.min.css.gz": {
    "type": "text/css; charset=utf-8",
    "encoding": "gzip",
    "etag": "\"251-gByt3WQ6VsSceoEFVMVR0GwJFes\"",
    "mtime": "2025-04-13T20:04:28.214Z",
    "size": 593,
    "path": "../public/app-assets/css/pages/aggrid.min.css.gz"
  },
  "/app-assets/css/pages/app-chat.min.css": {
    "type": "text/css; charset=utf-8",
    "etag": "\"25db-Xt8n4luPWSv0QEgMh2i8eIBrbI4\"",
    "mtime": "2025-04-13T20:04:20.344Z",
    "size": 9691,
    "path": "../public/app-assets/css/pages/app-chat.min.css"
  },
  "/app-assets/css/pages/app-chat.min.css.br": {
    "type": "text/css; charset=utf-8",
    "encoding": "br",
    "etag": "\"5db-e0GGGr24reqp1CoqZRjGI+zXZcE\"",
    "mtime": "2025-04-13T20:04:28.214Z",
    "size": 1499,
    "path": "../public/app-assets/css/pages/app-chat.min.css.br"
  },
  "/app-assets/css/pages/app-chat.min.css.gz": {
    "type": "text/css; charset=utf-8",
    "encoding": "gzip",
    "etag": "\"705-dlEoaKJMaf+KHH39Tz+ma6i3pdU\"",
    "mtime": "2025-04-13T20:04:28.214Z",
    "size": 1797,
    "path": "../public/app-assets/css/pages/app-chat.min.css.gz"
  },
  "/app-assets/css/pages/app-ecommerce-details.min.css": {
    "type": "text/css; charset=utf-8",
    "etag": "\"63a-Uc5nbBtOArglOn5k1hwyExg57ng\"",
    "mtime": "2025-04-13T20:04:20.335Z",
    "size": 1594,
    "path": "../public/app-assets/css/pages/app-ecommerce-details.min.css"
  },
  "/app-assets/css/pages/app-ecommerce-details.min.css.br": {
    "type": "text/css; charset=utf-8",
    "encoding": "br",
    "etag": "\"18e-0LDOWeRbbGkQKKq1/5uQ6i3qm6I\"",
    "mtime": "2025-04-13T20:04:28.214Z",
    "size": 398,
    "path": "../public/app-assets/css/pages/app-ecommerce-details.min.css.br"
  },
  "/app-assets/css/pages/app-ecommerce-details.min.css.gz": {
    "type": "text/css; charset=utf-8",
    "encoding": "gzip",
    "etag": "\"214-o6fZSZzLjanre/h7+spYjEmsFqw\"",
    "mtime": "2025-04-13T20:04:28.214Z",
    "size": 532,
    "path": "../public/app-assets/css/pages/app-ecommerce-details.min.css.gz"
  },
  "/app-assets/css/pages/app-ecommerce-shop.min.css": {
    "type": "text/css; charset=utf-8",
    "etag": "\"4379-e3ljAymfdVjN3/HKiwDoQSykLzQ\"",
    "mtime": "2025-04-13T20:04:20.334Z",
    "size": 17273,
    "path": "../public/app-assets/css/pages/app-ecommerce-shop.min.css"
  },
  "/app-assets/css/pages/app-ecommerce-shop.min.css.br": {
    "type": "text/css; charset=utf-8",
    "encoding": "br",
    "etag": "\"8c1-HPVHmZfERVEuR/6Ui2Dpag+7prY\"",
    "mtime": "2025-04-13T20:04:28.214Z",
    "size": 2241,
    "path": "../public/app-assets/css/pages/app-ecommerce-shop.min.css.br"
  },
  "/app-assets/css/pages/app-ecommerce-shop.min.css.gz": {
    "type": "text/css; charset=utf-8",
    "encoding": "gzip",
    "etag": "\"a41-qGpWnnPoJypvD2s8e2JuoY/B9WM\"",
    "mtime": "2025-04-13T20:04:28.214Z",
    "size": 2625,
    "path": "../public/app-assets/css/pages/app-ecommerce-shop.min.css.gz"
  },
  "/app-assets/css/pages/app-email.min.css": {
    "type": "text/css; charset=utf-8",
    "etag": "\"ca0e9-nuGxordISFbfGOtcW/57akZ69So\"",
    "mtime": "2025-04-13T20:04:20.334Z",
    "size": 827625,
    "path": "../public/app-assets/css/pages/app-email.min.css"
  },
  "/app-assets/css/pages/app-email.min.css.br": {
    "type": "text/css; charset=utf-8",
    "encoding": "br",
    "etag": "\"420f-4uPuUOJhRRyZ+jeS3rqkHvt6cE8\"",
    "mtime": "2025-04-13T20:04:28.650Z",
    "size": 16911,
    "path": "../public/app-assets/css/pages/app-email.min.css.br"
  },
  "/app-assets/css/pages/app-email.min.css.gz": {
    "type": "text/css; charset=utf-8",
    "encoding": "gzip",
    "etag": "\"af1c-jeNAmP/NpbTKjrzwKsqAKrP58zE\"",
    "mtime": "2025-04-13T20:04:28.683Z",
    "size": 44828,
    "path": "../public/app-assets/css/pages/app-email.min.css.gz"
  },
  "/app-assets/css/pages/app-todo.min.css": {
    "type": "text/css; charset=utf-8",
    "etag": "\"cdc93-2F2kHDZICYyA97K6Ap7yt0sCKiY\"",
    "mtime": "2025-04-13T20:04:20.334Z",
    "size": 842899,
    "path": "../public/app-assets/css/pages/app-todo.min.css"
  },
  "/app-assets/css/pages/app-todo.min.css.br": {
    "type": "text/css; charset=utf-8",
    "encoding": "br",
    "etag": "\"3c64-iht23sa5EpXV0lJ3s3h1AVu5Yoc\"",
    "mtime": "2025-04-13T20:04:28.625Z",
    "size": 15460,
    "path": "../public/app-assets/css/pages/app-todo.min.css.br"
  },
  "/app-assets/css/pages/app-todo.min.css.gz": {
    "type": "text/css; charset=utf-8",
    "encoding": "gzip",
    "etag": "\"b22e-f784MNeOgE/878gt48OykZA1fjc\"",
    "mtime": "2025-04-13T20:04:28.683Z",
    "size": 45614,
    "path": "../public/app-assets/css/pages/app-todo.min.css.gz"
  },
  "/app-assets/css/pages/app-user.min.css": {
    "type": "text/css; charset=utf-8",
    "etag": "\"47d-cdaE/9lV22lcfJV2y7XlAA75h4E\"",
    "mtime": "2025-04-13T20:04:20.333Z",
    "size": 1149,
    "path": "../public/app-assets/css/pages/app-user.min.css"
  },
  "/app-assets/css/pages/app-user.min.css.br": {
    "type": "text/css; charset=utf-8",
    "encoding": "br",
    "etag": "\"141-5mhxQ80dVGXZbzuH6BnRi9rCJgQ\"",
    "mtime": "2025-04-13T20:04:28.214Z",
    "size": 321,
    "path": "../public/app-assets/css/pages/app-user.min.css.br"
  },
  "/app-assets/css/pages/app-user.min.css.gz": {
    "type": "text/css; charset=utf-8",
    "encoding": "gzip",
    "etag": "\"19e-RGRxmGJaTlgOMjRgeReCtjP07ik\"",
    "mtime": "2025-04-13T20:04:28.214Z",
    "size": 414,
    "path": "../public/app-assets/css/pages/app-user.min.css.gz"
  },
  "/app-assets/css/pages/authentication.css": {
    "type": "text/css; charset=utf-8",
    "etag": "\"205-cOMPop+WuMlYmGkSr+YzhTNAKYw\"",
    "mtime": "2025-04-13T20:04:20.334Z",
    "size": 517,
    "path": "../public/app-assets/css/pages/authentication.css"
  },
  "/app-assets/css/pages/card-analytics.min.css": {
    "type": "text/css; charset=utf-8",
    "etag": "\"3be-HB1mdNRUcRdsYz7n5p6JHeXg/X0\"",
    "mtime": "2025-04-13T20:04:20.334Z",
    "size": 958,
    "path": "../public/app-assets/css/pages/card-analytics.min.css"
  },
  "/app-assets/css/pages/colors.min.css": {
    "type": "text/css; charset=utf-8",
    "etag": "\"6f-XPoZUou6Pb//Tt/ZMckUeY8i6lE\"",
    "mtime": "2025-04-13T20:04:20.334Z",
    "size": 111,
    "path": "../public/app-assets/css/pages/colors.min.css"
  },
  "/app-assets/css/pages/coming-soon.css": {
    "type": "text/css; charset=utf-8",
    "etag": "\"9b-giKfOtbD9l6T+PLbrf3KDfUpEYA\"",
    "mtime": "2025-04-13T20:04:20.334Z",
    "size": 155,
    "path": "../public/app-assets/css/pages/coming-soon.css"
  },
  "/app-assets/css/pages/dashboard-analytics.min.css": {
    "type": "text/css; charset=utf-8",
    "etag": "\"2f8-LrLEFo4POBn5i5+CVEUv4PNc4k8\"",
    "mtime": "2025-04-13T20:04:20.335Z",
    "size": 760,
    "path": "../public/app-assets/css/pages/dashboard-analytics.min.css"
  },
  "/app-assets/css/pages/dashboard-ecommerce.min.css": {
    "type": "text/css; charset=utf-8",
    "etag": "\"4c7-ALSfIk6udCnIIECO9AqJA0IXmao\"",
    "mtime": "2025-04-13T20:04:20.336Z",
    "size": 1223,
    "path": "../public/app-assets/css/pages/dashboard-ecommerce.min.css"
  },
  "/app-assets/css/pages/dashboard-ecommerce.min.css.br": {
    "type": "text/css; charset=utf-8",
    "encoding": "br",
    "etag": "\"120-K1CRtHvJSlmwp29wBFT0SVfE2xQ\"",
    "mtime": "2025-04-13T20:04:28.214Z",
    "size": 288,
    "path": "../public/app-assets/css/pages/dashboard-ecommerce.min.css.br"
  },
  "/app-assets/css/pages/dashboard-ecommerce.min.css.gz": {
    "type": "text/css; charset=utf-8",
    "encoding": "gzip",
    "etag": "\"19f-2sYbgo+q2rQgS6O0JigqNiY4oQ0\"",
    "mtime": "2025-04-13T20:04:28.214Z",
    "size": 415,
    "path": "../public/app-assets/css/pages/dashboard-ecommerce.min.css.gz"
  },
  "/app-assets/css/pages/data-list-view.min.css": {
    "type": "text/css; charset=utf-8",
    "etag": "\"4850-RXKUK0BPvP9BERDlHWCEjD8R1+8\"",
    "mtime": "2025-04-13T20:04:20.334Z",
    "size": 18512,
    "path": "../public/app-assets/css/pages/data-list-view.min.css"
  },
  "/app-assets/css/pages/data-list-view.min.css.br": {
    "type": "text/css; charset=utf-8",
    "encoding": "br",
    "etag": "\"8dc-m1OI0FFr6hMGeF/Ul9aV7JP135o\"",
    "mtime": "2025-04-13T20:04:28.215Z",
    "size": 2268,
    "path": "../public/app-assets/css/pages/data-list-view.min.css.br"
  },
  "/app-assets/css/pages/data-list-view.min.css.gz": {
    "type": "text/css; charset=utf-8",
    "encoding": "gzip",
    "etag": "\"a61-mm7JOHxAkTfCiDRvIgkZ0UV0HjY\"",
    "mtime": "2025-04-13T20:04:28.215Z",
    "size": 2657,
    "path": "../public/app-assets/css/pages/data-list-view.min.css.gz"
  },
  "/app-assets/css/pages/error.min.css": {
    "type": "text/css; charset=utf-8",
    "etag": "\"1c-UEzOJDwrzR0hUPlHYdQEw2eqF00\"",
    "mtime": "2025-04-13T20:04:20.335Z",
    "size": 28,
    "path": "../public/app-assets/css/pages/error.min.css"
  },
  "/app-assets/css/pages/faq.min.css": {
    "type": "text/css; charset=utf-8",
    "etag": "\"2e4-XaA3jkEkNdH9lk2nV4h30a0MVfA\"",
    "mtime": "2025-04-13T20:04:20.334Z",
    "size": 740,
    "path": "../public/app-assets/css/pages/faq.min.css"
  },
  "/app-assets/css/pages/invoice.min.css": {
    "type": "text/css; charset=utf-8",
    "etag": "\"34d-ONmtJIWP/fggMQNB33a17/6U8+8\"",
    "mtime": "2025-04-13T20:04:20.335Z",
    "size": 845,
    "path": "../public/app-assets/css/pages/invoice.min.css"
  },
  "/app-assets/css/pages/knowledge-base.min.css": {
    "type": "text/css; charset=utf-8",
    "etag": "\"2e5-zY+QmI1mg85vkR+tFYJ9BbT0d+w\"",
    "mtime": "2025-04-13T20:04:20.335Z",
    "size": 741,
    "path": "../public/app-assets/css/pages/knowledge-base.min.css"
  },
  "/app-assets/css/pages/search.min.css": {
    "type": "text/css; charset=utf-8",
    "etag": "\"348-QQEzPOyDZZCoJ945+ok8CDOlalo\"",
    "mtime": "2025-04-13T20:04:20.335Z",
    "size": 840,
    "path": "../public/app-assets/css/pages/search.min.css"
  },
  "/app-assets/css/pages/users.min.css": {
    "type": "text/css; charset=utf-8",
    "etag": "\"667-h+jI1cqkbGKpqupnlIxbgyA4i3s\"",
    "mtime": "2025-04-13T20:04:20.335Z",
    "size": 1639,
    "path": "../public/app-assets/css/pages/users.min.css"
  },
  "/app-assets/css/pages/users.min.css.br": {
    "type": "text/css; charset=utf-8",
    "encoding": "br",
    "etag": "\"1a3-KmgKa2J98tKzhtTFB/kRpEymq+I\"",
    "mtime": "2025-04-13T20:04:28.215Z",
    "size": 419,
    "path": "../public/app-assets/css/pages/users.min.css.br"
  },
  "/app-assets/css/pages/users.min.css.gz": {
    "type": "text/css; charset=utf-8",
    "encoding": "gzip",
    "etag": "\"231-ADuq0w0QGBecPdwsHv2SW9ud3Bc\"",
    "mtime": "2025-04-13T20:04:28.215Z",
    "size": 561,
    "path": "../public/app-assets/css/pages/users.min.css.gz"
  },
  "/app-assets/data/locales/de.json": {
    "type": "application/json",
    "etag": "\"14c1-E/Qb76sk3Fr+TujaoGn6cy43z20\"",
    "mtime": "2025-04-13T20:04:20.316Z",
    "size": 5313,
    "path": "../public/app-assets/data/locales/de.json"
  },
  "/app-assets/data/locales/de.json.br": {
    "type": "application/json",
    "encoding": "br",
    "etag": "\"777-hAvRFyO2DSHBYb1IdAwZUdOHDKY\"",
    "mtime": "2025-04-13T20:04:28.215Z",
    "size": 1911,
    "path": "../public/app-assets/data/locales/de.json.br"
  },
  "/app-assets/data/locales/de.json.gz": {
    "type": "application/json",
    "encoding": "gzip",
    "etag": "\"86b-sMdB8WRpCOe+4qx4UVPwoJKIadI\"",
    "mtime": "2025-04-13T20:04:28.215Z",
    "size": 2155,
    "path": "../public/app-assets/data/locales/de.json.gz"
  },
  "/app-assets/data/locales/en.json": {
    "type": "application/json",
    "etag": "\"1317-twqjwoQFMAIYRKIBj1NVr0KRTFI\"",
    "mtime": "2025-04-13T20:04:20.351Z",
    "size": 4887,
    "path": "../public/app-assets/data/locales/en.json"
  },
  "/app-assets/data/locales/en.json.br": {
    "type": "application/json",
    "encoding": "br",
    "etag": "\"501-luNWAjX5LGFpDVmj2RwzE7AfZQc\"",
    "mtime": "2025-04-13T20:04:28.215Z",
    "size": 1281,
    "path": "../public/app-assets/data/locales/en.json.br"
  },
  "/app-assets/data/locales/en.json.gz": {
    "type": "application/json",
    "encoding": "gzip",
    "etag": "\"5fe-tnK8XJ6auhnv/86nznQ7pKhNHe0\"",
    "mtime": "2025-04-13T20:04:28.215Z",
    "size": 1534,
    "path": "../public/app-assets/data/locales/en.json.gz"
  },
  "/app-assets/data/locales/fr.json": {
    "type": "application/json",
    "etag": "\"1586-/6bW6F2qpv6cohrPKlD1fkZbErQ\"",
    "mtime": "2025-04-13T20:04:20.350Z",
    "size": 5510,
    "path": "../public/app-assets/data/locales/fr.json"
  },
  "/app-assets/data/locales/fr.json.br": {
    "type": "application/json",
    "encoding": "br",
    "etag": "\"785-f+rci/tP3khdcrnCw2BiI/f8L6c\"",
    "mtime": "2025-04-13T20:04:28.215Z",
    "size": 1925,
    "path": "../public/app-assets/data/locales/fr.json.br"
  },
  "/app-assets/data/locales/fr.json.gz": {
    "type": "application/json",
    "encoding": "gzip",
    "etag": "\"889-z7mnI/M41bDsqHP903bAxcdJ8IY\"",
    "mtime": "2025-04-13T20:04:28.215Z",
    "size": 2185,
    "path": "../public/app-assets/data/locales/fr.json.gz"
  },
  "/app-assets/data/locales/pt.json": {
    "type": "application/json",
    "etag": "\"151d-oXS2AIdL5N8Tsy6gDPrf3K3EYCw\"",
    "mtime": "2025-04-13T20:04:20.352Z",
    "size": 5405,
    "path": "../public/app-assets/data/locales/pt.json"
  },
  "/app-assets/data/locales/pt.json.br": {
    "type": "application/json",
    "encoding": "br",
    "etag": "\"782-CI/g9gVZX4Nln6I9F8l3Y5wCXzw\"",
    "mtime": "2025-04-13T20:04:28.215Z",
    "size": 1922,
    "path": "../public/app-assets/data/locales/pt.json.br"
  },
  "/app-assets/data/locales/pt.json.gz": {
    "type": "application/json",
    "encoding": "gzip",
    "etag": "\"885-kt0WOvkXaUo3q9o0coG2YZzPMfI\"",
    "mtime": "2025-04-13T20:04:28.215Z",
    "size": 2181,
    "path": "../public/app-assets/data/locales/pt.json.gz"
  },
  "/app-assets/css/themes/dark-layout.min.css": {
    "type": "text/css; charset=utf-8",
    "etag": "\"fd50-loymRLne4aq2H97bweojTHQ4+LE\"",
    "mtime": "2025-04-13T20:04:20.321Z",
    "size": 64848,
    "path": "../public/app-assets/css/themes/dark-layout.min.css"
  },
  "/app-assets/css/themes/dark-layout.min.css.br": {
    "type": "text/css; charset=utf-8",
    "encoding": "br",
    "etag": "\"18fe-wTCGx4YP84EPJXhIT8W+5DyC3Cc\"",
    "mtime": "2025-04-13T20:04:28.215Z",
    "size": 6398,
    "path": "../public/app-assets/css/themes/dark-layout.min.css.br"
  },
  "/app-assets/css/themes/dark-layout.min.css.gz": {
    "type": "text/css; charset=utf-8",
    "encoding": "gzip",
    "etag": "\"1c12-6+icLSywrC3ppnpGn8KM4+11thE\"",
    "mtime": "2025-04-13T20:04:28.215Z",
    "size": 7186,
    "path": "../public/app-assets/css/themes/dark-layout.min.css.gz"
  },
  "/app-assets/css/themes/semi-dark-layout.min.css": {
    "type": "text/css; charset=utf-8",
    "etag": "\"73b-jgkV3SyT/WqbG6/E/LiEM5EZKdE\"",
    "mtime": "2025-04-13T20:04:20.337Z",
    "size": 1851,
    "path": "../public/app-assets/css/themes/semi-dark-layout.min.css"
  },
  "/app-assets/css/themes/semi-dark-layout.min.css.br": {
    "type": "text/css; charset=utf-8",
    "encoding": "br",
    "etag": "\"144-4AYmAIH6bevWH4Z5JfGhD9BjP2c\"",
    "mtime": "2025-04-13T20:04:28.215Z",
    "size": 324,
    "path": "../public/app-assets/css/themes/semi-dark-layout.min.css.br"
  },
  "/app-assets/css/themes/semi-dark-layout.min.css.gz": {
    "type": "text/css; charset=utf-8",
    "encoding": "gzip",
    "etag": "\"18d-XmobDUwJpYelMUZ+ObxD+T+se9c\"",
    "mtime": "2025-04-13T20:04:28.215Z",
    "size": 397,
    "path": "../public/app-assets/css/themes/semi-dark-layout.min.css.gz"
  },
  "/app-assets/fonts/feather/iconfont.css": {
    "type": "text/css; charset=utf-8",
    "etag": "\"339c-JEin8K5kqAVtMr1w5EiScd+cg+Q\"",
    "mtime": "2025-04-13T20:04:20.323Z",
    "size": 13212,
    "path": "../public/app-assets/fonts/feather/iconfont.css"
  },
  "/app-assets/fonts/feather/iconfont.css.br": {
    "type": "text/css; charset=utf-8",
    "encoding": "br",
    "etag": "\"79e-Ge4bqaWbWFSB+fkSScOQ2Cx9zPI\"",
    "mtime": "2025-04-13T20:04:28.215Z",
    "size": 1950,
    "path": "../public/app-assets/fonts/feather/iconfont.css.br"
  },
  "/app-assets/fonts/feather/iconfont.css.gz": {
    "type": "text/css; charset=utf-8",
    "encoding": "gzip",
    "etag": "\"955-pqm7m1VMqSg6x7MJF+/tLAopCF0\"",
    "mtime": "2025-04-13T20:04:28.215Z",
    "size": 2389,
    "path": "../public/app-assets/fonts/feather/iconfont.css.gz"
  },
  "/app-assets/fonts/flag-icon-css/LICENSE": {
    "type": "text/plain; charset=utf-8",
    "etag": "\"43f-SLomtagZwmp4RVQ6eygeUVT2h6w\"",
    "mtime": "2025-04-13T20:04:20.350Z",
    "size": 1087,
    "path": "../public/app-assets/fonts/flag-icon-css/LICENSE"
  },
  "/app-assets/fonts/flag-icon-css/LICENSE.br": {
    "type": "text/plain; charset=utf-8",
    "encoding": "br",
    "etag": "\"1ec-qWVXP7MLxbv/ovNd8w4yswDnxKE\"",
    "mtime": "2025-04-13T20:04:28.215Z",
    "size": 492,
    "path": "../public/app-assets/fonts/flag-icon-css/LICENSE.br"
  },
  "/app-assets/fonts/flag-icon-css/LICENSE.gz": {
    "type": "text/plain; charset=utf-8",
    "encoding": "gzip",
    "etag": "\"29b-zZ/TXk/qjR11nrFKoEf1ezbPkVQ\"",
    "mtime": "2025-04-13T20:04:28.215Z",
    "size": 667,
    "path": "../public/app-assets/fonts/flag-icon-css/LICENSE.gz"
  },
  "/app-assets/fonts/flag-icon-css/README.md": {
    "type": "text/markdown; charset=utf-8",
    "etag": "\"7e1-RmAU7QPPsolywvrB5xSWSHkOkkA\"",
    "mtime": "2025-04-13T20:04:20.350Z",
    "size": 2017,
    "path": "../public/app-assets/fonts/flag-icon-css/README.md"
  },
  "/app-assets/images/banner/banner-1.jpg": {
    "type": "image/jpeg",
    "etag": "\"14a54-0tfln7pmzK+iZK7SB1gCt0OUQHA\"",
    "mtime": "2025-04-13T20:04:20.322Z",
    "size": 84564,
    "path": "../public/app-assets/images/banner/banner-1.jpg"
  },
  "/app-assets/images/banner/banner-10.jpg": {
    "type": "image/jpeg",
    "etag": "\"1fc8b-evcCLEMhNDc/57SJZpKsbJKsifY\"",
    "mtime": "2025-04-13T20:04:20.338Z",
    "size": 130187,
    "path": "../public/app-assets/images/banner/banner-10.jpg"
  },
  "/app-assets/images/banner/banner-11.jpg": {
    "type": "image/jpeg",
    "etag": "\"e607-s3x5Ehfm1N6mBAVu5AhtV6mutKQ\"",
    "mtime": "2025-04-13T20:04:20.339Z",
    "size": 58887,
    "path": "../public/app-assets/images/banner/banner-11.jpg"
  },
  "/app-assets/images/banner/banner-12.jpg": {
    "type": "image/jpeg",
    "etag": "\"da52-nXHjxVdkO46oFrhUoMECg59+/ko\"",
    "mtime": "2025-04-13T20:04:20.338Z",
    "size": 55890,
    "path": "../public/app-assets/images/banner/banner-12.jpg"
  },
  "/app-assets/images/banner/banner-13.jpg": {
    "type": "image/jpeg",
    "etag": "\"11ce4-xnkKdw0gKFEkeu8jbrniN/HRDcQ\"",
    "mtime": "2025-04-13T20:04:20.338Z",
    "size": 72932,
    "path": "../public/app-assets/images/banner/banner-13.jpg"
  },
  "/app-assets/images/banner/banner-14.jpg": {
    "type": "image/jpeg",
    "etag": "\"145c0-mrY9RAI+dE5Xztlu20j56ZCkFGA\"",
    "mtime": "2025-04-13T20:04:20.339Z",
    "size": 83392,
    "path": "../public/app-assets/images/banner/banner-14.jpg"
  },
  "/app-assets/images/banner/banner-15.jpg": {
    "type": "image/jpeg",
    "etag": "\"11fee-YjtdjmkAf5TsReI4D4bpI4JHv7E\"",
    "mtime": "2025-04-13T20:04:20.340Z",
    "size": 73710,
    "path": "../public/app-assets/images/banner/banner-15.jpg"
  },
  "/app-assets/images/banner/banner-16.jpg": {
    "type": "image/jpeg",
    "etag": "\"11bd8-2nT3S9ZrBFkOI316PDqPLCVHDQ8\"",
    "mtime": "2025-04-13T20:04:20.340Z",
    "size": 72664,
    "path": "../public/app-assets/images/banner/banner-16.jpg"
  },
  "/app-assets/images/banner/banner-17.jpg": {
    "type": "image/jpeg",
    "etag": "\"16bc8-29FHHUe97eEmxXGmtXv6Km1PbC8\"",
    "mtime": "2025-04-13T20:04:20.339Z",
    "size": 93128,
    "path": "../public/app-assets/images/banner/banner-17.jpg"
  },
  "/app-assets/images/banner/banner-18.jpg": {
    "type": "image/jpeg",
    "etag": "\"1c833-gKmVyd1yv6tcpvqcWdpWfeP50AQ\"",
    "mtime": "2025-04-13T20:04:20.340Z",
    "size": 116787,
    "path": "../public/app-assets/images/banner/banner-18.jpg"
  },
  "/app-assets/images/banner/banner-19.jpg": {
    "type": "image/jpeg",
    "etag": "\"4650-r9D3JTH5hvGRuBVAEOotD99nQhg\"",
    "mtime": "2025-04-13T20:04:20.340Z",
    "size": 18000,
    "path": "../public/app-assets/images/banner/banner-19.jpg"
  },
  "/app-assets/images/banner/banner-2.jpg": {
    "type": "image/jpeg",
    "etag": "\"e9f2-MIp7SCGMnVcyjNPeQ3BT1ZINBZo\"",
    "mtime": "2025-04-13T20:04:20.340Z",
    "size": 59890,
    "path": "../public/app-assets/images/banner/banner-2.jpg"
  },
  "/app-assets/images/banner/banner-20.jpg": {
    "type": "image/jpeg",
    "etag": "\"b9bf-VVd/ZZL1/M9GTd3fnP7bMj4r2E8\"",
    "mtime": "2025-04-13T20:04:20.340Z",
    "size": 47551,
    "path": "../public/app-assets/images/banner/banner-20.jpg"
  },
  "/app-assets/images/banner/banner-21.jpg": {
    "type": "image/jpeg",
    "etag": "\"7be9-wEXlRz/muvywjedAKEBv3zivgGc\"",
    "mtime": "2025-04-13T20:04:20.340Z",
    "size": 31721,
    "path": "../public/app-assets/images/banner/banner-21.jpg"
  },
  "/app-assets/images/banner/banner-22.jpg": {
    "type": "image/jpeg",
    "etag": "\"2ad6-LQHGCvTaR7BD3ezmOVZ57C2ZMX8\"",
    "mtime": "2025-04-13T20:04:20.340Z",
    "size": 10966,
    "path": "../public/app-assets/images/banner/banner-22.jpg"
  },
  "/app-assets/images/banner/banner-23.jpg": {
    "type": "image/jpeg",
    "etag": "\"96e4-qOiUu6+6FwXriga3tkQ4u2FJCK0\"",
    "mtime": "2025-04-13T20:04:20.341Z",
    "size": 38628,
    "path": "../public/app-assets/images/banner/banner-23.jpg"
  },
  "/app-assets/images/banner/banner-24.jpg": {
    "type": "image/jpeg",
    "etag": "\"471d-uxNbPTETE2udOQtrL3CHBU8cMo8\"",
    "mtime": "2025-04-13T20:04:20.340Z",
    "size": 18205,
    "path": "../public/app-assets/images/banner/banner-24.jpg"
  },
  "/app-assets/images/banner/banner-26.jpg": {
    "type": "image/jpeg",
    "etag": "\"6dbf-2Ivdk7k5/qYsqd2IxQLGltLByMI\"",
    "mtime": "2025-04-13T20:04:20.341Z",
    "size": 28095,
    "path": "../public/app-assets/images/banner/banner-26.jpg"
  },
  "/app-assets/images/banner/banner-28.jpg": {
    "type": "image/jpeg",
    "etag": "\"980e-Bj52f0dP5QJriyIEJDMHbGUJjYU\"",
    "mtime": "2025-04-13T20:04:20.341Z",
    "size": 38926,
    "path": "../public/app-assets/images/banner/banner-28.jpg"
  },
  "/app-assets/images/banner/banner-29.jpg": {
    "type": "image/jpeg",
    "etag": "\"2766-IDWp7q/NJMZCXH5WY6RHAmJPs48\"",
    "mtime": "2025-04-13T20:04:20.340Z",
    "size": 10086,
    "path": "../public/app-assets/images/banner/banner-29.jpg"
  },
  "/app-assets/images/banner/banner-3.jpg": {
    "type": "image/jpeg",
    "etag": "\"14528-7GmBaSSb9HBI2pIxyKA7hKE/PnE\"",
    "mtime": "2025-04-13T20:04:20.341Z",
    "size": 83240,
    "path": "../public/app-assets/images/banner/banner-3.jpg"
  },
  "/app-assets/images/banner/banner-30.jpg": {
    "type": "image/jpeg",
    "etag": "\"fd29-Py6WjQ8+JnjoFrTQ1pJ79VPMoZE\"",
    "mtime": "2025-04-13T20:04:20.341Z",
    "size": 64809,
    "path": "../public/app-assets/images/banner/banner-30.jpg"
  },
  "/app-assets/images/banner/banner-31.jpg": {
    "type": "image/jpeg",
    "etag": "\"6fb1-wyuGmGf0KJZxCyNmxY1nvY6pylY\"",
    "mtime": "2025-04-13T20:04:20.342Z",
    "size": 28593,
    "path": "../public/app-assets/images/banner/banner-31.jpg"
  },
  "/app-assets/images/banner/banner-32.jpg": {
    "type": "image/jpeg",
    "etag": "\"2a71-683SiFuz/yOUka2kc5OUtLK5ZqY\"",
    "mtime": "2025-04-13T20:04:20.342Z",
    "size": 10865,
    "path": "../public/app-assets/images/banner/banner-32.jpg"
  },
  "/app-assets/images/banner/banner-33.jpg": {
    "type": "image/jpeg",
    "etag": "\"29ac-0fSQYsYQ514PpVgUQ8k78BSVlzg\"",
    "mtime": "2025-04-13T20:04:20.342Z",
    "size": 10668,
    "path": "../public/app-assets/images/banner/banner-33.jpg"
  },
  "/app-assets/images/banner/banner-34.jpg": {
    "type": "image/jpeg",
    "etag": "\"3833-U62XZAcogy/kPcIWHKcVJCMt+ss\"",
    "mtime": "2025-04-13T20:04:20.342Z",
    "size": 14387,
    "path": "../public/app-assets/images/banner/banner-34.jpg"
  },
  "/app-assets/images/banner/banner-35.jpg": {
    "type": "image/jpeg",
    "etag": "\"3318-+8EK5GmSbVCI4+f6GW4tZVxhtS4\"",
    "mtime": "2025-04-13T20:04:20.342Z",
    "size": 13080,
    "path": "../public/app-assets/images/banner/banner-35.jpg"
  },
  "/app-assets/images/banner/banner-36.jpg": {
    "type": "image/jpeg",
    "etag": "\"70cc-oi3R2FkDsSPkyzPAnR1fn5VQCag\"",
    "mtime": "2025-04-13T20:04:20.342Z",
    "size": 28876,
    "path": "../public/app-assets/images/banner/banner-36.jpg"
  },
  "/app-assets/images/banner/banner-37.jpg": {
    "type": "image/jpeg",
    "etag": "\"706d-Mn53BgY8x8orJuUS+R7q7UDt5u0\"",
    "mtime": "2025-04-13T20:04:20.342Z",
    "size": 28781,
    "path": "../public/app-assets/images/banner/banner-37.jpg"
  },
  "/app-assets/images/banner/banner-38.jpg": {
    "type": "image/jpeg",
    "etag": "\"1a86-2cPgA7FpSChcOBNtfjoRhOzVeMc\"",
    "mtime": "2025-04-13T20:04:20.343Z",
    "size": 6790,
    "path": "../public/app-assets/images/banner/banner-38.jpg"
  },
  "/app-assets/images/banner/banner-39.jpg": {
    "type": "image/jpeg",
    "etag": "\"79be-1EZnoW1qIeHbJRU+deiNxq1BTu0\"",
    "mtime": "2025-04-13T20:04:20.342Z",
    "size": 31166,
    "path": "../public/app-assets/images/banner/banner-39.jpg"
  },
  "/app-assets/images/banner/banner-4.jpg": {
    "type": "image/jpeg",
    "etag": "\"fb4c-5JqUb5rQ9fAOJ5gcTxb3sJ/4X4I\"",
    "mtime": "2025-04-13T20:04:20.343Z",
    "size": 64332,
    "path": "../public/app-assets/images/banner/banner-4.jpg"
  },
  "/app-assets/images/banner/banner-5.jpg": {
    "type": "image/jpeg",
    "etag": "\"15545-xD+ggeDXyExPZcuMIYOfZnGyKok\"",
    "mtime": "2025-04-13T20:04:20.342Z",
    "size": 87365,
    "path": "../public/app-assets/images/banner/banner-5.jpg"
  },
  "/app-assets/images/banner/banner-7.jpg": {
    "type": "image/jpeg",
    "etag": "\"e79f-C49p4QhciyZ/eKloYB10ov3Xe3E\"",
    "mtime": "2025-04-13T20:04:20.343Z",
    "size": 59295,
    "path": "../public/app-assets/images/banner/banner-7.jpg"
  },
  "/app-assets/images/banner/banner-8.jpg": {
    "type": "image/jpeg",
    "etag": "\"93c6-BeFvZPdr2BFIux4a+vSEuz4IU5M\"",
    "mtime": "2025-04-13T20:04:20.349Z",
    "size": 37830,
    "path": "../public/app-assets/images/banner/banner-8.jpg"
  },
  "/app-assets/images/banner/banner-9.jpg": {
    "type": "image/jpeg",
    "etag": "\"1b42d-QTnzQpAFRKEqc0GxvWAuXBXNd6I\"",
    "mtime": "2025-04-13T20:04:20.343Z",
    "size": 111661,
    "path": "../public/app-assets/images/banner/banner-9.jpg"
  },
  "/app-assets/images/banner/parallax-4.jpg": {
    "type": "image/jpeg",
    "etag": "\"834f-KGNkxX48xEcz2ea303AvLj8Voi4\"",
    "mtime": "2025-04-13T20:04:20.343Z",
    "size": 33615,
    "path": "../public/app-assets/images/banner/parallax-4.jpg"
  },
  "/app-assets/images/dropzone/spritemap.png": {
    "type": "image/png",
    "etag": "\"27e0-Q26Emsq+Je3it8hQDk9wa9woIGY\"",
    "mtime": "2025-04-13T20:04:20.316Z",
    "size": 10208,
    "path": "../public/app-assets/images/dropzone/spritemap.png"
  },
  "/app-assets/images/elements/apple-watch.png": {
    "type": "image/png",
    "etag": "\"a838-00s2yrnxLW1UUcwBHvMJDrBnU5Q\"",
    "mtime": "2025-04-13T20:04:20.322Z",
    "size": 43064,
    "path": "../public/app-assets/images/elements/apple-watch.png"
  },
  "/app-assets/images/elements/beats-headphones.png": {
    "type": "image/png",
    "etag": "\"94ef-NPWrZZBuwIt1RtphBxU8nXIKjyc\"",
    "mtime": "2025-04-13T20:04:20.336Z",
    "size": 38127,
    "path": "../public/app-assets/images/elements/beats-headphones.png"
  },
  "/app-assets/images/elements/decore-left.png": {
    "type": "image/png",
    "etag": "\"d07-5l2Nsm4JcJRFFsq5zDMx+OChwHo\"",
    "mtime": "2025-04-13T20:04:20.336Z",
    "size": 3335,
    "path": "../public/app-assets/images/elements/decore-left.png"
  },
  "/app-assets/images/elements/decore-right.png": {
    "type": "image/png",
    "etag": "\"716-v0rDYabQ73KrNOGstnxnHKRONJ8\"",
    "mtime": "2025-04-13T20:04:20.337Z",
    "size": 1814,
    "path": "../public/app-assets/images/elements/decore-right.png"
  },
  "/app-assets/images/elements/homepod.png": {
    "type": "image/png",
    "etag": "\"12181-8nzJ1lXyGYG1wWWmUUNP8Hdxckc\"",
    "mtime": "2025-04-13T20:04:20.337Z",
    "size": 74113,
    "path": "../public/app-assets/images/elements/homepod.png"
  },
  "/app-assets/images/elements/ipad-pro.png": {
    "type": "image/png",
    "etag": "\"16bb1-SoYV9gsqi1Oxpk0uHckpq05UYL4\"",
    "mtime": "2025-04-13T20:04:20.337Z",
    "size": 93105,
    "path": "../public/app-assets/images/elements/ipad-pro.png"
  },
  "/app-assets/images/elements/iphone-x.png": {
    "type": "image/png",
    "etag": "\"b6e4-HAXcqB9hldGcf/RhYbDitCk/SQQ\"",
    "mtime": "2025-04-13T20:04:20.336Z",
    "size": 46820,
    "path": "../public/app-assets/images/elements/iphone-x.png"
  },
  "/app-assets/images/elements/jbl-speaker.png": {
    "type": "image/png",
    "etag": "\"a3cf-cn4IVi2nc+3rPNb8yCkD3/s4RjE\"",
    "mtime": "2025-04-13T20:04:20.337Z",
    "size": 41935,
    "path": "../public/app-assets/images/elements/jbl-speaker.png"
  },
  "/app-assets/images/elements/macbook-pro.png": {
    "type": "image/png",
    "etag": "\"d964-4acmKWp6Ge+OMO4uZgEmv84sf4A\"",
    "mtime": "2025-04-13T20:04:20.336Z",
    "size": 55652,
    "path": "../public/app-assets/images/elements/macbook-pro.png"
  },
  "/app-assets/images/elements/magic-mouse.png": {
    "type": "image/png",
    "etag": "\"3532-qk+9/aH4LTugA5oz7jdYnjZcMSU\"",
    "mtime": "2025-04-13T20:04:20.337Z",
    "size": 13618,
    "path": "../public/app-assets/images/elements/magic-mouse.png"
  },
  "/app-assets/images/ico/apple-icon-120.html": {
    "type": "text/html; charset=utf-8",
    "etag": "\"ab-Qwr3igcCwLiUYlmJhoKMamlAxz4\"",
    "mtime": "2025-04-13T20:04:20.322Z",
    "size": 171,
    "path": "../public/app-assets/images/ico/apple-icon-120.html"
  },
  "/app-assets/images/icons/doc.png": {
    "type": "image/png",
    "etag": "\"a3e-sRobWiNJ2rqiQwwn94Hj7RQMsIQ\"",
    "mtime": "2025-04-13T20:04:20.322Z",
    "size": 2622,
    "path": "../public/app-assets/images/icons/doc.png"
  },
  "/app-assets/images/icons/jpg.png": {
    "type": "image/png",
    "etag": "\"9e8-mEeSzANqxUu8MVyqD5G2/QKhuCY\"",
    "mtime": "2025-04-13T20:04:20.343Z",
    "size": 2536,
    "path": "../public/app-assets/images/icons/jpg.png"
  },
  "/app-assets/images/icons/pdf.png": {
    "type": "image/png",
    "etag": "\"939-dorLfyM9WD9iw6di7DgMcOkbNxc\"",
    "mtime": "2025-04-13T20:04:20.345Z",
    "size": 2361,
    "path": "../public/app-assets/images/icons/pdf.png"
  },
  "/app-assets/images/icons/xls.png": {
    "type": "image/png",
    "etag": "\"974-OxzmokgeeVpG1QLSMITKldILyCs\"",
    "mtime": "2025-04-13T20:04:20.343Z",
    "size": 2420,
    "path": "../public/app-assets/images/icons/xls.png"
  },
  "/app-assets/images/logo/logo.png": {
    "type": "image/png",
    "etag": "\"19a3-dmiqaGdrYmknEOhm0eu6mP3sgT8\"",
    "mtime": "2025-04-13T20:04:20.321Z",
    "size": 6563,
    "path": "../public/app-assets/images/logo/logo.png"
  },
  "/app-assets/images/logo/vuexy-logo.png": {
    "type": "image/png",
    "etag": "\"2060-RYwCLuDPMnunPLUIGVk4GjGT+Uo\"",
    "mtime": "2025-04-13T20:04:20.346Z",
    "size": 8288,
    "path": "../public/app-assets/images/logo/vuexy-logo.png"
  },
  "/app-assets/images/pages/1-apex.png": {
    "type": "image/png",
    "etag": "\"8b4-jOFYTGJbFTqPJRkCfE+wNA44A5M\"",
    "mtime": "2025-04-13T20:04:20.344Z",
    "size": 2228,
    "path": "../public/app-assets/images/pages/1-apex.png"
  },
  "/app-assets/images/pages/2-stack.png": {
    "type": "image/png",
    "etag": "\"c20-MWoXYQ6iLR3+eJIestSt5D39O2w\"",
    "mtime": "2025-04-13T20:04:20.344Z",
    "size": 3104,
    "path": "../public/app-assets/images/pages/2-stack.png"
  },
  "/app-assets/images/pages/3-convex.png": {
    "type": "image/png",
    "etag": "\"86c-1X/QjG3p1i3aQgqvO1j4TDNEjKE\"",
    "mtime": "2025-04-13T20:04:20.344Z",
    "size": 2156,
    "path": "../public/app-assets/images/pages/3-convex.png"
  },
  "/app-assets/images/pages/4-materialize.png": {
    "type": "image/png",
    "etag": "\"904-1R1t/aGMRlB/C29/+b4jKCDdRAo\"",
    "mtime": "2025-04-13T20:04:20.344Z",
    "size": 2308,
    "path": "../public/app-assets/images/pages/4-materialize.png"
  },
  "/app-assets/images/pages/404.png": {
    "type": "image/png",
    "etag": "\"4a76-scQCJ7gBpd04J4IAlPlrsPmKB9Q\"",
    "mtime": "2025-04-13T20:04:20.344Z",
    "size": 19062,
    "path": "../public/app-assets/images/pages/404.png"
  },
  "/app-assets/images/pages/500.png": {
    "type": "image/png",
    "etag": "\"4897-sZRS67vaKXHfuZAR7yxeoPgHNnw\"",
    "mtime": "2025-04-13T20:04:20.344Z",
    "size": 18583,
    "path": "../public/app-assets/images/pages/500.png"
  },
  "/app-assets/images/pages/arrow-down.png": {
    "type": "image/png",
    "etag": "\"d9-iW5YZqQXGXzFWVcTcetCrvYITSA\"",
    "mtime": "2025-04-13T20:04:20.344Z",
    "size": 217,
    "path": "../public/app-assets/images/pages/arrow-down.png"
  },
  "/app-assets/images/pages/card-image-5.jpg": {
    "type": "image/jpeg",
    "etag": "\"106ed-wzXPTm13d4I2TgAzjYSKWS+DV6c\"",
    "mtime": "2025-04-13T20:04:20.345Z",
    "size": 67309,
    "path": "../public/app-assets/images/pages/card-image-5.jpg"
  },
  "/app-assets/images/pages/card-image-6.jpg": {
    "type": "image/jpeg",
    "etag": "\"aa66-7YgNOUyXihReLQzzvIxRStte6ns\"",
    "mtime": "2025-04-13T20:04:20.344Z",
    "size": 43622,
    "path": "../public/app-assets/images/pages/card-image-6.jpg"
  },
  "/app-assets/images/pages/content-img-1.jpg": {
    "type": "image/jpeg",
    "etag": "\"b8bf-Ww8/tLwDf4XdWo5POxuf9Bdkr+c\"",
    "mtime": "2025-04-13T20:04:20.346Z",
    "size": 47295,
    "path": "../public/app-assets/images/pages/content-img-1.jpg"
  },
  "/app-assets/images/pages/content-img-2.jpg": {
    "type": "image/jpeg",
    "etag": "\"56c1-50eSStLlba3UqZxh1cYm0Vzq7qs\"",
    "mtime": "2025-04-13T20:04:20.345Z",
    "size": 22209,
    "path": "../public/app-assets/images/pages/content-img-2.jpg"
  },
  "/app-assets/images/pages/content-img-3.jpg": {
    "type": "image/jpeg",
    "etag": "\"9f29-Ke1qcq+LLxKsjTiABR8dHJSJgaQ\"",
    "mtime": "2025-04-13T20:04:20.345Z",
    "size": 40745,
    "path": "../public/app-assets/images/pages/content-img-3.jpg"
  },
  "/app-assets/images/pages/content-img-4.jpg": {
    "type": "image/jpeg",
    "etag": "\"e1f1-CDc4EpqqZczSKs9/BZdz/7MfWGQ\"",
    "mtime": "2025-04-13T20:04:20.345Z",
    "size": 57841,
    "path": "../public/app-assets/images/pages/content-img-4.jpg"
  },
  "/app-assets/images/pages/faq.jpg": {
    "type": "image/jpeg",
    "etag": "\"17da3-lB/ehGDJjrPnPVgEagRrzGwKcAw\"",
    "mtime": "2025-04-13T20:04:20.345Z",
    "size": 97699,
    "path": "../public/app-assets/images/pages/faq.jpg"
  },
  "/app-assets/images/pages/forgot-password.png": {
    "type": "image/png",
    "etag": "\"2cfa-hbZ2GhDJCh6ZeV/e9JO+YmNkrh0\"",
    "mtime": "2025-04-13T20:04:20.345Z",
    "size": 11514,
    "path": "../public/app-assets/images/pages/forgot-password.png"
  },
  "/app-assets/images/pages/graphic-1.png": {
    "type": "image/png",
    "etag": "\"af94-qmrt/qDwwzI5R3aQPx1+1XWhnbs\"",
    "mtime": "2025-04-13T20:04:20.345Z",
    "size": 44948,
    "path": "../public/app-assets/images/pages/graphic-1.png"
  },
  "/app-assets/images/pages/graphic-2.png": {
    "type": "image/png",
    "etag": "\"5119-Jth4SN78sQKdqQpKmmRYW1BOGKU\"",
    "mtime": "2025-04-13T20:04:20.346Z",
    "size": 20761,
    "path": "../public/app-assets/images/pages/graphic-2.png"
  },
  "/app-assets/images/pages/graphic-3.png": {
    "type": "image/png",
    "etag": "\"6120-TDRMjJXnEz/afJNpVl8Ve0yji5c\"",
    "mtime": "2025-04-13T20:04:20.346Z",
    "size": 24864,
    "path": "../public/app-assets/images/pages/graphic-3.png"
  },
  "/app-assets/images/pages/graphic-4.png": {
    "type": "image/png",
    "etag": "\"8153-yPe5GO/BnbOmvyALCnYGYadBvWg\"",
    "mtime": "2025-04-13T20:04:20.346Z",
    "size": 33107,
    "path": "../public/app-assets/images/pages/graphic-4.png"
  },
  "/app-assets/images/pages/graphic-5.png": {
    "type": "image/png",
    "etag": "\"7064-+uvsho8XHH0NyyDxqvlnePzdmKU\"",
    "mtime": "2025-04-13T20:04:20.347Z",
    "size": 28772,
    "path": "../public/app-assets/images/pages/graphic-5.png"
  },
  "/app-assets/images/pages/graphic-6.png": {
    "type": "image/png",
    "etag": "\"4f77-4Jcx3+S7qSHnrQEIpzVkwTa7Qdc\"",
    "mtime": "2025-04-13T20:04:20.346Z",
    "size": 20343,
    "path": "../public/app-assets/images/pages/graphic-6.png"
  },
  "/app-assets/images/pages/kb-article.jpg": {
    "type": "image/jpeg",
    "etag": "\"106db-v8QjQvxbMH0f87iTRsTlDT347tQ\"",
    "mtime": "2025-04-13T20:04:20.347Z",
    "size": 67291,
    "path": "../public/app-assets/images/pages/kb-article.jpg"
  },
  "/app-assets/images/pages/knowledge-base-cover.jpg": {
    "type": "image/jpeg",
    "etag": "\"af8d-Xu1lpX7L2fAMY9DkGHvwvkqBFnQ\"",
    "mtime": "2025-04-13T20:04:20.347Z",
    "size": 44941,
    "path": "../public/app-assets/images/pages/knowledge-base-cover.jpg"
  },
  "/app-assets/images/pages/lock-screen.png": {
    "type": "image/png",
    "etag": "\"3c06-c7aWpcHqvwEZeSCee26CTF679IY\"",
    "mtime": "2025-04-13T20:04:20.346Z",
    "size": 15366,
    "path": "../public/app-assets/images/pages/lock-screen.png"
  },
  "/app-assets/images/pages/login.png": {
    "type": "image/png",
    "etag": "\"4eee-cLPLAKZarPiLQM0OtQJBhjyQ7b8\"",
    "mtime": "2025-04-13T20:04:20.347Z",
    "size": 20206,
    "path": "../public/app-assets/images/pages/login.png"
  },
  "/app-assets/images/pages/maintenance-2.png": {
    "type": "image/png",
    "etag": "\"3628-wghdPKTxSauyn14QEtD/3TZFC5w\"",
    "mtime": "2025-04-13T20:04:20.347Z",
    "size": 13864,
    "path": "../public/app-assets/images/pages/maintenance-2.png"
  },
  "/app-assets/images/pages/modern.jpg": {
    "type": "image/jpeg",
    "etag": "\"bf52-9Ts1oGD8nq3usC3mZBSpxJ9phkk\"",
    "mtime": "2025-04-13T20:04:20.347Z",
    "size": 48978,
    "path": "../public/app-assets/images/pages/modern.jpg"
  },
  "/app-assets/images/pages/not-authorized.png": {
    "type": "image/png",
    "etag": "\"4a0f-KCG0tJfq7hqh7WwFpPuYVu0j6Gw\"",
    "mtime": "2025-04-13T20:04:20.347Z",
    "size": 18959,
    "path": "../public/app-assets/images/pages/not-authorized.png"
  },
  "/app-assets/images/pages/register.jpg": {
    "type": "image/jpeg",
    "etag": "\"3247-rqJtm9TJ97n4lEu7+m7L+A7IoRQ\"",
    "mtime": "2025-04-13T20:04:20.348Z",
    "size": 12871,
    "path": "../public/app-assets/images/pages/register.jpg"
  },
  "/app-assets/images/pages/reset-password.png": {
    "type": "image/png",
    "etag": "\"31f2-AOzskyjEDlT487L5ocnhQlmehBo\"",
    "mtime": "2025-04-13T20:04:20.348Z",
    "size": 12786,
    "path": "../public/app-assets/images/pages/reset-password.png"
  },
  "/app-assets/images/pages/rocket.png": {
    "type": "image/png",
    "etag": "\"25cf-gabTRbYhwwMZf6JKROcdOr3Inv0\"",
    "mtime": "2025-04-13T20:04:20.347Z",
    "size": 9679,
    "path": "../public/app-assets/images/pages/rocket.png"
  },
  "/app-assets/images/pages/search-result.jpg": {
    "type": "image/jpeg",
    "etag": "\"5ea5-E5nXIwzLx4cUUkba4Js19wpiArY\"",
    "mtime": "2025-04-13T20:04:20.347Z",
    "size": 24229,
    "path": "../public/app-assets/images/pages/search-result.jpg"
  },
  "/app-assets/images/pages/vuexy-login-bg.jpg": {
    "type": "image/jpeg",
    "etag": "\"31dd-I+6OyPQROLBPgBgZpD+B5oK00Po\"",
    "mtime": "2025-04-13T20:04:20.348Z",
    "size": 12765,
    "path": "../public/app-assets/images/pages/vuexy-login-bg.jpg"
  },
  "/app-assets/images/slider/01.jpg": {
    "type": "image/jpeg",
    "etag": "\"a9f3-K2gmlY/koW8S+EXO/Bmr+TLUFuQ\"",
    "mtime": "2025-04-13T20:04:20.349Z",
    "size": 43507,
    "path": "../public/app-assets/images/slider/01.jpg"
  },
  "/app-assets/images/slider/02.jpg": {
    "type": "image/jpeg",
    "etag": "\"584d0-7YbTupbkfZQaAdYh1MJXmH2Hv6M\"",
    "mtime": "2025-04-13T20:04:20.324Z",
    "size": 361680,
    "path": "../public/app-assets/images/slider/02.jpg"
  },
  "/app-assets/images/slider/03.jpg": {
    "type": "image/jpeg",
    "etag": "\"8ff6-0rONExeUGoM9CVb/oU0F/jn4Ww8\"",
    "mtime": "2025-04-13T20:04:20.349Z",
    "size": 36854,
    "path": "../public/app-assets/images/slider/03.jpg"
  },
  "/app-assets/images/slider/04.jpg": {
    "type": "image/jpeg",
    "etag": "\"1f770-GvYYMN/2ZF1EiuFg/m3KUIRHfkI\"",
    "mtime": "2025-04-13T20:04:20.349Z",
    "size": 128880,
    "path": "../public/app-assets/images/slider/04.jpg"
  },
  "/app-assets/images/slider/05.jpg": {
    "type": "image/jpeg",
    "etag": "\"238ff-5dUzXgB8QV7K0a8iTWFT6l0K5pY\"",
    "mtime": "2025-04-13T20:04:20.351Z",
    "size": 145663,
    "path": "../public/app-assets/images/slider/05.jpg"
  },
  "/app-assets/images/slider/06.jpg": {
    "type": "image/jpeg",
    "etag": "\"16e63-ByWuJW3VHH1vM9ppECCNMYr9C/E\"",
    "mtime": "2025-04-13T20:04:20.349Z",
    "size": 93795,
    "path": "../public/app-assets/images/slider/06.jpg"
  },
  "/app-assets/js/core/app-menu.min.js": {
    "type": "text/javascript; charset=utf-8",
    "etag": "\"4172-1NJ/pE9NTvSgoc3EW1ix5vFt2CI\"",
    "mtime": "2025-04-13T20:04:20.316Z",
    "size": 16754,
    "path": "../public/app-assets/js/core/app-menu.min.js"
  },
  "/app-assets/js/core/app-menu.min.js.br": {
    "type": "text/javascript; charset=utf-8",
    "encoding": "br",
    "etag": "\"d42-EofZjiim7oeZAswOo/+rpKCzUGg\"",
    "mtime": "2025-04-13T20:04:28.215Z",
    "size": 3394,
    "path": "../public/app-assets/js/core/app-menu.min.js.br"
  },
  "/app-assets/js/core/app-menu.min.js.gz": {
    "type": "text/javascript; charset=utf-8",
    "encoding": "gzip",
    "etag": "\"ef3-OPmUqSCYBvE5g9AWtLTHqqVfr5M\"",
    "mtime": "2025-04-13T20:04:28.215Z",
    "size": 3827,
    "path": "../public/app-assets/js/core/app-menu.min.js.gz"
  },
  "/app-assets/js/core/app.min.js": {
    "type": "text/javascript; charset=utf-8",
    "etag": "\"37d5-5zLE0trDyoH9Hcrkqz/5s57/xuc\"",
    "mtime": "2025-04-13T20:04:20.350Z",
    "size": 14293,
    "path": "../public/app-assets/js/core/app.min.js"
  },
  "/app-assets/js/core/app.min.js.br": {
    "type": "text/javascript; charset=utf-8",
    "encoding": "br",
    "etag": "\"d9e-+a3Oyw5JRsjlkhYEHX3hIpjdqi4\"",
    "mtime": "2025-04-13T20:04:28.215Z",
    "size": 3486,
    "path": "../public/app-assets/js/core/app.min.js.br"
  },
  "/app-assets/js/core/app.min.js.gz": {
    "type": "text/javascript; charset=utf-8",
    "encoding": "gzip",
    "etag": "\"f9d-YFW9+gDHEN7O9laPAywgpeESU7Q\"",
    "mtime": "2025-04-13T20:04:28.215Z",
    "size": 3997,
    "path": "../public/app-assets/js/core/app.min.js.gz"
  },
  "/app-assets/js/scripts/components.min.js": {
    "type": "text/javascript; charset=utf-8",
    "etag": "\"47b-1DUjFGku5Antzcy8SgWEctjVXnk\"",
    "mtime": "2025-04-13T20:04:20.348Z",
    "size": 1147,
    "path": "../public/app-assets/js/scripts/components.min.js"
  },
  "/app-assets/js/scripts/components.min.js.br": {
    "type": "text/javascript; charset=utf-8",
    "encoding": "br",
    "etag": "\"192-KOgpizYc7EX1PjFxW1jz0kv0uHU\"",
    "mtime": "2025-04-13T20:04:28.215Z",
    "size": 402,
    "path": "../public/app-assets/js/scripts/components.min.js.br"
  },
  "/app-assets/js/scripts/components.min.js.gz": {
    "type": "text/javascript; charset=utf-8",
    "encoding": "gzip",
    "etag": "\"1f7-ZqULY4Mx93K03WpIcaYBWp+m1Jc\"",
    "mtime": "2025-04-13T20:04:28.215Z",
    "size": 503,
    "path": "../public/app-assets/js/scripts/components.min.js.gz"
  },
  "/app-assets/js/scripts/customizer.min.js": {
    "type": "text/javascript; charset=utf-8",
    "etag": "\"1777-UeNKf1hlo3RfNCwn9OafRrhKhq8\"",
    "mtime": "2025-04-13T20:04:20.349Z",
    "size": 6007,
    "path": "../public/app-assets/js/scripts/customizer.min.js"
  },
  "/app-assets/js/scripts/customizer.min.js.br": {
    "type": "text/javascript; charset=utf-8",
    "encoding": "br",
    "etag": "\"574-1kU2/XqG92azFsMlZHWZo6zB5Ss\"",
    "mtime": "2025-04-13T20:04:28.215Z",
    "size": 1396,
    "path": "../public/app-assets/js/scripts/customizer.min.js.br"
  },
  "/app-assets/js/scripts/customizer.min.js.gz": {
    "type": "text/javascript; charset=utf-8",
    "encoding": "gzip",
    "etag": "\"640-l8duCmMp32BVp0hW6xB9ZaNJeOQ\"",
    "mtime": "2025-04-13T20:04:28.215Z",
    "size": 1600,
    "path": "../public/app-assets/js/scripts/customizer.min.js.gz"
  },
  "/app-assets/js/scripts/footer.min.js": {
    "type": "text/javascript; charset=utf-8",
    "etag": "\"d9-4YKHbUTsp3VBnzC45L7RV7h/CqE\"",
    "mtime": "2025-04-13T20:04:20.349Z",
    "size": 217,
    "path": "../public/app-assets/js/scripts/footer.min.js"
  },
  "/app-assets/vendors/css/vendors.min.css": {
    "type": "text/css; charset=utf-8",
    "etag": "\"3acdb-rRNvwDMYl5hrwGnBbLTRfGVyZt4\"",
    "mtime": "2025-04-13T20:04:20.349Z",
    "size": 240859,
    "path": "../public/app-assets/vendors/css/vendors.min.css"
  },
  "/app-assets/vendors/css/vendors.min.css.br": {
    "type": "text/css; charset=utf-8",
    "encoding": "br",
    "etag": "\"1a778-WHajkOKmo9CKyJyllOLA86yFJFg\"",
    "mtime": "2025-04-13T20:04:28.749Z",
    "size": 108408,
    "path": "../public/app-assets/vendors/css/vendors.min.css.br"
  },
  "/app-assets/vendors/css/vendors.min.css.gz": {
    "type": "text/css; charset=utf-8",
    "encoding": "gzip",
    "etag": "\"1b9bb-6nSk5thqMESYJ+TSbXB7d0VWUuY\"",
    "mtime": "2025-04-13T20:04:28.749Z",
    "size": 113083,
    "path": "../public/app-assets/vendors/css/vendors.min.css.gz"
  },
  "/app-assets/vendors/js/vendors.min.js": {
    "type": "text/javascript; charset=utf-8",
    "etag": "\"82aa4-NluH8MbYgyX1XbMKCrjVQjy5dBc\"",
    "mtime": "2025-04-13T20:04:20.326Z",
    "size": 535204,
    "path": "../public/app-assets/vendors/js/vendors.min.js"
  },
  "/app-assets/vendors/js/vendors.min.js.br": {
    "type": "text/javascript; charset=utf-8",
    "encoding": "br",
    "etag": "\"181ac-OYgymBK2RiMkOLND1DeI7obORHA\"",
    "mtime": "2025-04-13T20:04:28.767Z",
    "size": 98732,
    "path": "../public/app-assets/vendors/js/vendors.min.js.br"
  },
  "/app-assets/vendors/js/vendors.min.js.gz": {
    "type": "text/javascript; charset=utf-8",
    "encoding": "gzip",
    "etag": "\"1c816-LKn3SW/uIExpfxMXAVivId59QMI\"",
    "mtime": "2025-04-13T20:04:28.770Z",
    "size": 116758,
    "path": "../public/app-assets/vendors/js/vendors.min.js.gz"
  },
  "/_nuxt/builds/meta/0ebc614b-2d19-480c-bf98-99328c20ff90.json": {
    "type": "application/json",
    "etag": "\"c0-P2MO8r1CP9xTNF5vcNn8RRZsDl0\"",
    "mtime": "2025-04-13T20:04:20.226Z",
    "size": 192,
    "path": "../public/_nuxt/builds/meta/0ebc614b-2d19-480c-bf98-99328c20ff90.json"
  },
  "/app-assets/css/core/colors/palette-gradient.min.css": {
    "type": "text/css; charset=utf-8",
    "etag": "\"12d8-WJduYRsd4eHkRDlesrDUdvfLmdQ\"",
    "mtime": "2025-04-13T20:04:20.315Z",
    "size": 4824,
    "path": "../public/app-assets/css/core/colors/palette-gradient.min.css"
  },
  "/app-assets/css/core/colors/palette-gradient.min.css.br": {
    "type": "text/css; charset=utf-8",
    "encoding": "br",
    "etag": "\"249-pcYvGZRjHOqj0vkpqJvj1XOskpc\"",
    "mtime": "2025-04-13T20:04:28.215Z",
    "size": 585,
    "path": "../public/app-assets/css/core/colors/palette-gradient.min.css.br"
  },
  "/app-assets/css/core/colors/palette-gradient.min.css.gz": {
    "type": "text/css; charset=utf-8",
    "encoding": "gzip",
    "etag": "\"2b2-Q1hY3CLu93irZmpuiguAZ1VGknA\"",
    "mtime": "2025-04-13T20:04:28.215Z",
    "size": 690,
    "path": "../public/app-assets/css/core/colors/palette-gradient.min.css.gz"
  },
  "/app-assets/css/core/colors/palette-noui.css": {
    "type": "text/css; charset=utf-8",
    "etag": "\"c84-Te9fzBLveKZ65kABGBc3TJKf1m0\"",
    "mtime": "2025-04-13T20:04:20.350Z",
    "size": 3204,
    "path": "../public/app-assets/css/core/colors/palette-noui.css"
  },
  "/app-assets/css/core/colors/palette-noui.css.br": {
    "type": "text/css; charset=utf-8",
    "encoding": "br",
    "etag": "\"123-ZoNhs2zHISmtRipwNUnt6zIl8cQ\"",
    "mtime": "2025-04-13T20:04:28.215Z",
    "size": 291,
    "path": "../public/app-assets/css/core/colors/palette-noui.css.br"
  },
  "/app-assets/css/core/colors/palette-noui.css.gz": {
    "type": "text/css; charset=utf-8",
    "encoding": "gzip",
    "etag": "\"17c-Qt8pZZ1t0doHj4ojd2/49XyU1oU\"",
    "mtime": "2025-04-13T20:04:28.215Z",
    "size": 380,
    "path": "../public/app-assets/css/core/colors/palette-noui.css.gz"
  },
  "/app-assets/css/plugins/animate/animate.min.css": {
    "type": "text/css; charset=utf-8",
    "etag": "\"d9e4-Vgy58X5FsrTreKG89V7Kw645XiU\"",
    "mtime": "2025-04-13T20:04:20.323Z",
    "size": 55780,
    "path": "../public/app-assets/css/plugins/animate/animate.min.css"
  },
  "/app-assets/css/plugins/animate/animate.min.css.br": {
    "type": "text/css; charset=utf-8",
    "encoding": "br",
    "etag": "\"c82-cglLxfHC+R2CqhfNlwkTQjrD13k\"",
    "mtime": "2025-04-13T20:04:28.215Z",
    "size": 3202,
    "path": "../public/app-assets/css/plugins/animate/animate.min.css.br"
  },
  "/app-assets/css/plugins/animate/animate.min.css.gz": {
    "type": "text/css; charset=utf-8",
    "encoding": "gzip",
    "etag": "\"e87-jaB2rk0DV9ewxDz5xtR57BLsHik\"",
    "mtime": "2025-04-13T20:04:28.216Z",
    "size": 3719,
    "path": "../public/app-assets/css/plugins/animate/animate.min.css.gz"
  },
  "/app-assets/css/plugins/calendars/fullcalendar.min.css": {
    "type": "text/css; charset=utf-8",
    "etag": "\"422c-rgM9v0jQWd9tuw5guj7ms+he14A\"",
    "mtime": "2025-04-13T20:04:20.316Z",
    "size": 16940,
    "path": "../public/app-assets/css/plugins/calendars/fullcalendar.min.css"
  },
  "/app-assets/css/plugins/calendars/fullcalendar.min.css.br": {
    "type": "text/css; charset=utf-8",
    "encoding": "br",
    "etag": "\"8be-csPy19T/m0FYoThb4C9U7JaJIJ8\"",
    "mtime": "2025-04-13T20:04:28.215Z",
    "size": 2238,
    "path": "../public/app-assets/css/plugins/calendars/fullcalendar.min.css.br"
  },
  "/app-assets/css/plugins/calendars/fullcalendar.min.css.gz": {
    "type": "text/css; charset=utf-8",
    "encoding": "gzip",
    "etag": "\"a79-P/Ntu3BehUEgFC/cgf9h09x+Ka0\"",
    "mtime": "2025-04-13T20:04:28.215Z",
    "size": 2681,
    "path": "../public/app-assets/css/plugins/calendars/fullcalendar.min.css.gz"
  },
  "/app-assets/css/plugins/extensions/context-menu.min.css": {
    "type": "text/css; charset=utf-8",
    "etag": "\"af-dB8b6ozJEfe5pFKBhJ5j76kqWtI\"",
    "mtime": "2025-04-13T20:04:20.351Z",
    "size": 175,
    "path": "../public/app-assets/css/plugins/extensions/context-menu.min.css"
  },
  "/app-assets/css/plugins/extensions/drag-and-drop.min.css": {
    "type": "text/css; charset=utf-8",
    "etag": "\"19b-eEMypCY3adYn+OhRRGPUnHMHYbg\"",
    "mtime": "2025-04-13T20:04:20.323Z",
    "size": 411,
    "path": "../public/app-assets/css/plugins/extensions/drag-and-drop.min.css"
  },
  "/app-assets/css/plugins/extensions/media-plyr.min.css": {
    "type": "text/css; charset=utf-8",
    "etag": "\"ee-NJeQVIV5D6uc3B0nw1UCsWHUdv8\"",
    "mtime": "2025-04-13T20:04:20.351Z",
    "size": 238,
    "path": "../public/app-assets/css/plugins/extensions/media-plyr.min.css"
  },
  "/app-assets/css/plugins/extensions/noui-slider.min.css": {
    "type": "text/css; charset=utf-8",
    "etag": "\"9c9-S9l8TPnAD4QGlTolLXPh2zpcYa0\"",
    "mtime": "2025-04-13T20:04:20.351Z",
    "size": 2505,
    "path": "../public/app-assets/css/plugins/extensions/noui-slider.min.css"
  },
  "/app-assets/css/plugins/extensions/noui-slider.min.css.br": {
    "type": "text/css; charset=utf-8",
    "encoding": "br",
    "etag": "\"222-/PGut5Wj6GxsTeyBe3KJEdreZdM\"",
    "mtime": "2025-04-13T20:04:28.215Z",
    "size": 546,
    "path": "../public/app-assets/css/plugins/extensions/noui-slider.min.css.br"
  },
  "/app-assets/css/plugins/extensions/noui-slider.min.css.gz": {
    "type": "text/css; charset=utf-8",
    "encoding": "gzip",
    "etag": "\"2ad-tf8ZXzvBuoEgVwbKj08ReUZmVwA\"",
    "mtime": "2025-04-13T20:04:28.215Z",
    "size": 685,
    "path": "../public/app-assets/css/plugins/extensions/noui-slider.min.css.gz"
  },
  "/app-assets/css/plugins/extensions/swiper.min.css": {
    "type": "text/css; charset=utf-8",
    "etag": "\"cc8-ClGCwn5rk6M612mFsxqTVmcnGcA\"",
    "mtime": "2025-04-13T20:04:20.351Z",
    "size": 3272,
    "path": "../public/app-assets/css/plugins/extensions/swiper.min.css"
  },
  "/app-assets/css/plugins/extensions/swiper.min.css.br": {
    "type": "text/css; charset=utf-8",
    "encoding": "br",
    "etag": "\"2b8-n62zZVpsjj8ln/MCNTXhDYLmrOc\"",
    "mtime": "2025-04-13T20:04:28.215Z",
    "size": 696,
    "path": "../public/app-assets/css/plugins/extensions/swiper.min.css.br"
  },
  "/app-assets/css/plugins/extensions/swiper.min.css.gz": {
    "type": "text/css; charset=utf-8",
    "encoding": "gzip",
    "etag": "\"360-b7nbYKEzElDBY8yl1RphC2Rgnqc\"",
    "mtime": "2025-04-13T20:04:28.215Z",
    "size": 864,
    "path": "../public/app-assets/css/plugins/extensions/swiper.min.css.gz"
  },
  "/app-assets/css/plugins/extensions/toastr.min.css": {
    "type": "text/css; charset=utf-8",
    "etag": "\"187-aMK9F+7pDNoL5Cv7ERkc6+fL6Qg\"",
    "mtime": "2025-04-13T20:04:20.351Z",
    "size": 391,
    "path": "../public/app-assets/css/plugins/extensions/toastr.min.css"
  },
  "/app-assets/css/plugins/file-uploaders/dropzone.min.css": {
    "type": "text/css; charset=utf-8",
    "etag": "\"44c-C7NQCMleC3s1rvm+qu7U8/7/x14\"",
    "mtime": "2025-04-13T20:04:20.323Z",
    "size": 1100,
    "path": "../public/app-assets/css/plugins/file-uploaders/dropzone.min.css"
  },
  "/app-assets/css/plugins/file-uploaders/dropzone.min.css.br": {
    "type": "text/css; charset=utf-8",
    "encoding": "br",
    "etag": "\"170-s0RXsLBpiJSbOpI3bPFiEivMh6s\"",
    "mtime": "2025-04-13T20:04:28.216Z",
    "size": 368,
    "path": "../public/app-assets/css/plugins/file-uploaders/dropzone.min.css.br"
  },
  "/app-assets/css/plugins/file-uploaders/dropzone.min.css.gz": {
    "type": "text/css; charset=utf-8",
    "encoding": "gzip",
    "etag": "\"1eb-9D7B1QdtzsHVkuVmaJOiFwusfss\"",
    "mtime": "2025-04-13T20:04:28.216Z",
    "size": 491,
    "path": "../public/app-assets/css/plugins/file-uploaders/dropzone.min.css.gz"
  },
  "/app-assets/css/plugins/forms/wizard.min.css": {
    "type": "text/css; charset=utf-8",
    "etag": "\"1282-zWHnr30AmlAwklRUMcC/yJVA38k\"",
    "mtime": "2025-04-13T20:04:20.354Z",
    "size": 4738,
    "path": "../public/app-assets/css/plugins/forms/wizard.min.css"
  },
  "/app-assets/css/plugins/forms/wizard.min.css.br": {
    "type": "text/css; charset=utf-8",
    "encoding": "br",
    "etag": "\"324-cvqBmTBiaglu9GrtxuOeArMqucU\"",
    "mtime": "2025-04-13T20:04:28.216Z",
    "size": 804,
    "path": "../public/app-assets/css/plugins/forms/wizard.min.css.br"
  },
  "/app-assets/css/plugins/forms/wizard.min.css.gz": {
    "type": "text/css; charset=utf-8",
    "encoding": "gzip",
    "etag": "\"3e8-ViX9xr8dqPPcAzfN2kQVlfkQHvQ\"",
    "mtime": "2025-04-13T20:04:28.216Z",
    "size": 1000,
    "path": "../public/app-assets/css/plugins/forms/wizard.min.css.gz"
  },
  "/app-assets/fonts/feather/fonts/feather.eot": {
    "type": "application/vnd.ms-fontobject",
    "etag": "\"f284-pLeVCDilkbggqCtZHoUFr0has1E\"",
    "mtime": "2025-04-13T20:04:20.318Z",
    "size": 62084,
    "path": "../public/app-assets/fonts/feather/fonts/feather.eot"
  },
  "/app-assets/fonts/feather/fonts/feather.eot.br": {
    "type": "application/vnd.ms-fontobject",
    "encoding": "br",
    "etag": "\"6ae9-HwlB71G249W1sjQB/fxyGZDoKI8\"",
    "mtime": "2025-04-13T20:04:28.585Z",
    "size": 27369,
    "path": "../public/app-assets/fonts/feather/fonts/feather.eot.br"
  },
  "/app-assets/fonts/feather/fonts/feather.eot.gz": {
    "type": "application/vnd.ms-fontobject",
    "encoding": "gzip",
    "etag": "\"75a4-BZYOIGqz/lsCEww6aT82J7nGGQE\"",
    "mtime": "2025-04-13T20:04:28.585Z",
    "size": 30116,
    "path": "../public/app-assets/fonts/feather/fonts/feather.eot.gz"
  },
  "/app-assets/fonts/feather/fonts/feather.svg": {
    "type": "image/svg+xml",
    "etag": "\"343a6-ooGCm//hb0/putt6y/fgMJ+YSU4\"",
    "mtime": "2025-04-13T20:04:20.369Z",
    "size": 213926,
    "path": "../public/app-assets/fonts/feather/fonts/feather.svg"
  },
  "/app-assets/fonts/feather/fonts/feather.svg.br": {
    "type": "image/svg+xml",
    "encoding": "br",
    "etag": "\"8982-pjRTl/VylQo8v+dlZYZevLrlBkI\"",
    "mtime": "2025-04-13T20:04:28.649Z",
    "size": 35202,
    "path": "../public/app-assets/fonts/feather/fonts/feather.svg.br"
  },
  "/app-assets/fonts/feather/fonts/feather.svg.gz": {
    "type": "image/svg+xml",
    "encoding": "gzip",
    "etag": "\"a791-w4WCNXJ6S+5wIgPS7A9FHvgNmDo\"",
    "mtime": "2025-04-13T20:04:28.650Z",
    "size": 42897,
    "path": "../public/app-assets/fonts/feather/fonts/feather.svg.gz"
  },
  "/app-assets/fonts/feather/fonts/feather.ttf": {
    "type": "font/ttf",
    "etag": "\"f1e0-K96FPLt2mquAsY81RKfnwfLL0xs\"",
    "mtime": "2025-04-13T20:04:20.367Z",
    "size": 61920,
    "path": "../public/app-assets/fonts/feather/fonts/feather.ttf"
  },
  "/app-assets/fonts/feather/fonts/feather.ttf.br": {
    "type": "font/ttf",
    "encoding": "br",
    "etag": "\"6a84-fHoTQ9GCwocrskizpslUel5SzTc\"",
    "mtime": "2025-04-13T20:04:28.585Z",
    "size": 27268,
    "path": "../public/app-assets/fonts/feather/fonts/feather.ttf.br"
  },
  "/app-assets/fonts/feather/fonts/feather.ttf.gz": {
    "type": "font/ttf",
    "encoding": "gzip",
    "etag": "\"7556-GeFCZk/cW3EVx+dNZtA/W1YqkyQ\"",
    "mtime": "2025-04-13T20:04:28.585Z",
    "size": 30038,
    "path": "../public/app-assets/fonts/feather/fonts/feather.ttf.gz"
  },
  "/app-assets/fonts/feather/fonts/feather.woff": {
    "type": "font/woff",
    "etag": "\"733c-fmowbm+2F48yXmrZqZx2G6UHQEQ\"",
    "mtime": "2025-04-13T20:04:20.367Z",
    "size": 29500,
    "path": "../public/app-assets/fonts/feather/fonts/feather.woff"
  },
  "/app-assets/data/fullcalendar/json/events.json": {
    "type": "application/json",
    "etag": "\"402-QILlAi2ZdXI1+YYp80RI6O1FGXs\"",
    "mtime": "2025-04-13T20:04:20.317Z",
    "size": 1026,
    "path": "../public/app-assets/data/fullcalendar/json/events.json"
  },
  "/app-assets/data/fullcalendar/json/events.json.br": {
    "type": "application/json",
    "encoding": "br",
    "etag": "\"ef-KGKUePWv9KQRfWDFIZ6dzUivafs\"",
    "mtime": "2025-04-13T20:04:28.216Z",
    "size": 239,
    "path": "../public/app-assets/data/fullcalendar/json/events.json.br"
  },
  "/app-assets/data/fullcalendar/json/events.json.gz": {
    "type": "application/json",
    "encoding": "gzip",
    "etag": "\"11b-CZlVpkdlJRn6rGzAmS7E4zsJcQQ\"",
    "mtime": "2025-04-13T20:04:28.216Z",
    "size": 283,
    "path": "../public/app-assets/data/fullcalendar/json/events.json.gz"
  },
  "/app-assets/css/plugins/tour/tour.min.css": {
    "type": "text/css; charset=utf-8",
    "etag": "\"687-/Ht4IrVOvsIDGlHSqwflrHWJKXg\"",
    "mtime": "2025-04-13T20:04:20.323Z",
    "size": 1671,
    "path": "../public/app-assets/css/plugins/tour/tour.min.css"
  },
  "/app-assets/css/plugins/tour/tour.min.css.br": {
    "type": "text/css; charset=utf-8",
    "encoding": "br",
    "etag": "\"14b-ImGJYVLMvSNw8l6QLIac3UhqmAU\"",
    "mtime": "2025-04-13T20:04:28.216Z",
    "size": 331,
    "path": "../public/app-assets/css/plugins/tour/tour.min.css.br"
  },
  "/app-assets/css/plugins/tour/tour.min.css.gz": {
    "type": "text/css; charset=utf-8",
    "encoding": "gzip",
    "etag": "\"1ab-+cKSKgG3676ErbF0h0C6cjXEOZc\"",
    "mtime": "2025-04-13T20:04:28.215Z",
    "size": 427,
    "path": "../public/app-assets/css/plugins/tour/tour.min.css.gz"
  },
  "/app-assets/data/fullcalendar/php/get-events.php": {
    "type": "application/x-httpd-php",
    "etag": "\"703-0HWaGNerRDx3BLIL72DGvCEH3e8\"",
    "mtime": "2025-04-13T20:04:20.374Z",
    "size": 1795,
    "path": "../public/app-assets/data/fullcalendar/php/get-events.php"
  },
  "/app-assets/data/fullcalendar/php/get-timezones.php": {
    "type": "application/x-httpd-php",
    "etag": "\"189-YCnT31zczukt0Ay0Y+Ie6Zt55p0\"",
    "mtime": "2025-04-13T20:04:20.329Z",
    "size": 393,
    "path": "../public/app-assets/data/fullcalendar/php/get-timezones.php"
  },
  "/app-assets/data/fullcalendar/php/utils.php": {
    "type": "application/x-httpd-php",
    "etag": "\"f77-CCrefb8CM6mX+sN6uNX7/srCKWU\"",
    "mtime": "2025-04-13T20:04:20.372Z",
    "size": 3959,
    "path": "../public/app-assets/data/fullcalendar/php/utils.php"
  },
  "/app-assets/fonts/flag-icon-css/css/flag-icon.css": {
    "type": "text/css; charset=utf-8",
    "etag": "\"9206-QfqwuyDzxM+UejB8z1cPrxVqDLA\"",
    "mtime": "2025-04-13T20:04:20.366Z",
    "size": 37382,
    "path": "../public/app-assets/fonts/flag-icon-css/css/flag-icon.css"
  },
  "/app-assets/fonts/flag-icon-css/css/flag-icon.css.br": {
    "type": "text/css; charset=utf-8",
    "encoding": "br",
    "etag": "\"5fd-ghoAuaA4ReaE1uIf1Fz5UTa9iNw\"",
    "mtime": "2025-04-13T20:04:28.216Z",
    "size": 1533,
    "path": "../public/app-assets/fonts/flag-icon-css/css/flag-icon.css.br"
  },
  "/app-assets/fonts/flag-icon-css/css/flag-icon.css.gz": {
    "type": "text/css; charset=utf-8",
    "encoding": "gzip",
    "etag": "\"9b3-l2IM2UpD1hgDmbub1D05aJsVQCE\"",
    "mtime": "2025-04-13T20:04:28.216Z",
    "size": 2483,
    "path": "../public/app-assets/fonts/flag-icon-css/css/flag-icon.css.gz"
  },
  "/app-assets/fonts/flag-icon-css/css/flag-icon.min.css": {
    "type": "text/css; charset=utf-8",
    "etag": "\"81b5-cdSYbCUa5EXX/c2IQyM/MQ4ugUg\"",
    "mtime": "2025-04-13T20:04:20.317Z",
    "size": 33205,
    "path": "../public/app-assets/fonts/flag-icon-css/css/flag-icon.min.css"
  },
  "/app-assets/fonts/flag-icon-css/css/flag-icon.min.css.br": {
    "type": "text/css; charset=utf-8",
    "encoding": "br",
    "etag": "\"582-Vco/wF0JpAoxioAJg2aSXbGinU0\"",
    "mtime": "2025-04-13T20:04:28.216Z",
    "size": 1410,
    "path": "../public/app-assets/fonts/flag-icon-css/css/flag-icon.min.css.br"
  },
  "/app-assets/fonts/flag-icon-css/css/flag-icon.min.css.gz": {
    "type": "text/css; charset=utf-8",
    "encoding": "gzip",
    "etag": "\"979-jY+Z1LXz2A2hkNx7Y49PZ+nq1yo\"",
    "mtime": "2025-04-13T20:04:28.216Z",
    "size": 2425,
    "path": "../public/app-assets/fonts/flag-icon-css/css/flag-icon.min.css.gz"
  },
  "/app-assets/fonts/flag-icon-css/sass/flag-icon-base.scss": {
    "type": "text/x-scss; charset=utf-8",
    "etag": "\"270-bRKWWCvOWfk9PJ7tMH18wg0AMhY\"",
    "mtime": "2025-04-13T20:04:20.328Z",
    "size": 624,
    "path": "../public/app-assets/fonts/flag-icon-css/sass/flag-icon-base.scss"
  },
  "/app-assets/fonts/flag-icon-css/sass/flag-icon-list.scss": {
    "type": "text/x-scss; charset=utf-8",
    "etag": "\"1758-eBLNfZ8X+V4ei4ECs8aSbb7H7hU\"",
    "mtime": "2025-04-13T20:04:20.366Z",
    "size": 5976,
    "path": "../public/app-assets/fonts/flag-icon-css/sass/flag-icon-list.scss"
  },
  "/app-assets/fonts/flag-icon-css/sass/flag-icon-more.scss": {
    "type": "text/x-scss; charset=utf-8",
    "etag": "\"6c-k/zoNNuyx7NHCgp7PtUxbkNnYy8\"",
    "mtime": "2025-04-13T20:04:20.366Z",
    "size": 108,
    "path": "../public/app-assets/fonts/flag-icon-css/sass/flag-icon-more.scss"
  },
  "/app-assets/fonts/flag-icon-css/sass/flag-icon.scss": {
    "type": "text/x-scss; charset=utf-8",
    "etag": "\"63-ilp/5o40GuoCsF0NQwm2Q/ym9z4\"",
    "mtime": "2025-04-13T20:04:20.366Z",
    "size": 99,
    "path": "../public/app-assets/fonts/flag-icon-css/sass/flag-icon.scss"
  },
  "/app-assets/fonts/flag-icon-css/sass/variables.scss": {
    "type": "text/x-scss; charset=utf-8",
    "etag": "\"7a-vkfHHfWiHgrJiD21VHEiWV69SZ0\"",
    "mtime": "2025-04-13T20:04:20.366Z",
    "size": 122,
    "path": "../public/app-assets/fonts/flag-icon-css/sass/variables.scss"
  },
  "/app-assets/fonts/font-awesome/css/font-awesome.css": {
    "type": "text/css; charset=utf-8",
    "etag": "\"11d9d-ad7MGdqS3CvYZCZfFv1zfZXlWtY\"",
    "mtime": "2025-04-13T20:04:20.367Z",
    "size": 73117,
    "path": "../public/app-assets/fonts/font-awesome/css/font-awesome.css"
  },
  "/app-assets/fonts/font-awesome/css/font-awesome.css.br": {
    "type": "text/css; charset=utf-8",
    "encoding": "br",
    "etag": "\"2997-w6eRU4XCv0l5rYyFXFzbzzhN/rA\"",
    "mtime": "2025-04-13T20:04:28.216Z",
    "size": 10647,
    "path": "../public/app-assets/fonts/font-awesome/css/font-awesome.css.br"
  },
  "/app-assets/fonts/font-awesome/css/font-awesome.css.gz": {
    "type": "text/css; charset=utf-8",
    "encoding": "gzip",
    "etag": "\"32fa-JUC2cOF44TqcKURJUi1SUljg0cc\"",
    "mtime": "2025-04-13T20:04:28.217Z",
    "size": 13050,
    "path": "../public/app-assets/fonts/font-awesome/css/font-awesome.css.gz"
  },
  "/app-assets/fonts/font-awesome/css/font-awesome.min.css": {
    "type": "text/css; charset=utf-8",
    "etag": "\"e637-bzPq6S1C/iCRZxOZQKCtajxsFn4\"",
    "mtime": "2025-04-13T20:04:20.320Z",
    "size": 58935,
    "path": "../public/app-assets/fonts/font-awesome/css/font-awesome.min.css"
  },
  "/app-assets/fonts/font-awesome/css/font-awesome.min.css.br": {
    "type": "text/css; charset=utf-8",
    "encoding": "br",
    "etag": "\"2897-3OI9gIxTlZHRCRdaD0xxPpSPKaU\"",
    "mtime": "2025-04-13T20:04:28.217Z",
    "size": 10391,
    "path": "../public/app-assets/fonts/font-awesome/css/font-awesome.min.css.br"
  },
  "/app-assets/fonts/font-awesome/css/font-awesome.min.css.gz": {
    "type": "text/css; charset=utf-8",
    "encoding": "gzip",
    "etag": "\"3113-7l6LzsVxtR/tHN2CX/59hDAGkh4\"",
    "mtime": "2025-04-13T20:04:28.218Z",
    "size": 12563,
    "path": "../public/app-assets/fonts/font-awesome/css/font-awesome.min.css.gz"
  },
  "/app-assets/images/portrait/small/avatar-s-1.jpg": {
    "type": "image/jpeg",
    "etag": "\"16a6-niMdpWfDGTRg1/1VqNozV71Ubqo\"",
    "mtime": "2025-04-13T20:04:20.316Z",
    "size": 5798,
    "path": "../public/app-assets/images/portrait/small/avatar-s-1.jpg"
  },
  "/app-assets/images/portrait/small/avatar-s-10.jpg": {
    "type": "image/jpeg",
    "etag": "\"18de-sMdT4HUFSPuKA2FUZr4d88In/eg\"",
    "mtime": "2025-04-13T20:04:20.355Z",
    "size": 6366,
    "path": "../public/app-assets/images/portrait/small/avatar-s-10.jpg"
  },
  "/app-assets/images/portrait/small/avatar-s-11.jpg": {
    "type": "image/jpeg",
    "etag": "\"195a-Bk9xHtXNxrXwPhiJj3OTDIiZmX0\"",
    "mtime": "2025-04-13T20:04:20.356Z",
    "size": 6490,
    "path": "../public/app-assets/images/portrait/small/avatar-s-11.jpg"
  },
  "/app-assets/images/portrait/small/avatar-s-12.jpg": {
    "type": "image/jpeg",
    "etag": "\"1b16-B4eboDFEaaq+5O/x5OSq6pTPBgg\"",
    "mtime": "2025-04-13T20:04:20.356Z",
    "size": 6934,
    "path": "../public/app-assets/images/portrait/small/avatar-s-12.jpg"
  },
  "/app-assets/images/portrait/small/avatar-s-13.jpg": {
    "type": "image/jpeg",
    "etag": "\"2453-TemBK1HUmFhvRlADQUEiZDn2QiA\"",
    "mtime": "2025-04-13T20:04:20.356Z",
    "size": 9299,
    "path": "../public/app-assets/images/portrait/small/avatar-s-13.jpg"
  },
  "/app-assets/images/portrait/small/avatar-s-14.jpg": {
    "type": "image/jpeg",
    "etag": "\"15f1-VjgjAW+bBCOB5OBiY+M6sFMF0ZE\"",
    "mtime": "2025-04-13T20:04:20.356Z",
    "size": 5617,
    "path": "../public/app-assets/images/portrait/small/avatar-s-14.jpg"
  },
  "/app-assets/images/portrait/small/avatar-s-15.jpg": {
    "type": "image/jpeg",
    "etag": "\"1960-Wf+rrH8kNuauAKusoqJtWJuIndo\"",
    "mtime": "2025-04-13T20:04:20.356Z",
    "size": 6496,
    "path": "../public/app-assets/images/portrait/small/avatar-s-15.jpg"
  },
  "/app-assets/images/portrait/small/avatar-s-16.jpg": {
    "type": "image/jpeg",
    "etag": "\"2012-BtTcpwwK2ZZcKfjvZFOZ9tdo+H8\"",
    "mtime": "2025-04-13T20:04:20.358Z",
    "size": 8210,
    "path": "../public/app-assets/images/portrait/small/avatar-s-16.jpg"
  },
  "/app-assets/images/portrait/small/avatar-s-17.jpg": {
    "type": "image/jpeg",
    "etag": "\"19b2-PkJc8ul8fl1hbAeI95RtKJveGFg\"",
    "mtime": "2025-04-13T20:04:20.357Z",
    "size": 6578,
    "path": "../public/app-assets/images/portrait/small/avatar-s-17.jpg"
  },
  "/app-assets/images/portrait/small/avatar-s-18.jpg": {
    "type": "image/jpeg",
    "etag": "\"202c-42MqtJQWziELGgHFTR4qpN8mXOY\"",
    "mtime": "2025-04-13T20:04:20.357Z",
    "size": 8236,
    "path": "../public/app-assets/images/portrait/small/avatar-s-18.jpg"
  },
  "/app-assets/images/portrait/small/avatar-s-2.jpg": {
    "type": "image/jpeg",
    "etag": "\"1f0a-wkv1F22jhMISLDLwEWZAqvjAs5k\"",
    "mtime": "2025-04-13T20:04:20.357Z",
    "size": 7946,
    "path": "../public/app-assets/images/portrait/small/avatar-s-2.jpg"
  },
  "/app-assets/images/portrait/small/avatar-s-20.jpg": {
    "type": "image/jpeg",
    "etag": "\"1868-9hiXk+dfT1Gc/o/D6al83TYXnWI\"",
    "mtime": "2025-04-13T20:04:20.357Z",
    "size": 6248,
    "path": "../public/app-assets/images/portrait/small/avatar-s-20.jpg"
  },
  "/app-assets/images/portrait/small/avatar-s-21.jpg": {
    "type": "image/jpeg",
    "etag": "\"19b9-xQuWo2W4o+mlHWQPPIAsR73Xetg\"",
    "mtime": "2025-04-13T20:04:20.357Z",
    "size": 6585,
    "path": "../public/app-assets/images/portrait/small/avatar-s-21.jpg"
  },
  "/app-assets/images/portrait/small/avatar-s-23.jpg": {
    "type": "image/jpeg",
    "etag": "\"1f00-1sfX89MLNfX2fPQ3K9mHhXYJQ9k\"",
    "mtime": "2025-04-13T20:04:20.360Z",
    "size": 7936,
    "path": "../public/app-assets/images/portrait/small/avatar-s-23.jpg"
  },
  "/app-assets/images/portrait/small/avatar-s-3.jpg": {
    "type": "image/jpeg",
    "etag": "\"10fd-xX8IrZDPe+OT2GTDEof/rjAUVHM\"",
    "mtime": "2025-04-13T20:04:20.357Z",
    "size": 4349,
    "path": "../public/app-assets/images/portrait/small/avatar-s-3.jpg"
  },
  "/app-assets/images/portrait/small/avatar-s-4.jpg": {
    "type": "image/jpeg",
    "etag": "\"1995-+8kUKBediebyRv9NivQZ5QdXGzo\"",
    "mtime": "2025-04-13T20:04:20.358Z",
    "size": 6549,
    "path": "../public/app-assets/images/portrait/small/avatar-s-4.jpg"
  },
  "/app-assets/images/portrait/small/avatar-s-5.jpg": {
    "type": "image/jpeg",
    "etag": "\"1d04-PFN+TKgM6HDcn7ueDMGMdZRmNTI\"",
    "mtime": "2025-04-13T20:04:20.365Z",
    "size": 7428,
    "path": "../public/app-assets/images/portrait/small/avatar-s-5.jpg"
  },
  "/app-assets/images/portrait/small/avatar-s-6.jpg": {
    "type": "image/jpeg",
    "etag": "\"1b4b-OlxfZeQPQvFqpeGpkFoFkIrain8\"",
    "mtime": "2025-04-13T20:04:20.358Z",
    "size": 6987,
    "path": "../public/app-assets/images/portrait/small/avatar-s-6.jpg"
  },
  "/app-assets/images/portrait/small/avatar-s-7.jpg": {
    "type": "image/jpeg",
    "etag": "\"1452-R6+OWdub9gVVQrn0FAVjcxq5WcI\"",
    "mtime": "2025-04-13T20:04:20.358Z",
    "size": 5202,
    "path": "../public/app-assets/images/portrait/small/avatar-s-7.jpg"
  },
  "/app-assets/images/portrait/small/avatar-s-8.jpg": {
    "type": "image/jpeg",
    "etag": "\"1b81-d9rlTQ3sZU2HPsoPONQcEj5+l58\"",
    "mtime": "2025-04-13T20:04:20.358Z",
    "size": 7041,
    "path": "../public/app-assets/images/portrait/small/avatar-s-8.jpg"
  },
  "/app-assets/images/portrait/small/avatar-s-9.jpg": {
    "type": "image/jpeg",
    "etag": "\"1a08-eCrDHigg+cdLqS4b+HrcCbFdvd0\"",
    "mtime": "2025-04-13T20:04:20.358Z",
    "size": 6664,
    "path": "../public/app-assets/images/portrait/small/avatar-s-9.jpg"
  },
  "/app-assets/images/pages/eCommerce/1.png": {
    "type": "image/png",
    "etag": "\"7aca-qAW4bLKQ/iiQBnv0FQM4lbRysYA\"",
    "mtime": "2025-04-13T20:04:20.317Z",
    "size": 31434,
    "path": "../public/app-assets/images/pages/eCommerce/1.png"
  },
  "/app-assets/images/pages/eCommerce/10.png": {
    "type": "image/png",
    "etag": "\"69a6-tszM40C94oPexQ79mTYFO6shA9Y\"",
    "mtime": "2025-04-13T20:04:20.352Z",
    "size": 27046,
    "path": "../public/app-assets/images/pages/eCommerce/10.png"
  },
  "/app-assets/images/pages/eCommerce/11.png": {
    "type": "image/png",
    "etag": "\"c5b5-4SYtrWrZNpiDYs+VJPMozGKWUSs\"",
    "mtime": "2025-04-13T20:04:20.354Z",
    "size": 50613,
    "path": "../public/app-assets/images/pages/eCommerce/11.png"
  },
  "/app-assets/images/pages/eCommerce/2.png": {
    "type": "image/png",
    "etag": "\"3d1a-uvxLXmk/fB0P9f/qJEhjfGueVnA\"",
    "mtime": "2025-04-13T20:04:20.352Z",
    "size": 15642,
    "path": "../public/app-assets/images/pages/eCommerce/2.png"
  },
  "/app-assets/images/pages/eCommerce/3.png": {
    "type": "image/png",
    "etag": "\"c836-x/1StBcRHyGGI/l0On0T2rbnmYE\"",
    "mtime": "2025-04-13T20:04:20.354Z",
    "size": 51254,
    "path": "../public/app-assets/images/pages/eCommerce/3.png"
  },
  "/app-assets/images/pages/eCommerce/4.png": {
    "type": "image/png",
    "etag": "\"69aa-iYd3GIhBumoQCSNCQ/Opj1h61fg\"",
    "mtime": "2025-04-13T20:04:20.353Z",
    "size": 27050,
    "path": "../public/app-assets/images/pages/eCommerce/4.png"
  },
  "/app-assets/images/pages/eCommerce/5.png": {
    "type": "image/png",
    "etag": "\"bd99-jJYq/61ocznF/ihlzBoCCoQsa6M\"",
    "mtime": "2025-04-13T20:04:20.353Z",
    "size": 48537,
    "path": "../public/app-assets/images/pages/eCommerce/5.png"
  },
  "/app-assets/images/pages/eCommerce/6.png": {
    "type": "image/png",
    "etag": "\"2f0f-DWhaA0s66F/Zt3leW3Cj9VZOh9s\"",
    "mtime": "2025-04-13T20:04:20.352Z",
    "size": 12047,
    "path": "../public/app-assets/images/pages/eCommerce/6.png"
  },
  "/app-assets/images/pages/eCommerce/7.png": {
    "type": "image/png",
    "etag": "\"7dea-Z702VtWLqPER3ZtLzKnLHopVARA\"",
    "mtime": "2025-04-13T20:04:20.353Z",
    "size": 32234,
    "path": "../public/app-assets/images/pages/eCommerce/7.png"
  },
  "/app-assets/images/pages/eCommerce/8.png": {
    "type": "image/png",
    "etag": "\"770a-mxSOp4q2k70SxgE57nZecEFH1dI\"",
    "mtime": "2025-04-13T20:04:20.353Z",
    "size": 30474,
    "path": "../public/app-assets/images/pages/eCommerce/8.png"
  },
  "/app-assets/images/pages/eCommerce/9.png": {
    "type": "image/png",
    "etag": "\"7659-4CvxbwBIQa4y+1w8Q6k2hpLoh5s\"",
    "mtime": "2025-04-13T20:04:20.355Z",
    "size": 30297,
    "path": "../public/app-assets/images/pages/eCommerce/9.png"
  },
  "/app-assets/images/pages/eCommerce/bank.png": {
    "type": "image/png",
    "etag": "\"1f7e-Rvyo6PJv5jvRRco0MrjBKQE3wFI\"",
    "mtime": "2025-04-13T20:04:20.354Z",
    "size": 8062,
    "path": "../public/app-assets/images/pages/eCommerce/bank.png"
  },
  "/app-assets/images/profile/post-media/2.jpg": {
    "type": "image/jpeg",
    "etag": "\"24312-d20ifwfOEEi0euVumFkEhhXPEYU\"",
    "mtime": "2025-04-13T20:04:20.325Z",
    "size": 148242,
    "path": "../public/app-assets/images/profile/post-media/2.jpg"
  },
  "/app-assets/images/profile/post-media/25.jpg": {
    "type": "image/jpeg",
    "etag": "\"1c7d7-+pA1Tmnz+15IMkWUIL67XNUo5jc\"",
    "mtime": "2025-04-13T20:04:20.359Z",
    "size": 116695,
    "path": "../public/app-assets/images/profile/post-media/25.jpg"
  },
  "/app-assets/images/profile/pages/page-01.jpg": {
    "type": "image/jpeg",
    "etag": "\"1b5a-Vafz3gr5dCE+9HeTnQ/Dq8fyVT8\"",
    "mtime": "2025-04-13T20:04:20.316Z",
    "size": 7002,
    "path": "../public/app-assets/images/profile/pages/page-01.jpg"
  },
  "/app-assets/images/profile/pages/page-02.jpg": {
    "type": "image/jpeg",
    "etag": "\"248a-8o+izubsG1REyRWUwPM53mB+/EY\"",
    "mtime": "2025-04-13T20:04:20.354Z",
    "size": 9354,
    "path": "../public/app-assets/images/profile/pages/page-02.jpg"
  },
  "/app-assets/images/profile/pages/page-03.jpg": {
    "type": "image/jpeg",
    "etag": "\"2b36-VbGsZlZLyjAPRgG5jxmqkWg+gkU\"",
    "mtime": "2025-04-13T20:04:20.354Z",
    "size": 11062,
    "path": "../public/app-assets/images/profile/pages/page-03.jpg"
  },
  "/app-assets/images/profile/pages/page-04.jpg": {
    "type": "image/jpeg",
    "etag": "\"23bb-6arYx+aOb6Ge7l+wFUJvhjsgQvE\"",
    "mtime": "2025-04-13T20:04:20.355Z",
    "size": 9147,
    "path": "../public/app-assets/images/profile/pages/page-04.jpg"
  },
  "/app-assets/images/profile/pages/page-05.jpg": {
    "type": "image/jpeg",
    "etag": "\"2ad0-J22PuZYBK4lsPIDK0TJTwZtg22U\"",
    "mtime": "2025-04-13T20:04:20.355Z",
    "size": 10960,
    "path": "../public/app-assets/images/profile/pages/page-05.jpg"
  },
  "/app-assets/images/profile/pages/page-06.jpg": {
    "type": "image/jpeg",
    "etag": "\"1a15-mKz+6qC0vDeCfiFpa+U+K6KszfY\"",
    "mtime": "2025-04-13T20:04:20.355Z",
    "size": 6677,
    "path": "../public/app-assets/images/profile/pages/page-06.jpg"
  },
  "/app-assets/images/profile/pages/page-07.jpg": {
    "type": "image/jpeg",
    "etag": "\"20b7-PnvsP8VtWzCJalKjciR+quXkc/8\"",
    "mtime": "2025-04-13T20:04:20.355Z",
    "size": 8375,
    "path": "../public/app-assets/images/profile/pages/page-07.jpg"
  },
  "/app-assets/images/profile/pages/page-08.jpg": {
    "type": "image/jpeg",
    "etag": "\"256f-wmIJkhhrzSzTnMgcT4cyu2FHMzM\"",
    "mtime": "2025-04-13T20:04:20.355Z",
    "size": 9583,
    "path": "../public/app-assets/images/profile/pages/page-08.jpg"
  },
  "/app-assets/images/profile/pages/page-09.jpg": {
    "type": "image/jpeg",
    "etag": "\"289f-EbF+Zb7WgIk9OljH3hT1vu8SOR0\"",
    "mtime": "2025-04-13T20:04:20.355Z",
    "size": 10399,
    "path": "../public/app-assets/images/profile/pages/page-09.jpg"
  },
  "/app-assets/fonts/font-awesome/webfonts/fa-brands-400.eot": {
    "type": "application/vnd.ms-fontobject",
    "etag": "\"20dde-QMjyoNwVQWD95Q4MJ/aU8Sx7FjY\"",
    "mtime": "2025-04-13T20:04:20.330Z",
    "size": 134622,
    "path": "../public/app-assets/fonts/font-awesome/webfonts/fa-brands-400.eot"
  },
  "/app-assets/fonts/font-awesome/webfonts/fa-brands-400.eot.br": {
    "type": "application/vnd.ms-fontobject",
    "encoding": "br",
    "etag": "\"149fe-G4OQ0Rb910JTsvZkrsOtHlSqwfE\"",
    "mtime": "2025-04-13T20:04:28.747Z",
    "size": 84478,
    "path": "../public/app-assets/fonts/font-awesome/webfonts/fa-brands-400.eot.br"
  },
  "/app-assets/fonts/font-awesome/webfonts/fa-brands-400.eot.gz": {
    "type": "application/vnd.ms-fontobject",
    "encoding": "gzip",
    "etag": "\"162c4-Yo6yCrWNR21LvlyJG9/8Bhe07yU\"",
    "mtime": "2025-04-13T20:04:28.747Z",
    "size": 90820,
    "path": "../public/app-assets/fonts/font-awesome/webfonts/fa-brands-400.eot.gz"
  },
  "/app-assets/fonts/font-awesome/webfonts/fa-brands-400.svg": {
    "type": "image/svg+xml",
    "etag": "\"b24be-md/wc5iCJ2rWxDTXMijvx5cbCmY\"",
    "mtime": "2025-04-13T20:04:20.373Z",
    "size": 730302,
    "path": "../public/app-assets/fonts/font-awesome/webfonts/fa-brands-400.svg"
  },
  "/app-assets/fonts/font-awesome/webfonts/fa-brands-400.svg.br": {
    "type": "image/svg+xml",
    "encoding": "br",
    "etag": "\"35160-mgspgp+f20B4bY6OwLTGD2Ae5aw\"",
    "mtime": "2025-04-13T20:04:28.807Z",
    "size": 217440,
    "path": "../public/app-assets/fonts/font-awesome/webfonts/fa-brands-400.svg.br"
  },
  "/app-assets/fonts/font-awesome/webfonts/fa-brands-400.svg.gz": {
    "type": "image/svg+xml",
    "encoding": "gzip",
    "etag": "\"3c0ca-GCGQ8GdW+iXzF8hUn4ZC9KPb100\"",
    "mtime": "2025-04-13T20:04:28.811Z",
    "size": 245962,
    "path": "../public/app-assets/fonts/font-awesome/webfonts/fa-brands-400.svg.gz"
  },
  "/app-assets/fonts/font-awesome/webfonts/fa-brands-400.ttf": {
    "type": "font/ttf",
    "etag": "\"20cac-KfWbTuzHIFLZEQpdQDChCtm/c9c\"",
    "mtime": "2025-04-13T20:04:20.368Z",
    "size": 134316,
    "path": "../public/app-assets/fonts/font-awesome/webfonts/fa-brands-400.ttf"
  },
  "/app-assets/fonts/font-awesome/webfonts/fa-brands-400.ttf.br": {
    "type": "font/ttf",
    "encoding": "br",
    "etag": "\"14974-aKK7modzzkXwub5ffmMJsXPtTmU\"",
    "mtime": "2025-04-13T20:04:28.747Z",
    "size": 84340,
    "path": "../public/app-assets/fonts/font-awesome/webfonts/fa-brands-400.ttf.br"
  },
  "/app-assets/fonts/font-awesome/webfonts/fa-brands-400.ttf.gz": {
    "type": "font/ttf",
    "encoding": "gzip",
    "etag": "\"16238-YJoM7hl9wpifvCIPDdHUQBXR+R4\"",
    "mtime": "2025-04-13T20:04:28.747Z",
    "size": 90680,
    "path": "../public/app-assets/fonts/font-awesome/webfonts/fa-brands-400.ttf.gz"
  },
  "/app-assets/fonts/font-awesome/webfonts/fa-brands-400.woff": {
    "type": "font/woff",
    "etag": "\"16230-/duV16D0jSv5Cl7jCV6CZNyhgFM\"",
    "mtime": "2025-04-13T20:04:20.368Z",
    "size": 90672,
    "path": "../public/app-assets/fonts/font-awesome/webfonts/fa-brands-400.woff"
  },
  "/app-assets/fonts/font-awesome/webfonts/fa-brands-400.woff2": {
    "type": "font/woff2",
    "etag": "\"12e58-YlhLmGhCj9da8/xe4vmRjdpCi+U\"",
    "mtime": "2025-04-13T20:04:20.369Z",
    "size": 77400,
    "path": "../public/app-assets/fonts/font-awesome/webfonts/fa-brands-400.woff2"
  },
  "/app-assets/fonts/font-awesome/webfonts/fa-regular-400.eot": {
    "type": "application/vnd.ms-fontobject",
    "etag": "\"862e-MwYXjJDZ35OdKl6r9TO6NlD76A4\"",
    "mtime": "2025-04-13T20:04:20.370Z",
    "size": 34350,
    "path": "../public/app-assets/fonts/font-awesome/webfonts/fa-regular-400.eot"
  },
  "/app-assets/fonts/font-awesome/webfonts/fa-regular-400.eot.br": {
    "type": "application/vnd.ms-fontobject",
    "encoding": "br",
    "etag": "\"3e31-+hTCVpWGz3GjgzRuD1rmWDspNVY\"",
    "mtime": "2025-04-13T20:04:28.217Z",
    "size": 15921,
    "path": "../public/app-assets/fonts/font-awesome/webfonts/fa-regular-400.eot.br"
  },
  "/app-assets/fonts/font-awesome/webfonts/fa-regular-400.eot.gz": {
    "type": "application/vnd.ms-fontobject",
    "encoding": "gzip",
    "etag": "\"424f-VaJfdS+k4vHOMzXHWFRbiBR+Ovg\"",
    "mtime": "2025-04-13T20:04:28.586Z",
    "size": 16975,
    "path": "../public/app-assets/fonts/font-awesome/webfonts/fa-regular-400.eot.gz"
  },
  "/app-assets/fonts/font-awesome/webfonts/fa-regular-400.svg": {
    "type": "image/svg+xml",
    "etag": "\"2354b-Ua/KVuMJ32/cVrU/pqfTzmSCZJA\"",
    "mtime": "2025-04-13T20:04:20.370Z",
    "size": 144715,
    "path": "../public/app-assets/fonts/font-awesome/webfonts/fa-regular-400.svg"
  },
  "/app-assets/fonts/font-awesome/webfonts/fa-regular-400.svg.br": {
    "type": "image/svg+xml",
    "encoding": "br",
    "etag": "\"7935-hmLN49pu+4cMBEZ5SpOkm34SdI0\"",
    "mtime": "2025-04-13T20:04:28.591Z",
    "size": 31029,
    "path": "../public/app-assets/fonts/font-awesome/webfonts/fa-regular-400.svg.br"
  },
  "/app-assets/fonts/font-awesome/webfonts/fa-regular-400.svg.gz": {
    "type": "image/svg+xml",
    "encoding": "gzip",
    "etag": "\"8fcf-XI5kd9Pp16Yks+6wxeyoKoyw9rE\"",
    "mtime": "2025-04-13T20:04:28.658Z",
    "size": 36815,
    "path": "../public/app-assets/fonts/font-awesome/webfonts/fa-regular-400.svg.gz"
  },
  "/app-assets/fonts/font-awesome/webfonts/fa-regular-400.ttf": {
    "type": "font/ttf",
    "etag": "\"8504-UXo7QcHgG2WJi18QdENNQ6NhpU8\"",
    "mtime": "2025-04-13T20:04:20.374Z",
    "size": 34052,
    "path": "../public/app-assets/fonts/font-awesome/webfonts/fa-regular-400.ttf"
  },
  "/app-assets/fonts/font-awesome/webfonts/fa-regular-400.ttf.br": {
    "type": "font/ttf",
    "encoding": "br",
    "etag": "\"3e0f-Bz/4r8kGC2xlJFxsv4EwUIG5iiU\"",
    "mtime": "2025-04-13T20:04:28.217Z",
    "size": 15887,
    "path": "../public/app-assets/fonts/font-awesome/webfonts/fa-regular-400.ttf.br"
  },
  "/app-assets/fonts/font-awesome/webfonts/fa-regular-400.ttf.gz": {
    "type": "font/ttf",
    "encoding": "gzip",
    "etag": "\"421b-gep9e82BAcB5HyzkAxFisYi6WLA\"",
    "mtime": "2025-04-13T20:04:28.586Z",
    "size": 16923,
    "path": "../public/app-assets/fonts/font-awesome/webfonts/fa-regular-400.ttf.gz"
  },
  "/app-assets/fonts/font-awesome/webfonts/fa-regular-400.woff": {
    "type": "font/woff",
    "etag": "\"418c-2hep8dyuN5yLog8QiQWcICIWy6c\"",
    "mtime": "2025-04-13T20:04:20.370Z",
    "size": 16780,
    "path": "../public/app-assets/fonts/font-awesome/webfonts/fa-regular-400.woff"
  },
  "/app-assets/fonts/font-awesome/webfonts/fa-regular-400.woff2": {
    "type": "font/woff2",
    "etag": "\"3520-Xk1FBS9D5Vqq1/FNEygCFeOapFs\"",
    "mtime": "2025-04-13T20:04:20.370Z",
    "size": 13600,
    "path": "../public/app-assets/fonts/font-awesome/webfonts/fa-regular-400.woff2"
  },
  "/app-assets/fonts/font-awesome/webfonts/fa-solid-900.eot": {
    "type": "application/vnd.ms-fontobject",
    "etag": "\"31dea-lqVjdClCZ2Tqmyi/TR61WuEN5X4\"",
    "mtime": "2025-04-13T20:04:20.371Z",
    "size": 204266,
    "path": "../public/app-assets/fonts/font-awesome/webfonts/fa-solid-900.eot"
  },
  "/app-assets/fonts/font-awesome/webfonts/fa-solid-900.eot.br": {
    "type": "application/vnd.ms-fontobject",
    "encoding": "br",
    "etag": "\"1725e-ulZGHYoWbd0y6WCRHJQGr6mq4xE\"",
    "mtime": "2025-04-13T20:04:28.747Z",
    "size": 94814,
    "path": "../public/app-assets/fonts/font-awesome/webfonts/fa-solid-900.eot.br"
  },
  "/app-assets/fonts/font-awesome/webfonts/fa-solid-900.eot.gz": {
    "type": "application/vnd.ms-fontobject",
    "encoding": "gzip",
    "etag": "\"19bb0-25OAKgalk8shVOH/fCOGLXCW4ms\"",
    "mtime": "2025-04-13T20:04:28.753Z",
    "size": 105392,
    "path": "../public/app-assets/fonts/font-awesome/webfonts/fa-solid-900.eot.gz"
  },
  "/app-assets/fonts/font-awesome/webfonts/fa-solid-900.svg": {
    "type": "image/svg+xml",
    "etag": "\"df2cd-VQH7YuIKib3Ym/P6FHyk280vxn8\"",
    "mtime": "2025-04-13T20:04:20.374Z",
    "size": 914125,
    "path": "../public/app-assets/fonts/font-awesome/webfonts/fa-solid-900.svg"
  },
  "/app-assets/fonts/font-awesome/webfonts/fa-solid-900.svg.br": {
    "type": "image/svg+xml",
    "encoding": "br",
    "etag": "\"3179e-sJ7L+EpWiILxHtiqw8wE+bzpKB0\"",
    "mtime": "2025-04-13T20:04:28.805Z",
    "size": 202654,
    "path": "../public/app-assets/fonts/font-awesome/webfonts/fa-solid-900.svg.br"
  },
  "/app-assets/fonts/font-awesome/webfonts/fa-solid-900.svg.gz": {
    "type": "image/svg+xml",
    "encoding": "gzip",
    "etag": "\"3da2a-0RkBV7Ko2B4Lnw6wwwTWGKv7TmY\"",
    "mtime": "2025-04-13T20:04:28.811Z",
    "size": 252458,
    "path": "../public/app-assets/fonts/font-awesome/webfonts/fa-solid-900.svg.gz"
  },
  "/app-assets/fonts/font-awesome/webfonts/fa-solid-900.ttf": {
    "type": "font/ttf",
    "etag": "\"31ccc-h0xlBwHQy/uPHeSKSW2r7Tu/IuY\"",
    "mtime": "2025-04-13T20:04:20.371Z",
    "size": 203980,
    "path": "../public/app-assets/fonts/font-awesome/webfonts/fa-solid-900.ttf"
  },
  "/app-assets/fonts/font-awesome/webfonts/fa-solid-900.ttf.br": {
    "type": "font/ttf",
    "encoding": "br",
    "etag": "\"172a6-y34l9iqxtedyJqkK7Ynb86QQ8zM\"",
    "mtime": "2025-04-13T20:04:28.747Z",
    "size": 94886,
    "path": "../public/app-assets/fonts/font-awesome/webfonts/fa-solid-900.ttf.br"
  },
  "/app-assets/fonts/font-awesome/webfonts/fa-solid-900.ttf.gz": {
    "type": "font/ttf",
    "encoding": "gzip",
    "etag": "\"19b39-DJ6tLLnWFSfx57+WCJpFIAAg6c0\"",
    "mtime": "2025-04-13T20:04:28.753Z",
    "size": 105273,
    "path": "../public/app-assets/fonts/font-awesome/webfonts/fa-solid-900.ttf.gz"
  },
  "/app-assets/fonts/font-awesome/webfonts/fa-solid-900.woff": {
    "type": "font/woff",
    "etag": "\"19644-8T4lL4pRpSef0h4mraC9L1W879g\"",
    "mtime": "2025-04-13T20:04:20.371Z",
    "size": 104004,
    "path": "../public/app-assets/fonts/font-awesome/webfonts/fa-solid-900.woff"
  },
  "/app-assets/fonts/font-awesome/webfonts/fa-solid-900.woff2": {
    "type": "font/woff2",
    "etag": "\"13914-YpCDRnKrqG1bbBxzswtXycU5lvc\"",
    "mtime": "2025-04-13T20:04:20.373Z",
    "size": 80148,
    "path": "../public/app-assets/fonts/font-awesome/webfonts/fa-solid-900.woff2"
  },
  "/app-assets/images/profile/user-uploads/cover.jpg": {
    "type": "image/jpeg",
    "etag": "\"2231e-xQYWDbnQ6LRhNuPvhFJyWA+XtBU\"",
    "mtime": "2025-04-13T20:04:20.325Z",
    "size": 140062,
    "path": "../public/app-assets/images/profile/user-uploads/cover.jpg"
  },
  "/app-assets/images/profile/user-uploads/user-01.jpg": {
    "type": "image/jpeg",
    "etag": "\"606d-39wCE4WsRt55payJIsy2xs8pVV8\"",
    "mtime": "2025-04-13T20:04:20.359Z",
    "size": 24685,
    "path": "../public/app-assets/images/profile/user-uploads/user-01.jpg"
  },
  "/app-assets/images/profile/user-uploads/user-02.jpg": {
    "type": "image/jpeg",
    "etag": "\"701c-s4jIc20wlbnJfwYE15hap8X0Kbk\"",
    "mtime": "2025-04-13T20:04:20.359Z",
    "size": 28700,
    "path": "../public/app-assets/images/profile/user-uploads/user-02.jpg"
  },
  "/app-assets/images/profile/user-uploads/user-03.jpg": {
    "type": "image/jpeg",
    "etag": "\"91ef-voEWZpiJHLU0VeVAqgyfc54qTYc\"",
    "mtime": "2025-04-13T20:04:20.359Z",
    "size": 37359,
    "path": "../public/app-assets/images/profile/user-uploads/user-03.jpg"
  },
  "/app-assets/images/profile/user-uploads/user-04.jpg": {
    "type": "image/jpeg",
    "etag": "\"7876-A0UEws0zANcjUwlFRYZo23rh+Jw\"",
    "mtime": "2025-04-13T20:04:20.359Z",
    "size": 30838,
    "path": "../public/app-assets/images/profile/user-uploads/user-04.jpg"
  },
  "/app-assets/images/profile/user-uploads/user-05.jpg": {
    "type": "image/jpeg",
    "etag": "\"575b-NGvNgPxiPsCydIRJ4xYKtRSDnY8\"",
    "mtime": "2025-04-13T20:04:20.359Z",
    "size": 22363,
    "path": "../public/app-assets/images/profile/user-uploads/user-05.jpg"
  },
  "/app-assets/images/profile/user-uploads/user-06.jpg": {
    "type": "image/jpeg",
    "etag": "\"57fa-GDZJL6XPLqjS0oe+S6MLmse83ms\"",
    "mtime": "2025-04-13T20:04:20.360Z",
    "size": 22522,
    "path": "../public/app-assets/images/profile/user-uploads/user-06.jpg"
  },
  "/app-assets/images/profile/user-uploads/user-07.jpg": {
    "type": "image/jpeg",
    "etag": "\"59ec-tuO+rUN+mH3ISU0cNLIzDQ7oHU8\"",
    "mtime": "2025-04-13T20:04:20.359Z",
    "size": 23020,
    "path": "../public/app-assets/images/profile/user-uploads/user-07.jpg"
  },
  "/app-assets/images/profile/user-uploads/user-08.jpg": {
    "type": "image/jpeg",
    "etag": "\"64b5-OKMyRc5NaO9pXSGiuPL7tPpgJwQ\"",
    "mtime": "2025-04-13T20:04:20.360Z",
    "size": 25781,
    "path": "../public/app-assets/images/profile/user-uploads/user-08.jpg"
  },
  "/app-assets/images/profile/user-uploads/user-09.jpg": {
    "type": "image/jpeg",
    "etag": "\"5729-7JgpxechMjp/e7uzztuVJ++HasE\"",
    "mtime": "2025-04-13T20:04:20.360Z",
    "size": 22313,
    "path": "../public/app-assets/images/profile/user-uploads/user-09.jpg"
  },
  "/app-assets/images/profile/user-uploads/user-13.jpg": {
    "type": "image/jpeg",
    "etag": "\"5f5b-Kt6pfhK4c9OKVYbVgGyeQOiyQuI\"",
    "mtime": "2025-04-13T20:04:20.360Z",
    "size": 24411,
    "path": "../public/app-assets/images/profile/user-uploads/user-13.jpg"
  },
  "/app-assets/js/scripts/ag-grid/ag-grid.min.js": {
    "type": "text/javascript; charset=utf-8",
    "etag": "\"731-8Lj3FkxmnKDz3Y1v9NmA48plIyA\"",
    "mtime": "2025-04-13T20:04:20.316Z",
    "size": 1841,
    "path": "../public/app-assets/js/scripts/ag-grid/ag-grid.min.js"
  },
  "/app-assets/js/scripts/ag-grid/ag-grid.min.js.br": {
    "type": "text/javascript; charset=utf-8",
    "encoding": "br",
    "etag": "\"23d-yzUPVGoMYNnjfozk+UkGhtJ+JnQ\"",
    "mtime": "2025-04-13T20:04:28.242Z",
    "size": 573,
    "path": "../public/app-assets/js/scripts/ag-grid/ag-grid.min.js.br"
  },
  "/app-assets/js/scripts/ag-grid/ag-grid.min.js.gz": {
    "type": "text/javascript; charset=utf-8",
    "encoding": "gzip",
    "etag": "\"2a8-MmbkqZz9iiIolFHeQsdsKgxGrmA\"",
    "mtime": "2025-04-13T20:04:28.242Z",
    "size": 680,
    "path": "../public/app-assets/js/scripts/ag-grid/ag-grid.min.js.gz"
  },
  "/app-assets/js/scripts/cards/card-analytics.min.js": {
    "type": "text/javascript; charset=utf-8",
    "etag": "\"18dd-xPNlLnwersWgRgCqniMupxVnrSU\"",
    "mtime": "2025-04-13T20:04:20.324Z",
    "size": 6365,
    "path": "../public/app-assets/js/scripts/cards/card-analytics.min.js"
  },
  "/app-assets/js/scripts/cards/card-analytics.min.js.br": {
    "type": "text/javascript; charset=utf-8",
    "encoding": "br",
    "etag": "\"679-QLUmGQeisS+Pc5CPPG2LxwQPE9M\"",
    "mtime": "2025-04-13T20:04:28.242Z",
    "size": 1657,
    "path": "../public/app-assets/js/scripts/cards/card-analytics.min.js.br"
  },
  "/app-assets/js/scripts/cards/card-analytics.min.js.gz": {
    "type": "text/javascript; charset=utf-8",
    "encoding": "gzip",
    "etag": "\"788-c7Uygumnx7zTvYC4spmuSuoiSzA\"",
    "mtime": "2025-04-13T20:04:28.242Z",
    "size": 1928,
    "path": "../public/app-assets/js/scripts/cards/card-analytics.min.js.gz"
  },
  "/app-assets/js/scripts/cards/card-statistics.min.js": {
    "type": "text/javascript; charset=utf-8",
    "etag": "\"1023-kRFSp4ilruAt1jsJhWD7479Hoow\"",
    "mtime": "2025-04-13T20:04:20.359Z",
    "size": 4131,
    "path": "../public/app-assets/js/scripts/cards/card-statistics.min.js"
  },
  "/app-assets/js/scripts/cards/card-statistics.min.js.br": {
    "type": "text/javascript; charset=utf-8",
    "encoding": "br",
    "etag": "\"25b-iwh/K7Yt9GSOYJjguUCrY4Xqj5Q\"",
    "mtime": "2025-04-13T20:04:28.242Z",
    "size": 603,
    "path": "../public/app-assets/js/scripts/cards/card-statistics.min.js.br"
  },
  "/app-assets/js/scripts/cards/card-statistics.min.js.gz": {
    "type": "text/javascript; charset=utf-8",
    "encoding": "gzip",
    "etag": "\"2da-oOZRTFnraFJTVaJ1Mht6k83Knh0\"",
    "mtime": "2025-04-13T20:04:28.242Z",
    "size": 730,
    "path": "../public/app-assets/js/scripts/cards/card-statistics.min.js.gz"
  },
  "/app-assets/js/scripts/charts/chart-apex.min.js": {
    "type": "text/javascript; charset=utf-8",
    "etag": "\"29bc-49GfO5CbIXVND+kgnIiQL7ZydMM\"",
    "mtime": "2025-04-13T20:04:20.360Z",
    "size": 10684,
    "path": "../public/app-assets/js/scripts/charts/chart-apex.min.js"
  },
  "/app-assets/js/scripts/charts/chart-apex.min.js.br": {
    "type": "text/javascript; charset=utf-8",
    "encoding": "br",
    "etag": "\"b55-cve8Nw1FrhK0Ka6mn04BnTH9kfw\"",
    "mtime": "2025-04-13T20:04:28.242Z",
    "size": 2901,
    "path": "../public/app-assets/js/scripts/charts/chart-apex.min.js.br"
  },
  "/app-assets/js/scripts/charts/chart-apex.min.js.gz": {
    "type": "text/javascript; charset=utf-8",
    "encoding": "gzip",
    "etag": "\"da0-yuF7VPm6acKSH1OIsEV4ud17bMU\"",
    "mtime": "2025-04-13T20:04:28.242Z",
    "size": 3488,
    "path": "../public/app-assets/js/scripts/charts/chart-apex.min.js.gz"
  },
  "/app-assets/js/scripts/charts/chart-chartjs.min.js": {
    "type": "text/javascript; charset=utf-8",
    "etag": "\"182e-fRsUoo+gMssTPp+wKTyj/aivNZw\"",
    "mtime": "2025-04-13T20:04:20.360Z",
    "size": 6190,
    "path": "../public/app-assets/js/scripts/charts/chart-chartjs.min.js"
  },
  "/app-assets/js/scripts/charts/chart-chartjs.min.js.br": {
    "type": "text/javascript; charset=utf-8",
    "encoding": "br",
    "etag": "\"552-beevmgsjWhrTv+pbXwiU0HgDuWc\"",
    "mtime": "2025-04-13T20:04:28.242Z",
    "size": 1362,
    "path": "../public/app-assets/js/scripts/charts/chart-chartjs.min.js.br"
  },
  "/app-assets/js/scripts/charts/chart-chartjs.min.js.gz": {
    "type": "text/javascript; charset=utf-8",
    "encoding": "gzip",
    "etag": "\"64c-J9Qh5Ab4bL6F41IOp1RJ2QqiGuU\"",
    "mtime": "2025-04-13T20:04:28.242Z",
    "size": 1612,
    "path": "../public/app-assets/js/scripts/charts/chart-chartjs.min.js.gz"
  },
  "/app-assets/js/scripts/charts/chart-echart.min.js": {
    "type": "text/javascript; charset=utf-8",
    "etag": "\"162e-v5x5sHuaf3i6jYXG9vt9BTxPMS8\"",
    "mtime": "2025-04-13T20:04:20.360Z",
    "size": 5678,
    "path": "../public/app-assets/js/scripts/charts/chart-echart.min.js"
  },
  "/app-assets/js/scripts/charts/chart-echart.min.js.br": {
    "type": "text/javascript; charset=utf-8",
    "encoding": "br",
    "etag": "\"76c-5Anu7lE0uZ9kqdFUlCJCXTDNbkg\"",
    "mtime": "2025-04-13T20:04:28.242Z",
    "size": 1900,
    "path": "../public/app-assets/js/scripts/charts/chart-echart.min.js.br"
  },
  "/app-assets/js/scripts/charts/chart-echart.min.js.gz": {
    "type": "text/javascript; charset=utf-8",
    "encoding": "gzip",
    "etag": "\"8f9-VFsZoD2hQzk+gDhAZHbenelaAn0\"",
    "mtime": "2025-04-13T20:04:28.242Z",
    "size": 2297,
    "path": "../public/app-assets/js/scripts/charts/chart-echart.min.js.gz"
  },
  "/app-assets/js/scripts/datatables/datatable.min.js": {
    "type": "text/javascript; charset=utf-8",
    "etag": "\"48e-I0cIPjoC1H/LgQzGm2clry4iNgE\"",
    "mtime": "2025-04-13T20:04:20.325Z",
    "size": 1166,
    "path": "../public/app-assets/js/scripts/datatables/datatable.min.js"
  },
  "/app-assets/js/scripts/datatables/datatable.min.js.br": {
    "type": "text/javascript; charset=utf-8",
    "encoding": "br",
    "etag": "\"216-tg4zeMAicKslRuRtKIof3H+ZonE\"",
    "mtime": "2025-04-13T20:04:28.242Z",
    "size": 534,
    "path": "../public/app-assets/js/scripts/datatables/datatable.min.js.br"
  },
  "/app-assets/js/scripts/datatables/datatable.min.js.gz": {
    "type": "text/javascript; charset=utf-8",
    "encoding": "gzip",
    "etag": "\"286-TZaBwwFuFLvNrtDmGvAKivI94iM\"",
    "mtime": "2025-04-13T20:04:28.242Z",
    "size": 646,
    "path": "../public/app-assets/js/scripts/datatables/datatable.min.js.gz"
  },
  "/app-assets/js/scripts/editors/editor-quill.min.js": {
    "type": "text/javascript; charset=utf-8",
    "etag": "\"374-FBp4ApRouUSbbe6Yj6ISVwPS348\"",
    "mtime": "2025-04-13T20:04:20.326Z",
    "size": 884,
    "path": "../public/app-assets/js/scripts/editors/editor-quill.min.js"
  },
  "/app-assets/js/scripts/extensions/context-menu.min.js": {
    "type": "text/javascript; charset=utf-8",
    "etag": "\"3c7-tiIND6IgTd+KtslipvryddbeNnk\"",
    "mtime": "2025-04-13T20:04:20.361Z",
    "size": 967,
    "path": "../public/app-assets/js/scripts/extensions/context-menu.min.js"
  },
  "/app-assets/js/scripts/extensions/copy-to-clipboard.min.js": {
    "type": "text/javascript; charset=utf-8",
    "etag": "\"91-islodfNPmoGTTB+DtvBHiLvDt3A\"",
    "mtime": "2025-04-13T20:04:20.360Z",
    "size": 145,
    "path": "../public/app-assets/js/scripts/extensions/copy-to-clipboard.min.js"
  },
  "/app-assets/js/scripts/extensions/drag-drop.min.js": {
    "type": "text/javascript; charset=utf-8",
    "etag": "\"1f9-RBYiWmrC1+q3z6fRuBotDEusk1g\"",
    "mtime": "2025-04-13T20:04:20.325Z",
    "size": 505,
    "path": "../public/app-assets/js/scripts/extensions/drag-drop.min.js"
  },
  "/app-assets/js/scripts/extensions/dropzone.min.js": {
    "type": "text/javascript; charset=utf-8",
    "etag": "\"31e-l52yledegn/JiWt0a0dfuTahPmM\"",
    "mtime": "2025-04-13T20:04:20.360Z",
    "size": 798,
    "path": "../public/app-assets/js/scripts/extensions/dropzone.min.js"
  },
  "/app-assets/js/scripts/extensions/fullcalendar.min.js": {
    "type": "text/javascript; charset=utf-8",
    "etag": "\"106d-HBXVpPeYfGUqlgatOuzErbT7blk\"",
    "mtime": "2025-04-13T20:04:20.360Z",
    "size": 4205,
    "path": "../public/app-assets/js/scripts/extensions/fullcalendar.min.js"
  },
  "/app-assets/js/scripts/extensions/fullcalendar.min.js.br": {
    "type": "text/javascript; charset=utf-8",
    "encoding": "br",
    "etag": "\"3f5-b1vPS+1KfY8bJibqnscDoFr0nsg\"",
    "mtime": "2025-04-13T20:04:28.242Z",
    "size": 1013,
    "path": "../public/app-assets/js/scripts/extensions/fullcalendar.min.js.br"
  },
  "/app-assets/js/scripts/extensions/fullcalendar.min.js.gz": {
    "type": "text/javascript; charset=utf-8",
    "encoding": "gzip",
    "etag": "\"4c4-wEQEP7JXRlNxEp2lPJJxbEqdnpM\"",
    "mtime": "2025-04-13T20:04:28.242Z",
    "size": 1220,
    "path": "../public/app-assets/js/scripts/extensions/fullcalendar.min.js.gz"
  },
  "/app-assets/js/scripts/extensions/i18n.js": {
    "type": "text/javascript; charset=utf-8",
    "etag": "\"919-AYWI+0NVA232kofyVG6KGZBK1FQ\"",
    "mtime": "2025-04-13T20:04:20.361Z",
    "size": 2329,
    "path": "../public/app-assets/js/scripts/extensions/i18n.js"
  },
  "/app-assets/js/scripts/extensions/i18n.js.br": {
    "type": "text/javascript; charset=utf-8",
    "encoding": "br",
    "etag": "\"3c5-LnivtwWcPMxFuizxGVG+GymRH58\"",
    "mtime": "2025-04-13T20:04:28.242Z",
    "size": 965,
    "path": "../public/app-assets/js/scripts/extensions/i18n.js.br"
  },
  "/app-assets/js/scripts/extensions/i18n.js.gz": {
    "type": "text/javascript; charset=utf-8",
    "encoding": "gzip",
    "etag": "\"423-GymdrbzFfU6L0xuUi2YvzqJ/8cs\"",
    "mtime": "2025-04-13T20:04:28.242Z",
    "size": 1059,
    "path": "../public/app-assets/js/scripts/extensions/i18n.js.gz"
  },
  "/app-assets/js/scripts/extensions/media-plyr.min.js": {
    "type": "text/javascript; charset=utf-8",
    "etag": "\"53-5v7WWT5Har486cJsaEok2qARHUs\"",
    "mtime": "2025-04-13T20:04:20.361Z",
    "size": 83,
    "path": "../public/app-assets/js/scripts/extensions/media-plyr.min.js"
  },
  "/app-assets/js/scripts/extensions/noui-slider.min.js": {
    "type": "text/javascript; charset=utf-8",
    "etag": "\"2736-P6ZYKeL9Z1FBsLlE3uxeZf70yjA\"",
    "mtime": "2025-04-13T20:04:20.361Z",
    "size": 10038,
    "path": "../public/app-assets/js/scripts/extensions/noui-slider.min.js"
  },
  "/app-assets/js/scripts/extensions/noui-slider.min.js.br": {
    "type": "text/javascript; charset=utf-8",
    "encoding": "br",
    "etag": "\"6ac-23R+5C83A0tH/eVlKGs4acuXj7c\"",
    "mtime": "2025-04-13T20:04:28.242Z",
    "size": 1708,
    "path": "../public/app-assets/js/scripts/extensions/noui-slider.min.js.br"
  },
  "/app-assets/js/scripts/extensions/noui-slider.min.js.gz": {
    "type": "text/javascript; charset=utf-8",
    "encoding": "gzip",
    "etag": "\"7e4-NQJk4ZInB8x9WpsVMEUom91ZqQY\"",
    "mtime": "2025-04-13T20:04:28.242Z",
    "size": 2020,
    "path": "../public/app-assets/js/scripts/extensions/noui-slider.min.js.gz"
  },
  "/app-assets/js/scripts/extensions/sweet-alerts.min.js": {
    "type": "text/javascript; charset=utf-8",
    "etag": "\"1acd-VlAVFhij7F+e3UQhrCFYEmGmPWg\"",
    "mtime": "2025-04-13T20:04:20.361Z",
    "size": 6861,
    "path": "../public/app-assets/js/scripts/extensions/sweet-alerts.min.js"
  },
  "/app-assets/js/scripts/extensions/sweet-alerts.min.js.br": {
    "type": "text/javascript; charset=utf-8",
    "encoding": "br",
    "etag": "\"5ae-NoK4bKIOy1GdvguhkEBSH7dmR5E\"",
    "mtime": "2025-04-13T20:04:28.242Z",
    "size": 1454,
    "path": "../public/app-assets/js/scripts/extensions/sweet-alerts.min.js.br"
  },
  "/app-assets/js/scripts/extensions/sweet-alerts.min.js.gz": {
    "type": "text/javascript; charset=utf-8",
    "encoding": "gzip",
    "etag": "\"6b1-gL54tMzJ6qfVFPBCQsqvykar+uI\"",
    "mtime": "2025-04-13T20:04:28.242Z",
    "size": 1713,
    "path": "../public/app-assets/js/scripts/extensions/sweet-alerts.min.js.gz"
  },
  "/app-assets/js/scripts/extensions/swiper.min.js": {
    "type": "text/javascript; charset=utf-8",
    "etag": "\"e51-WxKzPFr5eGiTVFtYqsxCCEe5dVo\"",
    "mtime": "2025-04-13T20:04:20.361Z",
    "size": 3665,
    "path": "../public/app-assets/js/scripts/extensions/swiper.min.js"
  },
  "/app-assets/js/scripts/extensions/swiper.min.js.br": {
    "type": "text/javascript; charset=utf-8",
    "encoding": "br",
    "etag": "\"33e-OjPG13y/Puug18fRLc6hN151oIM\"",
    "mtime": "2025-04-13T20:04:28.242Z",
    "size": 830,
    "path": "../public/app-assets/js/scripts/extensions/swiper.min.js.br"
  },
  "/app-assets/js/scripts/extensions/swiper.min.js.gz": {
    "type": "text/javascript; charset=utf-8",
    "encoding": "gzip",
    "etag": "\"3d9-I8QHM556z0WPQ0M074lrGjrpdLE\"",
    "mtime": "2025-04-13T20:04:28.242Z",
    "size": 985,
    "path": "../public/app-assets/js/scripts/extensions/swiper.min.js.gz"
  },
  "/app-assets/js/scripts/extensions/toastr.min.js": {
    "type": "text/javascript; charset=utf-8",
    "etag": "\"f24-zjnB/pvlSdVKFEjLMXnRgz9NAsk\"",
    "mtime": "2025-04-13T20:04:20.361Z",
    "size": 3876,
    "path": "../public/app-assets/js/scripts/extensions/toastr.min.js"
  },
  "/app-assets/js/scripts/extensions/toastr.min.js.br": {
    "type": "text/javascript; charset=utf-8",
    "encoding": "br",
    "etag": "\"29b-dObgRqx8JFHv19ZVeXUJDTEHywI\"",
    "mtime": "2025-04-13T20:04:28.242Z",
    "size": 667,
    "path": "../public/app-assets/js/scripts/extensions/toastr.min.js.br"
  },
  "/app-assets/js/scripts/extensions/toastr.min.js.gz": {
    "type": "text/javascript; charset=utf-8",
    "encoding": "gzip",
    "etag": "\"32c-aOCLUfvBNOQQ88aU/zkGWdJBaeM\"",
    "mtime": "2025-04-13T20:04:28.242Z",
    "size": 812,
    "path": "../public/app-assets/js/scripts/extensions/toastr.min.js.gz"
  },
  "/app-assets/js/scripts/extensions/tour.min.js": {
    "type": "text/javascript; charset=utf-8",
    "etag": "\"4aa-CKHXZykHf5HbokBcYFMieI9UifA\"",
    "mtime": "2025-04-13T20:04:20.361Z",
    "size": 1194,
    "path": "../public/app-assets/js/scripts/extensions/tour.min.js"
  },
  "/app-assets/js/scripts/extensions/tour.min.js.br": {
    "type": "text/javascript; charset=utf-8",
    "encoding": "br",
    "etag": "\"183-M6vdqp61vpulackdg2JzAMYUG9w\"",
    "mtime": "2025-04-13T20:04:28.242Z",
    "size": 387,
    "path": "../public/app-assets/js/scripts/extensions/tour.min.js.br"
  },
  "/app-assets/js/scripts/extensions/tour.min.js.gz": {
    "type": "text/javascript; charset=utf-8",
    "encoding": "gzip",
    "etag": "\"1fe-A7uR1rvay/DTwVmHOan26OLiWEQ\"",
    "mtime": "2025-04-13T20:04:28.242Z",
    "size": 510,
    "path": "../public/app-assets/js/scripts/extensions/tour.min.js.gz"
  },
  "/app-assets/js/scripts/forms/form-tooltip-valid.min.js": {
    "type": "text/javascript; charset=utf-8",
    "etag": "\"db-+Acyq518tFpu7mZbLzxKe1AE/f4\"",
    "mtime": "2025-04-13T20:04:20.361Z",
    "size": 219,
    "path": "../public/app-assets/js/scripts/forms/form-tooltip-valid.min.js"
  },
  "/app-assets/js/scripts/forms/number-input.min.js": {
    "type": "text/javascript; charset=utf-8",
    "etag": "\"4dd-BkjkVZlGwaCTtFzhR4t5S+qYFD8\"",
    "mtime": "2025-04-13T20:04:20.361Z",
    "size": 1245,
    "path": "../public/app-assets/js/scripts/forms/number-input.min.js"
  },
  "/app-assets/js/scripts/forms/number-input.min.js.br": {
    "type": "text/javascript; charset=utf-8",
    "encoding": "br",
    "etag": "\"18a-vCbsVULj39CTrDbTUsy31eVww/I\"",
    "mtime": "2025-04-13T20:04:28.242Z",
    "size": 394,
    "path": "../public/app-assets/js/scripts/forms/number-input.min.js.br"
  },
  "/app-assets/js/scripts/forms/number-input.min.js.gz": {
    "type": "text/javascript; charset=utf-8",
    "encoding": "gzip",
    "etag": "\"1c5-ofWCVv8uLMqntW4NxEMD3BI5wHw\"",
    "mtime": "2025-04-13T20:04:28.242Z",
    "size": 453,
    "path": "../public/app-assets/js/scripts/forms/number-input.min.js.gz"
  },
  "/app-assets/js/scripts/forms/wizard-steps.min.js": {
    "type": "text/javascript; charset=utf-8",
    "etag": "\"50b-feSAX3OhJNNqrmcn4jTZGXO3+70\"",
    "mtime": "2025-04-13T20:04:20.361Z",
    "size": 1291,
    "path": "../public/app-assets/js/scripts/forms/wizard-steps.min.js"
  },
  "/app-assets/js/scripts/forms/wizard-steps.min.js.br": {
    "type": "text/javascript; charset=utf-8",
    "encoding": "br",
    "etag": "\"15f-z/mLbHJ4K/GOBug8MvixNtuvK1w\"",
    "mtime": "2025-04-13T20:04:28.242Z",
    "size": 351,
    "path": "../public/app-assets/js/scripts/forms/wizard-steps.min.js.br"
  },
  "/app-assets/js/scripts/forms/wizard-steps.min.js.gz": {
    "type": "text/javascript; charset=utf-8",
    "encoding": "gzip",
    "etag": "\"1ce-X4O3BV2WIRF25/lL9iDDgJfJO1g\"",
    "mtime": "2025-04-13T20:04:28.242Z",
    "size": 462,
    "path": "../public/app-assets/js/scripts/forms/wizard-steps.min.js.gz"
  },
  "/app-assets/js/scripts/modal/components-modal.min.js": {
    "type": "text/javascript; charset=utf-8",
    "etag": "\"20b-ynIt8INAJgBUWWsrx36LBCh491w\"",
    "mtime": "2025-04-13T20:04:20.326Z",
    "size": 523,
    "path": "../public/app-assets/js/scripts/modal/components-modal.min.js"
  },
  "/app-assets/js/scripts/navs/navs.min.js": {
    "type": "text/javascript; charset=utf-8",
    "etag": "\"c9-tVjuESLxyCMtppFFNmLR38HBdSQ\"",
    "mtime": "2025-04-13T20:04:20.326Z",
    "size": 201,
    "path": "../public/app-assets/js/scripts/navs/navs.min.js"
  },
  "/app-assets/js/scripts/pagination/pagination.js": {
    "type": "text/javascript; charset=utf-8",
    "etag": "\"93a-m0lJojlUo1Xlbtb+HX09dw5D91g\"",
    "mtime": "2025-04-13T20:04:20.326Z",
    "size": 2362,
    "path": "../public/app-assets/js/scripts/pagination/pagination.js"
  },
  "/app-assets/js/scripts/pagination/pagination.js.br": {
    "type": "text/javascript; charset=utf-8",
    "encoding": "br",
    "etag": "\"208-RMzxNY7Exth/7WQdF2Wvnj4lDPA\"",
    "mtime": "2025-04-13T20:04:28.243Z",
    "size": 520,
    "path": "../public/app-assets/js/scripts/pagination/pagination.js.br"
  },
  "/app-assets/js/scripts/pagination/pagination.js.gz": {
    "type": "text/javascript; charset=utf-8",
    "encoding": "gzip",
    "etag": "\"275-EQ+vQgNZu2hS+1GgpnvaWSGeHzo\"",
    "mtime": "2025-04-13T20:04:28.243Z",
    "size": 629,
    "path": "../public/app-assets/js/scripts/pagination/pagination.js.gz"
  },
  "/app-assets/js/scripts/pages/account-setting.min.js": {
    "type": "text/javascript; charset=utf-8",
    "etag": "\"11e-2AbNqvKg40qGmt3kHYCjlCz5OIs\"",
    "mtime": "2025-04-13T20:04:20.361Z",
    "size": 286,
    "path": "../public/app-assets/js/scripts/pages/account-setting.min.js"
  },
  "/app-assets/js/scripts/pages/app-chat.min.js": {
    "type": "text/javascript; charset=utf-8",
    "etag": "\"ff8-XKe8lKCFGaNA8/O1uDd0PdG+0ck\"",
    "mtime": "2025-04-13T20:04:20.326Z",
    "size": 4088,
    "path": "../public/app-assets/js/scripts/pages/app-chat.min.js"
  },
  "/app-assets/js/scripts/pages/app-chat.min.js.br": {
    "type": "text/javascript; charset=utf-8",
    "encoding": "br",
    "etag": "\"301-k9m3KJgi7XXvIVTsRJMd6bxvkz4\"",
    "mtime": "2025-04-13T20:04:28.242Z",
    "size": 769,
    "path": "../public/app-assets/js/scripts/pages/app-chat.min.js.br"
  },
  "/app-assets/js/scripts/pages/app-chat.min.js.gz": {
    "type": "text/javascript; charset=utf-8",
    "encoding": "gzip",
    "etag": "\"3b5-7UVvdT2ti7hi3aSIMz4sWBo7WzA\"",
    "mtime": "2025-04-13T20:04:28.242Z",
    "size": 949,
    "path": "../public/app-assets/js/scripts/pages/app-chat.min.js.gz"
  },
  "/app-assets/js/scripts/pages/app-ecommerce-details.min.js": {
    "type": "text/javascript; charset=utf-8",
    "etag": "\"1e0-QMblAKK5OtkJ483PrspSTomxwUI\"",
    "mtime": "2025-04-13T20:04:20.361Z",
    "size": 480,
    "path": "../public/app-assets/js/scripts/pages/app-ecommerce-details.min.js"
  },
  "/app-assets/js/scripts/pages/app-ecommerce-shop.min.js": {
    "type": "text/javascript; charset=utf-8",
    "etag": "\"c14-zMhs/Gl/WLLPNbWxaR9u+DyQSJk\"",
    "mtime": "2025-04-13T20:04:20.361Z",
    "size": 3092,
    "path": "../public/app-assets/js/scripts/pages/app-ecommerce-shop.min.js"
  },
  "/app-assets/js/scripts/pages/app-ecommerce-shop.min.js.br": {
    "type": "text/javascript; charset=utf-8",
    "encoding": "br",
    "etag": "\"401-6n0+Zk6BefdrVdgBlKM0mm5nDsA\"",
    "mtime": "2025-04-13T20:04:28.243Z",
    "size": 1025,
    "path": "../public/app-assets/js/scripts/pages/app-ecommerce-shop.min.js.br"
  },
  "/app-assets/js/scripts/pages/app-ecommerce-shop.min.js.gz": {
    "type": "text/javascript; charset=utf-8",
    "encoding": "gzip",
    "etag": "\"4fc-bTryBnaJpXHXfoFRdfsHM0cRias\"",
    "mtime": "2025-04-13T20:04:28.243Z",
    "size": 1276,
    "path": "../public/app-assets/js/scripts/pages/app-ecommerce-shop.min.js.gz"
  },
  "/app-assets/js/scripts/pages/app-email.min.js": {
    "type": "text/javascript; charset=utf-8",
    "etag": "\"f00-cmCFEJ3g/tvEgICfc5QtN5mqGpk\"",
    "mtime": "2025-04-13T20:04:20.361Z",
    "size": 3840,
    "path": "../public/app-assets/js/scripts/pages/app-email.min.js"
  },
  "/app-assets/js/scripts/pages/app-email.min.js.br": {
    "type": "text/javascript; charset=utf-8",
    "encoding": "br",
    "etag": "\"33e-ZzQZ6SYaDepYqqpd1VPvfMFQSpg\"",
    "mtime": "2025-04-13T20:04:28.242Z",
    "size": 830,
    "path": "../public/app-assets/js/scripts/pages/app-email.min.js.br"
  },
  "/app-assets/js/scripts/pages/app-email.min.js.gz": {
    "type": "text/javascript; charset=utf-8",
    "encoding": "gzip",
    "etag": "\"3fe-8FRHiZ0JgbEdt/ZCHuHV4MKE2Fs\"",
    "mtime": "2025-04-13T20:04:28.242Z",
    "size": 1022,
    "path": "../public/app-assets/js/scripts/pages/app-email.min.js.gz"
  },
  "/app-assets/js/scripts/pages/app-todo.min.js": {
    "type": "text/javascript; charset=utf-8",
    "etag": "\"1a88-US+hHrTkULXsvxOBDGHctPZApVk\"",
    "mtime": "2025-04-13T20:04:20.362Z",
    "size": 6792,
    "path": "../public/app-assets/js/scripts/pages/app-todo.min.js"
  },
  "/app-assets/js/scripts/pages/app-todo.min.js.br": {
    "type": "text/javascript; charset=utf-8",
    "encoding": "br",
    "etag": "\"50c-qjO+u2z5jGJZC/6gVy8WoRwfGq8\"",
    "mtime": "2025-04-13T20:04:28.243Z",
    "size": 1292,
    "path": "../public/app-assets/js/scripts/pages/app-todo.min.js.br"
  },
  "/app-assets/js/scripts/pages/app-todo.min.js.gz": {
    "type": "text/javascript; charset=utf-8",
    "encoding": "gzip",
    "etag": "\"5eb-uLALijHqzW/yGu8WrZV6HuqTZEA\"",
    "mtime": "2025-04-13T20:04:28.242Z",
    "size": 1515,
    "path": "../public/app-assets/js/scripts/pages/app-todo.min.js.gz"
  },
  "/app-assets/js/scripts/pages/app-user.min.js": {
    "type": "text/javascript; charset=utf-8",
    "etag": "\"100c-aYYge2yX0l7o5SQUAk+hy5O2GNY\"",
    "mtime": "2025-04-13T20:04:20.362Z",
    "size": 4108,
    "path": "../public/app-assets/js/scripts/pages/app-user.min.js"
  },
  "/app-assets/js/scripts/pages/app-user.min.js.br": {
    "type": "text/javascript; charset=utf-8",
    "encoding": "br",
    "etag": "\"4b3-PnGs02ucK8HzuII297M4Jhhwi4A\"",
    "mtime": "2025-04-13T20:04:28.242Z",
    "size": 1203,
    "path": "../public/app-assets/js/scripts/pages/app-user.min.js.br"
  },
  "/app-assets/js/scripts/pages/app-user.min.js.gz": {
    "type": "text/javascript; charset=utf-8",
    "encoding": "gzip",
    "etag": "\"5b5-Qn2eizxy3Kc7sHk4q73dtLU8pSA\"",
    "mtime": "2025-04-13T20:04:28.242Z",
    "size": 1461,
    "path": "../public/app-assets/js/scripts/pages/app-user.min.js.gz"
  },
  "/app-assets/js/scripts/pages/bootstrap-toast.min.js": {
    "type": "text/javascript; charset=utf-8",
    "etag": "\"f9-TZHxc15teZejh9eb7XrRjZz7m3M\"",
    "mtime": "2025-04-13T20:04:20.362Z",
    "size": 249,
    "path": "../public/app-assets/js/scripts/pages/bootstrap-toast.min.js"
  },
  "/app-assets/js/scripts/pages/coming-soon.js": {
    "type": "text/javascript; charset=utf-8",
    "etag": "\"604-QQHzaP3wflqeNKHQIFhpyflaxD0\"",
    "mtime": "2025-04-13T20:04:20.361Z",
    "size": 1540,
    "path": "../public/app-assets/js/scripts/pages/coming-soon.js"
  },
  "/app-assets/js/scripts/pages/coming-soon.js.br": {
    "type": "text/javascript; charset=utf-8",
    "encoding": "br",
    "etag": "\"1bd-DVcMlNxHnSLFrel2VwPMPwf8//M\"",
    "mtime": "2025-04-13T20:04:28.243Z",
    "size": 445,
    "path": "../public/app-assets/js/scripts/pages/coming-soon.js.br"
  },
  "/app-assets/js/scripts/pages/coming-soon.js.gz": {
    "type": "text/javascript; charset=utf-8",
    "encoding": "gzip",
    "etag": "\"228-FNeMWHp1CPUDqMVcXkkfdRCgze4\"",
    "mtime": "2025-04-13T20:04:28.243Z",
    "size": 552,
    "path": "../public/app-assets/js/scripts/pages/coming-soon.js.gz"
  },
  "/app-assets/js/scripts/pages/dashboard-analytics.min.js": {
    "type": "text/javascript; charset=utf-8",
    "etag": "\"1615-pXOfFK0fW+rOtIlq3BYe5tGHbZg\"",
    "mtime": "2025-04-13T20:04:20.362Z",
    "size": 5653,
    "path": "../public/app-assets/js/scripts/pages/dashboard-analytics.min.js"
  },
  "/app-assets/js/scripts/pages/dashboard-analytics.min.js.br": {
    "type": "text/javascript; charset=utf-8",
    "encoding": "br",
    "etag": "\"527-RRLLnCLyxt/5MRik3137vzBmStk\"",
    "mtime": "2025-04-13T20:04:28.243Z",
    "size": 1319,
    "path": "../public/app-assets/js/scripts/pages/dashboard-analytics.min.js.br"
  },
  "/app-assets/js/scripts/pages/dashboard-analytics.min.js.gz": {
    "type": "text/javascript; charset=utf-8",
    "encoding": "gzip",
    "etag": "\"604-j32NTGhUOTDi5cpaWWflxRGx0EU\"",
    "mtime": "2025-04-13T20:04:28.243Z",
    "size": 1540,
    "path": "../public/app-assets/js/scripts/pages/dashboard-analytics.min.js.gz"
  },
  "/app-assets/js/scripts/pages/dashboard-ecommerce.min.js": {
    "type": "text/javascript; charset=utf-8",
    "etag": "\"1524-9zwkAedRDfwwq0l5Gh/FrO0EzX0\"",
    "mtime": "2025-04-13T20:04:20.362Z",
    "size": 5412,
    "path": "../public/app-assets/js/scripts/pages/dashboard-ecommerce.min.js"
  },
  "/app-assets/js/scripts/pages/dashboard-ecommerce.min.js.br": {
    "type": "text/javascript; charset=utf-8",
    "encoding": "br",
    "etag": "\"586-pU7MZ22rcczWBfOrIGY7TS4OSbs\"",
    "mtime": "2025-04-13T20:04:28.243Z",
    "size": 1414,
    "path": "../public/app-assets/js/scripts/pages/dashboard-ecommerce.min.js.br"
  },
  "/app-assets/js/scripts/pages/dashboard-ecommerce.min.js.gz": {
    "type": "text/javascript; charset=utf-8",
    "encoding": "gzip",
    "etag": "\"667-o2OqYU9/W6Uin0AZFpnLQfLwNuk\"",
    "mtime": "2025-04-13T20:04:28.243Z",
    "size": 1639,
    "path": "../public/app-assets/js/scripts/pages/dashboard-ecommerce.min.js.gz"
  },
  "/app-assets/js/scripts/pages/faq-kb.min.js": {
    "type": "text/javascript; charset=utf-8",
    "etag": "\"282-S5CTRWDKapAdj3xcDOUQ6CXnuLw\"",
    "mtime": "2025-04-13T20:04:20.362Z",
    "size": 642,
    "path": "../public/app-assets/js/scripts/pages/faq-kb.min.js"
  },
  "/app-assets/js/scripts/pages/invoice.min.js": {
    "type": "text/javascript; charset=utf-8",
    "etag": "\"51-QGqbTFXUxIXec/EoHnr+RXJ0bPU\"",
    "mtime": "2025-04-13T20:04:20.362Z",
    "size": 81,
    "path": "../public/app-assets/js/scripts/pages/invoice.min.js"
  },
  "/app-assets/js/scripts/pages/user-profile.min.js": {
    "type": "text/javascript; charset=utf-8",
    "etag": "\"1bd-6H8r3XFWppPnG9z8OMlzFjIQViQ\"",
    "mtime": "2025-04-13T20:04:20.362Z",
    "size": 445,
    "path": "../public/app-assets/js/scripts/pages/user-profile.min.js"
  },
  "/app-assets/js/scripts/popover/popover.min.js": {
    "type": "text/javascript; charset=utf-8",
    "etag": "\"7ac-Y/faT5Wq92I+LFhHg4JDOO5Brhg\"",
    "mtime": "2025-04-13T20:04:20.326Z",
    "size": 1964,
    "path": "../public/app-assets/js/scripts/popover/popover.min.js"
  },
  "/app-assets/js/scripts/popover/popover.min.js.br": {
    "type": "text/javascript; charset=utf-8",
    "encoding": "br",
    "etag": "\"19d-hVOubMlAPIO6N3Ov8EJIF6i516M\"",
    "mtime": "2025-04-13T20:04:28.243Z",
    "size": 413,
    "path": "../public/app-assets/js/scripts/popover/popover.min.js.br"
  },
  "/app-assets/js/scripts/popover/popover.min.js.gz": {
    "type": "text/javascript; charset=utf-8",
    "encoding": "gzip",
    "etag": "\"1eb-L4A5hueGNPJqwBGoLaJk7048Gn8\"",
    "mtime": "2025-04-13T20:04:28.243Z",
    "size": 491,
    "path": "../public/app-assets/js/scripts/popover/popover.min.js.gz"
  },
  "/app-assets/js/scripts/tooltip/tooltip.min.js": {
    "type": "text/javascript; charset=utf-8",
    "etag": "\"520-lHPYxT/DFpx2ehcIBYYDW2aClwE\"",
    "mtime": "2025-04-13T20:04:20.326Z",
    "size": 1312,
    "path": "../public/app-assets/js/scripts/tooltip/tooltip.min.js"
  },
  "/app-assets/js/scripts/tooltip/tooltip.min.js.br": {
    "type": "text/javascript; charset=utf-8",
    "encoding": "br",
    "etag": "\"134-DTtxmBsXX2gBNLqBZgNYvWUKxUw\"",
    "mtime": "2025-04-13T20:04:28.243Z",
    "size": 308,
    "path": "../public/app-assets/js/scripts/tooltip/tooltip.min.js.br"
  },
  "/app-assets/js/scripts/tooltip/tooltip.min.js.gz": {
    "type": "text/javascript; charset=utf-8",
    "encoding": "gzip",
    "etag": "\"17a-ZRbfAPOb/PwYq1jzP4GDokM8sGs\"",
    "mtime": "2025-04-13T20:04:28.243Z",
    "size": 378,
    "path": "../public/app-assets/js/scripts/tooltip/tooltip.min.js.gz"
  },
  "/app-assets/js/scripts/ui/data-list-view.min.js": {
    "type": "text/javascript; charset=utf-8",
    "etag": "\"b76-GJZBkuTPNaSMLElSyyrEoQsLFFo\"",
    "mtime": "2025-04-13T20:04:20.326Z",
    "size": 2934,
    "path": "../public/app-assets/js/scripts/ui/data-list-view.min.js"
  },
  "/app-assets/js/scripts/ui/data-list-view.min.js.br": {
    "type": "text/javascript; charset=utf-8",
    "encoding": "br",
    "etag": "\"2ed-8nr5N+RwFP3UEY0NcYidKHnmmA0\"",
    "mtime": "2025-04-13T20:04:28.243Z",
    "size": 749,
    "path": "../public/app-assets/js/scripts/ui/data-list-view.min.js.br"
  },
  "/app-assets/js/scripts/ui/data-list-view.min.js.gz": {
    "type": "text/javascript; charset=utf-8",
    "encoding": "gzip",
    "etag": "\"399-nJmnQfEbb9joQ1N7C08c8y1NgmM\"",
    "mtime": "2025-04-13T20:04:28.243Z",
    "size": 921,
    "path": "../public/app-assets/js/scripts/ui/data-list-view.min.js.gz"
  },
  "/app-assets/vendors/css/animate/animate.css": {
    "type": "text/css; charset=utf-8",
    "etag": "\"13053-d7U3iitL/BIOUngt2Gmuq37+L9Q\"",
    "mtime": "2025-04-13T20:04:20.317Z",
    "size": 77907,
    "path": "../public/app-assets/vendors/css/animate/animate.css"
  },
  "/app-assets/vendors/css/animate/animate.css.br": {
    "type": "text/css; charset=utf-8",
    "encoding": "br",
    "etag": "\"eda-d6cspbpjlZcEkOq2uQZtra2o53Q\"",
    "mtime": "2025-04-13T20:04:28.220Z",
    "size": 3802,
    "path": "../public/app-assets/vendors/css/animate/animate.css.br"
  },
  "/app-assets/vendors/css/animate/animate.css.gz": {
    "type": "text/css; charset=utf-8",
    "encoding": "gzip",
    "etag": "\"1248-UvNaRFEG/gzk67umYMaVz9REvuI\"",
    "mtime": "2025-04-13T20:04:28.220Z",
    "size": 4680,
    "path": "../public/app-assets/vendors/css/animate/animate.css.gz"
  },
  "/app-assets/vendors/css/calendars/fullcalendar.min.css": {
    "type": "text/css; charset=utf-8",
    "etag": "\"3879-aDQX8sEvvqAv3sfKDMR2L6+ov+k\"",
    "mtime": "2025-04-13T20:04:20.362Z",
    "size": 14457,
    "path": "../public/app-assets/vendors/css/calendars/fullcalendar.min.css"
  },
  "/app-assets/vendors/css/calendars/fullcalendar.min.css.br": {
    "type": "text/css; charset=utf-8",
    "encoding": "br",
    "etag": "\"f10-GhB3Io2Wzz4JrSf+QZYD7OSwjEY\"",
    "mtime": "2025-04-13T20:04:28.219Z",
    "size": 3856,
    "path": "../public/app-assets/vendors/css/calendars/fullcalendar.min.css.br"
  },
  "/app-assets/vendors/css/calendars/fullcalendar.min.css.gz": {
    "type": "text/css; charset=utf-8",
    "encoding": "gzip",
    "etag": "\"1181-o9eC9T6PSxqRFJI9HAx66LV0FUk\"",
    "mtime": "2025-04-13T20:04:28.219Z",
    "size": 4481,
    "path": "../public/app-assets/vendors/css/calendars/fullcalendar.min.css.gz"
  },
  "/app-assets/vendors/css/charts/apexcharts.css": {
    "type": "text/css; charset=utf-8",
    "etag": "\"2cf9-v8Gqz8CdzcGKygbZ6xl2EnOls88\"",
    "mtime": "2025-04-13T20:04:20.326Z",
    "size": 11513,
    "path": "../public/app-assets/vendors/css/charts/apexcharts.css"
  },
  "/app-assets/vendors/css/charts/apexcharts.css.br": {
    "type": "text/css; charset=utf-8",
    "encoding": "br",
    "etag": "\"7ee-PU8czjg5Vv4Iuge+zawF676mdsE\"",
    "mtime": "2025-04-13T20:04:28.219Z",
    "size": 2030,
    "path": "../public/app-assets/vendors/css/charts/apexcharts.css.br"
  },
  "/app-assets/vendors/css/charts/apexcharts.css.gz": {
    "type": "text/css; charset=utf-8",
    "encoding": "gzip",
    "etag": "\"959-EH5pVGFLmarbg835mzf0h9SizwM\"",
    "mtime": "2025-04-13T20:04:28.219Z",
    "size": 2393,
    "path": "../public/app-assets/vendors/css/charts/apexcharts.css.gz"
  },
  "/app-assets/vendors/css/file-uploaders/dropzone.min.css": {
    "type": "text/css; charset=utf-8",
    "etag": "\"2413-oYecW/SJmjW/oDThkOU6pv/M6Jc\"",
    "mtime": "2025-04-13T20:04:20.326Z",
    "size": 9235,
    "path": "../public/app-assets/vendors/css/file-uploaders/dropzone.min.css"
  },
  "/app-assets/vendors/css/file-uploaders/dropzone.min.css.br": {
    "type": "text/css; charset=utf-8",
    "encoding": "br",
    "etag": "\"4fb-TOFFpr3SL6HfRC3ke9A1iTHPWBs\"",
    "mtime": "2025-04-13T20:04:28.220Z",
    "size": 1275,
    "path": "../public/app-assets/vendors/css/file-uploaders/dropzone.min.css.br"
  },
  "/app-assets/vendors/css/file-uploaders/dropzone.min.css.gz": {
    "type": "text/css; charset=utf-8",
    "encoding": "gzip",
    "etag": "\"5d4-zJLQXmYFOz3hPR9YGtHlTO7LJAU\"",
    "mtime": "2025-04-13T20:04:28.220Z",
    "size": 1492,
    "path": "../public/app-assets/vendors/css/file-uploaders/dropzone.min.css.gz"
  },
  "/app-assets/vendors/css/extensions/dragula.min.css": {
    "type": "text/css; charset=utf-8",
    "etag": "\"1d2-ScR/1feHp+5Aiwp264tpSK10M3s\"",
    "mtime": "2025-04-13T20:04:20.362Z",
    "size": 466,
    "path": "../public/app-assets/vendors/css/extensions/dragula.min.css"
  },
  "/app-assets/vendors/css/extensions/jquery.contextMenu.min.css": {
    "type": "text/css; charset=utf-8",
    "etag": "\"1761-5kxECm6z9VB5u0XCwncKXRA8M9s\"",
    "mtime": "2025-04-13T20:04:20.362Z",
    "size": 5985,
    "path": "../public/app-assets/vendors/css/extensions/jquery.contextMenu.min.css"
  },
  "/app-assets/vendors/css/extensions/jquery.contextMenu.min.css.br": {
    "type": "text/css; charset=utf-8",
    "encoding": "br",
    "etag": "\"4f4-gNVRf9tdEANrewaaiZ7kQQTly2I\"",
    "mtime": "2025-04-13T20:04:28.220Z",
    "size": 1268,
    "path": "../public/app-assets/vendors/css/extensions/jquery.contextMenu.min.css.br"
  },
  "/app-assets/vendors/css/extensions/jquery.contextMenu.min.css.gz": {
    "type": "text/css; charset=utf-8",
    "encoding": "gzip",
    "etag": "\"5d8-0by4e0hNfkpVIvQUx1sfyl6Dp0U\"",
    "mtime": "2025-04-13T20:04:28.220Z",
    "size": 1496,
    "path": "../public/app-assets/vendors/css/extensions/jquery.contextMenu.min.css.gz"
  },
  "/app-assets/vendors/css/extensions/nouislider.min.css": {
    "type": "text/css; charset=utf-8",
    "etag": "\"fd8-rAcDcOqE5xR5j2Gj/eOxfU6e+qw\"",
    "mtime": "2025-04-13T20:04:20.362Z",
    "size": 4056,
    "path": "../public/app-assets/vendors/css/extensions/nouislider.min.css"
  },
  "/app-assets/vendors/css/extensions/nouislider.min.css.br": {
    "type": "text/css; charset=utf-8",
    "encoding": "br",
    "etag": "\"3c3-aVcvQf68iBq4v0z7sA1kF9v19co\"",
    "mtime": "2025-04-13T20:04:28.220Z",
    "size": 963,
    "path": "../public/app-assets/vendors/css/extensions/nouislider.min.css.br"
  },
  "/app-assets/vendors/css/extensions/nouislider.min.css.gz": {
    "type": "text/css; charset=utf-8",
    "encoding": "gzip",
    "etag": "\"4a7-OgzuzjI4rHMm+OVO6q6AD2h0NyU\"",
    "mtime": "2025-04-13T20:04:28.220Z",
    "size": 1191,
    "path": "../public/app-assets/vendors/css/extensions/nouislider.min.css.gz"
  },
  "/app-assets/vendors/css/extensions/plyr.css": {
    "type": "text/css; charset=utf-8",
    "etag": "\"6117-MFCIId+VcAJBDVmnKfo6Z7oWjAw\"",
    "mtime": "2025-04-13T20:04:20.362Z",
    "size": 24855,
    "path": "../public/app-assets/vendors/css/extensions/plyr.css"
  },
  "/app-assets/vendors/css/extensions/plyr.css.br": {
    "type": "text/css; charset=utf-8",
    "encoding": "br",
    "etag": "\"e71-Vyv4bVhv0IuVPXIP+3Kf9+if4Dk\"",
    "mtime": "2025-04-13T20:04:28.220Z",
    "size": 3697,
    "path": "../public/app-assets/vendors/css/extensions/plyr.css.br"
  },
  "/app-assets/vendors/css/extensions/plyr.css.gz": {
    "type": "text/css; charset=utf-8",
    "encoding": "gzip",
    "etag": "\"107b-bEo8+fZsELTNi9kNGd88xbEwz1s\"",
    "mtime": "2025-04-13T20:04:28.220Z",
    "size": 4219,
    "path": "../public/app-assets/vendors/css/extensions/plyr.css.gz"
  },
  "/app-assets/vendors/css/extensions/shepherd-theme-default.css": {
    "type": "text/css; charset=utf-8",
    "etag": "\"14cc-MEec92GUOBlDy2lVCgYOu5afFa0\"",
    "mtime": "2025-04-13T20:04:20.362Z",
    "size": 5324,
    "path": "../public/app-assets/vendors/css/extensions/shepherd-theme-default.css"
  },
  "/app-assets/vendors/css/extensions/shepherd-theme-default.css.br": {
    "type": "text/css; charset=utf-8",
    "encoding": "br",
    "etag": "\"42a-MlHAPQ4tBztfKblQmiL+pm8wp0I\"",
    "mtime": "2025-04-13T20:04:28.220Z",
    "size": 1066,
    "path": "../public/app-assets/vendors/css/extensions/shepherd-theme-default.css.br"
  },
  "/app-assets/vendors/css/extensions/shepherd-theme-default.css.gz": {
    "type": "text/css; charset=utf-8",
    "encoding": "gzip",
    "etag": "\"4fc-IuLxXEJ8aQH9PTRP1pft2Wr7Xa0\"",
    "mtime": "2025-04-13T20:04:28.220Z",
    "size": 1276,
    "path": "../public/app-assets/vendors/css/extensions/shepherd-theme-default.css.gz"
  },
  "/app-assets/vendors/css/extensions/sweetalert2.min.css": {
    "type": "text/css; charset=utf-8",
    "etag": "\"6950-a0Ck6dvudbIyv1ppCFv3xPcWREM\"",
    "mtime": "2025-04-13T20:04:20.362Z",
    "size": 26960,
    "path": "../public/app-assets/vendors/css/extensions/sweetalert2.min.css"
  },
  "/app-assets/vendors/css/extensions/sweetalert2.min.css.br": {
    "type": "text/css; charset=utf-8",
    "encoding": "br",
    "etag": "\"ec9-c6Jk2Hs962hBSpkXBlfufHyKwbo\"",
    "mtime": "2025-04-13T20:04:28.220Z",
    "size": 3785,
    "path": "../public/app-assets/vendors/css/extensions/sweetalert2.min.css.br"
  },
  "/app-assets/vendors/css/extensions/sweetalert2.min.css.gz": {
    "type": "text/css; charset=utf-8",
    "encoding": "gzip",
    "etag": "\"10b4-b+IUWB03rVx6zqJOHSvDDMDFs88\"",
    "mtime": "2025-04-13T20:04:28.220Z",
    "size": 4276,
    "path": "../public/app-assets/vendors/css/extensions/sweetalert2.min.css.gz"
  },
  "/app-assets/vendors/css/extensions/swiper.min.css": {
    "type": "text/css; charset=utf-8",
    "etag": "\"4d42-hzEuiTNa7gUfVSuilkSumx+MwME\"",
    "mtime": "2025-04-13T20:04:20.362Z",
    "size": 19778,
    "path": "../public/app-assets/vendors/css/extensions/swiper.min.css"
  },
  "/app-assets/vendors/css/extensions/swiper.min.css.br": {
    "type": "text/css; charset=utf-8",
    "encoding": "br",
    "etag": "\"a15-6QTrjAsHMOPXR6S7A6Ia0/KeNlo\"",
    "mtime": "2025-04-13T20:04:28.220Z",
    "size": 2581,
    "path": "../public/app-assets/vendors/css/extensions/swiper.min.css.br"
  },
  "/app-assets/vendors/css/extensions/swiper.min.css.gz": {
    "type": "text/css; charset=utf-8",
    "encoding": "gzip",
    "etag": "\"bd5-C+zUDOKCg7uDe0YeHatTW+kk6JI\"",
    "mtime": "2025-04-13T20:04:28.220Z",
    "size": 3029,
    "path": "../public/app-assets/vendors/css/extensions/swiper.min.css.gz"
  },
  "/app-assets/vendors/css/extensions/tether-theme-arrows.css": {
    "type": "text/css; charset=utf-8",
    "etag": "\"1d38-QgP5XRDbahT7c7Ht1wjAr8BzprA\"",
    "mtime": "2025-04-13T20:04:20.362Z",
    "size": 7480,
    "path": "../public/app-assets/vendors/css/extensions/tether-theme-arrows.css"
  },
  "/app-assets/vendors/css/extensions/tether-theme-arrows.css.br": {
    "type": "text/css; charset=utf-8",
    "encoding": "br",
    "etag": "\"264-UPqpXX88L0QQWU9jXKktvG6pVFA\"",
    "mtime": "2025-04-13T20:04:28.220Z",
    "size": 612,
    "path": "../public/app-assets/vendors/css/extensions/tether-theme-arrows.css.br"
  },
  "/app-assets/vendors/css/extensions/tether-theme-arrows.css.gz": {
    "type": "text/css; charset=utf-8",
    "encoding": "gzip",
    "etag": "\"2fe-T/c1XAhCijMPA9rj3ADoZzqyElk\"",
    "mtime": "2025-04-13T20:04:28.220Z",
    "size": 766,
    "path": "../public/app-assets/vendors/css/extensions/tether-theme-arrows.css.gz"
  },
  "/app-assets/vendors/css/extensions/tether.min.css": {
    "type": "text/css; charset=utf-8",
    "etag": "\"ed-TALpk83DRdQov+Qa+opWdufHF7g\"",
    "mtime": "2025-04-13T20:04:20.362Z",
    "size": 237,
    "path": "../public/app-assets/vendors/css/extensions/tether.min.css"
  },
  "/app-assets/vendors/css/extensions/toastr.css": {
    "type": "text/css; charset=utf-8",
    "etag": "\"1dac-foLbuXPu/o6QWcG4lt5Mf7uQwSM\"",
    "mtime": "2025-04-13T20:04:20.362Z",
    "size": 7596,
    "path": "../public/app-assets/vendors/css/extensions/toastr.css"
  },
  "/app-assets/vendors/css/extensions/toastr.css.br": {
    "type": "text/css; charset=utf-8",
    "encoding": "br",
    "etag": "\"a76-EUNAYeYmTRHQLbLHl4GAayIPHWs\"",
    "mtime": "2025-04-13T20:04:28.220Z",
    "size": 2678,
    "path": "../public/app-assets/vendors/css/extensions/toastr.css.br"
  },
  "/app-assets/vendors/css/extensions/toastr.css.gz": {
    "type": "text/css; charset=utf-8",
    "encoding": "gzip",
    "etag": "\"bfe-aVxb/YaMhrVQOpT2DJpJ2rZxAEw\"",
    "mtime": "2025-04-13T20:04:28.220Z",
    "size": 3070,
    "path": "../public/app-assets/vendors/css/extensions/toastr.css.gz"
  },
  "/app-assets/vendors/css/ui/prism.min.css": {
    "type": "text/css; charset=utf-8",
    "etag": "\"1a6a-I7MdbJ/S3ToSRSFj/hex4OUwIlc\"",
    "mtime": "2025-04-13T20:04:20.327Z",
    "size": 6762,
    "path": "../public/app-assets/vendors/css/ui/prism.min.css"
  },
  "/app-assets/vendors/css/ui/prism.min.css.br": {
    "type": "text/css; charset=utf-8",
    "encoding": "br",
    "etag": "\"6f6-joUuOvRHCq4YiqeQhMGH6jYkpZU\"",
    "mtime": "2025-04-13T20:04:28.220Z",
    "size": 1782,
    "path": "../public/app-assets/vendors/css/ui/prism.min.css.br"
  },
  "/app-assets/vendors/css/ui/prism.min.css.gz": {
    "type": "text/css; charset=utf-8",
    "encoding": "gzip",
    "etag": "\"850-7yVzxsrs90Sye0M6HUJl5lZ7G54\"",
    "mtime": "2025-04-13T20:04:28.220Z",
    "size": 2128,
    "path": "../public/app-assets/vendors/css/ui/prism.min.css.gz"
  },
  "/app-assets/vendors/js/calendar/fullcalendar.min.js": {
    "type": "text/javascript; charset=utf-8",
    "etag": "\"1eddd-ulVxawKpnNDtBL6YC+00bqXjkII\"",
    "mtime": "2025-04-13T20:04:20.364Z",
    "size": 126429,
    "path": "../public/app-assets/vendors/js/calendar/fullcalendar.min.js"
  },
  "/app-assets/vendors/js/calendar/fullcalendar.min.js.br": {
    "type": "text/javascript; charset=utf-8",
    "encoding": "br",
    "etag": "\"7ab5-4ksUkFn18NITxdY9O95+A0QY3z8\"",
    "mtime": "2025-04-13T20:04:28.595Z",
    "size": 31413,
    "path": "../public/app-assets/vendors/js/calendar/fullcalendar.min.js.br"
  },
  "/app-assets/vendors/js/calendar/fullcalendar.min.js.gz": {
    "type": "text/javascript; charset=utf-8",
    "encoding": "gzip",
    "etag": "\"8d74-x+WxSXllqktI14mIJe+j/N7yhWY\"",
    "mtime": "2025-04-13T20:04:28.658Z",
    "size": 36212,
    "path": "../public/app-assets/vendors/js/calendar/fullcalendar.min.js.gz"
  },
  "/app-assets/vendors/js/charts/apexcharts.min.js": {
    "type": "text/javascript; charset=utf-8",
    "etag": "\"6baf3-+yZcCAc74Gz/tyY3/56X0T8/B7w\"",
    "mtime": "2025-04-13T20:04:20.364Z",
    "size": 441075,
    "path": "../public/app-assets/vendors/js/charts/apexcharts.min.js"
  },
  "/app-assets/vendors/js/charts/apexcharts.min.js.br": {
    "type": "text/javascript; charset=utf-8",
    "encoding": "br",
    "etag": "\"16957-4dsWLo+ggpkxTZkeX6d5SLLwnF8\"",
    "mtime": "2025-04-13T20:04:28.747Z",
    "size": 92503,
    "path": "../public/app-assets/vendors/js/charts/apexcharts.min.js.br"
  },
  "/app-assets/vendors/js/charts/apexcharts.min.js.gz": {
    "type": "text/javascript; charset=utf-8",
    "encoding": "gzip",
    "etag": "\"1b200-qiBYWQNTYxZSYg6PXnIgrZQrJW4\"",
    "mtime": "2025-04-13T20:04:28.756Z",
    "size": 111104,
    "path": "../public/app-assets/vendors/js/charts/apexcharts.min.js.gz"
  },
  "/app-assets/vendors/js/charts/chart.min.js": {
    "type": "text/javascript; charset=utf-8",
    "etag": "\"26431-Lr+QDgOGdJNz6YhwJlkP59r8MK4\"",
    "mtime": "2025-04-13T20:04:20.329Z",
    "size": 156721,
    "path": "../public/app-assets/vendors/js/charts/chart.min.js"
  },
  "/app-assets/vendors/js/charts/chart.min.js.br": {
    "type": "text/javascript; charset=utf-8",
    "encoding": "br",
    "etag": "\"a04d-r9IqmsoLUUnToU8Dt3j9tRgI8mY\"",
    "mtime": "2025-04-13T20:04:28.659Z",
    "size": 41037,
    "path": "../public/app-assets/vendors/js/charts/chart.min.js.br"
  },
  "/app-assets/vendors/js/charts/chart.min.js.gz": {
    "type": "text/javascript; charset=utf-8",
    "encoding": "gzip",
    "etag": "\"b79e-tOxvhsX+JBNy3WTgrvSQmEdR6wM\"",
    "mtime": "2025-04-13T20:04:28.658Z",
    "size": 47006,
    "path": "../public/app-assets/vendors/js/charts/chart.min.js.gz"
  },
  "/app-assets/vendors/js/charts/gmaps.min.js": {
    "type": "text/javascript; charset=utf-8",
    "etag": "\"7c32-/v1V0o2LVWGVzB+mnzrQFc2q+sc\"",
    "mtime": "2025-04-13T20:04:20.363Z",
    "size": 31794,
    "path": "../public/app-assets/vendors/js/charts/gmaps.min.js"
  },
  "/app-assets/vendors/js/charts/gmaps.min.js.br": {
    "type": "text/javascript; charset=utf-8",
    "encoding": "br",
    "etag": "\"1ffd-LqMk7gTXRfHYjucSkCkWQS++sUY\"",
    "mtime": "2025-04-13T20:04:28.220Z",
    "size": 8189,
    "path": "../public/app-assets/vendors/js/charts/gmaps.min.js.br"
  },
  "/app-assets/vendors/js/charts/gmaps.min.js.gz": {
    "type": "text/javascript; charset=utf-8",
    "encoding": "gzip",
    "etag": "\"2454-qilfe/fjHVhLLgIGLivgUUjvenk\"",
    "mtime": "2025-04-13T20:04:28.220Z",
    "size": 9300,
    "path": "../public/app-assets/vendors/js/charts/gmaps.min.js.gz"
  },
  "/app-assets/vendors/js/coming-soon/jquery.countdown.min.js": {
    "type": "text/javascript; charset=utf-8",
    "etag": "\"14db-vWbkzVjeCcGY56vHf6TIg5VdGJ4\"",
    "mtime": "2025-04-13T20:04:20.327Z",
    "size": 5339,
    "path": "../public/app-assets/vendors/js/coming-soon/jquery.countdown.min.js"
  },
  "/app-assets/vendors/js/coming-soon/jquery.countdown.min.js.br": {
    "type": "text/javascript; charset=utf-8",
    "encoding": "br",
    "etag": "\"7c4-y/toS3+pNjyVgz6M18ZPXBhKnZM\"",
    "mtime": "2025-04-13T20:04:28.220Z",
    "size": 1988,
    "path": "../public/app-assets/vendors/js/coming-soon/jquery.countdown.min.js.br"
  },
  "/app-assets/vendors/js/coming-soon/jquery.countdown.min.js.gz": {
    "type": "text/javascript; charset=utf-8",
    "encoding": "gzip",
    "etag": "\"959-SGX5EkRbIhGRrU3SwJ7AmWgwNEk\"",
    "mtime": "2025-04-13T20:04:28.220Z",
    "size": 2393,
    "path": "../public/app-assets/vendors/js/coming-soon/jquery.countdown.min.js.gz"
  },
  "/app-assets/vendors/js/extensions/dragula.min.js": {
    "type": "text/javascript; charset=utf-8",
    "etag": "\"2c81-GAhtboP3z503M79Et8fG06MzBgc\"",
    "mtime": "2025-04-13T20:04:20.363Z",
    "size": 11393,
    "path": "../public/app-assets/vendors/js/extensions/dragula.min.js"
  },
  "/app-assets/vendors/js/extensions/dragula.min.js.br": {
    "type": "text/javascript; charset=utf-8",
    "encoding": "br",
    "etag": "\"f3e-ERvpZk+X/hwQuKi18mDsgigaY+A\"",
    "mtime": "2025-04-13T20:04:28.237Z",
    "size": 3902,
    "path": "../public/app-assets/vendors/js/extensions/dragula.min.js.br"
  },
  "/app-assets/vendors/js/extensions/dragula.min.js.gz": {
    "type": "text/javascript; charset=utf-8",
    "encoding": "gzip",
    "etag": "\"10c5-1NKwgzqf0lDMsUzltTNEtiAK0JY\"",
    "mtime": "2025-04-13T20:04:28.236Z",
    "size": 4293,
    "path": "../public/app-assets/vendors/js/extensions/dragula.min.js.gz"
  },
  "/app-assets/vendors/js/extensions/dropzone.min.js": {
    "type": "text/javascript; charset=utf-8",
    "etag": "\"8941-yjDQr0I3D/WgqapRDDrbhQhV2E0\"",
    "mtime": "2025-04-13T20:04:20.327Z",
    "size": 35137,
    "path": "../public/app-assets/vendors/js/extensions/dropzone.min.js"
  },
  "/app-assets/vendors/js/extensions/dropzone.min.js.br": {
    "type": "text/javascript; charset=utf-8",
    "encoding": "br",
    "etag": "\"1fe4-X3oZP305VZ48GMic89/FhRFr6Ww\"",
    "mtime": "2025-04-13T20:04:28.237Z",
    "size": 8164,
    "path": "../public/app-assets/vendors/js/extensions/dropzone.min.js.br"
  },
  "/app-assets/vendors/js/extensions/dropzone.min.js.gz": {
    "type": "text/javascript; charset=utf-8",
    "encoding": "gzip",
    "etag": "\"24d6-E8e3bdkHqrzzJ/MKI3LtmCkqNQ8\"",
    "mtime": "2025-04-13T20:04:28.237Z",
    "size": 9430,
    "path": "../public/app-assets/vendors/js/extensions/dropzone.min.js.gz"
  },
  "/app-assets/vendors/js/extensions/jquery.contextMenu.min.js": {
    "type": "text/javascript; charset=utf-8",
    "etag": "\"6c9f-ZegNuB70bFYmJ6inxd3pgYjc/x4\"",
    "mtime": "2025-04-13T20:04:20.370Z",
    "size": 27807,
    "path": "../public/app-assets/vendors/js/extensions/jquery.contextMenu.min.js"
  },
  "/app-assets/vendors/js/extensions/jquery.contextMenu.min.js.br": {
    "type": "text/javascript; charset=utf-8",
    "encoding": "br",
    "etag": "\"1bee-ixUTvHYGV7hBM0A3zdhJz0sHGaw\"",
    "mtime": "2025-04-13T20:04:28.236Z",
    "size": 7150,
    "path": "../public/app-assets/vendors/js/extensions/jquery.contextMenu.min.js.br"
  },
  "/app-assets/vendors/js/extensions/jquery.contextMenu.min.js.gz": {
    "type": "text/javascript; charset=utf-8",
    "encoding": "gzip",
    "etag": "\"1f25-vLTl9Wjh8P2X8JBXomwSHaMUX2g\"",
    "mtime": "2025-04-13T20:04:28.236Z",
    "size": 7973,
    "path": "../public/app-assets/vendors/js/extensions/jquery.contextMenu.min.js.gz"
  },
  "/app-assets/vendors/js/extensions/jquery.steps.min.js": {
    "type": "text/javascript; charset=utf-8",
    "etag": "\"3621-FOHih+yY6MwKmS7plng7DEL57A8\"",
    "mtime": "2025-04-13T20:04:20.363Z",
    "size": 13857,
    "path": "../public/app-assets/vendors/js/extensions/jquery.steps.min.js"
  },
  "/app-assets/vendors/js/extensions/jquery.steps.min.js.br": {
    "type": "text/javascript; charset=utf-8",
    "encoding": "br",
    "etag": "\"10fc-HhEaQHfpOT0byBuLp95rvkdeWlA\"",
    "mtime": "2025-04-13T20:04:28.237Z",
    "size": 4348,
    "path": "../public/app-assets/vendors/js/extensions/jquery.steps.min.js.br"
  },
  "/app-assets/vendors/js/extensions/jquery.steps.min.js.gz": {
    "type": "text/javascript; charset=utf-8",
    "encoding": "gzip",
    "etag": "\"1341-BgPcrOLmOkZVZglDwSlLZx0PP8k\"",
    "mtime": "2025-04-13T20:04:28.237Z",
    "size": 4929,
    "path": "../public/app-assets/vendors/js/extensions/jquery.steps.min.js.gz"
  },
  "/app-assets/vendors/js/extensions/jquery.ui.position.min.js": {
    "type": "text/javascript; charset=utf-8",
    "etag": "\"16df-hbcicyEcoi+rRPDsaCK02+XSFGk\"",
    "mtime": "2025-04-13T20:04:20.364Z",
    "size": 5855,
    "path": "../public/app-assets/vendors/js/extensions/jquery.ui.position.min.js"
  },
  "/app-assets/vendors/js/extensions/jquery.ui.position.min.js.br": {
    "type": "text/javascript; charset=utf-8",
    "encoding": "br",
    "etag": "\"7d6-hla2FcL7Kfxbd0p4yP7J7PBsT70\"",
    "mtime": "2025-04-13T20:04:28.237Z",
    "size": 2006,
    "path": "../public/app-assets/vendors/js/extensions/jquery.ui.position.min.js.br"
  },
  "/app-assets/vendors/js/extensions/jquery.ui.position.min.js.gz": {
    "type": "text/javascript; charset=utf-8",
    "encoding": "gzip",
    "etag": "\"8dc-b/5U/muFaT+2W2UI0vZKrZox8dA\"",
    "mtime": "2025-04-13T20:04:28.237Z",
    "size": 2268,
    "path": "../public/app-assets/vendors/js/extensions/jquery.ui.position.min.js.gz"
  },
  "/app-assets/vendors/js/extensions/moment.min.js": {
    "type": "text/javascript; charset=utf-8",
    "etag": "\"d0d1-z/rE47dotXrVDloMomrVVN225Gg\"",
    "mtime": "2025-04-13T20:04:20.364Z",
    "size": 53457,
    "path": "../public/app-assets/vendors/js/extensions/moment.min.js"
  },
  "/app-assets/vendors/js/extensions/moment.min.js.br": {
    "type": "text/javascript; charset=utf-8",
    "encoding": "br",
    "etag": "\"3cd3-h33HPgHBjW2sYGmgCprol7Mzz+A\"",
    "mtime": "2025-04-13T20:04:28.242Z",
    "size": 15571,
    "path": "../public/app-assets/vendors/js/extensions/moment.min.js.br"
  },
  "/app-assets/vendors/js/extensions/moment.min.js.gz": {
    "type": "text/javascript; charset=utf-8",
    "encoding": "gzip",
    "etag": "\"435e-62dYySA1nrX9QmWTXlM2xajaNDs\"",
    "mtime": "2025-04-13T20:04:28.595Z",
    "size": 17246,
    "path": "../public/app-assets/vendors/js/extensions/moment.min.js.gz"
  },
  "/app-assets/vendors/js/extensions/nouislider.min.js": {
    "type": "text/javascript; charset=utf-8",
    "etag": "\"5ba2-VjsL4mPPWSSO1OGSluO4tdKOaYI\"",
    "mtime": "2025-04-13T20:04:20.364Z",
    "size": 23458,
    "path": "../public/app-assets/vendors/js/extensions/nouislider.min.js"
  },
  "/app-assets/vendors/js/extensions/nouislider.min.js.br": {
    "type": "text/javascript; charset=utf-8",
    "encoding": "br",
    "etag": "\"1c90-hh4OMFuSaYw/BPJBc+4YACIxFvE\"",
    "mtime": "2025-04-13T20:04:28.242Z",
    "size": 7312,
    "path": "../public/app-assets/vendors/js/extensions/nouislider.min.js.br"
  },
  "/app-assets/vendors/js/extensions/nouislider.min.js.gz": {
    "type": "text/javascript; charset=utf-8",
    "encoding": "gzip",
    "etag": "\"1fbe-hsVkJJq1w9UfsHOD0T1dWbkZSCs\"",
    "mtime": "2025-04-13T20:04:28.242Z",
    "size": 8126,
    "path": "../public/app-assets/vendors/js/extensions/nouislider.min.js.gz"
  },
  "/app-assets/vendors/js/extensions/polyfill.min.js": {
    "type": "text/javascript; charset=utf-8",
    "etag": "\"c41-+PhKW/lCdObTqm7Z1szA3Nnqslw\"",
    "mtime": "2025-04-13T20:04:20.370Z",
    "size": 3137,
    "path": "../public/app-assets/vendors/js/extensions/polyfill.min.js"
  },
  "/app-assets/vendors/js/extensions/polyfill.min.js.br": {
    "type": "text/javascript; charset=utf-8",
    "encoding": "br",
    "etag": "\"410-xwr+oxec0uYCFX12aSiBSLkL98I\"",
    "mtime": "2025-04-13T20:04:28.237Z",
    "size": 1040,
    "path": "../public/app-assets/vendors/js/extensions/polyfill.min.js.br"
  },
  "/app-assets/vendors/js/extensions/polyfill.min.js.gz": {
    "type": "text/javascript; charset=utf-8",
    "encoding": "gzip",
    "etag": "\"489-FE/gQmTYgOt5cORHAss2nxAIKAk\"",
    "mtime": "2025-04-13T20:04:28.237Z",
    "size": 1161,
    "path": "../public/app-assets/vendors/js/extensions/polyfill.min.js.gz"
  },
  "/app-assets/vendors/js/extensions/shepherd.min.js": {
    "type": "text/javascript; charset=utf-8",
    "etag": "\"27a29-NyBTQMKtq8/rTCkFgKDDw9T7yds\"",
    "mtime": "2025-04-13T20:04:20.365Z",
    "size": 162345,
    "path": "../public/app-assets/vendors/js/extensions/shepherd.min.js"
  },
  "/app-assets/vendors/js/extensions/shepherd.min.js.br": {
    "type": "text/javascript; charset=utf-8",
    "encoding": "br",
    "etag": "\"9820-aBj6UtnobhcJN8jHPpLOhvBx3EA\"",
    "mtime": "2025-04-13T20:04:28.659Z",
    "size": 38944,
    "path": "../public/app-assets/vendors/js/extensions/shepherd.min.js.br"
  },
  "/app-assets/vendors/js/extensions/shepherd.min.js.gz": {
    "type": "text/javascript; charset=utf-8",
    "encoding": "gzip",
    "etag": "\"b3f1-XlqsDK8Og8YwM72ikvFzKwsaU9U\"",
    "mtime": "2025-04-13T20:04:28.659Z",
    "size": 46065,
    "path": "../public/app-assets/vendors/js/extensions/shepherd.min.js.gz"
  },
  "/app-assets/vendors/js/extensions/sweetalert2.all.min.js": {
    "type": "text/javascript; charset=utf-8",
    "etag": "\"fe53-hdDnrhR305gN1N9Oy9tjcnPYihU\"",
    "mtime": "2025-04-13T20:04:20.373Z",
    "size": 65107,
    "path": "../public/app-assets/vendors/js/extensions/sweetalert2.all.min.js"
  },
  "/app-assets/vendors/js/extensions/sweetalert2.all.min.js.br": {
    "type": "text/javascript; charset=utf-8",
    "encoding": "br",
    "etag": "\"3762-lUGEuaiSMTlQwKw+//7bmTeSL5Y\"",
    "mtime": "2025-04-13T20:04:28.242Z",
    "size": 14178,
    "path": "../public/app-assets/vendors/js/extensions/sweetalert2.all.min.js.br"
  },
  "/app-assets/vendors/js/extensions/sweetalert2.all.min.js.gz": {
    "type": "text/javascript; charset=utf-8",
    "encoding": "gzip",
    "etag": "\"3dd6-vCffhSP+Um2sDYkGlx4f5JylPi8\"",
    "mtime": "2025-04-13T20:04:28.242Z",
    "size": 15830,
    "path": "../public/app-assets/vendors/js/extensions/sweetalert2.all.min.js.gz"
  },
  "/app-assets/vendors/js/extensions/swiper.min.js": {
    "type": "text/javascript; charset=utf-8",
    "etag": "\"1f3bd-kc/MyhHK5JSJJHEIwqWp54phd2Y\"",
    "mtime": "2025-04-13T20:04:20.365Z",
    "size": 127933,
    "path": "../public/app-assets/vendors/js/extensions/swiper.min.js"
  },
  "/app-assets/vendors/js/extensions/swiper.min.js.br": {
    "type": "text/javascript; charset=utf-8",
    "encoding": "br",
    "etag": "\"70c1-whcQu+OKGNpcK57eHZnWHaU/K18\"",
    "mtime": "2025-04-13T20:04:28.599Z",
    "size": 28865,
    "path": "../public/app-assets/vendors/js/extensions/swiper.min.js.br"
  },
  "/app-assets/vendors/js/extensions/swiper.min.js.gz": {
    "type": "text/javascript; charset=utf-8",
    "encoding": "gzip",
    "etag": "\"81cf-C7MaCl+UNzwXnnZHULndGeWfTHo\"",
    "mtime": "2025-04-13T20:04:28.659Z",
    "size": 33231,
    "path": "../public/app-assets/vendors/js/extensions/swiper.min.js.gz"
  },
  "/app-assets/vendors/js/extensions/tether.min.js": {
    "type": "text/javascript; charset=utf-8",
    "etag": "\"6038-K11OoTA+qJktPURn90EronzOsLY\"",
    "mtime": "2025-04-13T20:04:20.364Z",
    "size": 24632,
    "path": "../public/app-assets/vendors/js/extensions/tether.min.js"
  },
  "/app-assets/vendors/js/extensions/tether.min.js.br": {
    "type": "text/javascript; charset=utf-8",
    "encoding": "br",
    "etag": "\"19da-dCYL154J54RNqTphS6aTZWkBwvA\"",
    "mtime": "2025-04-13T20:04:28.242Z",
    "size": 6618,
    "path": "../public/app-assets/vendors/js/extensions/tether.min.js.br"
  },
  "/app-assets/vendors/js/extensions/tether.min.js.gz": {
    "type": "text/javascript; charset=utf-8",
    "encoding": "gzip",
    "etag": "\"1cca-L3X+SssGZGogF5EUoEcVCO0K1XI\"",
    "mtime": "2025-04-13T20:04:28.242Z",
    "size": 7370,
    "path": "../public/app-assets/vendors/js/extensions/tether.min.js.gz"
  },
  "/app-assets/vendors/js/extensions/toastr.min.js": {
    "type": "text/javascript; charset=utf-8",
    "etag": "\"17be-lXgzrimXRgdaBn3kPHGsIVMvSLk\"",
    "mtime": "2025-04-13T20:04:20.365Z",
    "size": 6078,
    "path": "../public/app-assets/vendors/js/extensions/toastr.min.js"
  },
  "/app-assets/vendors/js/extensions/toastr.min.js.br": {
    "type": "text/javascript; charset=utf-8",
    "encoding": "br",
    "etag": "\"737-ef9V90i8QQtPG28Bp7WLMype6Q8\"",
    "mtime": "2025-04-13T20:04:28.242Z",
    "size": 1847,
    "path": "../public/app-assets/vendors/js/extensions/toastr.min.js.br"
  },
  "/app-assets/vendors/js/extensions/toastr.min.js.gz": {
    "type": "text/javascript; charset=utf-8",
    "encoding": "gzip",
    "etag": "\"851-FFYH0DKeQsYITWpZu06K3mfDnYo\"",
    "mtime": "2025-04-13T20:04:28.242Z",
    "size": 2129,
    "path": "../public/app-assets/vendors/js/extensions/toastr.min.js.gz"
  },
  "/app-assets/vendors/js/extensions/wNumb.js": {
    "type": "text/javascript; charset=utf-8",
    "etag": "\"2169-Zsfng4BtPTgOD6+Qm3HCYiYt3E8\"",
    "mtime": "2025-04-13T20:04:20.366Z",
    "size": 8553,
    "path": "../public/app-assets/vendors/js/extensions/wNumb.js"
  },
  "/app-assets/vendors/js/extensions/wNumb.js.br": {
    "type": "text/javascript; charset=utf-8",
    "encoding": "br",
    "etag": "\"8cc-F9WlNHr1NP1QLipguH0/fXFlzn0\"",
    "mtime": "2025-04-13T20:04:28.242Z",
    "size": 2252,
    "path": "../public/app-assets/vendors/js/extensions/wNumb.js.br"
  },
  "/app-assets/vendors/js/extensions/wNumb.js.gz": {
    "type": "text/javascript; charset=utf-8",
    "encoding": "gzip",
    "etag": "\"a95-CStuyKokqKobC0qU6lIUX8OFrG8\"",
    "mtime": "2025-04-13T20:04:28.242Z",
    "size": 2709,
    "path": "../public/app-assets/vendors/js/extensions/wNumb.js.gz"
  },
  "/app-assets/vendors/js/media/plyr.js": {
    "type": "text/javascript; charset=utf-8",
    "etag": "\"4a1a7-A6QN9fBhImVc+djvqCRISHGpJhk\"",
    "mtime": "2025-04-13T20:04:20.369Z",
    "size": 303527,
    "path": "../public/app-assets/vendors/js/media/plyr.js"
  },
  "/app-assets/vendors/js/media/plyr.js.br": {
    "type": "text/javascript; charset=utf-8",
    "encoding": "br",
    "etag": "\"e3a7-oT3QileGMqrhiitBL8JWa97dTVI\"",
    "mtime": "2025-04-13T20:04:28.701Z",
    "size": 58279,
    "path": "../public/app-assets/vendors/js/media/plyr.js.br"
  },
  "/app-assets/vendors/js/media/plyr.js.gz": {
    "type": "text/javascript; charset=utf-8",
    "encoding": "gzip",
    "etag": "\"1141b-J7cxh0EqzdBzVop8nvw758q5PPU\"",
    "mtime": "2025-04-13T20:04:28.718Z",
    "size": 70683,
    "path": "../public/app-assets/vendors/js/media/plyr.js.gz"
  },
  "/app-assets/vendors/js/media/plyr.polyfilled.js": {
    "type": "text/javascript; charset=utf-8",
    "etag": "\"27314-YkqS1jExGV1cmnou+dpFZzhvhn8\"",
    "mtime": "2025-04-13T20:04:20.329Z",
    "size": 160532,
    "path": "../public/app-assets/vendors/js/media/plyr.polyfilled.js"
  },
  "/app-assets/vendors/js/media/plyr.polyfilled.js.br": {
    "type": "text/javascript; charset=utf-8",
    "encoding": "br",
    "etag": "\"a485-zG9DSbYf3QxMAAZFaERqYhRLOOw\"",
    "mtime": "2025-04-13T20:04:28.659Z",
    "size": 42117,
    "path": "../public/app-assets/vendors/js/media/plyr.polyfilled.js.br"
  },
  "/app-assets/vendors/js/media/plyr.polyfilled.js.gz": {
    "type": "text/javascript; charset=utf-8",
    "encoding": "gzip",
    "etag": "\"b7ef-eDNX/gFK60oc28ED1lFu862Yohk\"",
    "mtime": "2025-04-13T20:04:28.658Z",
    "size": 47087,
    "path": "../public/app-assets/vendors/js/media/plyr.polyfilled.js.gz"
  },
  "/app-assets/vendors/js/pagination/jquery.bootpag.min.js": {
    "type": "text/javascript; charset=utf-8",
    "etag": "\"be1-D3lLgkH2mKU9GGGGz1y4wNZCfwQ\"",
    "mtime": "2025-04-13T20:04:20.327Z",
    "size": 3041,
    "path": "../public/app-assets/vendors/js/pagination/jquery.bootpag.min.js"
  },
  "/app-assets/vendors/js/pagination/jquery.bootpag.min.js.br": {
    "type": "text/javascript; charset=utf-8",
    "encoding": "br",
    "etag": "\"416-+4t2LbHtAwneBDT28Xdc8m4hKBY\"",
    "mtime": "2025-04-13T20:04:28.242Z",
    "size": 1046,
    "path": "../public/app-assets/vendors/js/pagination/jquery.bootpag.min.js.br"
  },
  "/app-assets/vendors/js/pagination/jquery.bootpag.min.js.gz": {
    "type": "text/javascript; charset=utf-8",
    "encoding": "gzip",
    "etag": "\"4d2-aYmCxYHySiPUnTgN9fEH1aZTOkw\"",
    "mtime": "2025-04-13T20:04:28.242Z",
    "size": 1234,
    "path": "../public/app-assets/vendors/js/pagination/jquery.bootpag.min.js.gz"
  },
  "/app-assets/vendors/js/pagination/jquery.twbsPagination.min.js": {
    "type": "text/javascript; charset=utf-8",
    "etag": "\"198e-qt31Ekp+1FU5KQc7T5rW3cgwOgg\"",
    "mtime": "2025-04-13T20:04:20.363Z",
    "size": 6542,
    "path": "../public/app-assets/vendors/js/pagination/jquery.twbsPagination.min.js"
  },
  "/app-assets/vendors/js/pagination/jquery.twbsPagination.min.js.br": {
    "type": "text/javascript; charset=utf-8",
    "encoding": "br",
    "etag": "\"72f-qcZtSJA1nA2q/iG7A9v2QkOINt4\"",
    "mtime": "2025-04-13T20:04:28.242Z",
    "size": 1839,
    "path": "../public/app-assets/vendors/js/pagination/jquery.twbsPagination.min.js.br"
  },
  "/app-assets/vendors/js/pagination/jquery.twbsPagination.min.js.gz": {
    "type": "text/javascript; charset=utf-8",
    "encoding": "gzip",
    "etag": "\"841-6zE6W2eQm2QX4Q28XLrIQiqlqaQ\"",
    "mtime": "2025-04-13T20:04:28.242Z",
    "size": 2113,
    "path": "../public/app-assets/vendors/js/pagination/jquery.twbsPagination.min.js.gz"
  },
  "/app-assets/css/core/menu/menu-types/vertical-menu.min.css": {
    "type": "text/css; charset=utf-8",
    "etag": "\"3675-UvcTTDBFESFMlRFXvkcdcSQY7rw\"",
    "mtime": "2025-04-13T20:04:20.317Z",
    "size": 13941,
    "path": "../public/app-assets/css/core/menu/menu-types/vertical-menu.min.css"
  },
  "/app-assets/css/core/menu/menu-types/vertical-menu.min.css.br": {
    "type": "text/css; charset=utf-8",
    "encoding": "br",
    "etag": "\"59f-UDP7UJvT+Sp0j9KxrRGKtLHeDrY\"",
    "mtime": "2025-04-13T20:04:28.243Z",
    "size": 1439,
    "path": "../public/app-assets/css/core/menu/menu-types/vertical-menu.min.css.br"
  },
  "/app-assets/css/core/menu/menu-types/vertical-menu.min.css.gz": {
    "type": "text/css; charset=utf-8",
    "encoding": "gzip",
    "etag": "\"690-q+ro8PVP8tf5ZTPMjWE7s1MmprE\"",
    "mtime": "2025-04-13T20:04:28.243Z",
    "size": 1680,
    "path": "../public/app-assets/css/core/menu/menu-types/vertical-menu.min.css.gz"
  },
  "/app-assets/vendors/js/ui/prism.min.js": {
    "type": "text/javascript; charset=utf-8",
    "etag": "\"9c6a-qPIfDaYquGKRc2kTPDAbogr4Mtc\"",
    "mtime": "2025-04-13T20:04:20.328Z",
    "size": 40042,
    "path": "../public/app-assets/vendors/js/ui/prism.min.js"
  },
  "/app-assets/vendors/js/ui/prism.min.js.br": {
    "type": "text/javascript; charset=utf-8",
    "encoding": "br",
    "etag": "\"31f2-Z2tQ9QfATM4jkQA3qkeEycZzoHs\"",
    "mtime": "2025-04-13T20:04:28.242Z",
    "size": 12786,
    "path": "../public/app-assets/vendors/js/ui/prism.min.js.br"
  },
  "/app-assets/vendors/js/ui/prism.min.js.gz": {
    "type": "text/javascript; charset=utf-8",
    "encoding": "gzip",
    "etag": "\"38cc-p+QL1+w6AwIsjjbneFrIljWW7ms\"",
    "mtime": "2025-04-13T20:04:28.242Z",
    "size": 14540,
    "path": "../public/app-assets/vendors/js/ui/prism.min.js.gz"
  },
  "/app-assets/css/plugins/forms/validation/form-validation.css": {
    "type": "text/css; charset=utf-8",
    "etag": "\"3cf-akXLOXLQtoBHvb26d+fzt8GKhLw\"",
    "mtime": "2025-04-13T20:04:20.317Z",
    "size": 975,
    "path": "../public/app-assets/css/plugins/forms/validation/form-validation.css"
  },
  "/app-assets/js/scripts/charts/gmaps/maps.min.js": {
    "type": "text/javascript; charset=utf-8",
    "etag": "\"429-aBG2xSBw21OcaUb+iD+MR1+iRAo\"",
    "mtime": "2025-04-13T20:04:20.318Z",
    "size": 1065,
    "path": "../public/app-assets/js/scripts/charts/gmaps/maps.min.js"
  },
  "/app-assets/js/scripts/charts/gmaps/maps.min.js.br": {
    "type": "text/javascript; charset=utf-8",
    "encoding": "br",
    "etag": "\"143-Wqhyz45ESwpSjC8yN9HE7nnmhyE\"",
    "mtime": "2025-04-13T20:04:28.570Z",
    "size": 323,
    "path": "../public/app-assets/js/scripts/charts/gmaps/maps.min.js.br"
  },
  "/app-assets/js/scripts/charts/gmaps/maps.min.js.gz": {
    "type": "text/javascript; charset=utf-8",
    "encoding": "gzip",
    "etag": "\"170-0lTVXlcDd+5Spdjqz0n2rVO+Tl8\"",
    "mtime": "2025-04-13T20:04:28.570Z",
    "size": 368,
    "path": "../public/app-assets/js/scripts/charts/gmaps/maps.min.js.gz"
  },
  "/app-assets/fonts/flag-icon-css/flags/1x1/ad.svg": {
    "type": "image/svg+xml",
    "etag": "\"e5ca-AOmB6VjVNUmXDZzGRmYHuXMCs6o\"",
    "mtime": "2025-04-13T20:04:20.320Z",
    "size": 58826,
    "path": "../public/app-assets/fonts/flag-icon-css/flags/1x1/ad.svg"
  },
  "/app-assets/fonts/flag-icon-css/flags/1x1/ad.svg.br": {
    "type": "image/svg+xml",
    "encoding": "br",
    "etag": "\"4bfd-a4/TWV1VhHXyRP1nqUXtOVA37Mk\"",
    "mtime": "2025-04-13T20:04:28.622Z",
    "size": 19453,
    "path": "../public/app-assets/fonts/flag-icon-css/flags/1x1/ad.svg.br"
  },
  "/app-assets/fonts/flag-icon-css/flags/1x1/ad.svg.gz": {
    "type": "image/svg+xml",
    "encoding": "gzip",
    "etag": "\"58f0-Y9GpY3/PtywGv0aBziu/kvIjJ0U\"",
    "mtime": "2025-04-13T20:04:28.622Z",
    "size": 22768,
    "path": "../public/app-assets/fonts/flag-icon-css/flags/1x1/ad.svg.gz"
  },
  "/app-assets/fonts/flag-icon-css/flags/1x1/ae.svg": {
    "type": "image/svg+xml",
    "etag": "\"175-PGwOOLptvPYKEERfZlMTcJDgZiw\"",
    "mtime": "2025-04-13T20:04:20.379Z",
    "size": 373,
    "path": "../public/app-assets/fonts/flag-icon-css/flags/1x1/ae.svg"
  },
  "/app-assets/fonts/flag-icon-css/flags/1x1/af.svg": {
    "type": "image/svg+xml",
    "etag": "\"16417-oJCy2nk6gDjK5rFwlcA5OrPSq3U\"",
    "mtime": "2025-04-13T20:04:20.381Z",
    "size": 91159,
    "path": "../public/app-assets/fonts/flag-icon-css/flags/1x1/af.svg"
  },
  "/app-assets/fonts/flag-icon-css/flags/1x1/af.svg.br": {
    "type": "image/svg+xml",
    "encoding": "br",
    "etag": "\"4a68-F8zuQj7H8qiRnjsp39ur6ljjktU\"",
    "mtime": "2025-04-13T20:04:28.622Z",
    "size": 19048,
    "path": "../public/app-assets/fonts/flag-icon-css/flags/1x1/af.svg.br"
  },
  "/app-assets/fonts/flag-icon-css/flags/1x1/af.svg.gz": {
    "type": "image/svg+xml",
    "encoding": "gzip",
    "etag": "\"5c02-lMAQbzZhztbDKmHRQ2amPJrtI9M\"",
    "mtime": "2025-04-13T20:04:28.622Z",
    "size": 23554,
    "path": "../public/app-assets/fonts/flag-icon-css/flags/1x1/af.svg.gz"
  },
  "/app-assets/fonts/flag-icon-css/flags/1x1/ag.svg": {
    "type": "image/svg+xml",
    "etag": "\"380-7tkrDWkzxylqqzsLsvRzn1JcCWw\"",
    "mtime": "2025-04-13T20:04:20.380Z",
    "size": 896,
    "path": "../public/app-assets/fonts/flag-icon-css/flags/1x1/ag.svg"
  },
  "/app-assets/fonts/flag-icon-css/flags/1x1/ai.svg": {
    "type": "image/svg+xml",
    "etag": "\"ea40-J1Av4dWgvuYL9XozjKn2yW2lUq0\"",
    "mtime": "2025-04-13T20:04:20.380Z",
    "size": 59968,
    "path": "../public/app-assets/fonts/flag-icon-css/flags/1x1/ai.svg"
  },
  "/app-assets/fonts/flag-icon-css/flags/1x1/ai.svg.br": {
    "type": "image/svg+xml",
    "encoding": "br",
    "etag": "\"1d1f-KIizFyY4NEGkZfSmhdc+P3jW0Mo\"",
    "mtime": "2025-04-13T20:04:28.556Z",
    "size": 7455,
    "path": "../public/app-assets/fonts/flag-icon-css/flags/1x1/ai.svg.br"
  },
  "/app-assets/fonts/flag-icon-css/flags/1x1/ai.svg.gz": {
    "type": "image/svg+xml",
    "encoding": "gzip",
    "etag": "\"2222-+3148m0wdKZr0C8bgDA8S1oZZpU\"",
    "mtime": "2025-04-13T20:04:28.557Z",
    "size": 8738,
    "path": "../public/app-assets/fonts/flag-icon-css/flags/1x1/ai.svg.gz"
  },
  "/app-assets/fonts/flag-icon-css/flags/1x1/al.svg": {
    "type": "image/svg+xml",
    "etag": "\"1316-39s02BywnsXKf6Xf8twBiPZzSNY\"",
    "mtime": "2025-04-13T20:04:20.383Z",
    "size": 4886,
    "path": "../public/app-assets/fonts/flag-icon-css/flags/1x1/al.svg"
  },
  "/app-assets/fonts/flag-icon-css/flags/1x1/al.svg.br": {
    "type": "image/svg+xml",
    "encoding": "br",
    "etag": "\"813-8ziePLmv+yddnmNWAB/5H6ubyZ4\"",
    "mtime": "2025-04-13T20:04:28.556Z",
    "size": 2067,
    "path": "../public/app-assets/fonts/flag-icon-css/flags/1x1/al.svg.br"
  },
  "/app-assets/fonts/flag-icon-css/flags/1x1/al.svg.gz": {
    "type": "image/svg+xml",
    "encoding": "gzip",
    "etag": "\"93a-H1XVJia3KXzDPusIuTxKeaMiu/Q\"",
    "mtime": "2025-04-13T20:04:28.556Z",
    "size": 2362,
    "path": "../public/app-assets/fonts/flag-icon-css/flags/1x1/al.svg.gz"
  },
  "/app-assets/fonts/flag-icon-css/flags/1x1/am.svg": {
    "type": "image/svg+xml",
    "etag": "\"14c-vu7Iv73/gV7fhAaUPLfl4NojIX8\"",
    "mtime": "2025-04-13T20:04:20.383Z",
    "size": 332,
    "path": "../public/app-assets/fonts/flag-icon-css/flags/1x1/am.svg"
  },
  "/app-assets/fonts/flag-icon-css/flags/1x1/ao.svg": {
    "type": "image/svg+xml",
    "etag": "\"8f6-0q7rhzZrrzb7JEN/ssiYbduW7hc\"",
    "mtime": "2025-04-13T20:04:20.380Z",
    "size": 2294,
    "path": "../public/app-assets/fonts/flag-icon-css/flags/1x1/ao.svg"
  },
  "/app-assets/fonts/flag-icon-css/flags/1x1/ao.svg.br": {
    "type": "image/svg+xml",
    "encoding": "br",
    "etag": "\"39b-Hw3P/gFslnU+olC0HMJYvlASklU\"",
    "mtime": "2025-04-13T20:04:28.556Z",
    "size": 923,
    "path": "../public/app-assets/fonts/flag-icon-css/flags/1x1/ao.svg.br"
  },
  "/app-assets/fonts/flag-icon-css/flags/1x1/ao.svg.gz": {
    "type": "image/svg+xml",
    "encoding": "gzip",
    "etag": "\"422-5kd9qodPE2hXHD4v6FKfGdvPX9o\"",
    "mtime": "2025-04-13T20:04:28.556Z",
    "size": 1058,
    "path": "../public/app-assets/fonts/flag-icon-css/flags/1x1/ao.svg.gz"
  },
  "/app-assets/fonts/flag-icon-css/flags/1x1/aq.svg": {
    "type": "image/svg+xml",
    "etag": "\"122c-mvUjEuqBfVUvojlq0JgtBUgalEA\"",
    "mtime": "2025-04-13T20:04:20.382Z",
    "size": 4652,
    "path": "../public/app-assets/fonts/flag-icon-css/flags/1x1/aq.svg"
  },
  "/app-assets/fonts/flag-icon-css/flags/1x1/aq.svg.br": {
    "type": "image/svg+xml",
    "encoding": "br",
    "etag": "\"79c-PDNLvrv6neSZriTz3Kv7KUp2rDU\"",
    "mtime": "2025-04-13T20:04:28.556Z",
    "size": 1948,
    "path": "../public/app-assets/fonts/flag-icon-css/flags/1x1/aq.svg.br"
  },
  "/app-assets/fonts/flag-icon-css/flags/1x1/aq.svg.gz": {
    "type": "image/svg+xml",
    "encoding": "gzip",
    "etag": "\"86f-fkovjvWYSDqAIQeC+gSeyC++WhE\"",
    "mtime": "2025-04-13T20:04:28.556Z",
    "size": 2159,
    "path": "../public/app-assets/fonts/flag-icon-css/flags/1x1/aq.svg.gz"
  },
  "/app-assets/fonts/flag-icon-css/flags/1x1/ar.svg": {
    "type": "image/svg+xml",
    "etag": "\"85fd-2XYnaU77a0TEXfDsqq9LnXpmxNM\"",
    "mtime": "2025-04-13T20:04:20.381Z",
    "size": 34301,
    "path": "../public/app-assets/fonts/flag-icon-css/flags/1x1/ar.svg"
  },
  "/app-assets/fonts/flag-icon-css/flags/1x1/ar.svg.br": {
    "type": "image/svg+xml",
    "encoding": "br",
    "etag": "\"901-e+Wy3bpuEDo8Yegwyn7V6bnLc58\"",
    "mtime": "2025-04-13T20:04:28.556Z",
    "size": 2305,
    "path": "../public/app-assets/fonts/flag-icon-css/flags/1x1/ar.svg.br"
  },
  "/app-assets/fonts/flag-icon-css/flags/1x1/ar.svg.gz": {
    "type": "image/svg+xml",
    "encoding": "gzip",
    "etag": "\"adc-lPQzGCrTYJCeClIZXFY2EpqbsKg\"",
    "mtime": "2025-04-13T20:04:28.556Z",
    "size": 2780,
    "path": "../public/app-assets/fonts/flag-icon-css/flags/1x1/ar.svg.gz"
  },
  "/app-assets/fonts/flag-icon-css/flags/1x1/as.svg": {
    "type": "image/svg+xml",
    "etag": "\"2e39-qtaMF5O/P6sKKfZ0xR68PEKuTQI\"",
    "mtime": "2025-04-13T20:04:20.381Z",
    "size": 11833,
    "path": "../public/app-assets/fonts/flag-icon-css/flags/1x1/as.svg"
  },
  "/app-assets/fonts/flag-icon-css/flags/1x1/as.svg.br": {
    "type": "image/svg+xml",
    "encoding": "br",
    "etag": "\"10de-C6L0MojmrpXYslAClPQ8tAOt/yo\"",
    "mtime": "2025-04-13T20:04:28.556Z",
    "size": 4318,
    "path": "../public/app-assets/fonts/flag-icon-css/flags/1x1/as.svg.br"
  },
  "/app-assets/fonts/flag-icon-css/flags/1x1/as.svg.gz": {
    "type": "image/svg+xml",
    "encoding": "gzip",
    "etag": "\"1244-Qvr0T1cIncyN56l6B7OrtF5XDt4\"",
    "mtime": "2025-04-13T20:04:28.556Z",
    "size": 4676,
    "path": "../public/app-assets/fonts/flag-icon-css/flags/1x1/as.svg.gz"
  },
  "/app-assets/fonts/flag-icon-css/flags/1x1/at.svg": {
    "type": "image/svg+xml",
    "etag": "\"126-F10QPI63J8yC0SslcSbOa7D756M\"",
    "mtime": "2025-04-13T20:04:20.385Z",
    "size": 294,
    "path": "../public/app-assets/fonts/flag-icon-css/flags/1x1/at.svg"
  },
  "/app-assets/fonts/flag-icon-css/flags/1x1/au.svg": {
    "type": "image/svg+xml",
    "etag": "\"73a-dqQXhVR9KUM8V+aMTb7LGTZNXl4\"",
    "mtime": "2025-04-13T20:04:20.385Z",
    "size": 1850,
    "path": "../public/app-assets/fonts/flag-icon-css/flags/1x1/au.svg"
  },
  "/app-assets/fonts/flag-icon-css/flags/1x1/au.svg.br": {
    "type": "image/svg+xml",
    "encoding": "br",
    "etag": "\"2a6-HLQ4Ir12ZnHGfKpim8kUaQnNkCg\"",
    "mtime": "2025-04-13T20:04:28.556Z",
    "size": 678,
    "path": "../public/app-assets/fonts/flag-icon-css/flags/1x1/au.svg.br"
  },
  "/app-assets/fonts/flag-icon-css/flags/1x1/au.svg.gz": {
    "type": "image/svg+xml",
    "encoding": "gzip",
    "etag": "\"2f5-Zk/YZ8zYYzzkCkQu7Sp1GGm7S3o\"",
    "mtime": "2025-04-13T20:04:28.556Z",
    "size": 757,
    "path": "../public/app-assets/fonts/flag-icon-css/flags/1x1/au.svg.gz"
  },
  "/app-assets/fonts/flag-icon-css/flags/1x1/aw.svg": {
    "type": "image/svg+xml",
    "etag": "\"3936-scNAuUgDcfkrxxm64Z9Jun3pLBo\"",
    "mtime": "2025-04-13T20:04:20.383Z",
    "size": 14646,
    "path": "../public/app-assets/fonts/flag-icon-css/flags/1x1/aw.svg"
  },
  "/app-assets/fonts/flag-icon-css/flags/1x1/aw.svg.br": {
    "type": "image/svg+xml",
    "encoding": "br",
    "etag": "\"6e0-p6KuoIRG5PARsOmAFSobB15a+fQ\"",
    "mtime": "2025-04-13T20:04:28.556Z",
    "size": 1760,
    "path": "../public/app-assets/fonts/flag-icon-css/flags/1x1/aw.svg.br"
  },
  "/app-assets/fonts/flag-icon-css/flags/1x1/aw.svg.gz": {
    "type": "image/svg+xml",
    "encoding": "gzip",
    "etag": "\"841-NdbfBKCPDsOLHpOSZkj84MKBN/c\"",
    "mtime": "2025-04-13T20:04:28.556Z",
    "size": 2113,
    "path": "../public/app-assets/fonts/flag-icon-css/flags/1x1/aw.svg.gz"
  },
  "/app-assets/fonts/flag-icon-css/flags/1x1/ax.svg": {
    "type": "image/svg+xml",
    "etag": "\"248-oFtG+yU41LS4afZKjoIcqgmC1Zo\"",
    "mtime": "2025-04-13T20:04:20.384Z",
    "size": 584,
    "path": "../public/app-assets/fonts/flag-icon-css/flags/1x1/ax.svg"
  },
  "/app-assets/fonts/flag-icon-css/flags/1x1/az.svg": {
    "type": "image/svg+xml",
    "etag": "\"24d-MSd4NU5Dz5UVT3sHIDI6dSIg6F8\"",
    "mtime": "2025-04-13T20:04:20.384Z",
    "size": 589,
    "path": "../public/app-assets/fonts/flag-icon-css/flags/1x1/az.svg"
  },
  "/app-assets/fonts/flag-icon-css/flags/1x1/ba.svg": {
    "type": "image/svg+xml",
    "etag": "\"628-qBbTjKfvJhKTbMlYZhCQNuvNPxE\"",
    "mtime": "2025-04-13T20:04:20.386Z",
    "size": 1576,
    "path": "../public/app-assets/fonts/flag-icon-css/flags/1x1/ba.svg"
  },
  "/app-assets/fonts/flag-icon-css/flags/1x1/ba.svg.br": {
    "type": "image/svg+xml",
    "encoding": "br",
    "etag": "\"1e1-pULxwzA6BS7wWogpe+vqLPls6Y0\"",
    "mtime": "2025-04-13T20:04:28.556Z",
    "size": 481,
    "path": "../public/app-assets/fonts/flag-icon-css/flags/1x1/ba.svg.br"
  },
  "/app-assets/fonts/flag-icon-css/flags/1x1/ba.svg.gz": {
    "type": "image/svg+xml",
    "encoding": "gzip",
    "etag": "\"236-aGVf/IVxDyG5fW44yfCL6/REfp8\"",
    "mtime": "2025-04-13T20:04:28.556Z",
    "size": 566,
    "path": "../public/app-assets/fonts/flag-icon-css/flags/1x1/ba.svg.gz"
  },
  "/app-assets/fonts/flag-icon-css/flags/1x1/bb.svg": {
    "type": "image/svg+xml",
    "etag": "\"2e5-Za6Z+Q1+3Pyv7DsypY2I9aH0TeM\"",
    "mtime": "2025-04-13T20:04:20.385Z",
    "size": 741,
    "path": "../public/app-assets/fonts/flag-icon-css/flags/1x1/bb.svg"
  },
  "/app-assets/fonts/flag-icon-css/flags/1x1/bd.svg": {
    "type": "image/svg+xml",
    "etag": "\"16c-XSVeHnf5FPD0gv4M2ILZqFpD8YY\"",
    "mtime": "2025-04-13T20:04:20.384Z",
    "size": 364,
    "path": "../public/app-assets/fonts/flag-icon-css/flags/1x1/bd.svg"
  },
  "/app-assets/fonts/flag-icon-css/flags/1x1/be.svg": {
    "type": "image/svg+xml",
    "etag": "\"15f-p2h2SLLjFW/2oS11XS7ICFWmQ28\"",
    "mtime": "2025-04-13T20:04:20.385Z",
    "size": 351,
    "path": "../public/app-assets/fonts/flag-icon-css/flags/1x1/be.svg"
  },
  "/app-assets/fonts/flag-icon-css/flags/1x1/bf.svg": {
    "type": "image/svg+xml",
    "etag": "\"1ec-Zwi9DfENlgZwexDPKTie62a6kUk\"",
    "mtime": "2025-04-13T20:04:20.457Z",
    "size": 492,
    "path": "../public/app-assets/fonts/flag-icon-css/flags/1x1/bf.svg"
  },
  "/app-assets/fonts/flag-icon-css/flags/1x1/bg.svg": {
    "type": "image/svg+xml",
    "etag": "\"156-pQ93tPJr4ZV1Thoi9vP8s4g4Xws\"",
    "mtime": "2025-04-13T20:04:20.390Z",
    "size": 342,
    "path": "../public/app-assets/fonts/flag-icon-css/flags/1x1/bg.svg"
  },
  "/app-assets/fonts/flag-icon-css/flags/1x1/bh.svg": {
    "type": "image/svg+xml",
    "etag": "\"2d2-IjRgP8idyj4QMQzsK2QkJNGqnWw\"",
    "mtime": "2025-04-13T20:04:20.385Z",
    "size": 722,
    "path": "../public/app-assets/fonts/flag-icon-css/flags/1x1/bh.svg"
  },
  "/app-assets/fonts/flag-icon-css/flags/1x1/bi.svg": {
    "type": "image/svg+xml",
    "etag": "\"509-owsGtJF/pALsUKmbUNVpYXusXOc\"",
    "mtime": "2025-04-13T20:04:20.385Z",
    "size": 1289,
    "path": "../public/app-assets/fonts/flag-icon-css/flags/1x1/bi.svg"
  },
  "/app-assets/fonts/flag-icon-css/flags/1x1/bi.svg.br": {
    "type": "image/svg+xml",
    "encoding": "br",
    "etag": "\"1e5-zc9XQmPG+uQS5QVzZBIOCkIl4yU\"",
    "mtime": "2025-04-13T20:04:28.556Z",
    "size": 485,
    "path": "../public/app-assets/fonts/flag-icon-css/flags/1x1/bi.svg.br"
  },
  "/app-assets/fonts/flag-icon-css/flags/1x1/bi.svg.gz": {
    "type": "image/svg+xml",
    "encoding": "gzip",
    "etag": "\"22d-gkoQ8endk3PMRMWL4Fn/jK+Rr+U\"",
    "mtime": "2025-04-13T20:04:28.556Z",
    "size": 557,
    "path": "../public/app-assets/fonts/flag-icon-css/flags/1x1/bi.svg.gz"
  },
  "/app-assets/fonts/flag-icon-css/flags/1x1/bj.svg": {
    "type": "image/svg+xml",
    "etag": "\"219-TapBmQiI/u3ApckmLcueehRWg3w\"",
    "mtime": "2025-04-13T20:04:20.386Z",
    "size": 537,
    "path": "../public/app-assets/fonts/flag-icon-css/flags/1x1/bj.svg"
  },
  "/app-assets/fonts/flag-icon-css/flags/1x1/bl.svg": {
    "type": "image/svg+xml",
    "etag": "\"15e-/3adX/bPUe6gJeTGtF9TqFeg83c\"",
    "mtime": "2025-04-13T20:04:20.385Z",
    "size": 350,
    "path": "../public/app-assets/fonts/flag-icon-css/flags/1x1/bl.svg"
  },
  "/app-assets/fonts/flag-icon-css/flags/1x1/bm.svg": {
    "type": "image/svg+xml",
    "etag": "\"7b83-UMBzBXUf3kEttYIE7fsUPdw6rfw\"",
    "mtime": "2025-04-13T20:04:20.386Z",
    "size": 31619,
    "path": "../public/app-assets/fonts/flag-icon-css/flags/1x1/bm.svg"
  },
  "/app-assets/fonts/flag-icon-css/flags/1x1/bm.svg.br": {
    "type": "image/svg+xml",
    "encoding": "br",
    "etag": "\"2439-Y/SstDnT0CulAPQO8wqe6EyAHyE\"",
    "mtime": "2025-04-13T20:04:28.557Z",
    "size": 9273,
    "path": "../public/app-assets/fonts/flag-icon-css/flags/1x1/bm.svg.br"
  },
  "/app-assets/fonts/flag-icon-css/flags/1x1/bm.svg.gz": {
    "type": "image/svg+xml",
    "encoding": "gzip",
    "etag": "\"2c1a-gNhXXi990x0+FL0i5QDtLxgrsnU\"",
    "mtime": "2025-04-13T20:04:28.556Z",
    "size": 11290,
    "path": "../public/app-assets/fonts/flag-icon-css/flags/1x1/bm.svg.gz"
  },
  "/app-assets/fonts/flag-icon-css/flags/1x1/bn.svg": {
    "type": "image/svg+xml",
    "etag": "\"5880-PvwKD2YVf7CefxckpcI75hkaW+Q\"",
    "mtime": "2025-04-13T20:04:20.387Z",
    "size": 22656,
    "path": "../public/app-assets/fonts/flag-icon-css/flags/1x1/bn.svg"
  },
  "/app-assets/fonts/flag-icon-css/flags/1x1/bn.svg.br": {
    "type": "image/svg+xml",
    "encoding": "br",
    "etag": "\"1b16-1gbNHVDocjYezQ7LvvL8pd25VJ8\"",
    "mtime": "2025-04-13T20:04:28.556Z",
    "size": 6934,
    "path": "../public/app-assets/fonts/flag-icon-css/flags/1x1/bn.svg.br"
  },
  "/app-assets/fonts/flag-icon-css/flags/1x1/bn.svg.gz": {
    "type": "image/svg+xml",
    "encoding": "gzip",
    "etag": "\"1f3f-LG7V/Qj1XzZJIRCJbo8y4/6Ovv4\"",
    "mtime": "2025-04-13T20:04:28.556Z",
    "size": 7999,
    "path": "../public/app-assets/fonts/flag-icon-css/flags/1x1/bn.svg.gz"
  },
  "/app-assets/fonts/flag-icon-css/flags/1x1/bo.svg": {
    "type": "image/svg+xml",
    "etag": "\"140-u5Axogyl24XTuL7GXogAuE83Fh0\"",
    "mtime": "2025-04-13T20:04:20.387Z",
    "size": 320,
    "path": "../public/app-assets/fonts/flag-icon-css/flags/1x1/bo.svg"
  },
  "/app-assets/fonts/flag-icon-css/flags/1x1/bq.svg": {
    "type": "image/svg+xml",
    "etag": "\"124-4y/lFsyZN9OWoQ43jNJuNu9WZ2Q\"",
    "mtime": "2025-04-13T20:04:20.386Z",
    "size": 292,
    "path": "../public/app-assets/fonts/flag-icon-css/flags/1x1/bq.svg"
  },
  "/app-assets/fonts/flag-icon-css/flags/1x1/br.svg": {
    "type": "image/svg+xml",
    "etag": "\"3003-+1gtLgAI5lMqhb0afeeJaCUsqFs\"",
    "mtime": "2025-04-13T20:04:20.387Z",
    "size": 12291,
    "path": "../public/app-assets/fonts/flag-icon-css/flags/1x1/br.svg"
  },
  "/app-assets/fonts/flag-icon-css/flags/1x1/br.svg.br": {
    "type": "image/svg+xml",
    "encoding": "br",
    "etag": "\"1081-CGpqZPUadm0f4cTpsgPRg0mgzTk\"",
    "mtime": "2025-04-13T20:04:28.557Z",
    "size": 4225,
    "path": "../public/app-assets/fonts/flag-icon-css/flags/1x1/br.svg.br"
  },
  "/app-assets/fonts/flag-icon-css/flags/1x1/br.svg.gz": {
    "type": "image/svg+xml",
    "encoding": "gzip",
    "etag": "\"1309-O+YZ0nnIvxWj0AJwXp3D018chcg\"",
    "mtime": "2025-04-13T20:04:28.556Z",
    "size": 4873,
    "path": "../public/app-assets/fonts/flag-icon-css/flags/1x1/br.svg.gz"
  },
  "/app-assets/fonts/flag-icon-css/flags/1x1/bs.svg": {
    "type": "image/svg+xml",
    "etag": "\"2b8-LKZpmYztvUhXynDA1zj5DHIeQDw\"",
    "mtime": "2025-04-13T20:04:20.386Z",
    "size": 696,
    "path": "../public/app-assets/fonts/flag-icon-css/flags/1x1/bs.svg"
  },
  "/app-assets/fonts/flag-icon-css/flags/1x1/bt.svg": {
    "type": "image/svg+xml",
    "etag": "\"15e3a-EPO4XhNLyv+qO5GvYgz1JCAIrbQ\"",
    "mtime": "2025-04-13T20:04:20.387Z",
    "size": 89658,
    "path": "../public/app-assets/fonts/flag-icon-css/flags/1x1/bt.svg"
  },
  "/app-assets/fonts/flag-icon-css/flags/1x1/bt.svg.br": {
    "type": "image/svg+xml",
    "encoding": "br",
    "etag": "\"75e4-SaeqgASWlaof4UQVD6EDtBlq4IU\"",
    "mtime": "2025-04-13T20:04:28.623Z",
    "size": 30180,
    "path": "../public/app-assets/fonts/flag-icon-css/flags/1x1/bt.svg.br"
  },
  "/app-assets/fonts/flag-icon-css/flags/1x1/bt.svg.gz": {
    "type": "image/svg+xml",
    "encoding": "gzip",
    "etag": "\"8190-a9VTQTxsSEFpb8zPsluLAD5Mp2c\"",
    "mtime": "2025-04-13T20:04:28.667Z",
    "size": 33168,
    "path": "../public/app-assets/fonts/flag-icon-css/flags/1x1/bt.svg.gz"
  },
  "/app-assets/fonts/flag-icon-css/flags/1x1/bv.svg": {
    "type": "image/svg+xml",
    "etag": "\"2a8-SGratZS78aGSXlzVt1hwVT7n0gw\"",
    "mtime": "2025-04-13T20:04:20.386Z",
    "size": 680,
    "path": "../public/app-assets/fonts/flag-icon-css/flags/1x1/bv.svg"
  },
  "/app-assets/fonts/flag-icon-css/flags/1x1/bw.svg": {
    "type": "image/svg+xml",
    "etag": "\"13e-UH/WXhFhfYWz0/tTY9cpVZoXkcA\"",
    "mtime": "2025-04-13T20:04:20.387Z",
    "size": 318,
    "path": "../public/app-assets/fonts/flag-icon-css/flags/1x1/bw.svg"
  },
  "/app-assets/fonts/flag-icon-css/flags/1x1/by.svg": {
    "type": "image/svg+xml",
    "etag": "\"24db-S6QCE3+mfBI/lf9rtVUvv9RVn8c\"",
    "mtime": "2025-04-13T20:04:20.388Z",
    "size": 9435,
    "path": "../public/app-assets/fonts/flag-icon-css/flags/1x1/by.svg"
  },
  "/app-assets/fonts/flag-icon-css/flags/1x1/by.svg.br": {
    "type": "image/svg+xml",
    "encoding": "br",
    "etag": "\"6ea-GooAAbL99n9L3zT8U5iQvP74lKE\"",
    "mtime": "2025-04-13T20:04:28.557Z",
    "size": 1770,
    "path": "../public/app-assets/fonts/flag-icon-css/flags/1x1/by.svg.br"
  },
  "/app-assets/fonts/flag-icon-css/flags/1x1/by.svg.gz": {
    "type": "image/svg+xml",
    "encoding": "gzip",
    "etag": "\"83e-IfQu+zMhGV2lIfVEB7zzI8C0uvk\"",
    "mtime": "2025-04-13T20:04:28.556Z",
    "size": 2110,
    "path": "../public/app-assets/fonts/flag-icon-css/flags/1x1/by.svg.gz"
  },
  "/app-assets/fonts/flag-icon-css/flags/1x1/bz.svg": {
    "type": "image/svg+xml",
    "etag": "\"d7d3-PB+U7AwgSBuXTvmbMWA2sVe5Gco\"",
    "mtime": "2025-04-13T20:04:20.388Z",
    "size": 55251,
    "path": "../public/app-assets/fonts/flag-icon-css/flags/1x1/bz.svg"
  },
  "/app-assets/fonts/flag-icon-css/flags/1x1/bz.svg.br": {
    "type": "image/svg+xml",
    "encoding": "br",
    "etag": "\"3056-GRSIb8hSBENMeDoCGIz8j6clbQA\"",
    "mtime": "2025-04-13T20:04:28.557Z",
    "size": 12374,
    "path": "../public/app-assets/fonts/flag-icon-css/flags/1x1/bz.svg.br"
  },
  "/app-assets/fonts/flag-icon-css/flags/1x1/bz.svg.gz": {
    "type": "image/svg+xml",
    "encoding": "gzip",
    "etag": "\"3848-zJ/PmWEMSrcGhb8eCs5dF7CiRbo\"",
    "mtime": "2025-04-13T20:04:28.557Z",
    "size": 14408,
    "path": "../public/app-assets/fonts/flag-icon-css/flags/1x1/bz.svg.gz"
  },
  "/app-assets/fonts/flag-icon-css/flags/1x1/ca.svg": {
    "type": "image/svg+xml",
    "etag": "\"45e-lb/rZHtYsl3s27wuE+1DfsexwQs\"",
    "mtime": "2025-04-13T20:04:20.387Z",
    "size": 1118,
    "path": "../public/app-assets/fonts/flag-icon-css/flags/1x1/ca.svg"
  },
  "/app-assets/fonts/flag-icon-css/flags/1x1/ca.svg.br": {
    "type": "image/svg+xml",
    "encoding": "br",
    "etag": "\"241-lB1PIOHleVn7qBsHifoQTs22oXg\"",
    "mtime": "2025-04-13T20:04:28.557Z",
    "size": 577,
    "path": "../public/app-assets/fonts/flag-icon-css/flags/1x1/ca.svg.br"
  },
  "/app-assets/fonts/flag-icon-css/flags/1x1/ca.svg.gz": {
    "type": "image/svg+xml",
    "encoding": "gzip",
    "etag": "\"2a1-A88CuFoyJdxEmmBe5LVA2RS4kMg\"",
    "mtime": "2025-04-13T20:04:28.557Z",
    "size": 673,
    "path": "../public/app-assets/fonts/flag-icon-css/flags/1x1/ca.svg.gz"
  },
  "/app-assets/fonts/flag-icon-css/flags/1x1/cc.svg": {
    "type": "image/svg+xml",
    "etag": "\"10e1-gH3r+q8WEVhB3+fyohF3x4rHmyQ\"",
    "mtime": "2025-04-13T20:04:20.388Z",
    "size": 4321,
    "path": "../public/app-assets/fonts/flag-icon-css/flags/1x1/cc.svg"
  },
  "/app-assets/fonts/flag-icon-css/flags/1x1/cc.svg.br": {
    "type": "image/svg+xml",
    "encoding": "br",
    "etag": "\"6cb-EG1a8iOv8YDe9MI+hRuJh6kU7gs\"",
    "mtime": "2025-04-13T20:04:28.557Z",
    "size": 1739,
    "path": "../public/app-assets/fonts/flag-icon-css/flags/1x1/cc.svg.br"
  },
  "/app-assets/fonts/flag-icon-css/flags/1x1/cc.svg.gz": {
    "type": "image/svg+xml",
    "encoding": "gzip",
    "etag": "\"7c7-1mUlZdDZ73FMdjaHQ0Thu/CQ6do\"",
    "mtime": "2025-04-13T20:04:28.557Z",
    "size": 1991,
    "path": "../public/app-assets/fonts/flag-icon-css/flags/1x1/cc.svg.gz"
  },
  "/app-assets/fonts/flag-icon-css/flags/1x1/cd.svg": {
    "type": "image/svg+xml",
    "etag": "\"221-IOF/mp/hY7o4dL9/Pe1PPFMqAV0\"",
    "mtime": "2025-04-13T20:04:20.387Z",
    "size": 545,
    "path": "../public/app-assets/fonts/flag-icon-css/flags/1x1/cd.svg"
  },
  "/app-assets/fonts/flag-icon-css/flags/1x1/cf.svg": {
    "type": "image/svg+xml",
    "etag": "\"2c8-kL6dQMCX6ZezxuLgq19DdIUvkRY\"",
    "mtime": "2025-04-13T20:04:20.388Z",
    "size": 712,
    "path": "../public/app-assets/fonts/flag-icon-css/flags/1x1/cf.svg"
  },
  "/app-assets/fonts/flag-icon-css/flags/1x1/cg.svg": {
    "type": "image/svg+xml",
    "etag": "\"21c-HYjRjxLLoEJNRhWaTVnM90InFk0\"",
    "mtime": "2025-04-13T20:04:20.388Z",
    "size": 540,
    "path": "../public/app-assets/fonts/flag-icon-css/flags/1x1/cg.svg"
  },
  "/app-assets/fonts/flag-icon-css/flags/1x1/ch.svg": {
    "type": "image/svg+xml",
    "etag": "\"183-LprviIrtSxZ1Uw5C1FFhVY2OEII\"",
    "mtime": "2025-04-13T20:04:20.388Z",
    "size": 387,
    "path": "../public/app-assets/fonts/flag-icon-css/flags/1x1/ch.svg"
  },
  "/app-assets/fonts/flag-icon-css/flags/1x1/ci.svg": {
    "type": "image/svg+xml",
    "etag": "\"152-GDC694iGVCRyFSU5gUm9Giam8S0\"",
    "mtime": "2025-04-13T20:04:20.388Z",
    "size": 338,
    "path": "../public/app-assets/fonts/flag-icon-css/flags/1x1/ci.svg"
  },
  "/app-assets/fonts/flag-icon-css/flags/1x1/ck.svg": {
    "type": "image/svg+xml",
    "etag": "\"a1f-LrY0K9IikeFY+uvJk2+GIPIfGZ4\"",
    "mtime": "2025-04-13T20:04:20.388Z",
    "size": 2591,
    "path": "../public/app-assets/fonts/flag-icon-css/flags/1x1/ck.svg"
  },
  "/app-assets/fonts/flag-icon-css/flags/1x1/ck.svg.br": {
    "type": "image/svg+xml",
    "encoding": "br",
    "etag": "\"4a2-NOTfQaG6QO1P9JIyn/Uvqd/0ObQ\"",
    "mtime": "2025-04-13T20:04:28.557Z",
    "size": 1186,
    "path": "../public/app-assets/fonts/flag-icon-css/flags/1x1/ck.svg.br"
  },
  "/app-assets/fonts/flag-icon-css/flags/1x1/ck.svg.gz": {
    "type": "image/svg+xml",
    "encoding": "gzip",
    "etag": "\"526-Kxrg2oPUqZKTlgr/AKfNgw1S75k\"",
    "mtime": "2025-04-13T20:04:28.557Z",
    "size": 1318,
    "path": "../public/app-assets/fonts/flag-icon-css/flags/1x1/ck.svg.gz"
  },
  "/app-assets/fonts/flag-icon-css/flags/1x1/cl.svg": {
    "type": "image/svg+xml",
    "etag": "\"2c8-6biE0YSScaKb69Ae5XWDPf2NEuQ\"",
    "mtime": "2025-04-13T20:04:20.389Z",
    "size": 712,
    "path": "../public/app-assets/fonts/flag-icon-css/flags/1x1/cl.svg"
  },
  "/app-assets/fonts/flag-icon-css/flags/1x1/cm.svg": {
    "type": "image/svg+xml",
    "etag": "\"33a-3MlzXHQ5a/UWlzGSE3Ny4qvZzKo\"",
    "mtime": "2025-04-13T20:04:20.388Z",
    "size": 826,
    "path": "../public/app-assets/fonts/flag-icon-css/flags/1x1/cm.svg"
  },
  "/app-assets/fonts/flag-icon-css/flags/1x1/cn.svg": {
    "type": "image/svg+xml",
    "etag": "\"412-SNvezODIdbv2Uw5V0zNR3xjQmnQ\"",
    "mtime": "2025-04-13T20:04:20.389Z",
    "size": 1042,
    "path": "../public/app-assets/fonts/flag-icon-css/flags/1x1/cn.svg"
  },
  "/app-assets/fonts/flag-icon-css/flags/1x1/cn.svg.br": {
    "type": "image/svg+xml",
    "encoding": "br",
    "etag": "\"19a-q4ucNuMi7rN+BrmRluZbMpsE7+k\"",
    "mtime": "2025-04-13T20:04:28.557Z",
    "size": 410,
    "path": "../public/app-assets/fonts/flag-icon-css/flags/1x1/cn.svg.br"
  },
  "/app-assets/fonts/flag-icon-css/flags/1x1/cn.svg.gz": {
    "type": "image/svg+xml",
    "encoding": "gzip",
    "etag": "\"1e4-4YX2YN+NQecZleruCBTugaXz2GE\"",
    "mtime": "2025-04-13T20:04:28.557Z",
    "size": 484,
    "path": "../public/app-assets/fonts/flag-icon-css/flags/1x1/cn.svg.gz"
  },
  "/app-assets/fonts/flag-icon-css/flags/1x1/co.svg": {
    "type": "image/svg+xml",
    "etag": "\"161-xrGPcoaLxCnRRhn25M/ejrUjaRk\"",
    "mtime": "2025-04-13T20:04:20.392Z",
    "size": 353,
    "path": "../public/app-assets/fonts/flag-icon-css/flags/1x1/co.svg"
  },
  "/app-assets/fonts/flag-icon-css/flags/1x1/cr.svg": {
    "type": "image/svg+xml",
    "etag": "\"161-1CefVLfAugaAWmMe0VncFPU7XJE\"",
    "mtime": "2025-04-13T20:04:20.389Z",
    "size": 353,
    "path": "../public/app-assets/fonts/flag-icon-css/flags/1x1/cr.svg"
  },
  "/app-assets/fonts/flag-icon-css/flags/1x1/cu.svg": {
    "type": "image/svg+xml",
    "etag": "\"2a1-nchoBPGYwEEnmHno6+al2htDJr0\"",
    "mtime": "2025-04-13T20:04:20.389Z",
    "size": 673,
    "path": "../public/app-assets/fonts/flag-icon-css/flags/1x1/cu.svg"
  },
  "/app-assets/fonts/flag-icon-css/flags/1x1/cv.svg": {
    "type": "image/svg+xml",
    "etag": "\"6f0-S4gTinem/nGLVVVXYzxTfXI7XxA\"",
    "mtime": "2025-04-13T20:04:20.389Z",
    "size": 1776,
    "path": "../public/app-assets/fonts/flag-icon-css/flags/1x1/cv.svg"
  },
  "/app-assets/fonts/flag-icon-css/flags/1x1/cv.svg.br": {
    "type": "image/svg+xml",
    "encoding": "br",
    "etag": "\"1d2-ECpeWNhk9WZX//DmDZ2jdkKa5Rs\"",
    "mtime": "2025-04-13T20:04:28.557Z",
    "size": 466,
    "path": "../public/app-assets/fonts/flag-icon-css/flags/1x1/cv.svg.br"
  },
  "/app-assets/fonts/flag-icon-css/flags/1x1/cv.svg.gz": {
    "type": "image/svg+xml",
    "encoding": "gzip",
    "etag": "\"228-IOxqXH81aSItSH9adOFZ8ojQ6UE\"",
    "mtime": "2025-04-13T20:04:28.557Z",
    "size": 552,
    "path": "../public/app-assets/fonts/flag-icon-css/flags/1x1/cv.svg.gz"
  },
  "/app-assets/fonts/flag-icon-css/flags/1x1/cw.svg": {
    "type": "image/svg+xml",
    "etag": "\"2f6-nlRoa6R0EFtgfTjWxOTmUNCwFBY\"",
    "mtime": "2025-04-13T20:04:20.389Z",
    "size": 758,
    "path": "../public/app-assets/fonts/flag-icon-css/flags/1x1/cw.svg"
  },
  "/app-assets/fonts/flag-icon-css/flags/1x1/cx.svg": {
    "type": "image/svg+xml",
    "etag": "\"d9b-o+TLZGzN3pMSPsgL8VBKuAIPTbE\"",
    "mtime": "2025-04-13T20:04:20.389Z",
    "size": 3483,
    "path": "../public/app-assets/fonts/flag-icon-css/flags/1x1/cx.svg"
  },
  "/app-assets/fonts/flag-icon-css/flags/1x1/cx.svg.br": {
    "type": "image/svg+xml",
    "encoding": "br",
    "etag": "\"5c3-x9F/VuH9WR52ogbO9aJiLlsnZ9o\"",
    "mtime": "2025-04-13T20:04:28.557Z",
    "size": 1475,
    "path": "../public/app-assets/fonts/flag-icon-css/flags/1x1/cx.svg.br"
  },
  "/app-assets/fonts/flag-icon-css/flags/1x1/cx.svg.gz": {
    "type": "image/svg+xml",
    "encoding": "gzip",
    "etag": "\"664-yoe5+qzubpN6h3IvfKoDXujK3Tc\"",
    "mtime": "2025-04-13T20:04:28.557Z",
    "size": 1636,
    "path": "../public/app-assets/fonts/flag-icon-css/flags/1x1/cx.svg.gz"
  },
  "/app-assets/fonts/flag-icon-css/flags/1x1/cy.svg": {
    "type": "image/svg+xml",
    "etag": "\"278b-oU3hSW/nYIGz7lGkBgMfrTC/C6w\"",
    "mtime": "2025-04-13T20:04:20.390Z",
    "size": 10123,
    "path": "../public/app-assets/fonts/flag-icon-css/flags/1x1/cy.svg"
  },
  "/app-assets/fonts/flag-icon-css/flags/1x1/cy.svg.br": {
    "type": "image/svg+xml",
    "encoding": "br",
    "etag": "\"ff9-+lhzoR3lWe/QPxiHQNnwAMm3GkQ\"",
    "mtime": "2025-04-13T20:04:28.557Z",
    "size": 4089,
    "path": "../public/app-assets/fonts/flag-icon-css/flags/1x1/cy.svg.br"
  },
  "/app-assets/fonts/flag-icon-css/flags/1x1/cy.svg.gz": {
    "type": "image/svg+xml",
    "encoding": "gzip",
    "etag": "\"122c-LCP/cmVZ+aQjtA9tBGVc4uU2wO0\"",
    "mtime": "2025-04-13T20:04:28.557Z",
    "size": 4652,
    "path": "../public/app-assets/fonts/flag-icon-css/flags/1x1/cy.svg.gz"
  },
  "/app-assets/fonts/flag-icon-css/flags/1x1/cz.svg": {
    "type": "image/svg+xml",
    "etag": "\"21b-+TDX1GEptWQm6fkLHwrr3Dyw6xY\"",
    "mtime": "2025-04-13T20:04:20.389Z",
    "size": 539,
    "path": "../public/app-assets/fonts/flag-icon-css/flags/1x1/cz.svg"
  },
  "/app-assets/fonts/flag-icon-css/flags/1x1/de.svg": {
    "type": "image/svg+xml",
    "etag": "\"159-ik1QSLe4aEd+2Zg9+HElBeZapMs\"",
    "mtime": "2025-04-13T20:04:20.389Z",
    "size": 345,
    "path": "../public/app-assets/fonts/flag-icon-css/flags/1x1/de.svg"
  },
  "/app-assets/fonts/flag-icon-css/flags/1x1/dj.svg": {
    "type": "image/svg+xml",
    "etag": "\"2b3-/zaw5xNoUhNvaTIJNPALnpgLyL0\"",
    "mtime": "2025-04-13T20:04:20.390Z",
    "size": 691,
    "path": "../public/app-assets/fonts/flag-icon-css/flags/1x1/dj.svg"
  },
  "/app-assets/fonts/flag-icon-css/flags/1x1/dk.svg": {
    "type": "image/svg+xml",
    "etag": "\"dd-PORwxSjXdjhttDE+tkXaOogP8nA\"",
    "mtime": "2025-04-13T20:04:20.391Z",
    "size": 221,
    "path": "../public/app-assets/fonts/flag-icon-css/flags/1x1/dk.svg"
  },
  "/app-assets/fonts/flag-icon-css/flags/1x1/dm.svg": {
    "type": "image/svg+xml",
    "etag": "\"51fc-11nrJ0CjSXdLrArDbnrPV6O6A0s\"",
    "mtime": "2025-04-13T20:04:20.391Z",
    "size": 20988,
    "path": "../public/app-assets/fonts/flag-icon-css/flags/1x1/dm.svg"
  },
  "/app-assets/fonts/flag-icon-css/flags/1x1/dm.svg.br": {
    "type": "image/svg+xml",
    "encoding": "br",
    "etag": "\"bdb-/mKcKY7VFjg1+chceZJHNJuMCaQ\"",
    "mtime": "2025-04-13T20:04:28.557Z",
    "size": 3035,
    "path": "../public/app-assets/fonts/flag-icon-css/flags/1x1/dm.svg.br"
  },
  "/app-assets/fonts/flag-icon-css/flags/1x1/dm.svg.gz": {
    "type": "image/svg+xml",
    "encoding": "gzip",
    "etag": "\"e5e-GhZZCu/OkurplBv6IfXqWItQA4Q\"",
    "mtime": "2025-04-13T20:04:28.557Z",
    "size": 3678,
    "path": "../public/app-assets/fonts/flag-icon-css/flags/1x1/dm.svg.gz"
  },
  "/app-assets/fonts/flag-icon-css/flags/1x1/do.svg": {
    "type": "image/svg+xml",
    "etag": "\"6f041-k53Rc4r/EmQVaEdtozCB2yTeptg\"",
    "mtime": "2025-04-13T20:04:20.391Z",
    "size": 454721,
    "path": "../public/app-assets/fonts/flag-icon-css/flags/1x1/do.svg"
  },
  "/app-assets/fonts/flag-icon-css/flags/1x1/do.svg.br": {
    "type": "image/svg+xml",
    "encoding": "br",
    "etag": "\"b680-mFtpv9znlmLq+kt4Qmc8zA4XclM\"",
    "mtime": "2025-04-13T20:04:28.698Z",
    "size": 46720,
    "path": "../public/app-assets/fonts/flag-icon-css/flags/1x1/do.svg.br"
  },
  "/app-assets/fonts/flag-icon-css/flags/1x1/do.svg.gz": {
    "type": "image/svg+xml",
    "encoding": "gzip",
    "etag": "\"e4f8-mkN5tZrWPapKZPo1PCVnQFRh8Ak\"",
    "mtime": "2025-04-13T20:04:28.701Z",
    "size": 58616,
    "path": "../public/app-assets/fonts/flag-icon-css/flags/1x1/do.svg.gz"
  },
  "/app-assets/fonts/flag-icon-css/flags/1x1/dz.svg": {
    "type": "image/svg+xml",
    "etag": "\"13d-jkmuozlLVMpsjeHcvRiEGvFb90o\"",
    "mtime": "2025-04-13T20:04:20.391Z",
    "size": 317,
    "path": "../public/app-assets/fonts/flag-icon-css/flags/1x1/dz.svg"
  },
  "/app-assets/fonts/flag-icon-css/flags/1x1/ec.svg": {
    "type": "image/svg+xml",
    "etag": "\"996f-ZKf9AYlddF50gj5vyTig6+0L39M\"",
    "mtime": "2025-04-13T20:04:20.391Z",
    "size": 39279,
    "path": "../public/app-assets/fonts/flag-icon-css/flags/1x1/ec.svg"
  },
  "/app-assets/fonts/flag-icon-css/flags/1x1/ec.svg.br": {
    "type": "image/svg+xml",
    "encoding": "br",
    "etag": "\"2156-q36hRp/LKN4vAARqeFJ4qFCpOGc\"",
    "mtime": "2025-04-13T20:04:28.557Z",
    "size": 8534,
    "path": "../public/app-assets/fonts/flag-icon-css/flags/1x1/ec.svg.br"
  },
  "/app-assets/fonts/flag-icon-css/flags/1x1/ec.svg.gz": {
    "type": "image/svg+xml",
    "encoding": "gzip",
    "etag": "\"25ad-5K1z+I9p3n+Y7xmGW+pk6Rxipls\"",
    "mtime": "2025-04-13T20:04:28.557Z",
    "size": 9645,
    "path": "../public/app-assets/fonts/flag-icon-css/flags/1x1/ec.svg.gz"
  },
  "/app-assets/fonts/flag-icon-css/flags/1x1/ee.svg": {
    "type": "image/svg+xml",
    "etag": "\"19d-/d98soVLklO4xzmlJIlMfGxulFw\"",
    "mtime": "2025-04-13T20:04:20.391Z",
    "size": 413,
    "path": "../public/app-assets/fonts/flag-icon-css/flags/1x1/ee.svg"
  },
  "/app-assets/fonts/flag-icon-css/flags/1x1/eg.svg": {
    "type": "image/svg+xml",
    "etag": "\"403c-rhrbQWBzInIzb+awUkISapMoHjQ\"",
    "mtime": "2025-04-13T20:04:20.391Z",
    "size": 16444,
    "path": "../public/app-assets/fonts/flag-icon-css/flags/1x1/eg.svg"
  },
  "/app-assets/fonts/flag-icon-css/flags/1x1/eg.svg.br": {
    "type": "image/svg+xml",
    "encoding": "br",
    "etag": "\"1813-552xMtThtFPA8cXv0sjBAMfwxao\"",
    "mtime": "2025-04-13T20:04:28.557Z",
    "size": 6163,
    "path": "../public/app-assets/fonts/flag-icon-css/flags/1x1/eg.svg.br"
  },
  "/app-assets/fonts/flag-icon-css/flags/1x1/eg.svg.gz": {
    "type": "image/svg+xml",
    "encoding": "gzip",
    "etag": "\"1b2b-udK3aRYLEVHve3zLczy3lTUjLuU\"",
    "mtime": "2025-04-13T20:04:28.557Z",
    "size": 6955,
    "path": "../public/app-assets/fonts/flag-icon-css/flags/1x1/eg.svg.gz"
  },
  "/app-assets/fonts/flag-icon-css/flags/1x1/eh.svg": {
    "type": "image/svg+xml",
    "etag": "\"425-sJY7SWAmfR5RuPUq8P6WPPI4i9U\"",
    "mtime": "2025-04-13T20:04:20.391Z",
    "size": 1061,
    "path": "../public/app-assets/fonts/flag-icon-css/flags/1x1/eh.svg"
  },
  "/app-assets/fonts/flag-icon-css/flags/1x1/eh.svg.br": {
    "type": "image/svg+xml",
    "encoding": "br",
    "etag": "\"20e-1tcMB+9iLVNM2fEjHfftUoC+tQA\"",
    "mtime": "2025-04-13T20:04:28.557Z",
    "size": 526,
    "path": "../public/app-assets/fonts/flag-icon-css/flags/1x1/eh.svg.br"
  },
  "/app-assets/fonts/flag-icon-css/flags/1x1/eh.svg.gz": {
    "type": "image/svg+xml",
    "encoding": "gzip",
    "etag": "\"261-LuUHTzmxNGL5QYcViei5NVnJK50\"",
    "mtime": "2025-04-13T20:04:28.557Z",
    "size": 609,
    "path": "../public/app-assets/fonts/flag-icon-css/flags/1x1/eh.svg.gz"
  },
  "/app-assets/fonts/flag-icon-css/flags/1x1/er.svg": {
    "type": "image/svg+xml",
    "etag": "\"1311-MHJiDdcv6iSQ0VJA7d6kUfeWBy0\"",
    "mtime": "2025-04-13T20:04:20.391Z",
    "size": 4881,
    "path": "../public/app-assets/fonts/flag-icon-css/flags/1x1/er.svg"
  },
  "/app-assets/fonts/flag-icon-css/flags/1x1/er.svg.br": {
    "type": "image/svg+xml",
    "encoding": "br",
    "etag": "\"7fa-TcT2vIeud/bqdDNre73d/asmoLY\"",
    "mtime": "2025-04-13T20:04:28.557Z",
    "size": 2042,
    "path": "../public/app-assets/fonts/flag-icon-css/flags/1x1/er.svg.br"
  },
  "/app-assets/fonts/flag-icon-css/flags/1x1/er.svg.gz": {
    "type": "image/svg+xml",
    "encoding": "gzip",
    "etag": "\"95a-pT2lfxiatop4Ybfvz+Mu8UyQUw8\"",
    "mtime": "2025-04-13T20:04:28.557Z",
    "size": 2394,
    "path": "../public/app-assets/fonts/flag-icon-css/flags/1x1/er.svg.gz"
  },
  "/app-assets/fonts/flag-icon-css/flags/1x1/es.svg": {
    "type": "image/svg+xml",
    "etag": "\"23fb1-pNbsdJGUnkhrsOVlG/UzgRmz800\"",
    "mtime": "2025-04-13T20:04:20.398Z",
    "size": 147377,
    "path": "../public/app-assets/fonts/flag-icon-css/flags/1x1/es.svg"
  },
  "/app-assets/fonts/flag-icon-css/flags/1x1/es.svg.br": {
    "type": "image/svg+xml",
    "encoding": "br",
    "etag": "\"64ac-v3xUrowCAZkdT95URsgBVBN88dE\"",
    "mtime": "2025-04-13T20:04:28.623Z",
    "size": 25772,
    "path": "../public/app-assets/fonts/flag-icon-css/flags/1x1/es.svg.br"
  },
  "/app-assets/fonts/flag-icon-css/flags/1x1/es.svg.gz": {
    "type": "image/svg+xml",
    "encoding": "gzip",
    "etag": "\"7ea4-yXeIH2Pm2gdsQSpuwxKTnEWtfz4\"",
    "mtime": "2025-04-13T20:04:28.623Z",
    "size": 32420,
    "path": "../public/app-assets/fonts/flag-icon-css/flags/1x1/es.svg.gz"
  },
  "/app-assets/fonts/flag-icon-css/flags/1x1/et.svg": {
    "type": "image/svg+xml",
    "etag": "\"65c-g8ft9kVvnDU+GqUTflWymhfF/iE\"",
    "mtime": "2025-04-13T20:04:20.392Z",
    "size": 1628,
    "path": "../public/app-assets/fonts/flag-icon-css/flags/1x1/et.svg"
  },
  "/app-assets/fonts/flag-icon-css/flags/1x1/et.svg.br": {
    "type": "image/svg+xml",
    "encoding": "br",
    "etag": "\"324-8HF/+fK84d0jDqWqHR6p/+4pFas\"",
    "mtime": "2025-04-13T20:04:28.558Z",
    "size": 804,
    "path": "../public/app-assets/fonts/flag-icon-css/flags/1x1/et.svg.br"
  },
  "/app-assets/fonts/flag-icon-css/flags/1x1/et.svg.gz": {
    "type": "image/svg+xml",
    "encoding": "gzip",
    "etag": "\"39a-4BDpDkgEitLLOPU2rKVl+kWb/Yk\"",
    "mtime": "2025-04-13T20:04:28.557Z",
    "size": 922,
    "path": "../public/app-assets/fonts/flag-icon-css/flags/1x1/et.svg.gz"
  },
  "/app-assets/fonts/flag-icon-css/flags/1x1/eu.svg": {
    "type": "image/svg+xml",
    "etag": "\"4f4-TQUxQOIMKUW+mC2Y+Xf3VZCkS1Q\"",
    "mtime": "2025-04-13T20:04:20.391Z",
    "size": 1268,
    "path": "../public/app-assets/fonts/flag-icon-css/flags/1x1/eu.svg"
  },
  "/app-assets/fonts/flag-icon-css/flags/1x1/eu.svg.br": {
    "type": "image/svg+xml",
    "encoding": "br",
    "etag": "\"161-K4Zo7ZACwISgryYlfMlha/pktFE\"",
    "mtime": "2025-04-13T20:04:28.557Z",
    "size": 353,
    "path": "../public/app-assets/fonts/flag-icon-css/flags/1x1/eu.svg.br"
  },
  "/app-assets/fonts/flag-icon-css/flags/1x1/eu.svg.gz": {
    "type": "image/svg+xml",
    "encoding": "gzip",
    "etag": "\"18e-fv3/UL8iUMIupcVdUjbwpjKmbSs\"",
    "mtime": "2025-04-13T20:04:28.557Z",
    "size": 398,
    "path": "../public/app-assets/fonts/flag-icon-css/flags/1x1/eu.svg.gz"
  },
  "/app-assets/fonts/flag-icon-css/flags/1x1/fi.svg": {
    "type": "image/svg+xml",
    "etag": "\"3e3-7i8zNVBKmHh0uB0il9gmPKw0DIM\"",
    "mtime": "2025-04-13T20:04:20.392Z",
    "size": 995,
    "path": "../public/app-assets/fonts/flag-icon-css/flags/1x1/fi.svg"
  },
  "/app-assets/fonts/flag-icon-css/flags/1x1/fj.svg": {
    "type": "image/svg+xml",
    "etag": "\"5b93-Z2kVLrCAwBt+z4kG9h1ESzh1Kq0\"",
    "mtime": "2025-04-13T20:04:20.392Z",
    "size": 23443,
    "path": "../public/app-assets/fonts/flag-icon-css/flags/1x1/fj.svg"
  },
  "/app-assets/fonts/flag-icon-css/flags/1x1/fj.svg.br": {
    "type": "image/svg+xml",
    "encoding": "br",
    "etag": "\"1508-9y54TXVQbPUfkOHZMbM88TM6Stk\"",
    "mtime": "2025-04-13T20:04:28.558Z",
    "size": 5384,
    "path": "../public/app-assets/fonts/flag-icon-css/flags/1x1/fj.svg.br"
  },
  "/app-assets/fonts/flag-icon-css/flags/1x1/fj.svg.gz": {
    "type": "image/svg+xml",
    "encoding": "gzip",
    "etag": "\"17f2-ZsYOKHuMGYPnJ1HH11uz96lAPwk\"",
    "mtime": "2025-04-13T20:04:28.558Z",
    "size": 6130,
    "path": "../public/app-assets/fonts/flag-icon-css/flags/1x1/fj.svg.gz"
  },
  "/app-assets/fonts/flag-icon-css/flags/1x1/fk.svg": {
    "type": "image/svg+xml",
    "etag": "\"b009-Tb5BtgqBQTlYsOmKP0MAV/nFCDc\"",
    "mtime": "2025-04-13T20:04:20.393Z",
    "size": 45065,
    "path": "../public/app-assets/fonts/flag-icon-css/flags/1x1/fk.svg"
  },
  "/app-assets/fonts/flag-icon-css/flags/1x1/fk.svg.br": {
    "type": "image/svg+xml",
    "encoding": "br",
    "etag": "\"34f1-6m/tBltfqQPo35jYFiUw8KoHN48\"",
    "mtime": "2025-04-13T20:04:28.559Z",
    "size": 13553,
    "path": "../public/app-assets/fonts/flag-icon-css/flags/1x1/fk.svg.br"
  },
  "/app-assets/fonts/flag-icon-css/flags/1x1/fk.svg.gz": {
    "type": "image/svg+xml",
    "encoding": "gzip",
    "etag": "\"3b54-j8UcoVeacyNb0jEoiq18wmrM/P0\"",
    "mtime": "2025-04-13T20:04:28.558Z",
    "size": 15188,
    "path": "../public/app-assets/fonts/flag-icon-css/flags/1x1/fk.svg.gz"
  },
  "/app-assets/fonts/flag-icon-css/flags/1x1/fm.svg": {
    "type": "image/svg+xml",
    "etag": "\"3d0-AzdWMyACLQ9HwUrfIKgtxndnas4\"",
    "mtime": "2025-04-13T20:04:20.392Z",
    "size": 976,
    "path": "../public/app-assets/fonts/flag-icon-css/flags/1x1/fm.svg"
  },
  "/app-assets/fonts/flag-icon-css/flags/1x1/fo.svg": {
    "type": "image/svg+xml",
    "etag": "\"26e-MjzFzGPvCIiVfNJRYlLa6AfeSKE\"",
    "mtime": "2025-04-13T20:04:20.393Z",
    "size": 622,
    "path": "../public/app-assets/fonts/flag-icon-css/flags/1x1/fo.svg"
  },
  "/app-assets/fonts/flag-icon-css/flags/1x1/fr.svg": {
    "type": "image/svg+xml",
    "etag": "\"15e-/3adX/bPUe6gJeTGtF9TqFeg83c\"",
    "mtime": "2025-04-13T20:04:20.392Z",
    "size": 350,
    "path": "../public/app-assets/fonts/flag-icon-css/flags/1x1/fr.svg"
  },
  "/app-assets/fonts/flag-icon-css/flags/1x1/ga.svg": {
    "type": "image/svg+xml",
    "etag": "\"169-dvhS+KiBf0qUj/fOdWOQu/VUzjg\"",
    "mtime": "2025-04-13T20:04:20.393Z",
    "size": 361,
    "path": "../public/app-assets/fonts/flag-icon-css/flags/1x1/ga.svg"
  },
  "/app-assets/fonts/flag-icon-css/flags/1x1/gb-eng.svg": {
    "type": "image/svg+xml",
    "etag": "\"ec-ZrlajapRVDDyrNZ8tfgq5tbmPvY\"",
    "mtime": "2025-04-13T20:04:20.392Z",
    "size": 236,
    "path": "../public/app-assets/fonts/flag-icon-css/flags/1x1/gb-eng.svg"
  },
  "/app-assets/fonts/flag-icon-css/flags/1x1/gb-sct.svg": {
    "type": "image/svg+xml",
    "etag": "\"e4-W/7dt1SEVmilgsWN8ykEFjgsR7U\"",
    "mtime": "2025-04-13T20:04:20.395Z",
    "size": 228,
    "path": "../public/app-assets/fonts/flag-icon-css/flags/1x1/gb-sct.svg"
  },
  "/app-assets/fonts/flag-icon-css/flags/1x1/gb-wls.svg": {
    "type": "image/svg+xml",
    "etag": "\"3815-Hkm4pR3BvMniibmmnOlbqwni5Aw\"",
    "mtime": "2025-04-13T20:04:20.393Z",
    "size": 14357,
    "path": "../public/app-assets/fonts/flag-icon-css/flags/1x1/gb-wls.svg"
  },
  "/app-assets/fonts/flag-icon-css/flags/1x1/gb-wls.svg.br": {
    "type": "image/svg+xml",
    "encoding": "br",
    "etag": "\"1753-TkXHZUb0g1n124YgMp14snlH2Dg\"",
    "mtime": "2025-04-13T20:04:28.558Z",
    "size": 5971,
    "path": "../public/app-assets/fonts/flag-icon-css/flags/1x1/gb-wls.svg.br"
  },
  "/app-assets/fonts/flag-icon-css/flags/1x1/gb-wls.svg.gz": {
    "type": "image/svg+xml",
    "encoding": "gzip",
    "etag": "\"19bd-rviGBo6euLDGE5jJmpmD+l5udOE\"",
    "mtime": "2025-04-13T20:04:28.558Z",
    "size": 6589,
    "path": "../public/app-assets/fonts/flag-icon-css/flags/1x1/gb-wls.svg.gz"
  },
  "/app-assets/fonts/flag-icon-css/flags/1x1/gb.svg": {
    "type": "image/svg+xml",
    "etag": "\"3b0-AsgxtMxQWUgZm8memtn3Yo8/80g\"",
    "mtime": "2025-04-13T20:04:20.392Z",
    "size": 944,
    "path": "../public/app-assets/fonts/flag-icon-css/flags/1x1/gb.svg"
  },
  "/app-assets/fonts/flag-icon-css/flags/1x1/gd.svg": {
    "type": "image/svg+xml",
    "etag": "\"772-eLo15Ybd9a/Y8skEVkY42F0Y0Xo\"",
    "mtime": "2025-04-13T20:04:20.393Z",
    "size": 1906,
    "path": "../public/app-assets/fonts/flag-icon-css/flags/1x1/gd.svg"
  },
  "/app-assets/fonts/flag-icon-css/flags/1x1/gd.svg.br": {
    "type": "image/svg+xml",
    "encoding": "br",
    "etag": "\"2b1-6VSyBEwHBf3KwgaFOWhKAM0IIMo\"",
    "mtime": "2025-04-13T20:04:28.558Z",
    "size": 689,
    "path": "../public/app-assets/fonts/flag-icon-css/flags/1x1/gd.svg.br"
  },
  "/app-assets/fonts/flag-icon-css/flags/1x1/gd.svg.gz": {
    "type": "image/svg+xml",
    "encoding": "gzip",
    "etag": "\"30c-ZydV1ZxfeF6PXt6MhX7ralADrlo\"",
    "mtime": "2025-04-13T20:04:28.558Z",
    "size": 780,
    "path": "../public/app-assets/fonts/flag-icon-css/flags/1x1/gd.svg.gz"
  },
  "/app-assets/fonts/flag-icon-css/flags/1x1/ge.svg": {
    "type": "image/svg+xml",
    "etag": "\"495-dbX/PzNFxb4B326wucug2fzKaeg\"",
    "mtime": "2025-04-13T20:04:20.394Z",
    "size": 1173,
    "path": "../public/app-assets/fonts/flag-icon-css/flags/1x1/ge.svg"
  },
  "/app-assets/fonts/flag-icon-css/flags/1x1/ge.svg.br": {
    "type": "image/svg+xml",
    "encoding": "br",
    "etag": "\"1a7-NpGE7lJmnCfzlplrDG9CxzgQDfw\"",
    "mtime": "2025-04-13T20:04:28.558Z",
    "size": 423,
    "path": "../public/app-assets/fonts/flag-icon-css/flags/1x1/ge.svg.br"
  },
  "/app-assets/fonts/flag-icon-css/flags/1x1/ge.svg.gz": {
    "type": "image/svg+xml",
    "encoding": "gzip",
    "etag": "\"1e4-zougwLIbx7aOcr6oyjrx6hbPTFY\"",
    "mtime": "2025-04-13T20:04:28.558Z",
    "size": 484,
    "path": "../public/app-assets/fonts/flag-icon-css/flags/1x1/ge.svg.gz"
  },
  "/app-assets/fonts/flag-icon-css/flags/1x1/gf.svg": {
    "type": "image/svg+xml",
    "etag": "\"10e-GqeLA17MAoRQGZ5vF96/wekPWhA\"",
    "mtime": "2025-04-13T20:04:20.393Z",
    "size": 270,
    "path": "../public/app-assets/fonts/flag-icon-css/flags/1x1/gf.svg"
  },
  "/app-assets/fonts/flag-icon-css/flags/1x1/gg.svg": {
    "type": "image/svg+xml",
    "etag": "\"31a-ixMUGvexgVpe6j4M4t8BrlMEcys\"",
    "mtime": "2025-04-13T20:04:20.393Z",
    "size": 794,
    "path": "../public/app-assets/fonts/flag-icon-css/flags/1x1/gg.svg"
  },
  "/app-assets/fonts/flag-icon-css/flags/1x1/gh.svg": {
    "type": "image/svg+xml",
    "etag": "\"136-FNSGt3NgApk+H8TOwXb8ZewXStY\"",
    "mtime": "2025-04-13T20:04:20.394Z",
    "size": 310,
    "path": "../public/app-assets/fonts/flag-icon-css/flags/1x1/gh.svg"
  },
  "/app-assets/fonts/flag-icon-css/flags/1x1/gi.svg": {
    "type": "image/svg+xml",
    "etag": "\"1037-mKF2gaAZHvwwbeA7Y1H0cSCGCnQ\"",
    "mtime": "2025-04-13T20:04:20.394Z",
    "size": 4151,
    "path": "../public/app-assets/fonts/flag-icon-css/flags/1x1/gi.svg"
  },
  "/app-assets/fonts/flag-icon-css/flags/1x1/gi.svg.br": {
    "type": "image/svg+xml",
    "encoding": "br",
    "etag": "\"6a8-elxLa1R2EXXWue0lahRALTVhLn4\"",
    "mtime": "2025-04-13T20:04:28.558Z",
    "size": 1704,
    "path": "../public/app-assets/fonts/flag-icon-css/flags/1x1/gi.svg.br"
  },
  "/app-assets/fonts/flag-icon-css/flags/1x1/gi.svg.gz": {
    "type": "image/svg+xml",
    "encoding": "gzip",
    "etag": "\"748-9rknuOVFj+gT3M/ycYYSEaTSeoM\"",
    "mtime": "2025-04-13T20:04:28.558Z",
    "size": 1864,
    "path": "../public/app-assets/fonts/flag-icon-css/flags/1x1/gi.svg.gz"
  },
  "/app-assets/fonts/flag-icon-css/flags/1x1/gl.svg": {
    "type": "image/svg+xml",
    "etag": "\"220-C1cEj5VKNNfOnHnHvpaDJ/BRPTg\"",
    "mtime": "2025-04-13T20:04:20.397Z",
    "size": 544,
    "path": "../public/app-assets/fonts/flag-icon-css/flags/1x1/gl.svg"
  },
  "/app-assets/fonts/flag-icon-css/flags/1x1/gm.svg": {
    "type": "image/svg+xml",
    "etag": "\"1c6-Ty0A3J+iqeYhhnJqkmfBh/m0zVE\"",
    "mtime": "2025-04-13T20:04:20.394Z",
    "size": 454,
    "path": "../public/app-assets/fonts/flag-icon-css/flags/1x1/gm.svg"
  },
  "/app-assets/fonts/flag-icon-css/flags/1x1/gn.svg": {
    "type": "image/svg+xml",
    "etag": "\"15b-nTSL8OMSS6MJ1UYZ8wWxORlJpuo\"",
    "mtime": "2025-04-13T20:04:20.394Z",
    "size": 347,
    "path": "../public/app-assets/fonts/flag-icon-css/flags/1x1/gn.svg"
  },
  "/app-assets/fonts/flag-icon-css/flags/1x1/gp.svg": {
    "type": "image/svg+xml",
    "etag": "\"15e-/3adX/bPUe6gJeTGtF9TqFeg83c\"",
    "mtime": "2025-04-13T20:04:20.395Z",
    "size": 350,
    "path": "../public/app-assets/fonts/flag-icon-css/flags/1x1/gp.svg"
  },
  "/app-assets/fonts/flag-icon-css/flags/1x1/gq.svg": {
    "type": "image/svg+xml",
    "etag": "\"4582-aCA9pBEWHAVqWFNttMfpjzeB1IE\"",
    "mtime": "2025-04-13T20:04:20.396Z",
    "size": 17794,
    "path": "../public/app-assets/fonts/flag-icon-css/flags/1x1/gq.svg"
  },
  "/app-assets/fonts/flag-icon-css/flags/1x1/gq.svg.br": {
    "type": "image/svg+xml",
    "encoding": "br",
    "etag": "\"1735-KyPOPzYaclEVuuYS5dv0kQEYk7k\"",
    "mtime": "2025-04-13T20:04:28.559Z",
    "size": 5941,
    "path": "../public/app-assets/fonts/flag-icon-css/flags/1x1/gq.svg.br"
  },
  "/app-assets/fonts/flag-icon-css/flags/1x1/gq.svg.gz": {
    "type": "image/svg+xml",
    "encoding": "gzip",
    "etag": "\"1a15-LTlsLJ9biFDHxQvHdKUimVAqa4U\"",
    "mtime": "2025-04-13T20:04:28.558Z",
    "size": 6677,
    "path": "../public/app-assets/fonts/flag-icon-css/flags/1x1/gq.svg.gz"
  },
  "/app-assets/fonts/flag-icon-css/flags/1x1/gr.svg": {
    "type": "image/svg+xml",
    "etag": "\"38d-eo+pDeNYJoKLwl916+CyMqNxgN0\"",
    "mtime": "2025-04-13T20:04:20.398Z",
    "size": 909,
    "path": "../public/app-assets/fonts/flag-icon-css/flags/1x1/gr.svg"
  },
  "/app-assets/fonts/flag-icon-css/flags/1x1/gs.svg": {
    "type": "image/svg+xml",
    "etag": "\"b950-Khfy88RcTB0v071m8vXnxvuZjXc\"",
    "mtime": "2025-04-13T20:04:20.396Z",
    "size": 47440,
    "path": "../public/app-assets/fonts/flag-icon-css/flags/1x1/gs.svg"
  },
  "/app-assets/fonts/flag-icon-css/flags/1x1/gs.svg.br": {
    "type": "image/svg+xml",
    "encoding": "br",
    "etag": "\"3796-LJm5Lhyjdi56uEhhIJ5s9y9ZBNs\"",
    "mtime": "2025-04-13T20:04:28.559Z",
    "size": 14230,
    "path": "../public/app-assets/fonts/flag-icon-css/flags/1x1/gs.svg.br"
  },
  "/app-assets/fonts/flag-icon-css/flags/1x1/gs.svg.gz": {
    "type": "image/svg+xml",
    "encoding": "gzip",
    "etag": "\"3f6d-0LPH6LsecgBpbdF+bvtF7hHnbZ4\"",
    "mtime": "2025-04-13T20:04:28.559Z",
    "size": 16237,
    "path": "../public/app-assets/fonts/flag-icon-css/flags/1x1/gs.svg.gz"
  },
  "/app-assets/fonts/flag-icon-css/flags/1x1/gt.svg": {
    "type": "image/svg+xml",
    "etag": "\"f079-P+yfTAZITLj1clpk7KUf0r0jzho\"",
    "mtime": "2025-04-13T20:04:20.396Z",
    "size": 61561,
    "path": "../public/app-assets/fonts/flag-icon-css/flags/1x1/gt.svg"
  },
  "/app-assets/fonts/flag-icon-css/flags/1x1/gt.svg.br": {
    "type": "image/svg+xml",
    "encoding": "br",
    "etag": "\"530c-hvKJf6Y9z1sGdqKWm2O9MLlfQzc\"",
    "mtime": "2025-04-13T20:04:28.623Z",
    "size": 21260,
    "path": "../public/app-assets/fonts/flag-icon-css/flags/1x1/gt.svg.br"
  },
  "/app-assets/fonts/flag-icon-css/flags/1x1/gt.svg.gz": {
    "type": "image/svg+xml",
    "encoding": "gzip",
    "etag": "\"613a-2BGP/6nWu7K2+Sm1gt1xRO6tlpk\"",
    "mtime": "2025-04-13T20:04:28.623Z",
    "size": 24890,
    "path": "../public/app-assets/fonts/flag-icon-css/flags/1x1/gt.svg.gz"
  },
  "/app-assets/fonts/flag-icon-css/flags/1x1/gu.svg": {
    "type": "image/svg+xml",
    "etag": "\"17d3-nNPRBb7NCTVc2q1gwGk3kweO0wI\"",
    "mtime": "2025-04-13T20:04:20.399Z",
    "size": 6099,
    "path": "../public/app-assets/fonts/flag-icon-css/flags/1x1/gu.svg"
  },
  "/app-assets/fonts/flag-icon-css/flags/1x1/gu.svg.br": {
    "type": "image/svg+xml",
    "encoding": "br",
    "etag": "\"861-z7D4wRgzvdAMmjca3qQ+1goaC5c\"",
    "mtime": "2025-04-13T20:04:28.559Z",
    "size": 2145,
    "path": "../public/app-assets/fonts/flag-icon-css/flags/1x1/gu.svg.br"
  },
  "/app-assets/fonts/flag-icon-css/flags/1x1/gu.svg.gz": {
    "type": "image/svg+xml",
    "encoding": "gzip",
    "etag": "\"971-0VoSg+OqucYfwIP49vlKIbZj3xk\"",
    "mtime": "2025-04-13T20:04:28.559Z",
    "size": 2417,
    "path": "../public/app-assets/fonts/flag-icon-css/flags/1x1/gu.svg.gz"
  },
  "/app-assets/fonts/flag-icon-css/flags/1x1/gw.svg": {
    "type": "image/svg+xml",
    "etag": "\"284-/Lfu0R+D60BnquzZEKIncQIne0o\"",
    "mtime": "2025-04-13T20:04:20.397Z",
    "size": 644,
    "path": "../public/app-assets/fonts/flag-icon-css/flags/1x1/gw.svg"
  },
  "/app-assets/fonts/flag-icon-css/flags/1x1/gy.svg": {
    "type": "image/svg+xml",
    "etag": "\"25e-5nlxtBwtuklLyG7u0YuwkpIMUrQ\"",
    "mtime": "2025-04-13T20:04:20.399Z",
    "size": 606,
    "path": "../public/app-assets/fonts/flag-icon-css/flags/1x1/gy.svg"
  },
  "/app-assets/fonts/flag-icon-css/flags/1x1/hk.svg": {
    "type": "image/svg+xml",
    "etag": "\"1267-l4hGretdnDUJJ1raez6ATWFr4L4\"",
    "mtime": "2025-04-13T20:04:20.398Z",
    "size": 4711,
    "path": "../public/app-assets/fonts/flag-icon-css/flags/1x1/hk.svg"
  },
  "/app-assets/fonts/flag-icon-css/flags/1x1/hk.svg.br": {
    "type": "image/svg+xml",
    "encoding": "br",
    "etag": "\"679-dmvzbJGd/RoVrzS7PVMMmdeLaA0\"",
    "mtime": "2025-04-13T20:04:28.559Z",
    "size": 1657,
    "path": "../public/app-assets/fonts/flag-icon-css/flags/1x1/hk.svg.br"
  },
  "/app-assets/fonts/flag-icon-css/flags/1x1/hk.svg.gz": {
    "type": "image/svg+xml",
    "encoding": "gzip",
    "etag": "\"774-FQscwPJoeB4Q4OMUwCL8Qo7x/s0\"",
    "mtime": "2025-04-13T20:04:28.559Z",
    "size": 1908,
    "path": "../public/app-assets/fonts/flag-icon-css/flags/1x1/hk.svg.gz"
  },
  "/app-assets/fonts/flag-icon-css/flags/1x1/hm.svg": {
    "type": "image/svg+xml",
    "etag": "\"752-YhF+jrxkFxSHD0bv5OqBm5KwQMA\"",
    "mtime": "2025-04-13T20:04:20.397Z",
    "size": 1874,
    "path": "../public/app-assets/fonts/flag-icon-css/flags/1x1/hm.svg"
  },
  "/app-assets/fonts/flag-icon-css/flags/1x1/hm.svg.br": {
    "type": "image/svg+xml",
    "encoding": "br",
    "etag": "\"2b1-Ysz+sHV4MOIRNiQseBKjCTsU+PI\"",
    "mtime": "2025-04-13T20:04:28.559Z",
    "size": 689,
    "path": "../public/app-assets/fonts/flag-icon-css/flags/1x1/hm.svg.br"
  },
  "/app-assets/fonts/flag-icon-css/flags/1x1/hm.svg.gz": {
    "type": "image/svg+xml",
    "encoding": "gzip",
    "etag": "\"31a-YXve2Dp9o7sVpY/A7e3l1B8kd44\"",
    "mtime": "2025-04-13T20:04:28.559Z",
    "size": 794,
    "path": "../public/app-assets/fonts/flag-icon-css/flags/1x1/hm.svg.gz"
  },
  "/app-assets/fonts/flag-icon-css/flags/1x1/hn.svg": {
    "type": "image/svg+xml",
    "etag": "\"4b9-ElZVFeBwh7+rmJkvTqFPAU4poig\"",
    "mtime": "2025-04-13T20:04:20.397Z",
    "size": 1209,
    "path": "../public/app-assets/fonts/flag-icon-css/flags/1x1/hn.svg"
  },
  "/app-assets/fonts/flag-icon-css/flags/1x1/hn.svg.br": {
    "type": "image/svg+xml",
    "encoding": "br",
    "etag": "\"14e-/PLfGyerbyu2W+alHrSdKs8sbJ0\"",
    "mtime": "2025-04-13T20:04:28.559Z",
    "size": 334,
    "path": "../public/app-assets/fonts/flag-icon-css/flags/1x1/hn.svg.br"
  },
  "/app-assets/fonts/flag-icon-css/flags/1x1/hn.svg.gz": {
    "type": "image/svg+xml",
    "encoding": "gzip",
    "etag": "\"177-CI3zTxJxdO5lBfjn5Y46oU2VvuI\"",
    "mtime": "2025-04-13T20:04:28.559Z",
    "size": 375,
    "path": "../public/app-assets/fonts/flag-icon-css/flags/1x1/hn.svg.gz"
  },
  "/app-assets/fonts/flag-icon-css/flags/1x1/hr.svg": {
    "type": "image/svg+xml",
    "etag": "\"13c87-bx7nLTgQfPvkUb5gX8oxEYU7PXA\"",
    "mtime": "2025-04-13T20:04:20.398Z",
    "size": 81031,
    "path": "../public/app-assets/fonts/flag-icon-css/flags/1x1/hr.svg"
  },
  "/app-assets/fonts/flag-icon-css/flags/1x1/hr.svg.br": {
    "type": "image/svg+xml",
    "encoding": "br",
    "etag": "\"6e69-4gGA1bStqEnSoOCeggNWeK8U7+4\"",
    "mtime": "2025-04-13T20:04:28.624Z",
    "size": 28265,
    "path": "../public/app-assets/fonts/flag-icon-css/flags/1x1/hr.svg.br"
  },
  "/app-assets/fonts/flag-icon-css/flags/1x1/hr.svg.gz": {
    "type": "image/svg+xml",
    "encoding": "gzip",
    "etag": "\"81d2-qXJYTNxRatbLUzBJ6s1d2SUEBsY\"",
    "mtime": "2025-04-13T20:04:28.667Z",
    "size": 33234,
    "path": "../public/app-assets/fonts/flag-icon-css/flags/1x1/hr.svg.gz"
  },
  "/app-assets/fonts/flag-icon-css/flags/1x1/ht.svg": {
    "type": "image/svg+xml",
    "etag": "\"59e4-PGXFJg0emZ0+H3mkKCNHMl6tRi4\"",
    "mtime": "2025-04-13T20:04:20.397Z",
    "size": 23012,
    "path": "../public/app-assets/fonts/flag-icon-css/flags/1x1/ht.svg"
  },
  "/app-assets/fonts/flag-icon-css/flags/1x1/ht.svg.br": {
    "type": "image/svg+xml",
    "encoding": "br",
    "etag": "\"1f21-E242wJxPZfMThX1IDOeybVt8xEs\"",
    "mtime": "2025-04-13T20:04:28.559Z",
    "size": 7969,
    "path": "../public/app-assets/fonts/flag-icon-css/flags/1x1/ht.svg.br"
  },
  "/app-assets/fonts/flag-icon-css/flags/1x1/ht.svg.gz": {
    "type": "image/svg+xml",
    "encoding": "gzip",
    "etag": "\"2393-yAd6IOzl7H4VstdghmMWOb3nzpQ\"",
    "mtime": "2025-04-13T20:04:28.559Z",
    "size": 9107,
    "path": "../public/app-assets/fonts/flag-icon-css/flags/1x1/ht.svg.gz"
  },
  "/app-assets/fonts/flag-icon-css/flags/1x1/hu.svg": {
    "type": "image/svg+xml",
    "etag": "\"168-SdOTs1MxNsniFMHrvsTHFJ3klFk\"",
    "mtime": "2025-04-13T20:04:20.397Z",
    "size": 360,
    "path": "../public/app-assets/fonts/flag-icon-css/flags/1x1/hu.svg"
  },
  "/app-assets/fonts/flag-icon-css/flags/1x1/id.svg": {
    "type": "image/svg+xml",
    "etag": "\"129-xcI8+65zYgYbW9DXUGmJG94uxPA\"",
    "mtime": "2025-04-13T20:04:20.399Z",
    "size": 297,
    "path": "../public/app-assets/fonts/flag-icon-css/flags/1x1/id.svg"
  },
  "/app-assets/fonts/flag-icon-css/flags/1x1/ie.svg": {
    "type": "image/svg+xml",
    "etag": "\"16a-24HAs52+D3cm1D5oHvvhTGA2IQc\"",
    "mtime": "2025-04-13T20:04:20.397Z",
    "size": 362,
    "path": "../public/app-assets/fonts/flag-icon-css/flags/1x1/ie.svg"
  },
  "/app-assets/fonts/flag-icon-css/flags/1x1/il.svg": {
    "type": "image/svg+xml",
    "etag": "\"412-kJNhQO0jXVDiyHZ1uXIHxZMMqm4\"",
    "mtime": "2025-04-13T20:04:20.397Z",
    "size": 1042,
    "path": "../public/app-assets/fonts/flag-icon-css/flags/1x1/il.svg"
  },
  "/app-assets/fonts/flag-icon-css/flags/1x1/il.svg.br": {
    "type": "image/svg+xml",
    "encoding": "br",
    "etag": "\"1e5-4zvKdLIo8lpQyZnypJF0erlwnLQ\"",
    "mtime": "2025-04-13T20:04:28.559Z",
    "size": 485,
    "path": "../public/app-assets/fonts/flag-icon-css/flags/1x1/il.svg.br"
  },
  "/app-assets/fonts/flag-icon-css/flags/1x1/il.svg.gz": {
    "type": "image/svg+xml",
    "encoding": "gzip",
    "etag": "\"22d-e3FDCbOsU/XvcC7sffW3mFhLDF0\"",
    "mtime": "2025-04-13T20:04:28.559Z",
    "size": 557,
    "path": "../public/app-assets/fonts/flag-icon-css/flags/1x1/il.svg.gz"
  },
  "/app-assets/fonts/flag-icon-css/flags/1x1/im.svg": {
    "type": "image/svg+xml",
    "etag": "\"3d94-8FtLym6laozauwLCQUIbW8CXZU0\"",
    "mtime": "2025-04-13T20:04:20.399Z",
    "size": 15764,
    "path": "../public/app-assets/fonts/flag-icon-css/flags/1x1/im.svg"
  },
  "/app-assets/fonts/flag-icon-css/flags/1x1/im.svg.br": {
    "type": "image/svg+xml",
    "encoding": "br",
    "etag": "\"171f-Y1ZrI1NBxJqHmbgZFpee+Cns0Ww\"",
    "mtime": "2025-04-13T20:04:28.560Z",
    "size": 5919,
    "path": "../public/app-assets/fonts/flag-icon-css/flags/1x1/im.svg.br"
  },
  "/app-assets/fonts/flag-icon-css/flags/1x1/im.svg.gz": {
    "type": "image/svg+xml",
    "encoding": "gzip",
    "etag": "\"1a5e-373zRI3xiUdul28R4p2AvFRbJjY\"",
    "mtime": "2025-04-13T20:04:28.560Z",
    "size": 6750,
    "path": "../public/app-assets/fonts/flag-icon-css/flags/1x1/im.svg.gz"
  },
  "/app-assets/fonts/flag-icon-css/flags/1x1/in.svg": {
    "type": "image/svg+xml",
    "etag": "\"47c-HlXADWkIlfRXEtYU7D8od07rshw\"",
    "mtime": "2025-04-13T20:04:20.398Z",
    "size": 1148,
    "path": "../public/app-assets/fonts/flag-icon-css/flags/1x1/in.svg"
  },
  "/app-assets/fonts/flag-icon-css/flags/1x1/in.svg.br": {
    "type": "image/svg+xml",
    "encoding": "br",
    "etag": "\"159-QmhXYjiMzqW08/4QcEcB8sr91pQ\"",
    "mtime": "2025-04-13T20:04:28.559Z",
    "size": 345,
    "path": "../public/app-assets/fonts/flag-icon-css/flags/1x1/in.svg.br"
  },
  "/app-assets/fonts/flag-icon-css/flags/1x1/in.svg.gz": {
    "type": "image/svg+xml",
    "encoding": "gzip",
    "etag": "\"187-7VFikkptYM4nuRbFXO6tJtQOJcY\"",
    "mtime": "2025-04-13T20:04:28.559Z",
    "size": 391,
    "path": "../public/app-assets/fonts/flag-icon-css/flags/1x1/in.svg.gz"
  },
  "/app-assets/fonts/flag-icon-css/flags/1x1/io.svg": {
    "type": "image/svg+xml",
    "etag": "\"99df-dNx03N8pcIAFr4N8uB0HLRhDSyM\"",
    "mtime": "2025-04-13T20:04:20.398Z",
    "size": 39391,
    "path": "../public/app-assets/fonts/flag-icon-css/flags/1x1/io.svg"
  },
  "/app-assets/fonts/flag-icon-css/flags/1x1/io.svg.br": {
    "type": "image/svg+xml",
    "encoding": "br",
    "etag": "\"f2c-RoLXU9ld5gp/QKWoZ0p0OrbI4+4\"",
    "mtime": "2025-04-13T20:04:28.560Z",
    "size": 3884,
    "path": "../public/app-assets/fonts/flag-icon-css/flags/1x1/io.svg.br"
  },
  "/app-assets/fonts/flag-icon-css/flags/1x1/io.svg.gz": {
    "type": "image/svg+xml",
    "encoding": "gzip",
    "etag": "\"1205-L4y3ZtqOocmlojrOKye4p7/HXPQ\"",
    "mtime": "2025-04-13T20:04:28.560Z",
    "size": 4613,
    "path": "../public/app-assets/fonts/flag-icon-css/flags/1x1/io.svg.gz"
  },
  "/app-assets/fonts/flag-icon-css/flags/1x1/iq.svg": {
    "type": "image/svg+xml",
    "etag": "\"906-fRy4Yp5gZsoRrrmCoElIv6TkB0M\"",
    "mtime": "2025-04-13T20:04:20.399Z",
    "size": 2310,
    "path": "../public/app-assets/fonts/flag-icon-css/flags/1x1/iq.svg"
  },
  "/app-assets/fonts/flag-icon-css/flags/1x1/iq.svg.br": {
    "type": "image/svg+xml",
    "encoding": "br",
    "etag": "\"421-Er283ssfU7k5BrAx1PjFjcj/VbY\"",
    "mtime": "2025-04-13T20:04:28.559Z",
    "size": 1057,
    "path": "../public/app-assets/fonts/flag-icon-css/flags/1x1/iq.svg.br"
  },
  "/app-assets/fonts/flag-icon-css/flags/1x1/iq.svg.gz": {
    "type": "image/svg+xml",
    "encoding": "gzip",
    "etag": "\"47a-+zzkVweBw1R/wN9hHcwo1NLhoOc\"",
    "mtime": "2025-04-13T20:04:28.559Z",
    "size": 1146,
    "path": "../public/app-assets/fonts/flag-icon-css/flags/1x1/iq.svg.gz"
  },
  "/app-assets/fonts/flag-icon-css/flags/1x1/ir.svg": {
    "type": "image/svg+xml",
    "etag": "\"b6df-89eO/wtuQAXaz2K9/wzD/htPMN4\"",
    "mtime": "2025-04-13T20:04:20.401Z",
    "size": 46815,
    "path": "../public/app-assets/fonts/flag-icon-css/flags/1x1/ir.svg"
  },
  "/app-assets/fonts/flag-icon-css/flags/1x1/ir.svg.br": {
    "type": "image/svg+xml",
    "encoding": "br",
    "etag": "\"9ab-0kyCitJwjzCv5TW3TwWyBmX+aSc\"",
    "mtime": "2025-04-13T20:04:28.560Z",
    "size": 2475,
    "path": "../public/app-assets/fonts/flag-icon-css/flags/1x1/ir.svg.br"
  },
  "/app-assets/fonts/flag-icon-css/flags/1x1/ir.svg.gz": {
    "type": "image/svg+xml",
    "encoding": "gzip",
    "etag": "\"ddf-abBj5RBPFUfxNza5opMaBaVAVuc\"",
    "mtime": "2025-04-13T20:04:28.560Z",
    "size": 3551,
    "path": "../public/app-assets/fonts/flag-icon-css/flags/1x1/ir.svg.gz"
  },
  "/app-assets/fonts/flag-icon-css/flags/1x1/is.svg": {
    "type": "image/svg+xml",
    "etag": "\"49d-nmzbBP9R6nUnuyWhET7j+yYxus4\"",
    "mtime": "2025-04-13T20:04:20.400Z",
    "size": 1181,
    "path": "../public/app-assets/fonts/flag-icon-css/flags/1x1/is.svg"
  },
  "/app-assets/fonts/flag-icon-css/flags/1x1/is.svg.br": {
    "type": "image/svg+xml",
    "encoding": "br",
    "etag": "\"237-pKWMcalUwCsdRoeGLqKdyoox4JE\"",
    "mtime": "2025-04-13T20:04:28.560Z",
    "size": 567,
    "path": "../public/app-assets/fonts/flag-icon-css/flags/1x1/is.svg.br"
  },
  "/app-assets/fonts/flag-icon-css/flags/1x1/is.svg.gz": {
    "type": "image/svg+xml",
    "encoding": "gzip",
    "etag": "\"285-hLB7Qx8NRnacgGg5utszWU7AfrM\"",
    "mtime": "2025-04-13T20:04:28.560Z",
    "size": 645,
    "path": "../public/app-assets/fonts/flag-icon-css/flags/1x1/is.svg.gz"
  },
  "/app-assets/fonts/flag-icon-css/flags/1x1/it.svg": {
    "type": "image/svg+xml",
    "etag": "\"36b-mcnwZzSHxyrwPVhpfpHSED6A+nI\"",
    "mtime": "2025-04-13T20:04:20.399Z",
    "size": 875,
    "path": "../public/app-assets/fonts/flag-icon-css/flags/1x1/it.svg"
  },
  "/app-assets/fonts/flag-icon-css/flags/1x1/je.svg": {
    "type": "image/svg+xml",
    "etag": "\"2b0d-BsWW+WWfKbfXHX1tZQAeuhmjfvk\"",
    "mtime": "2025-04-13T20:04:20.399Z",
    "size": 11021,
    "path": "../public/app-assets/fonts/flag-icon-css/flags/1x1/je.svg"
  },
  "/app-assets/fonts/flag-icon-css/flags/1x1/je.svg.br": {
    "type": "image/svg+xml",
    "encoding": "br",
    "etag": "\"eba-arE3Ja/jQO/x3Mc/KUXcEkl4TU0\"",
    "mtime": "2025-04-13T20:04:28.560Z",
    "size": 3770,
    "path": "../public/app-assets/fonts/flag-icon-css/flags/1x1/je.svg.br"
  },
  "/app-assets/fonts/flag-icon-css/flags/1x1/je.svg.gz": {
    "type": "image/svg+xml",
    "encoding": "gzip",
    "etag": "\"10ce-rH6m3fe+fvrD8udIC1GV5t8LziI\"",
    "mtime": "2025-04-13T20:04:28.560Z",
    "size": 4302,
    "path": "../public/app-assets/fonts/flag-icon-css/flags/1x1/je.svg.gz"
  },
  "/app-assets/fonts/flag-icon-css/flags/1x1/jm.svg": {
    "type": "image/svg+xml",
    "etag": "\"42a-nqw8esYO5ei+jqa7QS8MJ5sAMLs\"",
    "mtime": "2025-04-13T20:04:20.416Z",
    "size": 1066,
    "path": "../public/app-assets/fonts/flag-icon-css/flags/1x1/jm.svg"
  },
  "/app-assets/fonts/flag-icon-css/flags/1x1/jm.svg.br": {
    "type": "image/svg+xml",
    "encoding": "br",
    "etag": "\"1b7-2AcUugErANh5nx/xW7BTEriT/JY\"",
    "mtime": "2025-04-13T20:04:28.560Z",
    "size": 439,
    "path": "../public/app-assets/fonts/flag-icon-css/flags/1x1/jm.svg.br"
  },
  "/app-assets/fonts/flag-icon-css/flags/1x1/jm.svg.gz": {
    "type": "image/svg+xml",
    "encoding": "gzip",
    "etag": "\"20b-yH2OdiYJxzIIjWhmsUBB1oX/2q0\"",
    "mtime": "2025-04-13T20:04:28.560Z",
    "size": 523,
    "path": "../public/app-assets/fonts/flag-icon-css/flags/1x1/jm.svg.gz"
  },
  "/app-assets/fonts/flag-icon-css/flags/1x1/jo.svg": {
    "type": "image/svg+xml",
    "etag": "\"59c-c/FSnJMGeZZFHWKUUM6QPCF5sKc\"",
    "mtime": "2025-04-13T20:04:20.400Z",
    "size": 1436,
    "path": "../public/app-assets/fonts/flag-icon-css/flags/1x1/jo.svg"
  },
  "/app-assets/fonts/flag-icon-css/flags/1x1/jo.svg.br": {
    "type": "image/svg+xml",
    "encoding": "br",
    "etag": "\"261-ghuCV0xpZTVBXj4zkfGyQWIQhXg\"",
    "mtime": "2025-04-13T20:04:28.560Z",
    "size": 609,
    "path": "../public/app-assets/fonts/flag-icon-css/flags/1x1/jo.svg.br"
  },
  "/app-assets/fonts/flag-icon-css/flags/1x1/jo.svg.gz": {
    "type": "image/svg+xml",
    "encoding": "gzip",
    "etag": "\"2c9-U+9OtkrQ4M6Bg7IPEFBCUWIaufU\"",
    "mtime": "2025-04-13T20:04:28.560Z",
    "size": 713,
    "path": "../public/app-assets/fonts/flag-icon-css/flags/1x1/jo.svg.gz"
  },
  "/app-assets/fonts/flag-icon-css/flags/1x1/jp.svg": {
    "type": "image/svg+xml",
    "etag": "\"53a-JH5U07eCDY8mF+6lw7a6AajVAns\"",
    "mtime": "2025-04-13T20:04:20.401Z",
    "size": 1338,
    "path": "../public/app-assets/fonts/flag-icon-css/flags/1x1/jp.svg"
  },
  "/app-assets/fonts/flag-icon-css/flags/1x1/jp.svg.br": {
    "type": "image/svg+xml",
    "encoding": "br",
    "etag": "\"246-3M58sfOMp2SKLMRHBFSNLEUZwmY\"",
    "mtime": "2025-04-13T20:04:28.560Z",
    "size": 582,
    "path": "../public/app-assets/fonts/flag-icon-css/flags/1x1/jp.svg.br"
  },
  "/app-assets/fonts/flag-icon-css/flags/1x1/jp.svg.gz": {
    "type": "image/svg+xml",
    "encoding": "gzip",
    "etag": "\"2aa-1NuO8yJbq3I5MqwhW/IW1Zu8rLM\"",
    "mtime": "2025-04-13T20:04:28.560Z",
    "size": 682,
    "path": "../public/app-assets/fonts/flag-icon-css/flags/1x1/jp.svg.gz"
  },
  "/app-assets/fonts/flag-icon-css/flags/1x1/ke.svg": {
    "type": "image/svg+xml",
    "etag": "\"60c-Cbe9/vnb7HBv1BDSRoEdHpUP4/Q\"",
    "mtime": "2025-04-13T20:04:20.400Z",
    "size": 1548,
    "path": "../public/app-assets/fonts/flag-icon-css/flags/1x1/ke.svg"
  },
  "/app-assets/fonts/flag-icon-css/flags/1x1/ke.svg.br": {
    "type": "image/svg+xml",
    "encoding": "br",
    "etag": "\"21c-zOTc0fElRIC1Uswo4BywSaajz1Y\"",
    "mtime": "2025-04-13T20:04:28.560Z",
    "size": 540,
    "path": "../public/app-assets/fonts/flag-icon-css/flags/1x1/ke.svg.br"
  },
  "/app-assets/fonts/flag-icon-css/flags/1x1/ke.svg.gz": {
    "type": "image/svg+xml",
    "encoding": "gzip",
    "etag": "\"254-8DBfJpDLxNlFmwVXmDgSWoATZHM\"",
    "mtime": "2025-04-13T20:04:28.560Z",
    "size": 596,
    "path": "../public/app-assets/fonts/flag-icon-css/flags/1x1/ke.svg.gz"
  },
  "/app-assets/fonts/flag-icon-css/flags/1x1/kg.svg": {
    "type": "image/svg+xml",
    "etag": "\"1790-Z5GG41TZd+s0h80Ly9XesY2RbE8\"",
    "mtime": "2025-04-13T20:04:20.399Z",
    "size": 6032,
    "path": "../public/app-assets/fonts/flag-icon-css/flags/1x1/kg.svg"
  },
  "/app-assets/fonts/flag-icon-css/flags/1x1/kg.svg.br": {
    "type": "image/svg+xml",
    "encoding": "br",
    "etag": "\"944-UBItqbpxy/u4nK94jEmLq/fv/nw\"",
    "mtime": "2025-04-13T20:04:28.560Z",
    "size": 2372,
    "path": "../public/app-assets/fonts/flag-icon-css/flags/1x1/kg.svg.br"
  },
  "/app-assets/fonts/flag-icon-css/flags/1x1/kg.svg.gz": {
    "type": "image/svg+xml",
    "encoding": "gzip",
    "etag": "\"ace-3iq2LqywXBkFgysQJ1gkq03akis\"",
    "mtime": "2025-04-13T20:04:28.560Z",
    "size": 2766,
    "path": "../public/app-assets/fonts/flag-icon-css/flags/1x1/kg.svg.gz"
  },
  "/app-assets/fonts/flag-icon-css/flags/1x1/kh.svg": {
    "type": "image/svg+xml",
    "etag": "\"4d0d-SnclsNX/oOQzyjD0teamkaUt0lE\"",
    "mtime": "2025-04-13T20:04:20.400Z",
    "size": 19725,
    "path": "../public/app-assets/fonts/flag-icon-css/flags/1x1/kh.svg"
  },
  "/app-assets/fonts/flag-icon-css/flags/1x1/kh.svg.br": {
    "type": "image/svg+xml",
    "encoding": "br",
    "etag": "\"a29-NAI14oH6pjvGyUIFJDwXma37/WA\"",
    "mtime": "2025-04-13T20:04:28.561Z",
    "size": 2601,
    "path": "../public/app-assets/fonts/flag-icon-css/flags/1x1/kh.svg.br"
  },
  "/app-assets/fonts/flag-icon-css/flags/1x1/kh.svg.gz": {
    "type": "image/svg+xml",
    "encoding": "gzip",
    "etag": "\"c3a-JPiRJXpGnQqYFax7o+4uf7ESmYA\"",
    "mtime": "2025-04-13T20:04:28.560Z",
    "size": 3130,
    "path": "../public/app-assets/fonts/flag-icon-css/flags/1x1/kh.svg.gz"
  },
  "/app-assets/fonts/flag-icon-css/flags/1x1/ki.svg": {
    "type": "image/svg+xml",
    "etag": "\"2914-DIGYRRiud+BlYzh/SoMCabalOrA\"",
    "mtime": "2025-04-13T20:04:20.400Z",
    "size": 10516,
    "path": "../public/app-assets/fonts/flag-icon-css/flags/1x1/ki.svg"
  },
  "/app-assets/fonts/flag-icon-css/flags/1x1/ki.svg.br": {
    "type": "image/svg+xml",
    "encoding": "br",
    "etag": "\"880-EnNySe2jT7OueJAqOJSefN7WC1Y\"",
    "mtime": "2025-04-13T20:04:28.560Z",
    "size": 2176,
    "path": "../public/app-assets/fonts/flag-icon-css/flags/1x1/ki.svg.br"
  },
  "/app-assets/fonts/flag-icon-css/flags/1x1/ki.svg.gz": {
    "type": "image/svg+xml",
    "encoding": "gzip",
    "etag": "\"9e9-ACntoooKNUBGRxFPRn62cF2dXtI\"",
    "mtime": "2025-04-13T20:04:28.560Z",
    "size": 2537,
    "path": "../public/app-assets/fonts/flag-icon-css/flags/1x1/ki.svg.gz"
  },
  "/app-assets/fonts/flag-icon-css/flags/1x1/km.svg": {
    "type": "image/svg+xml",
    "etag": "\"cae-5kPG9AelDArlTYYZArs5UfyxQ9s\"",
    "mtime": "2025-04-13T20:04:20.399Z",
    "size": 3246,
    "path": "../public/app-assets/fonts/flag-icon-css/flags/1x1/km.svg"
  },
  "/app-assets/fonts/flag-icon-css/flags/1x1/km.svg.br": {
    "type": "image/svg+xml",
    "encoding": "br",
    "etag": "\"358-U8UJe0qLVBvRK2Z9UB9XPi0Pqao\"",
    "mtime": "2025-04-13T20:04:28.560Z",
    "size": 856,
    "path": "../public/app-assets/fonts/flag-icon-css/flags/1x1/km.svg.br"
  },
  "/app-assets/fonts/flag-icon-css/flags/1x1/km.svg.gz": {
    "type": "image/svg+xml",
    "encoding": "gzip",
    "etag": "\"3f5-n+2lAs4yki92XLv5LwrQIasncdc\"",
    "mtime": "2025-04-13T20:04:28.560Z",
    "size": 1013,
    "path": "../public/app-assets/fonts/flag-icon-css/flags/1x1/km.svg.gz"
  },
  "/app-assets/fonts/flag-icon-css/flags/1x1/kn.svg": {
    "type": "image/svg+xml",
    "etag": "\"74f-I/HEncsjdIh7RrB7cvTFTTVGElA\"",
    "mtime": "2025-04-13T20:04:20.401Z",
    "size": 1871,
    "path": "../public/app-assets/fonts/flag-icon-css/flags/1x1/kn.svg"
  },
  "/app-assets/fonts/flag-icon-css/flags/1x1/kn.svg.br": {
    "type": "image/svg+xml",
    "encoding": "br",
    "etag": "\"2fe-cNyQQU7r5UMd+4zIYWlCVQW+mwA\"",
    "mtime": "2025-04-13T20:04:28.560Z",
    "size": 766,
    "path": "../public/app-assets/fonts/flag-icon-css/flags/1x1/kn.svg.br"
  },
  "/app-assets/fonts/flag-icon-css/flags/1x1/kn.svg.gz": {
    "type": "image/svg+xml",
    "encoding": "gzip",
    "etag": "\"361-42Xmvynt9gYkYs3lHLYQoaLsYOo\"",
    "mtime": "2025-04-13T20:04:28.560Z",
    "size": 865,
    "path": "../public/app-assets/fonts/flag-icon-css/flags/1x1/kn.svg.gz"
  },
  "/app-assets/fonts/flag-icon-css/flags/1x1/kp.svg": {
    "type": "image/svg+xml",
    "etag": "\"780-SeGoQfJf2g6cBZ3F+H9xrTvmwUk\"",
    "mtime": "2025-04-13T20:04:20.400Z",
    "size": 1920,
    "path": "../public/app-assets/fonts/flag-icon-css/flags/1x1/kp.svg"
  },
  "/app-assets/fonts/flag-icon-css/flags/1x1/kp.svg.br": {
    "type": "image/svg+xml",
    "encoding": "br",
    "etag": "\"2df-KhdL5KDq6CoSHErSZuhunB18eb8\"",
    "mtime": "2025-04-13T20:04:28.560Z",
    "size": 735,
    "path": "../public/app-assets/fonts/flag-icon-css/flags/1x1/kp.svg.br"
  },
  "/app-assets/fonts/flag-icon-css/flags/1x1/kp.svg.gz": {
    "type": "image/svg+xml",
    "encoding": "gzip",
    "etag": "\"358-lTYyIohU3SmCsCcvrL5KZsF1M70\"",
    "mtime": "2025-04-13T20:04:28.560Z",
    "size": 856,
    "path": "../public/app-assets/fonts/flag-icon-css/flags/1x1/kp.svg.gz"
  },
  "/app-assets/fonts/flag-icon-css/flags/1x1/kr.svg": {
    "type": "image/svg+xml",
    "etag": "\"101d-90IkFiMe5mPXW3+yb5HaixOrv9E\"",
    "mtime": "2025-04-13T20:04:20.400Z",
    "size": 4125,
    "path": "../public/app-assets/fonts/flag-icon-css/flags/1x1/kr.svg"
  },
  "/app-assets/fonts/flag-icon-css/flags/1x1/kr.svg.br": {
    "type": "image/svg+xml",
    "encoding": "br",
    "etag": "\"3e2-p6p9bDYP8Ojte80PqBA0wddGfs4\"",
    "mtime": "2025-04-13T20:04:28.560Z",
    "size": 994,
    "path": "../public/app-assets/fonts/flag-icon-css/flags/1x1/kr.svg.br"
  },
  "/app-assets/fonts/flag-icon-css/flags/1x1/kr.svg.gz": {
    "type": "image/svg+xml",
    "encoding": "gzip",
    "etag": "\"496-aJgzSf5krgwZnp4mSAytbdIMuI4\"",
    "mtime": "2025-04-13T20:04:28.560Z",
    "size": 1174,
    "path": "../public/app-assets/fonts/flag-icon-css/flags/1x1/kr.svg.gz"
  },
  "/app-assets/fonts/flag-icon-css/flags/1x1/kw.svg": {
    "type": "image/svg+xml",
    "etag": "\"4ae-bUn0GKNmwE+C1dBlbN8BAKWSGTc\"",
    "mtime": "2025-04-13T20:04:20.400Z",
    "size": 1198,
    "path": "../public/app-assets/fonts/flag-icon-css/flags/1x1/kw.svg"
  },
  "/app-assets/fonts/flag-icon-css/flags/1x1/kw.svg.br": {
    "type": "image/svg+xml",
    "encoding": "br",
    "etag": "\"20b-/Wr4Hqm3RNt7vNEXi8TOslG0ZOU\"",
    "mtime": "2025-04-13T20:04:28.560Z",
    "size": 523,
    "path": "../public/app-assets/fonts/flag-icon-css/flags/1x1/kw.svg.br"
  },
  "/app-assets/fonts/flag-icon-css/flags/1x1/kw.svg.gz": {
    "type": "image/svg+xml",
    "encoding": "gzip",
    "etag": "\"262-qp3VZgOChg6zndB5UslB1j1Z0nU\"",
    "mtime": "2025-04-13T20:04:28.560Z",
    "size": 610,
    "path": "../public/app-assets/fonts/flag-icon-css/flags/1x1/kw.svg.gz"
  },
  "/app-assets/fonts/flag-icon-css/flags/1x1/ky.svg": {
    "type": "image/svg+xml",
    "etag": "\"b091-f83KAOsZpwDx+6GBv/hscfdYRvs\"",
    "mtime": "2025-04-13T20:04:20.401Z",
    "size": 45201,
    "path": "../public/app-assets/fonts/flag-icon-css/flags/1x1/ky.svg"
  },
  "/app-assets/fonts/flag-icon-css/flags/1x1/ky.svg.br": {
    "type": "image/svg+xml",
    "encoding": "br",
    "etag": "\"3343-tXMEbFz2d+1MOpZrS541LIbPkCI\"",
    "mtime": "2025-04-13T20:04:28.561Z",
    "size": 13123,
    "path": "../public/app-assets/fonts/flag-icon-css/flags/1x1/ky.svg.br"
  },
  "/app-assets/fonts/flag-icon-css/flags/1x1/ky.svg.gz": {
    "type": "image/svg+xml",
    "encoding": "gzip",
    "etag": "\"3a7a-5UYndgSmORqCF8n8I4k5jaicgQc\"",
    "mtime": "2025-04-13T20:04:28.560Z",
    "size": 14970,
    "path": "../public/app-assets/fonts/flag-icon-css/flags/1x1/ky.svg.gz"
  },
  "/app-assets/fonts/flag-icon-css/flags/1x1/kz.svg": {
    "type": "image/svg+xml",
    "etag": "\"516e-6+a+mAd9hMTWISNb7vQw1en9tEI\"",
    "mtime": "2025-04-13T20:04:20.402Z",
    "size": 20846,
    "path": "../public/app-assets/fonts/flag-icon-css/flags/1x1/kz.svg"
  },
  "/app-assets/fonts/flag-icon-css/flags/1x1/kz.svg.br": {
    "type": "image/svg+xml",
    "encoding": "br",
    "etag": "\"1397-von5Af7ofRKIT3y5KPE0h5Qe8gQ\"",
    "mtime": "2025-04-13T20:04:28.561Z",
    "size": 5015,
    "path": "../public/app-assets/fonts/flag-icon-css/flags/1x1/kz.svg.br"
  },
  "/app-assets/fonts/flag-icon-css/flags/1x1/kz.svg.gz": {
    "type": "image/svg+xml",
    "encoding": "gzip",
    "etag": "\"1634-HdgaKIGWd1ijEapNMYL09ewc8pE\"",
    "mtime": "2025-04-13T20:04:28.560Z",
    "size": 5684,
    "path": "../public/app-assets/fonts/flag-icon-css/flags/1x1/kz.svg.gz"
  },
  "/app-assets/fonts/flag-icon-css/flags/1x1/la.svg": {
    "type": "image/svg+xml",
    "etag": "\"515-MCsD+MXcMKrDZZHhGzvRIGOhDYk\"",
    "mtime": "2025-04-13T20:04:20.400Z",
    "size": 1301,
    "path": "../public/app-assets/fonts/flag-icon-css/flags/1x1/la.svg"
  },
  "/app-assets/fonts/flag-icon-css/flags/1x1/la.svg.br": {
    "type": "image/svg+xml",
    "encoding": "br",
    "etag": "\"236-4ihheNHXb18XSI/BNE4T6M+mzB0\"",
    "mtime": "2025-04-13T20:04:28.561Z",
    "size": 566,
    "path": "../public/app-assets/fonts/flag-icon-css/flags/1x1/la.svg.br"
  },
  "/app-assets/fonts/flag-icon-css/flags/1x1/la.svg.gz": {
    "type": "image/svg+xml",
    "encoding": "gzip",
    "etag": "\"291-QjzLuQ0DfuCwbeymEB1RWj5JSRc\"",
    "mtime": "2025-04-13T20:04:28.561Z",
    "size": 657,
    "path": "../public/app-assets/fonts/flag-icon-css/flags/1x1/la.svg.gz"
  },
  "/app-assets/fonts/flag-icon-css/flags/1x1/lb.svg": {
    "type": "image/svg+xml",
    "etag": "\"1d3d-Ycoj7yycSDq7ffOA6YGQYPiFeec\"",
    "mtime": "2025-04-13T20:04:20.401Z",
    "size": 7485,
    "path": "../public/app-assets/fonts/flag-icon-css/flags/1x1/lb.svg"
  },
  "/app-assets/fonts/flag-icon-css/flags/1x1/lb.svg.br": {
    "type": "image/svg+xml",
    "encoding": "br",
    "etag": "\"7de-5Un5417TKvEy+DKEZlq1aJe3FM4\"",
    "mtime": "2025-04-13T20:04:28.561Z",
    "size": 2014,
    "path": "../public/app-assets/fonts/flag-icon-css/flags/1x1/lb.svg.br"
  },
  "/app-assets/fonts/flag-icon-css/flags/1x1/lb.svg.gz": {
    "type": "image/svg+xml",
    "encoding": "gzip",
    "etag": "\"92b-fpAkAXN81gneTqZcBbA5ElvKRgE\"",
    "mtime": "2025-04-13T20:04:28.561Z",
    "size": 2347,
    "path": "../public/app-assets/fonts/flag-icon-css/flags/1x1/lb.svg.gz"
  },
  "/app-assets/fonts/flag-icon-css/flags/1x1/lc.svg": {
    "type": "image/svg+xml",
    "etag": "\"383-gPq65ShTsrTmfW1SoxX0kmQ/xtc\"",
    "mtime": "2025-04-13T20:04:20.401Z",
    "size": 899,
    "path": "../public/app-assets/fonts/flag-icon-css/flags/1x1/lc.svg"
  },
  "/app-assets/fonts/flag-icon-css/flags/1x1/li.svg": {
    "type": "image/svg+xml",
    "etag": "\"30c6-Ntdy6PFMK/SODwElESTGiMOO9h8\"",
    "mtime": "2025-04-13T20:04:20.401Z",
    "size": 12486,
    "path": "../public/app-assets/fonts/flag-icon-css/flags/1x1/li.svg"
  },
  "/app-assets/fonts/flag-icon-css/flags/1x1/li.svg.br": {
    "type": "image/svg+xml",
    "encoding": "br",
    "etag": "\"129e-6F7+XMzsfiTwomzRuKzrp9dO0x8\"",
    "mtime": "2025-04-13T20:04:28.561Z",
    "size": 4766,
    "path": "../public/app-assets/fonts/flag-icon-css/flags/1x1/li.svg.br"
  },
  "/app-assets/fonts/flag-icon-css/flags/1x1/li.svg.gz": {
    "type": "image/svg+xml",
    "encoding": "gzip",
    "etag": "\"14c6-e9cclqI04UzQGmATVjjdJlZptWs\"",
    "mtime": "2025-04-13T20:04:28.561Z",
    "size": 5318,
    "path": "../public/app-assets/fonts/flag-icon-css/flags/1x1/li.svg.gz"
  },
  "/app-assets/fonts/flag-icon-css/flags/1x1/lk.svg": {
    "type": "image/svg+xml",
    "etag": "\"44f3-72HGXehGrzcprRNd7OVynSbIhxU\"",
    "mtime": "2025-04-13T20:04:20.402Z",
    "size": 17651,
    "path": "../public/app-assets/fonts/flag-icon-css/flags/1x1/lk.svg"
  },
  "/app-assets/fonts/flag-icon-css/flags/1x1/lk.svg.br": {
    "type": "image/svg+xml",
    "encoding": "br",
    "etag": "\"1b5f-sWwBDteP3ZgAqc0O7n42vy+pJH4\"",
    "mtime": "2025-04-13T20:04:28.561Z",
    "size": 7007,
    "path": "../public/app-assets/fonts/flag-icon-css/flags/1x1/lk.svg.br"
  },
  "/app-assets/fonts/flag-icon-css/flags/1x1/lk.svg.gz": {
    "type": "image/svg+xml",
    "encoding": "gzip",
    "etag": "\"1efb-vSd2DNuBQE49ZhBIlVPDv1albmw\"",
    "mtime": "2025-04-13T20:04:28.561Z",
    "size": 7931,
    "path": "../public/app-assets/fonts/flag-icon-css/flags/1x1/lk.svg.gz"
  },
  "/app-assets/fonts/flag-icon-css/flags/1x1/lr.svg": {
    "type": "image/svg+xml",
    "etag": "\"7a3-4XxyMo8vxixHnndYNc7g+LGF6Lc\"",
    "mtime": "2025-04-13T20:04:20.403Z",
    "size": 1955,
    "path": "../public/app-assets/fonts/flag-icon-css/flags/1x1/lr.svg"
  },
  "/app-assets/fonts/flag-icon-css/flags/1x1/lr.svg.br": {
    "type": "image/svg+xml",
    "encoding": "br",
    "etag": "\"28a-CCZdDb5VK5jx+Fpr6tETrY5uyH0\"",
    "mtime": "2025-04-13T20:04:28.561Z",
    "size": 650,
    "path": "../public/app-assets/fonts/flag-icon-css/flags/1x1/lr.svg.br"
  },
  "/app-assets/fonts/flag-icon-css/flags/1x1/lr.svg.gz": {
    "type": "image/svg+xml",
    "encoding": "gzip",
    "etag": "\"2f7-jxJUOpI974fEkhowU0Sj+2z5nYk\"",
    "mtime": "2025-04-13T20:04:28.561Z",
    "size": 759,
    "path": "../public/app-assets/fonts/flag-icon-css/flags/1x1/lr.svg.gz"
  },
  "/app-assets/fonts/flag-icon-css/flags/1x1/ls.svg": {
    "type": "image/svg+xml",
    "etag": "\"1828-9x2ElT3YUHAfF66DkTruoeORMMM\"",
    "mtime": "2025-04-13T20:04:20.402Z",
    "size": 6184,
    "path": "../public/app-assets/fonts/flag-icon-css/flags/1x1/ls.svg"
  },
  "/app-assets/fonts/flag-icon-css/flags/1x1/ls.svg.br": {
    "type": "image/svg+xml",
    "encoding": "br",
    "etag": "\"6ee-/SYWfkOQaNhga0vzRpn5c5sYoL8\"",
    "mtime": "2025-04-13T20:04:28.561Z",
    "size": 1774,
    "path": "../public/app-assets/fonts/flag-icon-css/flags/1x1/ls.svg.br"
  },
  "/app-assets/fonts/flag-icon-css/flags/1x1/ls.svg.gz": {
    "type": "image/svg+xml",
    "encoding": "gzip",
    "etag": "\"7f1-gAjPRdkwq8cTXKcUXgY+bsXmSO8\"",
    "mtime": "2025-04-13T20:04:28.561Z",
    "size": 2033,
    "path": "../public/app-assets/fonts/flag-icon-css/flags/1x1/ls.svg.gz"
  },
  "/app-assets/fonts/flag-icon-css/flags/1x1/lt.svg": {
    "type": "image/svg+xml",
    "etag": "\"3f8-aLaMx3HmpTmDoiVv4XLYcbnmdBE\"",
    "mtime": "2025-04-13T20:04:20.410Z",
    "size": 1016,
    "path": "../public/app-assets/fonts/flag-icon-css/flags/1x1/lt.svg"
  },
  "/app-assets/fonts/flag-icon-css/flags/1x1/lu.svg": {
    "type": "image/svg+xml",
    "etag": "\"35d-D2tssaBSWcjQiltoSWsTgq8jF6Q\"",
    "mtime": "2025-04-13T20:04:20.401Z",
    "size": 861,
    "path": "../public/app-assets/fonts/flag-icon-css/flags/1x1/lu.svg"
  },
  "/app-assets/fonts/flag-icon-css/flags/1x1/lv.svg": {
    "type": "image/svg+xml",
    "etag": "\"37a-IgxNqcrUglQcBJUyYo8iqCzQ8yM\"",
    "mtime": "2025-04-13T20:04:20.401Z",
    "size": 890,
    "path": "../public/app-assets/fonts/flag-icon-css/flags/1x1/lv.svg"
  },
  "/app-assets/fonts/flag-icon-css/flags/1x1/ly.svg": {
    "type": "image/svg+xml",
    "etag": "\"490-KbyeaktLIJTm5fp06oUz7WLtetY\"",
    "mtime": "2025-04-13T20:04:20.403Z",
    "size": 1168,
    "path": "../public/app-assets/fonts/flag-icon-css/flags/1x1/ly.svg"
  },
  "/app-assets/fonts/flag-icon-css/flags/1x1/ly.svg.br": {
    "type": "image/svg+xml",
    "encoding": "br",
    "etag": "\"1f5-8AoaFEXG64XPIxGGhX045f+A+Xo\"",
    "mtime": "2025-04-13T20:04:28.561Z",
    "size": 501,
    "path": "../public/app-assets/fonts/flag-icon-css/flags/1x1/ly.svg.br"
  },
  "/app-assets/fonts/flag-icon-css/flags/1x1/ly.svg.gz": {
    "type": "image/svg+xml",
    "encoding": "gzip",
    "etag": "\"24d-Z25Q+Rt/K/1yKu+V/TvEdA1R+Rg\"",
    "mtime": "2025-04-13T20:04:28.561Z",
    "size": 589,
    "path": "../public/app-assets/fonts/flag-icon-css/flags/1x1/ly.svg.gz"
  },
  "/app-assets/fonts/flag-icon-css/flags/1x1/ma.svg": {
    "type": "image/svg+xml",
    "etag": "\"104-qT0v0xlektmyBy3H5rqG2PVJxos\"",
    "mtime": "2025-04-13T20:04:20.403Z",
    "size": 260,
    "path": "../public/app-assets/fonts/flag-icon-css/flags/1x1/ma.svg"
  },
  "/app-assets/fonts/flag-icon-css/flags/1x1/mc.svg": {
    "type": "image/svg+xml",
    "etag": "\"317-hoknK+qSd7Q9UohOEMJbaw73r1k\"",
    "mtime": "2025-04-13T20:04:20.403Z",
    "size": 791,
    "path": "../public/app-assets/fonts/flag-icon-css/flags/1x1/mc.svg"
  },
  "/app-assets/fonts/flag-icon-css/flags/1x1/md.svg": {
    "type": "image/svg+xml",
    "etag": "\"48c7-7StdoOjySU9fi15bh7TU48oHRjM\"",
    "mtime": "2025-04-13T20:04:20.403Z",
    "size": 18631,
    "path": "../public/app-assets/fonts/flag-icon-css/flags/1x1/md.svg"
  },
  "/app-assets/fonts/flag-icon-css/flags/1x1/md.svg.br": {
    "type": "image/svg+xml",
    "encoding": "br",
    "etag": "\"ce4-UP1U68ePfbI6030O+2sYPWGGsMc\"",
    "mtime": "2025-04-13T20:04:28.561Z",
    "size": 3300,
    "path": "../public/app-assets/fonts/flag-icon-css/flags/1x1/md.svg.br"
  },
  "/app-assets/fonts/flag-icon-css/flags/1x1/md.svg.gz": {
    "type": "image/svg+xml",
    "encoding": "gzip",
    "etag": "\"eae-nvbv1G12BREo+uF4Z3L07pDZ6n0\"",
    "mtime": "2025-04-13T20:04:28.561Z",
    "size": 3758,
    "path": "../public/app-assets/fonts/flag-icon-css/flags/1x1/md.svg.gz"
  },
  "/app-assets/fonts/flag-icon-css/flags/1x1/me.svg": {
    "type": "image/svg+xml",
    "etag": "\"1ff8f-MxVV0g2MSsKCvPeGV0hMXKExpyo\"",
    "mtime": "2025-04-13T20:04:20.403Z",
    "size": 130959,
    "path": "../public/app-assets/fonts/flag-icon-css/flags/1x1/me.svg"
  },
  "/app-assets/fonts/flag-icon-css/flags/1x1/me.svg.br": {
    "type": "image/svg+xml",
    "encoding": "br",
    "etag": "\"a74a-+MLXEA4vws50FofgmlCQGuoOVEk\"",
    "mtime": "2025-04-13T20:04:28.668Z",
    "size": 42826,
    "path": "../public/app-assets/fonts/flag-icon-css/flags/1x1/me.svg.br"
  },
  "/app-assets/fonts/flag-icon-css/flags/1x1/me.svg.gz": {
    "type": "image/svg+xml",
    "encoding": "gzip",
    "etag": "\"ba07-lYJl4IV2Q8INnkhRfqkt86Sq4NU\"",
    "mtime": "2025-04-13T20:04:28.668Z",
    "size": 47623,
    "path": "../public/app-assets/fonts/flag-icon-css/flags/1x1/me.svg.gz"
  },
  "/app-assets/fonts/flag-icon-css/flags/1x1/mf.svg": {
    "type": "image/svg+xml",
    "etag": "\"369-1L2rEnHDs38qVNgAyHV8s7YbDu0\"",
    "mtime": "2025-04-13T20:04:20.404Z",
    "size": 873,
    "path": "../public/app-assets/fonts/flag-icon-css/flags/1x1/mf.svg"
  },
  "/app-assets/fonts/flag-icon-css/flags/1x1/mg.svg": {
    "type": "image/svg+xml",
    "etag": "\"386-WH11WrdCKf7C/IeBver9/dnOEqI\"",
    "mtime": "2025-04-13T20:04:20.403Z",
    "size": 902,
    "path": "../public/app-assets/fonts/flag-icon-css/flags/1x1/mg.svg"
  },
  "/app-assets/fonts/flag-icon-css/flags/1x1/mh.svg": {
    "type": "image/svg+xml",
    "etag": "\"624-FHvo/xESZa/J2oFnjmiKxx7TwjE\"",
    "mtime": "2025-04-13T20:04:20.404Z",
    "size": 1572,
    "path": "../public/app-assets/fonts/flag-icon-css/flags/1x1/mh.svg"
  },
  "/app-assets/fonts/flag-icon-css/flags/1x1/mh.svg.br": {
    "type": "image/svg+xml",
    "encoding": "br",
    "etag": "\"2ea-2SfiJIhj6FjyqnPLOy3B2eLzOYc\"",
    "mtime": "2025-04-13T20:04:28.561Z",
    "size": 746,
    "path": "../public/app-assets/fonts/flag-icon-css/flags/1x1/mh.svg.br"
  },
  "/app-assets/fonts/flag-icon-css/flags/1x1/mh.svg.gz": {
    "type": "image/svg+xml",
    "encoding": "gzip",
    "etag": "\"360-ntYIWolujr52B/FdwamNhFHlEz4\"",
    "mtime": "2025-04-13T20:04:28.561Z",
    "size": 864,
    "path": "../public/app-assets/fonts/flag-icon-css/flags/1x1/mh.svg.gz"
  },
  "/app-assets/fonts/flag-icon-css/flags/1x1/mk.svg": {
    "type": "image/svg+xml",
    "etag": "\"191-jl6JL5BZ3DvAXZqBwcokP9Y17nM\"",
    "mtime": "2025-04-13T20:04:20.414Z",
    "size": 401,
    "path": "../public/app-assets/fonts/flag-icon-css/flags/1x1/mk.svg"
  },
  "/app-assets/fonts/flag-icon-css/flags/1x1/ml.svg": {
    "type": "image/svg+xml",
    "etag": "\"364-uyf5FnBeCd1Wh3yw7Csg/Fn//6Y\"",
    "mtime": "2025-04-13T20:04:20.410Z",
    "size": 868,
    "path": "../public/app-assets/fonts/flag-icon-css/flags/1x1/ml.svg"
  },
  "/app-assets/fonts/flag-icon-css/flags/1x1/mm.svg": {
    "type": "image/svg+xml",
    "etag": "\"dae-zN6A2MgnS/i4AGN/pHViRJ5rS1s\"",
    "mtime": "2025-04-13T20:04:20.403Z",
    "size": 3502,
    "path": "../public/app-assets/fonts/flag-icon-css/flags/1x1/mm.svg"
  },
  "/app-assets/fonts/flag-icon-css/flags/1x1/mm.svg.br": {
    "type": "image/svg+xml",
    "encoding": "br",
    "etag": "\"3bc-axg4rNdihKQed1DQKu/ny1aHqZ0\"",
    "mtime": "2025-04-13T20:04:28.561Z",
    "size": 956,
    "path": "../public/app-assets/fonts/flag-icon-css/flags/1x1/mm.svg.br"
  },
  "/app-assets/fonts/flag-icon-css/flags/1x1/mm.svg.gz": {
    "type": "image/svg+xml",
    "encoding": "gzip",
    "etag": "\"450-dVVqokWYXLqEtsAPhREI/Lg6Ra4\"",
    "mtime": "2025-04-13T20:04:28.561Z",
    "size": 1104,
    "path": "../public/app-assets/fonts/flag-icon-css/flags/1x1/mm.svg.gz"
  },
  "/app-assets/fonts/flag-icon-css/flags/1x1/mn.svg": {
    "type": "image/svg+xml",
    "etag": "\"471-zukwfJP/Wl7w1PY2OeG6uUgyxLo\"",
    "mtime": "2025-04-13T20:04:20.411Z",
    "size": 1137,
    "path": "../public/app-assets/fonts/flag-icon-css/flags/1x1/mn.svg"
  },
  "/app-assets/fonts/flag-icon-css/flags/1x1/mn.svg.br": {
    "type": "image/svg+xml",
    "encoding": "br",
    "etag": "\"1bf-O/26P1kIWBO2d3FERt+3ZnhB4NM\"",
    "mtime": "2025-04-13T20:04:28.561Z",
    "size": 447,
    "path": "../public/app-assets/fonts/flag-icon-css/flags/1x1/mn.svg.br"
  },
  "/app-assets/fonts/flag-icon-css/flags/1x1/mn.svg.gz": {
    "type": "image/svg+xml",
    "encoding": "gzip",
    "etag": "\"1e7-BcVZkbqXe+3bdTWbadCxLYGWfjc\"",
    "mtime": "2025-04-13T20:04:28.561Z",
    "size": 487,
    "path": "../public/app-assets/fonts/flag-icon-css/flags/1x1/mn.svg.gz"
  },
  "/app-assets/fonts/flag-icon-css/flags/1x1/mo.svg": {
    "type": "image/svg+xml",
    "etag": "\"811-dzZEqBMxvLuwgmUtMrUYCWu2XWw\"",
    "mtime": "2025-04-13T20:04:20.411Z",
    "size": 2065,
    "path": "../public/app-assets/fonts/flag-icon-css/flags/1x1/mo.svg"
  },
  "/app-assets/fonts/flag-icon-css/flags/1x1/mo.svg.br": {
    "type": "image/svg+xml",
    "encoding": "br",
    "etag": "\"3cd-TvFawlEj+cF2GgFfEM0WZ2yfuWY\"",
    "mtime": "2025-04-13T20:04:28.561Z",
    "size": 973,
    "path": "../public/app-assets/fonts/flag-icon-css/flags/1x1/mo.svg.br"
  },
  "/app-assets/fonts/flag-icon-css/flags/1x1/mo.svg.gz": {
    "type": "image/svg+xml",
    "encoding": "gzip",
    "etag": "\"417-wTv29SW6iENztJhwcqCNiQamo3w\"",
    "mtime": "2025-04-13T20:04:28.561Z",
    "size": 1047,
    "path": "../public/app-assets/fonts/flag-icon-css/flags/1x1/mo.svg.gz"
  },
  "/app-assets/fonts/flag-icon-css/flags/1x1/mp.svg": {
    "type": "image/svg+xml",
    "etag": "\"c177-53HE3h+uVlJ7qnZTU/RIUcE64cE\"",
    "mtime": "2025-04-13T20:04:20.404Z",
    "size": 49527,
    "path": "../public/app-assets/fonts/flag-icon-css/flags/1x1/mp.svg"
  },
  "/app-assets/fonts/flag-icon-css/flags/1x1/mp.svg.br": {
    "type": "image/svg+xml",
    "encoding": "br",
    "etag": "\"2b34-Emz54kSjcIZxj+38fdz8xzjRCrk\"",
    "mtime": "2025-04-13T20:04:28.562Z",
    "size": 11060,
    "path": "../public/app-assets/fonts/flag-icon-css/flags/1x1/mp.svg.br"
  },
  "/app-assets/fonts/flag-icon-css/flags/1x1/mp.svg.gz": {
    "type": "image/svg+xml",
    "encoding": "gzip",
    "etag": "\"345d-1uBeBsJTlrBpmDrkso2Ug+wf7UY\"",
    "mtime": "2025-04-13T20:04:28.561Z",
    "size": 13405,
    "path": "../public/app-assets/fonts/flag-icon-css/flags/1x1/mp.svg.gz"
  },
  "/app-assets/fonts/flag-icon-css/flags/1x1/mq.svg": {
    "type": "image/svg+xml",
    "etag": "\"36b-HJPrUMGEZCgMVArOsf1TnKiQ4YQ\"",
    "mtime": "2025-04-13T20:04:20.410Z",
    "size": 875,
    "path": "../public/app-assets/fonts/flag-icon-css/flags/1x1/mq.svg"
  },
  "/app-assets/fonts/flag-icon-css/flags/1x1/mr.svg": {
    "type": "image/svg+xml",
    "etag": "\"3b5-gwdwKq/axzIHhEZxSo+y6Pr4z6o\"",
    "mtime": "2025-04-13T20:04:20.415Z",
    "size": 949,
    "path": "../public/app-assets/fonts/flag-icon-css/flags/1x1/mr.svg"
  },
  "/app-assets/fonts/flag-icon-css/flags/1x1/ms.svg": {
    "type": "image/svg+xml",
    "etag": "\"2a0d-33oHTGE4ZELIr5IC0KFTdc9HhEU\"",
    "mtime": "2025-04-13T20:04:20.414Z",
    "size": 10765,
    "path": "../public/app-assets/fonts/flag-icon-css/flags/1x1/ms.svg"
  },
  "/app-assets/fonts/flag-icon-css/flags/1x1/ms.svg.br": {
    "type": "image/svg+xml",
    "encoding": "br",
    "etag": "\"bf3-SgJEI80uvPlVyfKsAojCqhIsO2w\"",
    "mtime": "2025-04-13T20:04:28.561Z",
    "size": 3059,
    "path": "../public/app-assets/fonts/flag-icon-css/flags/1x1/ms.svg.br"
  },
  "/app-assets/fonts/flag-icon-css/flags/1x1/ms.svg.gz": {
    "type": "image/svg+xml",
    "encoding": "gzip",
    "etag": "\"d7d-+3bAtZUkinQy21rOv3Ms2sLWJRc\"",
    "mtime": "2025-04-13T20:04:28.561Z",
    "size": 3453,
    "path": "../public/app-assets/fonts/flag-icon-css/flags/1x1/ms.svg.gz"
  },
  "/app-assets/fonts/flag-icon-css/flags/1x1/mt.svg": {
    "type": "image/svg+xml",
    "etag": "\"5066-SjIZwFoDKTe+2IYOcOMLBhjUgG4\"",
    "mtime": "2025-04-13T20:04:20.411Z",
    "size": 20582,
    "path": "../public/app-assets/fonts/flag-icon-css/flags/1x1/mt.svg"
  },
  "/app-assets/fonts/flag-icon-css/flags/1x1/mt.svg.br": {
    "type": "image/svg+xml",
    "encoding": "br",
    "etag": "\"13fe-72ImE9OKzReCrDXO9SFbBDf3I6U\"",
    "mtime": "2025-04-13T20:04:28.561Z",
    "size": 5118,
    "path": "../public/app-assets/fonts/flag-icon-css/flags/1x1/mt.svg.br"
  },
  "/app-assets/fonts/flag-icon-css/flags/1x1/mt.svg.gz": {
    "type": "image/svg+xml",
    "encoding": "gzip",
    "etag": "\"1766-v8N0Yp7csxbfH6n9Sh5TF2T/LGE\"",
    "mtime": "2025-04-13T20:04:28.561Z",
    "size": 5990,
    "path": "../public/app-assets/fonts/flag-icon-css/flags/1x1/mt.svg.gz"
  },
  "/app-assets/fonts/flag-icon-css/flags/1x1/mu.svg": {
    "type": "image/svg+xml",
    "etag": "\"3b0-XYRmbrmyHtydIQrxbfseo9sKNTI\"",
    "mtime": "2025-04-13T20:04:20.414Z",
    "size": 944,
    "path": "../public/app-assets/fonts/flag-icon-css/flags/1x1/mu.svg"
  },
  "/app-assets/fonts/flag-icon-css/flags/1x1/mv.svg": {
    "type": "image/svg+xml",
    "etag": "\"54f-3NgC69IC+jYoEuWtBt8ZKKHjA5Q\"",
    "mtime": "2025-04-13T20:04:20.416Z",
    "size": 1359,
    "path": "../public/app-assets/fonts/flag-icon-css/flags/1x1/mv.svg"
  },
  "/app-assets/fonts/flag-icon-css/flags/1x1/mv.svg.br": {
    "type": "image/svg+xml",
    "encoding": "br",
    "etag": "\"21c-L/KPVOlwY8TFTAr+yifTaKSV79I\"",
    "mtime": "2025-04-13T20:04:28.561Z",
    "size": 540,
    "path": "../public/app-assets/fonts/flag-icon-css/flags/1x1/mv.svg.br"
  },
  "/app-assets/fonts/flag-icon-css/flags/1x1/mv.svg.gz": {
    "type": "image/svg+xml",
    "encoding": "gzip",
    "etag": "\"281-WWMmj/CArxCYEvVjed4Xg5vCH7c\"",
    "mtime": "2025-04-13T20:04:28.561Z",
    "size": 641,
    "path": "../public/app-assets/fonts/flag-icon-css/flags/1x1/mv.svg.gz"
  },
  "/app-assets/fonts/flag-icon-css/flags/1x1/mw.svg": {
    "type": "image/svg+xml",
    "etag": "\"26e8-sZBafNGalgnBX3j34lQF2m0QsuQ\"",
    "mtime": "2025-04-13T20:04:20.416Z",
    "size": 9960,
    "path": "../public/app-assets/fonts/flag-icon-css/flags/1x1/mw.svg"
  },
  "/app-assets/fonts/flag-icon-css/flags/1x1/mw.svg.br": {
    "type": "image/svg+xml",
    "encoding": "br",
    "etag": "\"52c-WiddaAj3yA9H1ux5e4Hlt9uoA6M\"",
    "mtime": "2025-04-13T20:04:28.561Z",
    "size": 1324,
    "path": "../public/app-assets/fonts/flag-icon-css/flags/1x1/mw.svg.br"
  },
  "/app-assets/fonts/flag-icon-css/flags/1x1/mw.svg.gz": {
    "type": "image/svg+xml",
    "encoding": "gzip",
    "etag": "\"625-yEXops4RCL0rRREe4t9lw2g+a08\"",
    "mtime": "2025-04-13T20:04:28.561Z",
    "size": 1573,
    "path": "../public/app-assets/fonts/flag-icon-css/flags/1x1/mw.svg.gz"
  },
  "/app-assets/fonts/flag-icon-css/flags/1x1/mx.svg": {
    "type": "image/svg+xml",
    "etag": "\"11a61-gpZzp8KIHzjwNyIwtIYnxdCT02o\"",
    "mtime": "2025-04-13T20:04:20.415Z",
    "size": 72289,
    "path": "../public/app-assets/fonts/flag-icon-css/flags/1x1/mx.svg"
  },
  "/app-assets/fonts/flag-icon-css/flags/1x1/mx.svg.br": {
    "type": "image/svg+xml",
    "encoding": "br",
    "etag": "\"4313-MQ5IUXDxsIV+TSy+0AX61jMHk6Y\"",
    "mtime": "2025-04-13T20:04:28.635Z",
    "size": 17171,
    "path": "../public/app-assets/fonts/flag-icon-css/flags/1x1/mx.svg.br"
  },
  "/app-assets/fonts/flag-icon-css/flags/1x1/mx.svg.gz": {
    "type": "image/svg+xml",
    "encoding": "gzip",
    "etag": "\"4e4f-K7GVdfxQLOE0FJtNsjIUHwPigtA\"",
    "mtime": "2025-04-13T20:04:28.634Z",
    "size": 20047,
    "path": "../public/app-assets/fonts/flag-icon-css/flags/1x1/mx.svg.gz"
  },
  "/app-assets/fonts/flag-icon-css/flags/1x1/my.svg": {
    "type": "image/svg+xml",
    "etag": "\"5ec-waeg5xWVw+OgDS4ZgO93NNr2hk4\"",
    "mtime": "2025-04-13T20:04:20.415Z",
    "size": 1516,
    "path": "../public/app-assets/fonts/flag-icon-css/flags/1x1/my.svg"
  },
  "/app-assets/fonts/flag-icon-css/flags/1x1/my.svg.br": {
    "type": "image/svg+xml",
    "encoding": "br",
    "etag": "\"206-mAWSEx4RjzVmwSp9VIPFAe8XJYg\"",
    "mtime": "2025-04-13T20:04:28.561Z",
    "size": 518,
    "path": "../public/app-assets/fonts/flag-icon-css/flags/1x1/my.svg.br"
  },
  "/app-assets/fonts/flag-icon-css/flags/1x1/my.svg.gz": {
    "type": "image/svg+xml",
    "encoding": "gzip",
    "etag": "\"257-K/mFnoY1E85njGhrarCGpSrAq/I\"",
    "mtime": "2025-04-13T20:04:28.561Z",
    "size": 599,
    "path": "../public/app-assets/fonts/flag-icon-css/flags/1x1/my.svg.gz"
  },
  "/app-assets/fonts/flag-icon-css/flags/1x1/mz.svg": {
    "type": "image/svg+xml",
    "etag": "\"143a-+wPJc0/4ofhonNZDNfDhBJ0KGzo\"",
    "mtime": "2025-04-13T20:04:20.417Z",
    "size": 5178,
    "path": "../public/app-assets/fonts/flag-icon-css/flags/1x1/mz.svg"
  },
  "/app-assets/fonts/flag-icon-css/flags/1x1/mz.svg.br": {
    "type": "image/svg+xml",
    "encoding": "br",
    "etag": "\"774-mGGyowsDm3SjT/JjR+yvXKxjF0I\"",
    "mtime": "2025-04-13T20:04:28.562Z",
    "size": 1908,
    "path": "../public/app-assets/fonts/flag-icon-css/flags/1x1/mz.svg.br"
  },
  "/app-assets/fonts/flag-icon-css/flags/1x1/mz.svg.gz": {
    "type": "image/svg+xml",
    "encoding": "gzip",
    "etag": "\"859-ADh0I8+jMay7HbfzuWHgAKM5skA\"",
    "mtime": "2025-04-13T20:04:28.562Z",
    "size": 2137,
    "path": "../public/app-assets/fonts/flag-icon-css/flags/1x1/mz.svg.gz"
  },
  "/app-assets/fonts/flag-icon-css/flags/1x1/na.svg": {
    "type": "image/svg+xml",
    "etag": "\"a84-BFZo56AdrsK1iwzFE3CsPj2+5xE\"",
    "mtime": "2025-04-13T20:04:20.415Z",
    "size": 2692,
    "path": "../public/app-assets/fonts/flag-icon-css/flags/1x1/na.svg"
  },
  "/app-assets/fonts/flag-icon-css/flags/1x1/na.svg.br": {
    "type": "image/svg+xml",
    "encoding": "br",
    "etag": "\"41e-YouLuC8j9mIA24UvB87wOsXKOeQ\"",
    "mtime": "2025-04-13T20:04:28.562Z",
    "size": 1054,
    "path": "../public/app-assets/fonts/flag-icon-css/flags/1x1/na.svg.br"
  },
  "/app-assets/fonts/flag-icon-css/flags/1x1/na.svg.gz": {
    "type": "image/svg+xml",
    "encoding": "gzip",
    "etag": "\"4b5-jlt//F6mPbRihfr1X3M+gELK/sA\"",
    "mtime": "2025-04-13T20:04:28.562Z",
    "size": 1205,
    "path": "../public/app-assets/fonts/flag-icon-css/flags/1x1/na.svg.gz"
  },
  "/app-assets/fonts/flag-icon-css/flags/1x1/nc.svg": {
    "type": "image/svg+xml",
    "etag": "\"368-5XXYELAIIlb5rtwplO9s7cyc1gA\"",
    "mtime": "2025-04-13T20:04:20.416Z",
    "size": 872,
    "path": "../public/app-assets/fonts/flag-icon-css/flags/1x1/nc.svg"
  },
  "/app-assets/fonts/flag-icon-css/flags/1x1/ne.svg": {
    "type": "image/svg+xml",
    "etag": "\"119-dieb9FlgYJKsjiLe8RNUOB59xec\"",
    "mtime": "2025-04-13T20:04:20.415Z",
    "size": 281,
    "path": "../public/app-assets/fonts/flag-icon-css/flags/1x1/ne.svg"
  },
  "/app-assets/fonts/flag-icon-css/flags/1x1/nf.svg": {
    "type": "image/svg+xml",
    "etag": "\"35e6-T4kphWZf1UHluHG0y5y0rjEeTOM\"",
    "mtime": "2025-04-13T20:04:20.415Z",
    "size": 13798,
    "path": "../public/app-assets/fonts/flag-icon-css/flags/1x1/nf.svg"
  },
  "/app-assets/fonts/flag-icon-css/flags/1x1/nf.svg.br": {
    "type": "image/svg+xml",
    "encoding": "br",
    "etag": "\"1163-xyopwi0GUkUiQBnjE+sHfvuNPpU\"",
    "mtime": "2025-04-13T20:04:28.562Z",
    "size": 4451,
    "path": "../public/app-assets/fonts/flag-icon-css/flags/1x1/nf.svg.br"
  },
  "/app-assets/fonts/flag-icon-css/flags/1x1/nf.svg.gz": {
    "type": "image/svg+xml",
    "encoding": "gzip",
    "etag": "\"133c-Ax8gYoMfh+BgItJ5cm6EM6bLF0U\"",
    "mtime": "2025-04-13T20:04:28.561Z",
    "size": 4924,
    "path": "../public/app-assets/fonts/flag-icon-css/flags/1x1/nf.svg.gz"
  },
  "/app-assets/fonts/flag-icon-css/flags/1x1/ng.svg": {
    "type": "image/svg+xml",
    "etag": "\"3bd-I0ruF0rhccLaousC0z95sBzk2iY\"",
    "mtime": "2025-04-13T20:04:20.419Z",
    "size": 957,
    "path": "../public/app-assets/fonts/flag-icon-css/flags/1x1/ng.svg"
  },
  "/app-assets/fonts/flag-icon-css/flags/1x1/ni.svg": {
    "type": "image/svg+xml",
    "etag": "\"71b4-7g2buOydrgTvqvznJm41Ywqd6Jg\"",
    "mtime": "2025-04-13T20:04:20.417Z",
    "size": 29108,
    "path": "../public/app-assets/fonts/flag-icon-css/flags/1x1/ni.svg"
  },
  "/app-assets/fonts/flag-icon-css/flags/1x1/ni.svg.br": {
    "type": "image/svg+xml",
    "encoding": "br",
    "etag": "\"24b1-65FdytIakotPQOiWCHR3hFtZciY\"",
    "mtime": "2025-04-13T20:04:28.562Z",
    "size": 9393,
    "path": "../public/app-assets/fonts/flag-icon-css/flags/1x1/ni.svg.br"
  },
  "/app-assets/fonts/flag-icon-css/flags/1x1/ni.svg.gz": {
    "type": "image/svg+xml",
    "encoding": "gzip",
    "etag": "\"2b27-yYpVckFT0H5V6Wc3TLDKY9S+8dA\"",
    "mtime": "2025-04-13T20:04:28.562Z",
    "size": 11047,
    "path": "../public/app-assets/fonts/flag-icon-css/flags/1x1/ni.svg.gz"
  },
  "/app-assets/fonts/flag-icon-css/flags/1x1/nl.svg": {
    "type": "image/svg+xml",
    "etag": "\"384-kpYPlXlqz6VHXBq3qcMEo4MHOMU\"",
    "mtime": "2025-04-13T20:04:20.417Z",
    "size": 900,
    "path": "../public/app-assets/fonts/flag-icon-css/flags/1x1/nl.svg"
  },
  "/app-assets/fonts/flag-icon-css/flags/1x1/no.svg": {
    "type": "image/svg+xml",
    "etag": "\"13a-D//yA1viQqii1ghF0u7Qz0IGHSY\"",
    "mtime": "2025-04-13T20:04:20.417Z",
    "size": 314,
    "path": "../public/app-assets/fonts/flag-icon-css/flags/1x1/no.svg"
  },
  "/app-assets/fonts/flag-icon-css/flags/1x1/np.svg": {
    "type": "image/svg+xml",
    "etag": "\"b92-WLcoq4Xx1eh7h0f8t14HgcvlCf0\"",
    "mtime": "2025-04-13T20:04:20.417Z",
    "size": 2962,
    "path": "../public/app-assets/fonts/flag-icon-css/flags/1x1/np.svg"
  },
  "/app-assets/fonts/flag-icon-css/flags/1x1/np.svg.br": {
    "type": "image/svg+xml",
    "encoding": "br",
    "etag": "\"487-n1iCtQ8XlCiBV321aGSyS/QoxJE\"",
    "mtime": "2025-04-13T20:04:28.562Z",
    "size": 1159,
    "path": "../public/app-assets/fonts/flag-icon-css/flags/1x1/np.svg.br"
  },
  "/app-assets/fonts/flag-icon-css/flags/1x1/np.svg.gz": {
    "type": "image/svg+xml",
    "encoding": "gzip",
    "etag": "\"558-P1PjFv3vi3l5zlvgf/lZuFUC6Qs\"",
    "mtime": "2025-04-13T20:04:28.562Z",
    "size": 1368,
    "path": "../public/app-assets/fonts/flag-icon-css/flags/1x1/np.svg.gz"
  },
  "/app-assets/fonts/flag-icon-css/flags/1x1/nr.svg": {
    "type": "image/svg+xml",
    "etag": "\"7a4-/CE92ONZnBOcdcQJJAg1tZA0d/g\"",
    "mtime": "2025-04-13T20:04:20.418Z",
    "size": 1956,
    "path": "../public/app-assets/fonts/flag-icon-css/flags/1x1/nr.svg"
  },
  "/app-assets/fonts/flag-icon-css/flags/1x1/nr.svg.br": {
    "type": "image/svg+xml",
    "encoding": "br",
    "etag": "\"34b-bfgKKXYu6ZmtJUK4MDrU0TPvkuw\"",
    "mtime": "2025-04-13T20:04:28.562Z",
    "size": 843,
    "path": "../public/app-assets/fonts/flag-icon-css/flags/1x1/nr.svg.br"
  },
  "/app-assets/fonts/flag-icon-css/flags/1x1/nr.svg.gz": {
    "type": "image/svg+xml",
    "encoding": "gzip",
    "etag": "\"3d2-KL7ZppbTWSk4977gLbJgwt4/1F8\"",
    "mtime": "2025-04-13T20:04:28.562Z",
    "size": 978,
    "path": "../public/app-assets/fonts/flag-icon-css/flags/1x1/nr.svg.gz"
  },
  "/app-assets/fonts/flag-icon-css/flags/1x1/nu.svg": {
    "type": "image/svg+xml",
    "etag": "\"f9d-V+BuI+oAOy3e1jnjiO9Kn48/7nY\"",
    "mtime": "2025-04-13T20:04:20.418Z",
    "size": 3997,
    "path": "../public/app-assets/fonts/flag-icon-css/flags/1x1/nu.svg"
  },
  "/app-assets/fonts/flag-icon-css/flags/1x1/nu.svg.br": {
    "type": "image/svg+xml",
    "encoding": "br",
    "etag": "\"497-y7CzWA2kRYrbAhcwh+9xq5H//8k\"",
    "mtime": "2025-04-13T20:04:28.562Z",
    "size": 1175,
    "path": "../public/app-assets/fonts/flag-icon-css/flags/1x1/nu.svg.br"
  },
  "/app-assets/fonts/flag-icon-css/flags/1x1/nu.svg.gz": {
    "type": "image/svg+xml",
    "encoding": "gzip",
    "etag": "\"540-25kanORY2HZvq7GFWGZvjpKEPw0\"",
    "mtime": "2025-04-13T20:04:28.562Z",
    "size": 1344,
    "path": "../public/app-assets/fonts/flag-icon-css/flags/1x1/nu.svg.gz"
  },
  "/app-assets/fonts/flag-icon-css/flags/1x1/nz.svg": {
    "type": "image/svg+xml",
    "etag": "\"15eb-iV2G99HzhWPgBdIk8nRhbuuHF3A\"",
    "mtime": "2025-04-13T20:04:20.419Z",
    "size": 5611,
    "path": "../public/app-assets/fonts/flag-icon-css/flags/1x1/nz.svg"
  },
  "/app-assets/fonts/flag-icon-css/flags/1x1/nz.svg.br": {
    "type": "image/svg+xml",
    "encoding": "br",
    "etag": "\"45b-J2HMho95eWznUx/rdZlzGA7aM9M\"",
    "mtime": "2025-04-13T20:04:28.562Z",
    "size": 1115,
    "path": "../public/app-assets/fonts/flag-icon-css/flags/1x1/nz.svg.br"
  },
  "/app-assets/fonts/flag-icon-css/flags/1x1/nz.svg.gz": {
    "type": "image/svg+xml",
    "encoding": "gzip",
    "etag": "\"517-RsaLicymqEVmGGTLJCP0Efd9La4\"",
    "mtime": "2025-04-13T20:04:28.562Z",
    "size": 1303,
    "path": "../public/app-assets/fonts/flag-icon-css/flags/1x1/nz.svg.gz"
  },
  "/app-assets/fonts/flag-icon-css/flags/1x1/om.svg": {
    "type": "image/svg+xml",
    "etag": "\"cc98-9grksRuoN7u4g3XzY8jfesl7iD4\"",
    "mtime": "2025-04-13T20:04:20.417Z",
    "size": 52376,
    "path": "../public/app-assets/fonts/flag-icon-css/flags/1x1/om.svg"
  },
  "/app-assets/fonts/flag-icon-css/flags/1x1/om.svg.br": {
    "type": "image/svg+xml",
    "encoding": "br",
    "etag": "\"192b-Qnq0PO4EUl3KsB3J7IJ5prF5ezQ\"",
    "mtime": "2025-04-13T20:04:28.563Z",
    "size": 6443,
    "path": "../public/app-assets/fonts/flag-icon-css/flags/1x1/om.svg.br"
  },
  "/app-assets/fonts/flag-icon-css/flags/1x1/om.svg.gz": {
    "type": "image/svg+xml",
    "encoding": "gzip",
    "etag": "\"1e50-8kHknAi/HBAh0xVXkEecarjyTwE\"",
    "mtime": "2025-04-13T20:04:28.562Z",
    "size": 7760,
    "path": "../public/app-assets/fonts/flag-icon-css/flags/1x1/om.svg.gz"
  },
  "/app-assets/fonts/flag-icon-css/flags/1x1/pa.svg": {
    "type": "image/svg+xml",
    "etag": "\"604-qVlJ5wTJFhtqnQKu+IbwFro0d6E\"",
    "mtime": "2025-04-13T20:04:20.418Z",
    "size": 1540,
    "path": "../public/app-assets/fonts/flag-icon-css/flags/1x1/pa.svg"
  },
  "/app-assets/fonts/flag-icon-css/flags/1x1/pa.svg.br": {
    "type": "image/svg+xml",
    "encoding": "br",
    "etag": "\"256-BYLBurBZra1378orqZx1R4wf3YI\"",
    "mtime": "2025-04-13T20:04:28.562Z",
    "size": 598,
    "path": "../public/app-assets/fonts/flag-icon-css/flags/1x1/pa.svg.br"
  },
  "/app-assets/fonts/flag-icon-css/flags/1x1/pa.svg.gz": {
    "type": "image/svg+xml",
    "encoding": "gzip",
    "etag": "\"2bb-wR66Hr9SqQIXxdWyA5PE5ttm+uU\"",
    "mtime": "2025-04-13T20:04:28.562Z",
    "size": 699,
    "path": "../public/app-assets/fonts/flag-icon-css/flags/1x1/pa.svg.gz"
  },
  "/app-assets/fonts/flag-icon-css/flags/1x1/pe.svg": {
    "type": "image/svg+xml",
    "etag": "\"363-w9289Hcj7usQ/kSBQfrCCcGCNv8\"",
    "mtime": "2025-04-13T20:04:20.417Z",
    "size": 867,
    "path": "../public/app-assets/fonts/flag-icon-css/flags/1x1/pe.svg"
  },
  "/app-assets/fonts/flag-icon-css/flags/1x1/pf.svg": {
    "type": "image/svg+xml",
    "etag": "\"296b-kt5O/rSTFu0DeKD9+mNa8scKYrs\"",
    "mtime": "2025-04-13T20:04:20.418Z",
    "size": 10603,
    "path": "../public/app-assets/fonts/flag-icon-css/flags/1x1/pf.svg"
  },
  "/app-assets/fonts/flag-icon-css/flags/1x1/pf.svg.br": {
    "type": "image/svg+xml",
    "encoding": "br",
    "etag": "\"b48-OnmHT5Az8kkvHrPJZMnhNJwBqco\"",
    "mtime": "2025-04-13T20:04:28.562Z",
    "size": 2888,
    "path": "../public/app-assets/fonts/flag-icon-css/flags/1x1/pf.svg.br"
  },
  "/app-assets/fonts/flag-icon-css/flags/1x1/pf.svg.gz": {
    "type": "image/svg+xml",
    "encoding": "gzip",
    "etag": "\"d19-Kyxc2RaBRRuwkESifPbYFInrZJI\"",
    "mtime": "2025-04-13T20:04:28.562Z",
    "size": 3353,
    "path": "../public/app-assets/fonts/flag-icon-css/flags/1x1/pf.svg.gz"
  },
  "/app-assets/fonts/flag-icon-css/flags/1x1/pg.svg": {
    "type": "image/svg+xml",
    "etag": "\"11d2-01tsEM1XgVJgldeAk1c8lD8IT2M\"",
    "mtime": "2025-04-13T20:04:20.420Z",
    "size": 4562,
    "path": "../public/app-assets/fonts/flag-icon-css/flags/1x1/pg.svg"
  },
  "/app-assets/fonts/flag-icon-css/flags/1x1/pg.svg.br": {
    "type": "image/svg+xml",
    "encoding": "br",
    "etag": "\"762-LXdVmNL06yVoYzmMbul19awsZG8\"",
    "mtime": "2025-04-13T20:04:28.562Z",
    "size": 1890,
    "path": "../public/app-assets/fonts/flag-icon-css/flags/1x1/pg.svg.br"
  },
  "/app-assets/fonts/flag-icon-css/flags/1x1/pg.svg.gz": {
    "type": "image/svg+xml",
    "encoding": "gzip",
    "etag": "\"853-gNe8tN9DSZYz2aG6oUACK1nXmek\"",
    "mtime": "2025-04-13T20:04:28.562Z",
    "size": 2131,
    "path": "../public/app-assets/fonts/flag-icon-css/flags/1x1/pg.svg.gz"
  },
  "/app-assets/fonts/flag-icon-css/flags/1x1/ph.svg": {
    "type": "image/svg+xml",
    "etag": "\"1393-4d7lvy7M7X9Bf9HOJLdtsAXxgsM\"",
    "mtime": "2025-04-13T20:04:20.417Z",
    "size": 5011,
    "path": "../public/app-assets/fonts/flag-icon-css/flags/1x1/ph.svg"
  },
  "/app-assets/fonts/flag-icon-css/flags/1x1/ph.svg.br": {
    "type": "image/svg+xml",
    "encoding": "br",
    "etag": "\"42f-fsFXcwtFN/d4dAIARpm+rznlJK4\"",
    "mtime": "2025-04-13T20:04:28.562Z",
    "size": 1071,
    "path": "../public/app-assets/fonts/flag-icon-css/flags/1x1/ph.svg.br"
  },
  "/app-assets/fonts/flag-icon-css/flags/1x1/ph.svg.gz": {
    "type": "image/svg+xml",
    "encoding": "gzip",
    "etag": "\"4cf-wO0wwhHGZBCNkDgPvgGFS+4rT44\"",
    "mtime": "2025-04-13T20:04:28.562Z",
    "size": 1231,
    "path": "../public/app-assets/fonts/flag-icon-css/flags/1x1/ph.svg.gz"
  },
  "/app-assets/fonts/flag-icon-css/flags/1x1/pk.svg": {
    "type": "image/svg+xml",
    "etag": "\"5f7-uAXzOYorCnzaitOJ26K9KmrutcQ\"",
    "mtime": "2025-04-13T20:04:20.420Z",
    "size": 1527,
    "path": "../public/app-assets/fonts/flag-icon-css/flags/1x1/pk.svg"
  },
  "/app-assets/fonts/flag-icon-css/flags/1x1/pk.svg.br": {
    "type": "image/svg+xml",
    "encoding": "br",
    "etag": "\"2c1-zz01/WZPVyTrmNywIcUTyOFYIVQ\"",
    "mtime": "2025-04-13T20:04:28.562Z",
    "size": 705,
    "path": "../public/app-assets/fonts/flag-icon-css/flags/1x1/pk.svg.br"
  },
  "/app-assets/fonts/flag-icon-css/flags/1x1/pk.svg.gz": {
    "type": "image/svg+xml",
    "encoding": "gzip",
    "etag": "\"32f-Kuix6v5zxVZWnsxoEYD0V/WFAkU\"",
    "mtime": "2025-04-13T20:04:28.562Z",
    "size": 815,
    "path": "../public/app-assets/fonts/flag-icon-css/flags/1x1/pk.svg.gz"
  },
  "/app-assets/fonts/flag-icon-css/flags/1x1/pl.svg": {
    "type": "image/svg+xml",
    "etag": "\"30f-h/YUYN26r/V35L+YYx5vZi0oDKo\"",
    "mtime": "2025-04-13T20:04:20.418Z",
    "size": 783,
    "path": "../public/app-assets/fonts/flag-icon-css/flags/1x1/pl.svg"
  },
  "/app-assets/fonts/flag-icon-css/flags/1x1/pm.svg": {
    "type": "image/svg+xml",
    "etag": "\"36b-nAldgwCWkT0mS99/GCcJZF3DHFI\"",
    "mtime": "2025-04-13T20:04:20.418Z",
    "size": 875,
    "path": "../public/app-assets/fonts/flag-icon-css/flags/1x1/pm.svg"
  },
  "/app-assets/fonts/flag-icon-css/flags/1x1/pn.svg": {
    "type": "image/svg+xml",
    "etag": "\"639f-IosVKnUlJyWvI4ov1aAWrY9XXFU\"",
    "mtime": "2025-04-13T20:04:20.418Z",
    "size": 25503,
    "path": "../public/app-assets/fonts/flag-icon-css/flags/1x1/pn.svg"
  },
  "/app-assets/fonts/flag-icon-css/flags/1x1/pn.svg.br": {
    "type": "image/svg+xml",
    "encoding": "br",
    "etag": "\"201e-VTpFfj7sTJo4NoZ15LCCH9gr0WM\"",
    "mtime": "2025-04-13T20:04:28.563Z",
    "size": 8222,
    "path": "../public/app-assets/fonts/flag-icon-css/flags/1x1/pn.svg.br"
  },
  "/app-assets/fonts/flag-icon-css/flags/1x1/pn.svg.gz": {
    "type": "image/svg+xml",
    "encoding": "gzip",
    "etag": "\"240f-1EjKNQ6xDR7csx4Obg9aIo4mg7M\"",
    "mtime": "2025-04-13T20:04:28.562Z",
    "size": 9231,
    "path": "../public/app-assets/fonts/flag-icon-css/flags/1x1/pn.svg.gz"
  },
  "/app-assets/fonts/flag-icon-css/flags/1x1/pr.svg": {
    "type": "image/svg+xml",
    "etag": "\"5f0-mJhJ64MMewFmjflR8SM5sHfhciA\"",
    "mtime": "2025-04-13T20:04:20.419Z",
    "size": 1520,
    "path": "../public/app-assets/fonts/flag-icon-css/flags/1x1/pr.svg"
  },
  "/app-assets/fonts/flag-icon-css/flags/1x1/pr.svg.br": {
    "type": "image/svg+xml",
    "encoding": "br",
    "etag": "\"26d-IffGCG8WAKIpbs5DyDgw7cIELt4\"",
    "mtime": "2025-04-13T20:04:28.562Z",
    "size": 621,
    "path": "../public/app-assets/fonts/flag-icon-css/flags/1x1/pr.svg.br"
  },
  "/app-assets/fonts/flag-icon-css/flags/1x1/pr.svg.gz": {
    "type": "image/svg+xml",
    "encoding": "gzip",
    "etag": "\"2d6-EKWNyJR/lEsVSMG4vuqXCjGD3Ew\"",
    "mtime": "2025-04-13T20:04:28.562Z",
    "size": 726,
    "path": "../public/app-assets/fonts/flag-icon-css/flags/1x1/pr.svg.gz"
  },
  "/app-assets/fonts/flag-icon-css/flags/1x1/ps.svg": {
    "type": "image/svg+xml",
    "etag": "\"49f-Bn2Ekfey/ccpZH3IXmgIo3us82g\"",
    "mtime": "2025-04-13T20:04:20.418Z",
    "size": 1183,
    "path": "../public/app-assets/fonts/flag-icon-css/flags/1x1/ps.svg"
  },
  "/app-assets/fonts/flag-icon-css/flags/1x1/ps.svg.br": {
    "type": "image/svg+xml",
    "encoding": "br",
    "etag": "\"200-PvUcONdkgLHfMtPr4ByvBnxxOcw\"",
    "mtime": "2025-04-13T20:04:28.562Z",
    "size": 512,
    "path": "../public/app-assets/fonts/flag-icon-css/flags/1x1/ps.svg.br"
  },
  "/app-assets/fonts/flag-icon-css/flags/1x1/ps.svg.gz": {
    "type": "image/svg+xml",
    "encoding": "gzip",
    "etag": "\"259-B+qVgLI/Q8U9CGT9NtqlfP8UMVc\"",
    "mtime": "2025-04-13T20:04:28.562Z",
    "size": 601,
    "path": "../public/app-assets/fonts/flag-icon-css/flags/1x1/ps.svg.gz"
  },
  "/app-assets/fonts/flag-icon-css/flags/1x1/pt.svg": {
    "type": "image/svg+xml",
    "etag": "\"3087-dHE9g0eDEk9lCPWYcXjoyS4d29E\"",
    "mtime": "2025-04-13T20:04:20.419Z",
    "size": 12423,
    "path": "../public/app-assets/fonts/flag-icon-css/flags/1x1/pt.svg"
  },
  "/app-assets/fonts/flag-icon-css/flags/1x1/pt.svg.br": {
    "type": "image/svg+xml",
    "encoding": "br",
    "etag": "\"11b9-qQMBru2OBbicqEBH2JKveTz1srs\"",
    "mtime": "2025-04-13T20:04:28.563Z",
    "size": 4537,
    "path": "../public/app-assets/fonts/flag-icon-css/flags/1x1/pt.svg.br"
  },
  "/app-assets/fonts/flag-icon-css/flags/1x1/pt.svg.gz": {
    "type": "image/svg+xml",
    "encoding": "gzip",
    "etag": "\"1465-5RBfrGcS7igWwvJeMP4luUwLUMI\"",
    "mtime": "2025-04-13T20:04:28.562Z",
    "size": 5221,
    "path": "../public/app-assets/fonts/flag-icon-css/flags/1x1/pt.svg.gz"
  },
  "/app-assets/fonts/flag-icon-css/flags/1x1/pw.svg": {
    "type": "image/svg+xml",
    "etag": "\"4e5-UvhxpnKKwxj/lvAtLLB7wOiaVUA\"",
    "mtime": "2025-04-13T20:04:20.419Z",
    "size": 1253,
    "path": "../public/app-assets/fonts/flag-icon-css/flags/1x1/pw.svg"
  },
  "/app-assets/fonts/flag-icon-css/flags/1x1/pw.svg.br": {
    "type": "image/svg+xml",
    "encoding": "br",
    "etag": "\"22e-7hncRW7NL7TZHX/yELu3BmQICC8\"",
    "mtime": "2025-04-13T20:04:28.562Z",
    "size": 558,
    "path": "../public/app-assets/fonts/flag-icon-css/flags/1x1/pw.svg.br"
  },
  "/app-assets/fonts/flag-icon-css/flags/1x1/pw.svg.gz": {
    "type": "image/svg+xml",
    "encoding": "gzip",
    "etag": "\"28f-KW4ENFnyvpLKJ8WyTev24mSj7eE\"",
    "mtime": "2025-04-13T20:04:28.562Z",
    "size": 655,
    "path": "../public/app-assets/fonts/flag-icon-css/flags/1x1/pw.svg.gz"
  },
  "/app-assets/fonts/flag-icon-css/flags/1x1/py.svg": {
    "type": "image/svg+xml",
    "etag": "\"7915-V8e53geAwem0XCHRKlqdxcAvxCw\"",
    "mtime": "2025-04-13T20:04:20.419Z",
    "size": 30997,
    "path": "../public/app-assets/fonts/flag-icon-css/flags/1x1/py.svg"
  },
  "/app-assets/fonts/flag-icon-css/flags/1x1/py.svg.br": {
    "type": "image/svg+xml",
    "encoding": "br",
    "etag": "\"2589-ycltvXIZQ67j5XrVL5f7EgY1PI0\"",
    "mtime": "2025-04-13T20:04:28.563Z",
    "size": 9609,
    "path": "../public/app-assets/fonts/flag-icon-css/flags/1x1/py.svg.br"
  },
  "/app-assets/fonts/flag-icon-css/flags/1x1/py.svg.gz": {
    "type": "image/svg+xml",
    "encoding": "gzip",
    "etag": "\"2bfb-UcT7iI2qZrdCPEAbK5HX/2+2Z6A\"",
    "mtime": "2025-04-13T20:04:28.563Z",
    "size": 11259,
    "path": "../public/app-assets/fonts/flag-icon-css/flags/1x1/py.svg.gz"
  },
  "/app-assets/fonts/flag-icon-css/flags/1x1/qa.svg": {
    "type": "image/svg+xml",
    "etag": "\"4f3-U5GNbEOtNi7KPqiOpe6RRMNtqNs\"",
    "mtime": "2025-04-13T20:04:20.419Z",
    "size": 1267,
    "path": "../public/app-assets/fonts/flag-icon-css/flags/1x1/qa.svg"
  },
  "/app-assets/fonts/flag-icon-css/flags/1x1/qa.svg.br": {
    "type": "image/svg+xml",
    "encoding": "br",
    "etag": "\"209-NS/TDBJDZk8fgfgO+IRJgTIAPEc\"",
    "mtime": "2025-04-13T20:04:28.563Z",
    "size": 521,
    "path": "../public/app-assets/fonts/flag-icon-css/flags/1x1/qa.svg.br"
  },
  "/app-assets/fonts/flag-icon-css/flags/1x1/qa.svg.gz": {
    "type": "image/svg+xml",
    "encoding": "gzip",
    "etag": "\"26c-o3dddH8KOsDb9aUGc8JwZ9Px6+I\"",
    "mtime": "2025-04-13T20:04:28.563Z",
    "size": 620,
    "path": "../public/app-assets/fonts/flag-icon-css/flags/1x1/qa.svg.gz"
  },
  "/app-assets/fonts/flag-icon-css/flags/1x1/re.svg": {
    "type": "image/svg+xml",
    "etag": "\"36b-5a36g2EJGHjYZkaKgnzN9tZIMfI\"",
    "mtime": "2025-04-13T20:04:20.419Z",
    "size": 875,
    "path": "../public/app-assets/fonts/flag-icon-css/flags/1x1/re.svg"
  },
  "/app-assets/fonts/flag-icon-css/flags/1x1/ro.svg": {
    "type": "image/svg+xml",
    "etag": "\"37a-l1tacF7gu/zcBdXwJXZpxGhHzs8\"",
    "mtime": "2025-04-13T20:04:20.419Z",
    "size": 890,
    "path": "../public/app-assets/fonts/flag-icon-css/flags/1x1/ro.svg"
  },
  "/app-assets/fonts/flag-icon-css/flags/1x1/rs.svg": {
    "type": "image/svg+xml",
    "etag": "\"d5a29-5neFYKtYKel3rmlx6Gjze+SI2s4\"",
    "mtime": "2025-04-13T20:04:20.423Z",
    "size": 875049,
    "path": "../public/app-assets/fonts/flag-icon-css/flags/1x1/rs.svg"
  },
  "/app-assets/fonts/flag-icon-css/flags/1x1/rs.svg.br": {
    "type": "image/svg+xml",
    "encoding": "br",
    "etag": "\"31a7e-Ta/n5X2xhMI9Mk/PzDg+1C568Yg\"",
    "mtime": "2025-04-13T20:04:28.805Z",
    "size": 203390,
    "path": "../public/app-assets/fonts/flag-icon-css/flags/1x1/rs.svg.br"
  },
  "/app-assets/fonts/flag-icon-css/flags/1x1/rs.svg.gz": {
    "type": "image/svg+xml",
    "encoding": "gzip",
    "etag": "\"3fdb9-Ml14Dt6GSlLJoOgPfRGyCbagXIs\"",
    "mtime": "2025-04-13T20:04:28.816Z",
    "size": 261561,
    "path": "../public/app-assets/fonts/flag-icon-css/flags/1x1/rs.svg.gz"
  },
  "/app-assets/fonts/flag-icon-css/flags/1x1/ru.svg": {
    "type": "image/svg+xml",
    "etag": "\"36c-0Gej+CmMZg8NvjRkpNzyMfldRYM\"",
    "mtime": "2025-04-13T20:04:20.419Z",
    "size": 876,
    "path": "../public/app-assets/fonts/flag-icon-css/flags/1x1/ru.svg"
  },
  "/app-assets/fonts/flag-icon-css/flags/1x1/rw.svg": {
    "type": "image/svg+xml",
    "etag": "\"305-ruyNw1N7Lqu51z1YAaGZ5jfPMxA\"",
    "mtime": "2025-04-13T20:04:20.421Z",
    "size": 773,
    "path": "../public/app-assets/fonts/flag-icon-css/flags/1x1/rw.svg"
  },
  "/app-assets/fonts/flag-icon-css/flags/1x1/sa.svg": {
    "type": "image/svg+xml",
    "etag": "\"4a4d-Uj/HAV+yYFI/+8w9mPrzKGb5wwg\"",
    "mtime": "2025-04-13T20:04:20.421Z",
    "size": 19021,
    "path": "../public/app-assets/fonts/flag-icon-css/flags/1x1/sa.svg"
  },
  "/app-assets/fonts/flag-icon-css/flags/1x1/sa.svg.br": {
    "type": "image/svg+xml",
    "encoding": "br",
    "etag": "\"1abd-MxeIPT86QlOCECdE81PD6JWLDeM\"",
    "mtime": "2025-04-13T20:04:28.563Z",
    "size": 6845,
    "path": "../public/app-assets/fonts/flag-icon-css/flags/1x1/sa.svg.br"
  },
  "/app-assets/fonts/flag-icon-css/flags/1x1/sa.svg.gz": {
    "type": "image/svg+xml",
    "encoding": "gzip",
    "etag": "\"1e79-laoqbchDw++SMwWaXx/YVEOoB+4\"",
    "mtime": "2025-04-13T20:04:28.563Z",
    "size": 7801,
    "path": "../public/app-assets/fonts/flag-icon-css/flags/1x1/sa.svg.gz"
  },
  "/app-assets/fonts/flag-icon-css/flags/1x1/sb.svg": {
    "type": "image/svg+xml",
    "etag": "\"98e-Y5yhSOQn9+8F5wrhsXabXw1PRak\"",
    "mtime": "2025-04-13T20:04:20.419Z",
    "size": 2446,
    "path": "../public/app-assets/fonts/flag-icon-css/flags/1x1/sb.svg"
  },
  "/app-assets/fonts/flag-icon-css/flags/1x1/sb.svg.br": {
    "type": "image/svg+xml",
    "encoding": "br",
    "etag": "\"2b7-6I41M0T1MJUXdL9uSD2IyxHOOnc\"",
    "mtime": "2025-04-13T20:04:28.563Z",
    "size": 695,
    "path": "../public/app-assets/fonts/flag-icon-css/flags/1x1/sb.svg.br"
  },
  "/app-assets/fonts/flag-icon-css/flags/1x1/sb.svg.gz": {
    "type": "image/svg+xml",
    "encoding": "gzip",
    "etag": "\"329-t1OjnNq9T1gPgbHJq2Mh3HIN0lg\"",
    "mtime": "2025-04-13T20:04:28.563Z",
    "size": 809,
    "path": "../public/app-assets/fonts/flag-icon-css/flags/1x1/sb.svg.gz"
  },
  "/app-assets/fonts/flag-icon-css/flags/1x1/sc.svg": {
    "type": "image/svg+xml",
    "etag": "\"5b8-nfAv4+/NJxiv8LblJalvoozvdy4\"",
    "mtime": "2025-04-13T20:04:20.419Z",
    "size": 1464,
    "path": "../public/app-assets/fonts/flag-icon-css/flags/1x1/sc.svg"
  },
  "/app-assets/fonts/flag-icon-css/flags/1x1/sc.svg.br": {
    "type": "image/svg+xml",
    "encoding": "br",
    "etag": "\"223-VWRoqJxp05/A1dy178QjNFRuaMw\"",
    "mtime": "2025-04-13T20:04:28.563Z",
    "size": 547,
    "path": "../public/app-assets/fonts/flag-icon-css/flags/1x1/sc.svg.br"
  },
  "/app-assets/fonts/flag-icon-css/flags/1x1/sc.svg.gz": {
    "type": "image/svg+xml",
    "encoding": "gzip",
    "etag": "\"281-83ZvCSu1GeCmFktFGPITnkA+Y2I\"",
    "mtime": "2025-04-13T20:04:28.563Z",
    "size": 641,
    "path": "../public/app-assets/fonts/flag-icon-css/flags/1x1/sc.svg.gz"
  },
  "/app-assets/fonts/flag-icon-css/flags/1x1/sd.svg": {
    "type": "image/svg+xml",
    "etag": "\"4a1-et9VQ/6dJcjdaQpoPJ1THzjuJgc\"",
    "mtime": "2025-04-13T20:04:20.420Z",
    "size": 1185,
    "path": "../public/app-assets/fonts/flag-icon-css/flags/1x1/sd.svg"
  },
  "/app-assets/fonts/flag-icon-css/flags/1x1/sd.svg.br": {
    "type": "image/svg+xml",
    "encoding": "br",
    "etag": "\"1f8-BEVE8mvxDABa/ZEO9/gkfbp8rvo\"",
    "mtime": "2025-04-13T20:04:28.563Z",
    "size": 504,
    "path": "../public/app-assets/fonts/flag-icon-css/flags/1x1/sd.svg.br"
  },
  "/app-assets/fonts/flag-icon-css/flags/1x1/sd.svg.gz": {
    "type": "image/svg+xml",
    "encoding": "gzip",
    "etag": "\"254-UPeyWKqd0v990xLslgHSh5vJvTw\"",
    "mtime": "2025-04-13T20:04:28.563Z",
    "size": 596,
    "path": "../public/app-assets/fonts/flag-icon-css/flags/1x1/sd.svg.gz"
  },
  "/app-assets/fonts/flag-icon-css/flags/1x1/se.svg": {
    "type": "image/svg+xml",
    "etag": "\"602-l75pCFTQfW+iWd1ZmpBN449pihY\"",
    "mtime": "2025-04-13T20:04:20.420Z",
    "size": 1538,
    "path": "../public/app-assets/fonts/flag-icon-css/flags/1x1/se.svg"
  },
  "/app-assets/fonts/flag-icon-css/flags/1x1/se.svg.br": {
    "type": "image/svg+xml",
    "encoding": "br",
    "etag": "\"22e-+jmvSXJ7BNppBdpCwpbFhH7DRWw\"",
    "mtime": "2025-04-13T20:04:28.563Z",
    "size": 558,
    "path": "../public/app-assets/fonts/flag-icon-css/flags/1x1/se.svg.br"
  },
  "/app-assets/fonts/flag-icon-css/flags/1x1/se.svg.gz": {
    "type": "image/svg+xml",
    "encoding": "gzip",
    "etag": "\"293-2K9wNmGKGZOT/QaB1/i+uvPT03s\"",
    "mtime": "2025-04-13T20:04:28.563Z",
    "size": 659,
    "path": "../public/app-assets/fonts/flag-icon-css/flags/1x1/se.svg.gz"
  },
  "/app-assets/fonts/flag-icon-css/flags/1x1/sg.svg": {
    "type": "image/svg+xml",
    "etag": "\"ad3-LCeCFySDFSxUdypqmrThb/asFgE\"",
    "mtime": "2025-04-13T20:04:20.420Z",
    "size": 2771,
    "path": "../public/app-assets/fonts/flag-icon-css/flags/1x1/sg.svg"
  },
  "/app-assets/fonts/flag-icon-css/flags/1x1/sg.svg.br": {
    "type": "image/svg+xml",
    "encoding": "br",
    "etag": "\"301-NSdCiwW+ZBZ7VTeLwBJVXn6Yt9I\"",
    "mtime": "2025-04-13T20:04:28.563Z",
    "size": 769,
    "path": "../public/app-assets/fonts/flag-icon-css/flags/1x1/sg.svg.br"
  },
  "/app-assets/fonts/flag-icon-css/flags/1x1/sg.svg.gz": {
    "type": "image/svg+xml",
    "encoding": "gzip",
    "etag": "\"383-Rbm5T083dS7pitiiyfDtwPowvv4\"",
    "mtime": "2025-04-13T20:04:28.563Z",
    "size": 899,
    "path": "../public/app-assets/fonts/flag-icon-css/flags/1x1/sg.svg.gz"
  },
  "/app-assets/fonts/flag-icon-css/flags/1x1/sh.svg": {
    "type": "image/svg+xml",
    "etag": "\"125b1-J0KPEdtTqfRBKeKKOYOB5eouXKg\"",
    "mtime": "2025-04-13T20:04:20.421Z",
    "size": 75185,
    "path": "../public/app-assets/fonts/flag-icon-css/flags/1x1/sh.svg"
  },
  "/app-assets/fonts/flag-icon-css/flags/1x1/sh.svg.br": {
    "type": "image/svg+xml",
    "encoding": "br",
    "etag": "\"45f2-ZOWUnWvksR4Bl7SJbAHop8FDjXA\"",
    "mtime": "2025-04-13T20:04:28.642Z",
    "size": 17906,
    "path": "../public/app-assets/fonts/flag-icon-css/flags/1x1/sh.svg.br"
  },
  "/app-assets/fonts/flag-icon-css/flags/1x1/sh.svg.gz": {
    "type": "image/svg+xml",
    "encoding": "gzip",
    "etag": "\"519e-HYmlbJQc9RG6quhVMTWhB1Aat+s\"",
    "mtime": "2025-04-13T20:04:28.636Z",
    "size": 20894,
    "path": "../public/app-assets/fonts/flag-icon-css/flags/1x1/sh.svg.gz"
  },
  "/app-assets/fonts/flag-icon-css/flags/1x1/si.svg": {
    "type": "image/svg+xml",
    "etag": "\"1072-5dYPCQjDYFfc9QL4fahIqzqfg70\"",
    "mtime": "2025-04-13T20:04:20.420Z",
    "size": 4210,
    "path": "../public/app-assets/fonts/flag-icon-css/flags/1x1/si.svg"
  },
  "/app-assets/fonts/flag-icon-css/flags/1x1/si.svg.br": {
    "type": "image/svg+xml",
    "encoding": "br",
    "etag": "\"536-6D+eFr5R23o/Gqb3QDHsrKT3rjk\"",
    "mtime": "2025-04-13T20:04:28.563Z",
    "size": 1334,
    "path": "../public/app-assets/fonts/flag-icon-css/flags/1x1/si.svg.br"
  },
  "/app-assets/fonts/flag-icon-css/flags/1x1/si.svg.gz": {
    "type": "image/svg+xml",
    "encoding": "gzip",
    "etag": "\"62c-FybImMh3LC8RyInqEZ2EckPvkL8\"",
    "mtime": "2025-04-13T20:04:28.563Z",
    "size": 1580,
    "path": "../public/app-assets/fonts/flag-icon-css/flags/1x1/si.svg.gz"
  },
  "/app-assets/fonts/flag-icon-css/flags/1x1/sj.svg": {
    "type": "image/svg+xml",
    "etag": "\"6e4-8uYUS5jY26XsLhAztFIKHYvd5E8\"",
    "mtime": "2025-04-13T20:04:20.421Z",
    "size": 1764,
    "path": "../public/app-assets/fonts/flag-icon-css/flags/1x1/sj.svg"
  },
  "/app-assets/fonts/flag-icon-css/flags/1x1/sj.svg.br": {
    "type": "image/svg+xml",
    "encoding": "br",
    "etag": "\"22e-GRRfXMyw1eEUOJ4CEtxnmjNPBw0\"",
    "mtime": "2025-04-13T20:04:28.563Z",
    "size": 558,
    "path": "../public/app-assets/fonts/flag-icon-css/flags/1x1/sj.svg.br"
  },
  "/app-assets/fonts/flag-icon-css/flags/1x1/sj.svg.gz": {
    "type": "image/svg+xml",
    "encoding": "gzip",
    "etag": "\"299-jX72alCZaKHk4hix10kzSxQTRrs\"",
    "mtime": "2025-04-13T20:04:28.563Z",
    "size": 665,
    "path": "../public/app-assets/fonts/flag-icon-css/flags/1x1/sj.svg.gz"
  },
  "/app-assets/fonts/flag-icon-css/flags/1x1/sk.svg": {
    "type": "image/svg+xml",
    "etag": "\"8e2-onM2pRixc6SzPn6gksO08MclZho\"",
    "mtime": "2025-04-13T20:04:20.420Z",
    "size": 2274,
    "path": "../public/app-assets/fonts/flag-icon-css/flags/1x1/sk.svg"
  },
  "/app-assets/fonts/flag-icon-css/flags/1x1/sk.svg.br": {
    "type": "image/svg+xml",
    "encoding": "br",
    "etag": "\"3e1-GUZIp2xJVKG/3aV7sEsfxHbEipk\"",
    "mtime": "2025-04-13T20:04:28.563Z",
    "size": 993,
    "path": "../public/app-assets/fonts/flag-icon-css/flags/1x1/sk.svg.br"
  },
  "/app-assets/fonts/flag-icon-css/flags/1x1/sk.svg.gz": {
    "type": "image/svg+xml",
    "encoding": "gzip",
    "etag": "\"475-oQobxQCmhQpwE6hoCu5GhplfU+k\"",
    "mtime": "2025-04-13T20:04:28.563Z",
    "size": 1141,
    "path": "../public/app-assets/fonts/flag-icon-css/flags/1x1/sk.svg.gz"
  },
  "/app-assets/fonts/flag-icon-css/flags/1x1/sl.svg": {
    "type": "image/svg+xml",
    "etag": "\"859-h+0RT1+I2q9ZMI8wbBLqX3IxVaw\"",
    "mtime": "2025-04-13T20:04:20.420Z",
    "size": 2137,
    "path": "../public/app-assets/fonts/flag-icon-css/flags/1x1/sl.svg"
  },
  "/app-assets/fonts/flag-icon-css/flags/1x1/sl.svg.br": {
    "type": "image/svg+xml",
    "encoding": "br",
    "etag": "\"2fc-5hYLOc9y9CKs/2JFvHYvmv2PxRk\"",
    "mtime": "2025-04-13T20:04:28.563Z",
    "size": 764,
    "path": "../public/app-assets/fonts/flag-icon-css/flags/1x1/sl.svg.br"
  },
  "/app-assets/fonts/flag-icon-css/flags/1x1/sl.svg.gz": {
    "type": "image/svg+xml",
    "encoding": "gzip",
    "etag": "\"37a-vSe6Qar5yTbOs10VhLDaX4PHlFw\"",
    "mtime": "2025-04-13T20:04:28.563Z",
    "size": 890,
    "path": "../public/app-assets/fonts/flag-icon-css/flags/1x1/sl.svg.gz"
  },
  "/app-assets/fonts/flag-icon-css/flags/1x1/sm.svg": {
    "type": "image/svg+xml",
    "etag": "\"8db5-ppgTqCjJ5G0q5GB6idAm8L99a5U\"",
    "mtime": "2025-04-13T20:04:20.425Z",
    "size": 36277,
    "path": "../public/app-assets/fonts/flag-icon-css/flags/1x1/sm.svg"
  },
  "/app-assets/fonts/flag-icon-css/flags/1x1/sm.svg.br": {
    "type": "image/svg+xml",
    "encoding": "br",
    "etag": "\"1c62-50f3jn5lR1bvF51zxZVtEUwNyC4\"",
    "mtime": "2025-04-13T20:04:28.564Z",
    "size": 7266,
    "path": "../public/app-assets/fonts/flag-icon-css/flags/1x1/sm.svg.br"
  },
  "/app-assets/fonts/flag-icon-css/flags/1x1/sm.svg.gz": {
    "type": "image/svg+xml",
    "encoding": "gzip",
    "etag": "\"215b-dmNvRybavt/wdjSo0P+HnBy8Cbw\"",
    "mtime": "2025-04-13T20:04:28.563Z",
    "size": 8539,
    "path": "../public/app-assets/fonts/flag-icon-css/flags/1x1/sm.svg.gz"
  },
  "/app-assets/fonts/flag-icon-css/flags/1x1/sn.svg": {
    "type": "image/svg+xml",
    "etag": "\"454-vUeUr9k2zt58hy2K3Z4e3ZsmbLA\"",
    "mtime": "2025-04-13T20:04:20.425Z",
    "size": 1108,
    "path": "../public/app-assets/fonts/flag-icon-css/flags/1x1/sn.svg"
  },
  "/app-assets/fonts/flag-icon-css/flags/1x1/sn.svg.br": {
    "type": "image/svg+xml",
    "encoding": "br",
    "etag": "\"1e1-Rb5z9G/lZD9y3gjJqobdVHSIqtM\"",
    "mtime": "2025-04-13T20:04:28.563Z",
    "size": 481,
    "path": "../public/app-assets/fonts/flag-icon-css/flags/1x1/sn.svg.br"
  },
  "/app-assets/fonts/flag-icon-css/flags/1x1/sn.svg.gz": {
    "type": "image/svg+xml",
    "encoding": "gzip",
    "etag": "\"237-UXrOn5aUhQGyOczASn6VbeB+pKk\"",
    "mtime": "2025-04-13T20:04:28.563Z",
    "size": 567,
    "path": "../public/app-assets/fonts/flag-icon-css/flags/1x1/sn.svg.gz"
  },
  "/app-assets/fonts/flag-icon-css/flags/1x1/so.svg": {
    "type": "image/svg+xml",
    "etag": "\"4bc-2Ml5OMrv6KrWK6/gE4Nku17dON4\"",
    "mtime": "2025-04-13T20:04:20.422Z",
    "size": 1212,
    "path": "../public/app-assets/fonts/flag-icon-css/flags/1x1/so.svg"
  },
  "/app-assets/fonts/flag-icon-css/flags/1x1/so.svg.br": {
    "type": "image/svg+xml",
    "encoding": "br",
    "etag": "\"239-px+Iztbz0us0ogxAJvEU8G3udXM\"",
    "mtime": "2025-04-13T20:04:28.563Z",
    "size": 569,
    "path": "../public/app-assets/fonts/flag-icon-css/flags/1x1/so.svg.br"
  },
  "/app-assets/fonts/flag-icon-css/flags/1x1/so.svg.gz": {
    "type": "image/svg+xml",
    "encoding": "gzip",
    "etag": "\"294-s4tYlyzc4xDuK2la4HEMa7a7mDM\"",
    "mtime": "2025-04-13T20:04:28.563Z",
    "size": 660,
    "path": "../public/app-assets/fonts/flag-icon-css/flags/1x1/so.svg.gz"
  },
  "/app-assets/fonts/flag-icon-css/flags/1x1/sr.svg": {
    "type": "image/svg+xml",
    "etag": "\"147-vDCOu0QTqIh12M270wCHJljLrmw\"",
    "mtime": "2025-04-13T20:04:20.422Z",
    "size": 327,
    "path": "../public/app-assets/fonts/flag-icon-css/flags/1x1/sr.svg"
  },
  "/app-assets/fonts/flag-icon-css/flags/1x1/ss.svg": {
    "type": "image/svg+xml",
    "etag": "\"4e6-+ko6WLoMJqIq+X6qlDJicoY4Fis\"",
    "mtime": "2025-04-13T20:04:20.421Z",
    "size": 1254,
    "path": "../public/app-assets/fonts/flag-icon-css/flags/1x1/ss.svg"
  },
  "/app-assets/fonts/flag-icon-css/flags/1x1/ss.svg.br": {
    "type": "image/svg+xml",
    "encoding": "br",
    "etag": "\"1ff-diYkOGlORoxGEB/p89nGYPFGqe8\"",
    "mtime": "2025-04-13T20:04:28.563Z",
    "size": 511,
    "path": "../public/app-assets/fonts/flag-icon-css/flags/1x1/ss.svg.br"
  },
  "/app-assets/fonts/flag-icon-css/flags/1x1/ss.svg.gz": {
    "type": "image/svg+xml",
    "encoding": "gzip",
    "etag": "\"255-I4wL/DTv4JbaP+f47Fft+fRSGAM\"",
    "mtime": "2025-04-13T20:04:28.563Z",
    "size": 597,
    "path": "../public/app-assets/fonts/flag-icon-css/flags/1x1/ss.svg.gz"
  },
  "/app-assets/fonts/flag-icon-css/flags/1x1/st.svg": {
    "type": "image/svg+xml",
    "etag": "\"70d-ue4pf1G52jMiehMokeSliTRRMf8\"",
    "mtime": "2025-04-13T20:04:20.421Z",
    "size": 1805,
    "path": "../public/app-assets/fonts/flag-icon-css/flags/1x1/st.svg"
  },
  "/app-assets/fonts/flag-icon-css/flags/1x1/st.svg.br": {
    "type": "image/svg+xml",
    "encoding": "br",
    "etag": "\"294-OHlnJSoXoqoMWcncsCuxrUJKpqg\"",
    "mtime": "2025-04-13T20:04:28.563Z",
    "size": 660,
    "path": "../public/app-assets/fonts/flag-icon-css/flags/1x1/st.svg.br"
  },
  "/app-assets/fonts/flag-icon-css/flags/1x1/st.svg.gz": {
    "type": "image/svg+xml",
    "encoding": "gzip",
    "etag": "\"305-RQzjXYK+NRR1KyBP/RLMgEb+Bt8\"",
    "mtime": "2025-04-13T20:04:28.563Z",
    "size": 773,
    "path": "../public/app-assets/fonts/flag-icon-css/flags/1x1/st.svg.gz"
  },
  "/app-assets/fonts/flag-icon-css/flags/1x1/sv.svg": {
    "type": "image/svg+xml",
    "etag": "\"21a18-YxOkEQhVorxrKGmG9Igta5qiw+s\"",
    "mtime": "2025-04-13T20:04:20.426Z",
    "size": 137752,
    "path": "../public/app-assets/fonts/flag-icon-css/flags/1x1/sv.svg"
  },
  "/app-assets/fonts/flag-icon-css/flags/1x1/sv.svg.br": {
    "type": "image/svg+xml",
    "encoding": "br",
    "etag": "\"92c4-bf3RIwptr187BRTJudqGqRfYrC4\"",
    "mtime": "2025-04-13T20:04:28.676Z",
    "size": 37572,
    "path": "../public/app-assets/fonts/flag-icon-css/flags/1x1/sv.svg.br"
  },
  "/app-assets/fonts/flag-icon-css/flags/1x1/sv.svg.gz": {
    "type": "image/svg+xml",
    "encoding": "gzip",
    "etag": "\"a81a-uUjkOGCmGmTCbftjVBrgmgmxDoE\"",
    "mtime": "2025-04-13T20:04:28.676Z",
    "size": 43034,
    "path": "../public/app-assets/fonts/flag-icon-css/flags/1x1/sv.svg.gz"
  },
  "/app-assets/fonts/flag-icon-css/flags/1x1/sx.svg": {
    "type": "image/svg+xml",
    "etag": "\"6d4c-vLuqD0BA1GEfYWa6/zhoe7drpas\"",
    "mtime": "2025-04-13T20:04:20.422Z",
    "size": 27980,
    "path": "../public/app-assets/fonts/flag-icon-css/flags/1x1/sx.svg"
  },
  "/app-assets/fonts/flag-icon-css/flags/1x1/sx.svg.br": {
    "type": "image/svg+xml",
    "encoding": "br",
    "etag": "\"20dc-avJ/JM/+QMx7+wrq8HH1XIHIJXE\"",
    "mtime": "2025-04-13T20:04:28.564Z",
    "size": 8412,
    "path": "../public/app-assets/fonts/flag-icon-css/flags/1x1/sx.svg.br"
  },
  "/app-assets/fonts/flag-icon-css/flags/1x1/sx.svg.gz": {
    "type": "image/svg+xml",
    "encoding": "gzip",
    "etag": "\"24ee-fhB5r0QvADmfhkv9Vhv9f064/oQ\"",
    "mtime": "2025-04-13T20:04:28.563Z",
    "size": 9454,
    "path": "../public/app-assets/fonts/flag-icon-css/flags/1x1/sx.svg.gz"
  },
  "/app-assets/fonts/flag-icon-css/flags/1x1/sy.svg": {
    "type": "image/svg+xml",
    "etag": "\"841-0B8J1FRzt8rjDVMct6WWVx7yx10\"",
    "mtime": "2025-04-13T20:04:20.421Z",
    "size": 2113,
    "path": "../public/app-assets/fonts/flag-icon-css/flags/1x1/sy.svg"
  },
  "/app-assets/fonts/flag-icon-css/flags/1x1/sy.svg.br": {
    "type": "image/svg+xml",
    "encoding": "br",
    "etag": "\"258-SmSOhuAiSPzKhA90vgH4R63PXYY\"",
    "mtime": "2025-04-13T20:04:28.564Z",
    "size": 600,
    "path": "../public/app-assets/fonts/flag-icon-css/flags/1x1/sy.svg.br"
  },
  "/app-assets/fonts/flag-icon-css/flags/1x1/sy.svg.gz": {
    "type": "image/svg+xml",
    "encoding": "gzip",
    "etag": "\"2b9-5m/pBnGpmeBYjPsv2K77TINel0w\"",
    "mtime": "2025-04-13T20:04:28.564Z",
    "size": 697,
    "path": "../public/app-assets/fonts/flag-icon-css/flags/1x1/sy.svg.gz"
  },
  "/app-assets/fonts/flag-icon-css/flags/1x1/sz.svg": {
    "type": "image/svg+xml",
    "etag": "\"339d-E0WyQSx311JK9AwzrdjJym4VowI\"",
    "mtime": "2025-04-13T20:04:20.422Z",
    "size": 13213,
    "path": "../public/app-assets/fonts/flag-icon-css/flags/1x1/sz.svg"
  },
  "/app-assets/fonts/flag-icon-css/flags/1x1/sz.svg.br": {
    "type": "image/svg+xml",
    "encoding": "br",
    "etag": "\"a9a-4yhwUBLtHsT4JPFEOpLMQY/sA1I\"",
    "mtime": "2025-04-13T20:04:28.564Z",
    "size": 2714,
    "path": "../public/app-assets/fonts/flag-icon-css/flags/1x1/sz.svg.br"
  },
  "/app-assets/fonts/flag-icon-css/flags/1x1/sz.svg.gz": {
    "type": "image/svg+xml",
    "encoding": "gzip",
    "etag": "\"c7d-0KNdrI8e54fua4U0yECjrbV88bE\"",
    "mtime": "2025-04-13T20:04:28.564Z",
    "size": 3197,
    "path": "../public/app-assets/fonts/flag-icon-css/flags/1x1/sz.svg.gz"
  },
  "/app-assets/fonts/flag-icon-css/flags/1x1/tc.svg": {
    "type": "image/svg+xml",
    "etag": "\"5a5b-bY7Xxjt/wS7rm/ApfRv81ahvJbQ\"",
    "mtime": "2025-04-13T20:04:20.424Z",
    "size": 23131,
    "path": "../public/app-assets/fonts/flag-icon-css/flags/1x1/tc.svg"
  },
  "/app-assets/fonts/flag-icon-css/flags/1x1/tc.svg.br": {
    "type": "image/svg+xml",
    "encoding": "br",
    "etag": "\"1313-hlD1yxb3HzJiufvtTXsSe7jF68s\"",
    "mtime": "2025-04-13T20:04:28.564Z",
    "size": 4883,
    "path": "../public/app-assets/fonts/flag-icon-css/flags/1x1/tc.svg.br"
  },
  "/app-assets/fonts/flag-icon-css/flags/1x1/tc.svg.gz": {
    "type": "image/svg+xml",
    "encoding": "gzip",
    "etag": "\"15cc-rgSkeJd6IjstqAraBJyaWNeuAV0\"",
    "mtime": "2025-04-13T20:04:28.564Z",
    "size": 5580,
    "path": "../public/app-assets/fonts/flag-icon-css/flags/1x1/tc.svg.gz"
  },
  "/app-assets/fonts/flag-icon-css/flags/1x1/td.svg": {
    "type": "image/svg+xml",
    "etag": "\"6fa-E89fE1f+v82yOtC1E1YjYncKu8o\"",
    "mtime": "2025-04-13T20:04:20.423Z",
    "size": 1786,
    "path": "../public/app-assets/fonts/flag-icon-css/flags/1x1/td.svg"
  },
  "/app-assets/fonts/flag-icon-css/flags/1x1/td.svg.br": {
    "type": "image/svg+xml",
    "encoding": "br",
    "etag": "\"26f-fEaVLJ3jgafTH2/on6J0NOX6TEQ\"",
    "mtime": "2025-04-13T20:04:28.564Z",
    "size": 623,
    "path": "../public/app-assets/fonts/flag-icon-css/flags/1x1/td.svg.br"
  },
  "/app-assets/fonts/flag-icon-css/flags/1x1/td.svg.gz": {
    "type": "image/svg+xml",
    "encoding": "gzip",
    "etag": "\"2df-NcuU3hEdnowQQ7zGkuRPRsxk9yo\"",
    "mtime": "2025-04-13T20:04:28.564Z",
    "size": 735,
    "path": "../public/app-assets/fonts/flag-icon-css/flags/1x1/td.svg.gz"
  },
  "/app-assets/fonts/flag-icon-css/flags/1x1/tf.svg": {
    "type": "image/svg+xml",
    "etag": "\"506-1CpF9GgyXXV4PdsQFAF+7cWdt6U\"",
    "mtime": "2025-04-13T20:04:20.422Z",
    "size": 1286,
    "path": "../public/app-assets/fonts/flag-icon-css/flags/1x1/tf.svg"
  },
  "/app-assets/fonts/flag-icon-css/flags/1x1/tf.svg.br": {
    "type": "image/svg+xml",
    "encoding": "br",
    "etag": "\"1af-Uwat0TyAuxwkLBO7F6Jp135XxCg\"",
    "mtime": "2025-04-13T20:04:28.564Z",
    "size": 431,
    "path": "../public/app-assets/fonts/flag-icon-css/flags/1x1/tf.svg.br"
  },
  "/app-assets/fonts/flag-icon-css/flags/1x1/tf.svg.gz": {
    "type": "image/svg+xml",
    "encoding": "gzip",
    "etag": "\"1d9-KYRy/ij9NiDP1A5eewjn8nzcKKI\"",
    "mtime": "2025-04-13T20:04:28.564Z",
    "size": 473,
    "path": "../public/app-assets/fonts/flag-icon-css/flags/1x1/tf.svg.gz"
  },
  "/app-assets/fonts/flag-icon-css/flags/1x1/tg.svg": {
    "type": "image/svg+xml",
    "etag": "\"67a-1S/UAiIOTVkqWaezsiTBgVnIL1k\"",
    "mtime": "2025-04-13T20:04:20.423Z",
    "size": 1658,
    "path": "../public/app-assets/fonts/flag-icon-css/flags/1x1/tg.svg"
  },
  "/app-assets/fonts/flag-icon-css/flags/1x1/tg.svg.br": {
    "type": "image/svg+xml",
    "encoding": "br",
    "etag": "\"27b-405vZ7mAaZPdSWf3rR/23bIBA4M\"",
    "mtime": "2025-04-13T20:04:28.564Z",
    "size": 635,
    "path": "../public/app-assets/fonts/flag-icon-css/flags/1x1/tg.svg.br"
  },
  "/app-assets/fonts/flag-icon-css/flags/1x1/tg.svg.gz": {
    "type": "image/svg+xml",
    "encoding": "gzip",
    "etag": "\"2e8-Nd4rZzbqSWsmuRCHRa2AqoUv2eQ\"",
    "mtime": "2025-04-13T20:04:28.564Z",
    "size": 744,
    "path": "../public/app-assets/fonts/flag-icon-css/flags/1x1/tg.svg.gz"
  },
  "/app-assets/fonts/flag-icon-css/flags/1x1/th.svg": {
    "type": "image/svg+xml",
    "etag": "\"36f-G+1pYgOFyZLNK6eL9tkKpbKQLQI\"",
    "mtime": "2025-04-13T20:04:20.423Z",
    "size": 879,
    "path": "../public/app-assets/fonts/flag-icon-css/flags/1x1/th.svg"
  },
  "/app-assets/fonts/flag-icon-css/flags/1x1/tj.svg": {
    "type": "image/svg+xml",
    "etag": "\"13fc-A27/w/AULmEAbqfcPc//hl5+4+s\"",
    "mtime": "2025-04-13T20:04:20.424Z",
    "size": 5116,
    "path": "../public/app-assets/fonts/flag-icon-css/flags/1x1/tj.svg"
  },
  "/app-assets/fonts/flag-icon-css/flags/1x1/tj.svg.br": {
    "type": "image/svg+xml",
    "encoding": "br",
    "etag": "\"59a-eeeChAQcVli8wVeCBnCWth4YjtI\"",
    "mtime": "2025-04-13T20:04:28.564Z",
    "size": 1434,
    "path": "../public/app-assets/fonts/flag-icon-css/flags/1x1/tj.svg.br"
  },
  "/app-assets/fonts/flag-icon-css/flags/1x1/tj.svg.gz": {
    "type": "image/svg+xml",
    "encoding": "gzip",
    "etag": "\"682-aOb2Vty/ZF8fjk/qhmRyTrq2Sis\"",
    "mtime": "2025-04-13T20:04:28.564Z",
    "size": 1666,
    "path": "../public/app-assets/fonts/flag-icon-css/flags/1x1/tj.svg.gz"
  },
  "/app-assets/fonts/flag-icon-css/flags/1x1/tk.svg": {
    "type": "image/svg+xml",
    "etag": "\"684-UWdvAXr8VxY4lGHHnhLRqdF6ymk\"",
    "mtime": "2025-04-13T20:04:20.423Z",
    "size": 1668,
    "path": "../public/app-assets/fonts/flag-icon-css/flags/1x1/tk.svg"
  },
  "/app-assets/fonts/flag-icon-css/flags/1x1/tk.svg.br": {
    "type": "image/svg+xml",
    "encoding": "br",
    "etag": "\"2af-ck+n186skdADCOSsm1d/nWw8YQU\"",
    "mtime": "2025-04-13T20:04:28.564Z",
    "size": 687,
    "path": "../public/app-assets/fonts/flag-icon-css/flags/1x1/tk.svg.br"
  },
  "/app-assets/fonts/flag-icon-css/flags/1x1/tk.svg.gz": {
    "type": "image/svg+xml",
    "encoding": "gzip",
    "etag": "\"346-a+03JmHcO276fTHRczO+X+qoFio\"",
    "mtime": "2025-04-13T20:04:28.564Z",
    "size": 838,
    "path": "../public/app-assets/fonts/flag-icon-css/flags/1x1/tk.svg.gz"
  },
  "/app-assets/fonts/flag-icon-css/flags/1x1/tl.svg": {
    "type": "image/svg+xml",
    "etag": "\"53a-FO2mwPLSctG3kGzSc7Nq8ae9BXs\"",
    "mtime": "2025-04-13T20:04:20.424Z",
    "size": 1338,
    "path": "../public/app-assets/fonts/flag-icon-css/flags/1x1/tl.svg"
  },
  "/app-assets/fonts/flag-icon-css/flags/1x1/tl.svg.br": {
    "type": "image/svg+xml",
    "encoding": "br",
    "etag": "\"256-GT7DyHXkCeh+JLCpNsXk63hgP3A\"",
    "mtime": "2025-04-13T20:04:28.564Z",
    "size": 598,
    "path": "../public/app-assets/fonts/flag-icon-css/flags/1x1/tl.svg.br"
  },
  "/app-assets/fonts/flag-icon-css/flags/1x1/tl.svg.gz": {
    "type": "image/svg+xml",
    "encoding": "gzip",
    "etag": "\"2ba-mCOxhwTVgCkdAnQC53WW/wvL0wU\"",
    "mtime": "2025-04-13T20:04:28.564Z",
    "size": 698,
    "path": "../public/app-assets/fonts/flag-icon-css/flags/1x1/tl.svg.gz"
  },
  "/app-assets/fonts/flag-icon-css/flags/1x1/tm.svg": {
    "type": "image/svg+xml",
    "etag": "\"12077-oEWinDvoYt4L/04XlUG6NevyRAU\"",
    "mtime": "2025-04-13T20:04:20.425Z",
    "size": 73847,
    "path": "../public/app-assets/fonts/flag-icon-css/flags/1x1/tm.svg"
  },
  "/app-assets/fonts/flag-icon-css/flags/1x1/tm.svg.br": {
    "type": "image/svg+xml",
    "encoding": "br",
    "etag": "\"1a77-9rhDdGrNCN0z2NqfZH8OMVbTzU0\"",
    "mtime": "2025-04-13T20:04:28.565Z",
    "size": 6775,
    "path": "../public/app-assets/fonts/flag-icon-css/flags/1x1/tm.svg.br"
  },
  "/app-assets/fonts/flag-icon-css/flags/1x1/tm.svg.gz": {
    "type": "image/svg+xml",
    "encoding": "gzip",
    "etag": "\"1fc6-Z17/3PZQD2bS/O/08k0gcwky8P4\"",
    "mtime": "2025-04-13T20:04:28.564Z",
    "size": 8134,
    "path": "../public/app-assets/fonts/flag-icon-css/flags/1x1/tm.svg.gz"
  },
  "/app-assets/fonts/flag-icon-css/flags/1x1/tn.svg": {
    "type": "image/svg+xml",
    "etag": "\"790-72uaptIDhLqooTZLgE4eY4p6cwc\"",
    "mtime": "2025-04-13T20:04:20.424Z",
    "size": 1936,
    "path": "../public/app-assets/fonts/flag-icon-css/flags/1x1/tn.svg"
  },
  "/app-assets/fonts/flag-icon-css/flags/1x1/tn.svg.br": {
    "type": "image/svg+xml",
    "encoding": "br",
    "etag": "\"33f-0NgdouuckvemHgS3I91omhbdcmU\"",
    "mtime": "2025-04-13T20:04:28.564Z",
    "size": 831,
    "path": "../public/app-assets/fonts/flag-icon-css/flags/1x1/tn.svg.br"
  },
  "/app-assets/fonts/flag-icon-css/flags/1x1/tn.svg.gz": {
    "type": "image/svg+xml",
    "encoding": "gzip",
    "etag": "\"3cf-IMzx1xCvjM2Zv9tPMBnbbX4KLNs\"",
    "mtime": "2025-04-13T20:04:28.564Z",
    "size": 975,
    "path": "../public/app-assets/fonts/flag-icon-css/flags/1x1/tn.svg.gz"
  },
  "/app-assets/fonts/flag-icon-css/flags/1x1/to.svg": {
    "type": "image/svg+xml",
    "etag": "\"435-cORZd03A11jo55D7Gq/4gZyh24U\"",
    "mtime": "2025-04-13T20:04:20.423Z",
    "size": 1077,
    "path": "../public/app-assets/fonts/flag-icon-css/flags/1x1/to.svg"
  },
  "/app-assets/fonts/flag-icon-css/flags/1x1/to.svg.br": {
    "type": "image/svg+xml",
    "encoding": "br",
    "etag": "\"1c5-0ITSOz/07cv5UJNBUIoSxETaKRg\"",
    "mtime": "2025-04-13T20:04:28.564Z",
    "size": 453,
    "path": "../public/app-assets/fonts/flag-icon-css/flags/1x1/to.svg.br"
  },
  "/app-assets/fonts/flag-icon-css/flags/1x1/to.svg.gz": {
    "type": "image/svg+xml",
    "encoding": "gzip",
    "etag": "\"21a-Z+mMvHmPAKG1LT3+LhRUmGCZ13w\"",
    "mtime": "2025-04-13T20:04:28.564Z",
    "size": 538,
    "path": "../public/app-assets/fonts/flag-icon-css/flags/1x1/to.svg.gz"
  },
  "/app-assets/fonts/flag-icon-css/flags/1x1/tr.svg": {
    "type": "image/svg+xml",
    "etag": "\"2d3-tmEG5xi7cjrk2KlFW5AwN7IHnAE\"",
    "mtime": "2025-04-13T20:04:20.425Z",
    "size": 723,
    "path": "../public/app-assets/fonts/flag-icon-css/flags/1x1/tr.svg"
  },
  "/app-assets/fonts/flag-icon-css/flags/1x1/tt.svg": {
    "type": "image/svg+xml",
    "etag": "\"491-PFmniaozz883zYd2HIg9oXh8Y9Y\"",
    "mtime": "2025-04-13T20:04:20.426Z",
    "size": 1169,
    "path": "../public/app-assets/fonts/flag-icon-css/flags/1x1/tt.svg"
  },
  "/app-assets/fonts/flag-icon-css/flags/1x1/tt.svg.br": {
    "type": "image/svg+xml",
    "encoding": "br",
    "etag": "\"1f4-kzkLnkC/ATo1glVRjqBVEiMY4oM\"",
    "mtime": "2025-04-13T20:04:28.564Z",
    "size": 500,
    "path": "../public/app-assets/fonts/flag-icon-css/flags/1x1/tt.svg.br"
  },
  "/app-assets/fonts/flag-icon-css/flags/1x1/tt.svg.gz": {
    "type": "image/svg+xml",
    "encoding": "gzip",
    "etag": "\"24e-xY4+3JP63atUxIEZd78XQyXwYkE\"",
    "mtime": "2025-04-13T20:04:28.564Z",
    "size": 590,
    "path": "../public/app-assets/fonts/flag-icon-css/flags/1x1/tt.svg.gz"
  },
  "/app-assets/fonts/flag-icon-css/flags/1x1/tv.svg": {
    "type": "image/svg+xml",
    "etag": "\"137f-V2aHyabdNG1EEwd2dXM7delGRr4\"",
    "mtime": "2025-04-13T20:04:20.424Z",
    "size": 4991,
    "path": "../public/app-assets/fonts/flag-icon-css/flags/1x1/tv.svg"
  },
  "/app-assets/fonts/flag-icon-css/flags/1x1/tv.svg.br": {
    "type": "image/svg+xml",
    "encoding": "br",
    "etag": "\"4db-BEdVzW6CDNfAarUgA94qf12Gu3g\"",
    "mtime": "2025-04-13T20:04:28.564Z",
    "size": 1243,
    "path": "../public/app-assets/fonts/flag-icon-css/flags/1x1/tv.svg.br"
  },
  "/app-assets/fonts/flag-icon-css/flags/1x1/tv.svg.gz": {
    "type": "image/svg+xml",
    "encoding": "gzip",
    "etag": "\"586-bg2ajTcVIsq0lkIhlRgsWKZlf1w\"",
    "mtime": "2025-04-13T20:04:28.564Z",
    "size": 1414,
    "path": "../public/app-assets/fonts/flag-icon-css/flags/1x1/tv.svg.gz"
  },
  "/app-assets/fonts/flag-icon-css/flags/1x1/tw.svg": {
    "type": "image/svg+xml",
    "etag": "\"bf1-jFW3GxWBBbfrWwSKxZetIb0wq+4\"",
    "mtime": "2025-04-13T20:04:20.424Z",
    "size": 3057,
    "path": "../public/app-assets/fonts/flag-icon-css/flags/1x1/tw.svg"
  },
  "/app-assets/fonts/flag-icon-css/flags/1x1/tw.svg.br": {
    "type": "image/svg+xml",
    "encoding": "br",
    "etag": "\"4a7-QuCipqcZnhrQrUWgSYkdMn9EI2A\"",
    "mtime": "2025-04-13T20:04:28.564Z",
    "size": 1191,
    "path": "../public/app-assets/fonts/flag-icon-css/flags/1x1/tw.svg.br"
  },
  "/app-assets/fonts/flag-icon-css/flags/1x1/tw.svg.gz": {
    "type": "image/svg+xml",
    "encoding": "gzip",
    "etag": "\"57d-T173/ni5GLFhzQrCOKlY1xqclMI\"",
    "mtime": "2025-04-13T20:04:28.564Z",
    "size": 1405,
    "path": "../public/app-assets/fonts/flag-icon-css/flags/1x1/tw.svg.gz"
  },
  "/app-assets/fonts/flag-icon-css/flags/1x1/tz.svg": {
    "type": "image/svg+xml",
    "etag": "\"562-XOpvDyMmNY/mD+q3jnU+muoDEs4\"",
    "mtime": "2025-04-13T20:04:20.427Z",
    "size": 1378,
    "path": "../public/app-assets/fonts/flag-icon-css/flags/1x1/tz.svg"
  },
  "/app-assets/fonts/flag-icon-css/flags/1x1/tz.svg.br": {
    "type": "image/svg+xml",
    "encoding": "br",
    "etag": "\"25e-TXsmq7iuD/1ch7mQV83f3K6irxs\"",
    "mtime": "2025-04-13T20:04:28.564Z",
    "size": 606,
    "path": "../public/app-assets/fonts/flag-icon-css/flags/1x1/tz.svg.br"
  },
  "/app-assets/fonts/flag-icon-css/flags/1x1/tz.svg.gz": {
    "type": "image/svg+xml",
    "encoding": "gzip",
    "etag": "\"2c3-8pV1fXtZeNOgw2qclp7NyObojaA\"",
    "mtime": "2025-04-13T20:04:28.564Z",
    "size": 707,
    "path": "../public/app-assets/fonts/flag-icon-css/flags/1x1/tz.svg.gz"
  },
  "/app-assets/fonts/flag-icon-css/flags/1x1/ua.svg": {
    "type": "image/svg+xml",
    "etag": "\"316-21fdgfe5vArQtH7yol3Q/uxvSAg\"",
    "mtime": "2025-04-13T20:04:20.425Z",
    "size": 790,
    "path": "../public/app-assets/fonts/flag-icon-css/flags/1x1/ua.svg"
  },
  "/app-assets/fonts/flag-icon-css/flags/1x1/ug.svg": {
    "type": "image/svg+xml",
    "etag": "\"1a8c-KiV061RLhftI9IflT7e5jCoC8dY\"",
    "mtime": "2025-04-13T20:04:20.425Z",
    "size": 6796,
    "path": "../public/app-assets/fonts/flag-icon-css/flags/1x1/ug.svg"
  },
  "/app-assets/fonts/flag-icon-css/flags/1x1/ug.svg.br": {
    "type": "image/svg+xml",
    "encoding": "br",
    "etag": "\"850-mesB4KCyxp/ofokRMiTSqFRJZqc\"",
    "mtime": "2025-04-13T20:04:28.565Z",
    "size": 2128,
    "path": "../public/app-assets/fonts/flag-icon-css/flags/1x1/ug.svg.br"
  },
  "/app-assets/fonts/flag-icon-css/flags/1x1/ug.svg.gz": {
    "type": "image/svg+xml",
    "encoding": "gzip",
    "etag": "\"952-+M/IMWs46281IXLjsn+ko1a4WnU\"",
    "mtime": "2025-04-13T20:04:28.565Z",
    "size": 2386,
    "path": "../public/app-assets/fonts/flag-icon-css/flags/1x1/ug.svg.gz"
  },
  "/app-assets/fonts/flag-icon-css/flags/1x1/um.svg": {
    "type": "image/svg+xml",
    "etag": "\"5b67-L9+98JsfdCwciS2wtJ6fXVQPgXM\"",
    "mtime": "2025-04-13T20:04:20.426Z",
    "size": 23399,
    "path": "../public/app-assets/fonts/flag-icon-css/flags/1x1/um.svg"
  },
  "/app-assets/fonts/flag-icon-css/flags/1x1/um.svg.br": {
    "type": "image/svg+xml",
    "encoding": "br",
    "etag": "\"417-dJVenzFkWlz15oVA9YN42V+VYLo\"",
    "mtime": "2025-04-13T20:04:28.565Z",
    "size": 1047,
    "path": "../public/app-assets/fonts/flag-icon-css/flags/1x1/um.svg.br"
  },
  "/app-assets/fonts/flag-icon-css/flags/1x1/um.svg.gz": {
    "type": "image/svg+xml",
    "encoding": "gzip",
    "etag": "\"557-pEGgV0tKBklBvpJHg6/T5brJZhI\"",
    "mtime": "2025-04-13T20:04:28.565Z",
    "size": 1367,
    "path": "../public/app-assets/fonts/flag-icon-css/flags/1x1/um.svg.gz"
  },
  "/app-assets/fonts/flag-icon-css/flags/1x1/us.svg": {
    "type": "image/svg+xml",
    "etag": "\"5b6c-xo81rAVAZLSnHrOUIuNoH0ttIi0\"",
    "mtime": "2025-04-13T20:04:20.426Z",
    "size": 23404,
    "path": "../public/app-assets/fonts/flag-icon-css/flags/1x1/us.svg"
  },
  "/app-assets/fonts/flag-icon-css/flags/1x1/us.svg.br": {
    "type": "image/svg+xml",
    "encoding": "br",
    "etag": "\"41d-edb/7+AH6mr1Tc+YvYJHi6jMSXs\"",
    "mtime": "2025-04-13T20:04:28.565Z",
    "size": 1053,
    "path": "../public/app-assets/fonts/flag-icon-css/flags/1x1/us.svg.br"
  },
  "/app-assets/fonts/flag-icon-css/flags/1x1/us.svg.gz": {
    "type": "image/svg+xml",
    "encoding": "gzip",
    "etag": "\"55a-HpvUrgJqFTBNKPyF3QHG2fyG8bY\"",
    "mtime": "2025-04-13T20:04:28.565Z",
    "size": 1370,
    "path": "../public/app-assets/fonts/flag-icon-css/flags/1x1/us.svg.gz"
  },
  "/app-assets/fonts/flag-icon-css/flags/1x1/uy.svg": {
    "type": "image/svg+xml",
    "etag": "\"274b-jqQARKg7MDN23Y2HZ0X91ub3n0k\"",
    "mtime": "2025-04-13T20:04:20.425Z",
    "size": 10059,
    "path": "../public/app-assets/fonts/flag-icon-css/flags/1x1/uy.svg"
  },
  "/app-assets/fonts/flag-icon-css/flags/1x1/uy.svg.br": {
    "type": "image/svg+xml",
    "encoding": "br",
    "etag": "\"62e-CXnekspztAYi5+GbAz8DAVTpeBQ\"",
    "mtime": "2025-04-13T20:04:28.565Z",
    "size": 1582,
    "path": "../public/app-assets/fonts/flag-icon-css/flags/1x1/uy.svg.br"
  },
  "/app-assets/fonts/flag-icon-css/flags/1x1/uy.svg.gz": {
    "type": "image/svg+xml",
    "encoding": "gzip",
    "etag": "\"71f-7RsgsFBJpINvY7ejV3NIZz3sUeo\"",
    "mtime": "2025-04-13T20:04:28.565Z",
    "size": 1823,
    "path": "../public/app-assets/fonts/flag-icon-css/flags/1x1/uy.svg.gz"
  },
  "/app-assets/fonts/flag-icon-css/flags/1x1/uz.svg": {
    "type": "image/svg+xml",
    "etag": "\"5b9-oWMQTarI4kCT3QMo2IXPq4E4L40\"",
    "mtime": "2025-04-13T20:04:20.425Z",
    "size": 1465,
    "path": "../public/app-assets/fonts/flag-icon-css/flags/1x1/uz.svg"
  },
  "/app-assets/fonts/flag-icon-css/flags/1x1/uz.svg.br": {
    "type": "image/svg+xml",
    "encoding": "br",
    "etag": "\"185-lKaadYMR99Dpo9mLdKg2Nhc6scc\"",
    "mtime": "2025-04-13T20:04:28.565Z",
    "size": 389,
    "path": "../public/app-assets/fonts/flag-icon-css/flags/1x1/uz.svg.br"
  },
  "/app-assets/fonts/flag-icon-css/flags/1x1/uz.svg.gz": {
    "type": "image/svg+xml",
    "encoding": "gzip",
    "etag": "\"1ba-KFWALddXMhgfTcDoNG2EQ0PED4k\"",
    "mtime": "2025-04-13T20:04:28.565Z",
    "size": 442,
    "path": "../public/app-assets/fonts/flag-icon-css/flags/1x1/uz.svg.gz"
  },
  "/app-assets/fonts/flag-icon-css/flags/1x1/va.svg": {
    "type": "image/svg+xml",
    "etag": "\"1e2ab-SgcGgntcVAvsM2lfnI8KXoXLPYc\"",
    "mtime": "2025-04-13T20:04:20.426Z",
    "size": 123563,
    "path": "../public/app-assets/fonts/flag-icon-css/flags/1x1/va.svg"
  },
  "/app-assets/fonts/flag-icon-css/flags/1x1/va.svg.br": {
    "type": "image/svg+xml",
    "encoding": "br",
    "etag": "\"2172-BDQz0CF25ZZaBUene8fzv8nuI1c\"",
    "mtime": "2025-04-13T20:04:28.565Z",
    "size": 8562,
    "path": "../public/app-assets/fonts/flag-icon-css/flags/1x1/va.svg.br"
  },
  "/app-assets/fonts/flag-icon-css/flags/1x1/va.svg.gz": {
    "type": "image/svg+xml",
    "encoding": "gzip",
    "etag": "\"2d74-KXdiX5BCkJwkXhvyV3ew58Tsn5I\"",
    "mtime": "2025-04-13T20:04:28.565Z",
    "size": 11636,
    "path": "../public/app-assets/fonts/flag-icon-css/flags/1x1/va.svg.gz"
  },
  "/app-assets/fonts/flag-icon-css/flags/1x1/vc.svg": {
    "type": "image/svg+xml",
    "etag": "\"4fc-pMK68GcW/nnvR6yDPOnkQftN2gQ\"",
    "mtime": "2025-04-13T20:04:20.425Z",
    "size": 1276,
    "path": "../public/app-assets/fonts/flag-icon-css/flags/1x1/vc.svg"
  },
  "/app-assets/fonts/flag-icon-css/flags/1x1/vc.svg.br": {
    "type": "image/svg+xml",
    "encoding": "br",
    "etag": "\"1ff-ow7Jn0S8JivFxf9QwI7qR8fZfTw\"",
    "mtime": "2025-04-13T20:04:28.565Z",
    "size": 511,
    "path": "../public/app-assets/fonts/flag-icon-css/flags/1x1/vc.svg.br"
  },
  "/app-assets/fonts/flag-icon-css/flags/1x1/vc.svg.gz": {
    "type": "image/svg+xml",
    "encoding": "gzip",
    "etag": "\"257-G1o9WyM+AJUNgK/MT/N3tDTkLKE\"",
    "mtime": "2025-04-13T20:04:28.565Z",
    "size": 599,
    "path": "../public/app-assets/fonts/flag-icon-css/flags/1x1/vc.svg.gz"
  },
  "/app-assets/fonts/flag-icon-css/flags/1x1/ve.svg": {
    "type": "image/svg+xml",
    "etag": "\"4f7-vhdf0FecLrx6EOvmx4wkV6wktNY\"",
    "mtime": "2025-04-13T20:04:20.425Z",
    "size": 1271,
    "path": "../public/app-assets/fonts/flag-icon-css/flags/1x1/ve.svg"
  },
  "/app-assets/fonts/flag-icon-css/flags/1x1/ve.svg.br": {
    "type": "image/svg+xml",
    "encoding": "br",
    "etag": "\"194-0YohsixU09S9lRYRnzSYXIPRl9c\"",
    "mtime": "2025-04-13T20:04:28.565Z",
    "size": 404,
    "path": "../public/app-assets/fonts/flag-icon-css/flags/1x1/ve.svg.br"
  },
  "/app-assets/fonts/flag-icon-css/flags/1x1/ve.svg.gz": {
    "type": "image/svg+xml",
    "encoding": "gzip",
    "etag": "\"1c1-qUEJzVwHJIzPGB8vkrLfho32vnU\"",
    "mtime": "2025-04-13T20:04:28.565Z",
    "size": 449,
    "path": "../public/app-assets/fonts/flag-icon-css/flags/1x1/ve.svg.gz"
  },
  "/app-assets/fonts/flag-icon-css/flags/1x1/vg.svg": {
    "type": "image/svg+xml",
    "etag": "\"c34c-sl/6f332BrhnVT+Nf5iJDgDbV14\"",
    "mtime": "2025-04-13T20:04:20.428Z",
    "size": 49996,
    "path": "../public/app-assets/fonts/flag-icon-css/flags/1x1/vg.svg"
  },
  "/app-assets/fonts/flag-icon-css/flags/1x1/vg.svg.br": {
    "type": "image/svg+xml",
    "encoding": "br",
    "etag": "\"22fb-Nq4Eg53JKcbZrj3q8eCKFqT0vOQ\"",
    "mtime": "2025-04-13T20:04:28.566Z",
    "size": 8955,
    "path": "../public/app-assets/fonts/flag-icon-css/flags/1x1/vg.svg.br"
  },
  "/app-assets/fonts/flag-icon-css/flags/1x1/vg.svg.gz": {
    "type": "image/svg+xml",
    "encoding": "gzip",
    "etag": "\"292c-t6BgZSG/84A+W/uQ8AJZb6Rwb7w\"",
    "mtime": "2025-04-13T20:04:28.566Z",
    "size": 10540,
    "path": "../public/app-assets/fonts/flag-icon-css/flags/1x1/vg.svg.gz"
  },
  "/app-assets/fonts/flag-icon-css/flags/1x1/vi.svg": {
    "type": "image/svg+xml",
    "etag": "\"311a-ZFP3bQJqNLNfY2rPPnuSC6/9Izk\"",
    "mtime": "2025-04-13T20:04:20.426Z",
    "size": 12570,
    "path": "../public/app-assets/fonts/flag-icon-css/flags/1x1/vi.svg"
  },
  "/app-assets/fonts/flag-icon-css/flags/1x1/vi.svg.br": {
    "type": "image/svg+xml",
    "encoding": "br",
    "etag": "\"12fa-U9BvmMSXTQcpq7eesopYMEcN98Y\"",
    "mtime": "2025-04-13T20:04:28.566Z",
    "size": 4858,
    "path": "../public/app-assets/fonts/flag-icon-css/flags/1x1/vi.svg.br"
  },
  "/app-assets/fonts/flag-icon-css/flags/1x1/vi.svg.gz": {
    "type": "image/svg+xml",
    "encoding": "gzip",
    "etag": "\"14d9-3JrvnitLbFlfwyomVrFlB4FH3Pk\"",
    "mtime": "2025-04-13T20:04:28.565Z",
    "size": 5337,
    "path": "../public/app-assets/fonts/flag-icon-css/flags/1x1/vi.svg.gz"
  },
  "/app-assets/fonts/flag-icon-css/flags/1x1/vn.svg": {
    "type": "image/svg+xml",
    "etag": "\"4be-zg25WDdW6QBHdG0vfnIvu3ty1Fg\"",
    "mtime": "2025-04-13T20:04:20.426Z",
    "size": 1214,
    "path": "../public/app-assets/fonts/flag-icon-css/flags/1x1/vn.svg"
  },
  "/app-assets/fonts/flag-icon-css/flags/1x1/vn.svg.br": {
    "type": "image/svg+xml",
    "encoding": "br",
    "etag": "\"231-+ieBsF4hVHwUPBjJYQ1AddSLmG4\"",
    "mtime": "2025-04-13T20:04:28.565Z",
    "size": 561,
    "path": "../public/app-assets/fonts/flag-icon-css/flags/1x1/vn.svg.br"
  },
  "/app-assets/fonts/flag-icon-css/flags/1x1/vn.svg.gz": {
    "type": "image/svg+xml",
    "encoding": "gzip",
    "etag": "\"296-CjBBiZq8OPakkdkRPR9dY032L6U\"",
    "mtime": "2025-04-13T20:04:28.565Z",
    "size": 662,
    "path": "../public/app-assets/fonts/flag-icon-css/flags/1x1/vn.svg.gz"
  },
  "/app-assets/fonts/flag-icon-css/flags/1x1/vu.svg": {
    "type": "image/svg+xml",
    "etag": "\"1af1-NJrF/NUhsuancXSPRJ35WUrBLC0\"",
    "mtime": "2025-04-13T20:04:20.426Z",
    "size": 6897,
    "path": "../public/app-assets/fonts/flag-icon-css/flags/1x1/vu.svg"
  },
  "/app-assets/fonts/flag-icon-css/flags/1x1/vu.svg.br": {
    "type": "image/svg+xml",
    "encoding": "br",
    "etag": "\"726-amaI2I1yJkpcdDLc0g+uHIGEpB4\"",
    "mtime": "2025-04-13T20:04:28.565Z",
    "size": 1830,
    "path": "../public/app-assets/fonts/flag-icon-css/flags/1x1/vu.svg.br"
  },
  "/app-assets/fonts/flag-icon-css/flags/1x1/vu.svg.gz": {
    "type": "image/svg+xml",
    "encoding": "gzip",
    "etag": "\"82b-2TMEWfvNsV8f80lOUijKRYCc+Mc\"",
    "mtime": "2025-04-13T20:04:28.565Z",
    "size": 2091,
    "path": "../public/app-assets/fonts/flag-icon-css/flags/1x1/vu.svg.gz"
  },
  "/app-assets/fonts/flag-icon-css/flags/1x1/wf.svg": {
    "type": "image/svg+xml",
    "etag": "\"35d-T18BDIsAnFYKxiARzGDY3rp/Kfk\"",
    "mtime": "2025-04-13T20:04:20.426Z",
    "size": 861,
    "path": "../public/app-assets/fonts/flag-icon-css/flags/1x1/wf.svg"
  },
  "/app-assets/fonts/flag-icon-css/flags/1x1/ws.svg": {
    "type": "image/svg+xml",
    "etag": "\"b91-tM79s+Jw2nYq2pSTcoaxZSdBRuk\"",
    "mtime": "2025-04-13T20:04:20.427Z",
    "size": 2961,
    "path": "../public/app-assets/fonts/flag-icon-css/flags/1x1/ws.svg"
  },
  "/app-assets/fonts/flag-icon-css/flags/1x1/ws.svg.br": {
    "type": "image/svg+xml",
    "encoding": "br",
    "etag": "\"4a0-4RDYZq8L5285PmanlLkrD7BWwhc\"",
    "mtime": "2025-04-13T20:04:28.565Z",
    "size": 1184,
    "path": "../public/app-assets/fonts/flag-icon-css/flags/1x1/ws.svg.br"
  },
  "/app-assets/fonts/flag-icon-css/flags/1x1/ws.svg.gz": {
    "type": "image/svg+xml",
    "encoding": "gzip",
    "etag": "\"594-2oIqhPhgyv/SRb1JKajziD0NlJY\"",
    "mtime": "2025-04-13T20:04:28.565Z",
    "size": 1428,
    "path": "../public/app-assets/fonts/flag-icon-css/flags/1x1/ws.svg.gz"
  },
  "/app-assets/fonts/flag-icon-css/flags/1x1/ye.svg": {
    "type": "image/svg+xml",
    "etag": "\"369-n76p8VIIo9R1Gu+ZRpu7yiRYwYg\"",
    "mtime": "2025-04-13T20:04:20.427Z",
    "size": 873,
    "path": "../public/app-assets/fonts/flag-icon-css/flags/1x1/ye.svg"
  },
  "/app-assets/fonts/flag-icon-css/flags/1x1/yt.svg": {
    "type": "image/svg+xml",
    "etag": "\"36b-pWqv1hRFCuTyM78008ri95TiCGA\"",
    "mtime": "2025-04-13T20:04:20.427Z",
    "size": 875,
    "path": "../public/app-assets/fonts/flag-icon-css/flags/1x1/yt.svg"
  },
  "/app-assets/fonts/flag-icon-css/flags/1x1/za.svg": {
    "type": "image/svg+xml",
    "etag": "\"6e6-aHJuZ3U4hfE3zfCc3Kkjy3x3OZc\"",
    "mtime": "2025-04-13T20:04:20.427Z",
    "size": 1766,
    "path": "../public/app-assets/fonts/flag-icon-css/flags/1x1/za.svg"
  },
  "/app-assets/fonts/flag-icon-css/flags/1x1/za.svg.br": {
    "type": "image/svg+xml",
    "encoding": "br",
    "etag": "\"2ca-5rYXlD1aA7fuza5dwJSXmJLbRZQ\"",
    "mtime": "2025-04-13T20:04:28.565Z",
    "size": 714,
    "path": "../public/app-assets/fonts/flag-icon-css/flags/1x1/za.svg.br"
  },
  "/app-assets/fonts/flag-icon-css/flags/1x1/za.svg.gz": {
    "type": "image/svg+xml",
    "encoding": "gzip",
    "etag": "\"33c-vwndbxpqh5j/jSd/tSmNq/yEjxY\"",
    "mtime": "2025-04-13T20:04:28.565Z",
    "size": 828,
    "path": "../public/app-assets/fonts/flag-icon-css/flags/1x1/za.svg.gz"
  },
  "/app-assets/fonts/flag-icon-css/flags/1x1/zm.svg": {
    "type": "image/svg+xml",
    "etag": "\"2a11-mYaf6o+uWKH4l5l6WB844lO3h9o\"",
    "mtime": "2025-04-13T20:04:20.428Z",
    "size": 10769,
    "path": "../public/app-assets/fonts/flag-icon-css/flags/1x1/zm.svg"
  },
  "/app-assets/fonts/flag-icon-css/flags/1x1/zm.svg.br": {
    "type": "image/svg+xml",
    "encoding": "br",
    "etag": "\"ec6-dShYAGA/tceYucQNoIdvwcX+uW8\"",
    "mtime": "2025-04-13T20:04:28.565Z",
    "size": 3782,
    "path": "../public/app-assets/fonts/flag-icon-css/flags/1x1/zm.svg.br"
  },
  "/app-assets/fonts/flag-icon-css/flags/1x1/zm.svg.gz": {
    "type": "image/svg+xml",
    "encoding": "gzip",
    "etag": "\"10c2-f/iMz83Jtt/0zIYEo2VB5PM+SvY\"",
    "mtime": "2025-04-13T20:04:28.565Z",
    "size": 4290,
    "path": "../public/app-assets/fonts/flag-icon-css/flags/1x1/zm.svg.gz"
  },
  "/app-assets/fonts/flag-icon-css/flags/1x1/zw.svg": {
    "type": "image/svg+xml",
    "etag": "\"148b-r8aUFV4SAvDEEo9Ek53badk3pvs\"",
    "mtime": "2025-04-13T20:04:20.427Z",
    "size": 5259,
    "path": "../public/app-assets/fonts/flag-icon-css/flags/1x1/zw.svg"
  },
  "/app-assets/fonts/flag-icon-css/flags/1x1/zw.svg.br": {
    "type": "image/svg+xml",
    "encoding": "br",
    "etag": "\"631-GZKWr8NTzoy6CPZRiZ/HHf9t1UU\"",
    "mtime": "2025-04-13T20:04:28.566Z",
    "size": 1585,
    "path": "../public/app-assets/fonts/flag-icon-css/flags/1x1/zw.svg.br"
  },
  "/app-assets/fonts/flag-icon-css/flags/1x1/zw.svg.gz": {
    "type": "image/svg+xml",
    "encoding": "gzip",
    "etag": "\"713-xdHKS/CrGaZsrz44q6zycpXxO3Y\"",
    "mtime": "2025-04-13T20:04:28.565Z",
    "size": 1811,
    "path": "../public/app-assets/fonts/flag-icon-css/flags/1x1/zw.svg.gz"
  },
  "/app-assets/fonts/flag-icon-css/flags/1x1/zz.svg": {
    "type": "image/svg+xml",
    "etag": "\"f3-VSINaL1z1SuKdUnS92i3Nksq8hg\"",
    "mtime": "2025-04-13T20:04:20.429Z",
    "size": 243,
    "path": "../public/app-assets/fonts/flag-icon-css/flags/1x1/zz.svg"
  },
  "/app-assets/fonts/flag-icon-css/flags/4x3/ad.svg": {
    "type": "image/svg+xml",
    "etag": "\"e8bd-nHRGhQtc3Kp5O+acCtyQrgpDdMY\"",
    "mtime": "2025-04-13T20:04:20.331Z",
    "size": 59581,
    "path": "../public/app-assets/fonts/flag-icon-css/flags/4x3/ad.svg"
  },
  "/app-assets/fonts/flag-icon-css/flags/4x3/ad.svg.br": {
    "type": "image/svg+xml",
    "encoding": "br",
    "etag": "\"4cde-F14aEH/8bo4htFBfDqpbTi1mJds\"",
    "mtime": "2025-04-13T20:04:28.599Z",
    "size": 19678,
    "path": "../public/app-assets/fonts/flag-icon-css/flags/4x3/ad.svg.br"
  },
  "/app-assets/fonts/flag-icon-css/flags/4x3/ad.svg.gz": {
    "type": "image/svg+xml",
    "encoding": "gzip",
    "etag": "\"5a44-PJJ9sDL+RjEuYn/XJLypv/MohjM\"",
    "mtime": "2025-04-13T20:04:28.599Z",
    "size": 23108,
    "path": "../public/app-assets/fonts/flag-icon-css/flags/4x3/ad.svg.gz"
  },
  "/app-assets/fonts/flag-icon-css/flags/4x3/ae.svg": {
    "type": "image/svg+xml",
    "etag": "\"1b6-QsM3bk1yqYgoogJK9Rt69QWPoP8\"",
    "mtime": "2025-04-13T20:04:20.431Z",
    "size": 438,
    "path": "../public/app-assets/fonts/flag-icon-css/flags/4x3/ae.svg"
  },
  "/app-assets/fonts/flag-icon-css/flags/4x3/af.svg": {
    "type": "image/svg+xml",
    "etag": "\"16435-nJt+u2yXKOYpssK/Tfhhu4xK8Js\"",
    "mtime": "2025-04-13T20:04:20.432Z",
    "size": 91189,
    "path": "../public/app-assets/fonts/flag-icon-css/flags/4x3/af.svg"
  },
  "/app-assets/fonts/flag-icon-css/flags/4x3/af.svg.br": {
    "type": "image/svg+xml",
    "encoding": "br",
    "etag": "\"4a71-i3gV3KC+fWSC02XnixL6eMz3n1M\"",
    "mtime": "2025-04-13T20:04:28.600Z",
    "size": 19057,
    "path": "../public/app-assets/fonts/flag-icon-css/flags/4x3/af.svg.br"
  },
  "/app-assets/fonts/flag-icon-css/flags/4x3/af.svg.gz": {
    "type": "image/svg+xml",
    "encoding": "gzip",
    "etag": "\"5c1f-JxbHt1dh3d5XQf/eZq84ybSCNGc\"",
    "mtime": "2025-04-13T20:04:28.599Z",
    "size": 23583,
    "path": "../public/app-assets/fonts/flag-icon-css/flags/4x3/af.svg.gz"
  },
  "/app-assets/fonts/flag-icon-css/flags/4x3/ag.svg": {
    "type": "image/svg+xml",
    "etag": "\"3a7-j/f67E+T+DToPP9lb8cW5sUrvAM\"",
    "mtime": "2025-04-13T20:04:20.432Z",
    "size": 935,
    "path": "../public/app-assets/fonts/flag-icon-css/flags/4x3/ag.svg"
  },
  "/app-assets/fonts/flag-icon-css/flags/4x3/ai.svg": {
    "type": "image/svg+xml",
    "etag": "\"df0e-mBAYo2V1jLNmdxttrRhwaSp5wkk\"",
    "mtime": "2025-04-13T20:04:20.431Z",
    "size": 57102,
    "path": "../public/app-assets/fonts/flag-icon-css/flags/4x3/ai.svg"
  },
  "/app-assets/fonts/flag-icon-css/flags/4x3/ai.svg.br": {
    "type": "image/svg+xml",
    "encoding": "br",
    "etag": "\"1989-1ubOpUTeJsmBfpIq8YjqUFjRWSk\"",
    "mtime": "2025-04-13T20:04:28.549Z",
    "size": 6537,
    "path": "../public/app-assets/fonts/flag-icon-css/flags/4x3/ai.svg.br"
  },
  "/app-assets/fonts/flag-icon-css/flags/4x3/ai.svg.gz": {
    "type": "image/svg+xml",
    "encoding": "gzip",
    "etag": "\"1ebd-Uu/0U69hyUIThJo2/4GkmDc0KWQ\"",
    "mtime": "2025-04-13T20:04:28.243Z",
    "size": 7869,
    "path": "../public/app-assets/fonts/flag-icon-css/flags/4x3/ai.svg.gz"
  },
  "/app-assets/fonts/flag-icon-css/flags/4x3/al.svg": {
    "type": "image/svg+xml",
    "etag": "\"1211-JPdOgmifikg84mhpqic3IYGKH9M\"",
    "mtime": "2025-04-13T20:04:20.432Z",
    "size": 4625,
    "path": "../public/app-assets/fonts/flag-icon-css/flags/4x3/al.svg"
  },
  "/app-assets/fonts/flag-icon-css/flags/4x3/al.svg.br": {
    "type": "image/svg+xml",
    "encoding": "br",
    "etag": "\"77b-m/wlR68dg5vgtI5jmmyISjJ2EN0\"",
    "mtime": "2025-04-13T20:04:28.549Z",
    "size": 1915,
    "path": "../public/app-assets/fonts/flag-icon-css/flags/4x3/al.svg.br"
  },
  "/app-assets/fonts/flag-icon-css/flags/4x3/al.svg.gz": {
    "type": "image/svg+xml",
    "encoding": "gzip",
    "etag": "\"8c8-geesvPv+YyUkuW8OWsxNdWCoSFk\"",
    "mtime": "2025-04-13T20:04:28.549Z",
    "size": 2248,
    "path": "../public/app-assets/fonts/flag-icon-css/flags/4x3/al.svg.gz"
  },
  "/app-assets/fonts/flag-icon-css/flags/4x3/am.svg": {
    "type": "image/svg+xml",
    "etag": "\"152-h+9zSd0UQQSNawiyFTCZO+nQBC0\"",
    "mtime": "2025-04-13T20:04:20.431Z",
    "size": 338,
    "path": "../public/app-assets/fonts/flag-icon-css/flags/4x3/am.svg"
  },
  "/app-assets/fonts/flag-icon-css/flags/4x3/ao.svg": {
    "type": "image/svg+xml",
    "etag": "\"8f0-bX86U5er0MwU2ZWI58ElV+Zj1yc\"",
    "mtime": "2025-04-13T20:04:20.432Z",
    "size": 2288,
    "path": "../public/app-assets/fonts/flag-icon-css/flags/4x3/ao.svg"
  },
  "/app-assets/fonts/flag-icon-css/flags/4x3/ao.svg.br": {
    "type": "image/svg+xml",
    "encoding": "br",
    "etag": "\"3a3-tYKNcN8+gWztpjGSxEe3XY3URhM\"",
    "mtime": "2025-04-13T20:04:28.549Z",
    "size": 931,
    "path": "../public/app-assets/fonts/flag-icon-css/flags/4x3/ao.svg.br"
  },
  "/app-assets/fonts/flag-icon-css/flags/4x3/ao.svg.gz": {
    "type": "image/svg+xml",
    "encoding": "gzip",
    "etag": "\"422-5rPGf74P1BSxuI6IHhk15BqATNs\"",
    "mtime": "2025-04-13T20:04:28.549Z",
    "size": 1058,
    "path": "../public/app-assets/fonts/flag-icon-css/flags/4x3/ao.svg.gz"
  },
  "/app-assets/fonts/flag-icon-css/flags/4x3/aq.svg": {
    "type": "image/svg+xml",
    "etag": "\"1122-DQR8SpDMGlgSl1wW6bNeLdSfclU\"",
    "mtime": "2025-04-13T20:04:20.433Z",
    "size": 4386,
    "path": "../public/app-assets/fonts/flag-icon-css/flags/4x3/aq.svg"
  },
  "/app-assets/fonts/flag-icon-css/flags/4x3/aq.svg.br": {
    "type": "image/svg+xml",
    "encoding": "br",
    "etag": "\"73e-2hIUUSdoCeaUTCpk77rgSVO4k9E\"",
    "mtime": "2025-04-13T20:04:28.549Z",
    "size": 1854,
    "path": "../public/app-assets/fonts/flag-icon-css/flags/4x3/aq.svg.br"
  },
  "/app-assets/fonts/flag-icon-css/flags/4x3/aq.svg.gz": {
    "type": "image/svg+xml",
    "encoding": "gzip",
    "etag": "\"7f3-TBpA0nr3ODrgigV4mmGE+uR8Cco\"",
    "mtime": "2025-04-13T20:04:28.549Z",
    "size": 2035,
    "path": "../public/app-assets/fonts/flag-icon-css/flags/4x3/aq.svg.gz"
  },
  "/app-assets/fonts/flag-icon-css/flags/4x3/ar.svg": {
    "type": "image/svg+xml",
    "etag": "\"864e-Pu6UaimR1uLKkx0u/Aq6NgD1ITc\"",
    "mtime": "2025-04-13T20:04:20.432Z",
    "size": 34382,
    "path": "../public/app-assets/fonts/flag-icon-css/flags/4x3/ar.svg"
  },
  "/app-assets/fonts/flag-icon-css/flags/4x3/ar.svg.br": {
    "type": "image/svg+xml",
    "encoding": "br",
    "etag": "\"908-OSA16+0CwJH9MnNKgmkdygyYVxA\"",
    "mtime": "2025-04-13T20:04:28.550Z",
    "size": 2312,
    "path": "../public/app-assets/fonts/flag-icon-css/flags/4x3/ar.svg.br"
  },
  "/app-assets/fonts/flag-icon-css/flags/4x3/ar.svg.gz": {
    "type": "image/svg+xml",
    "encoding": "gzip",
    "etag": "\"ae7-sP9FTnAat+3WOblvgNVyB1yt8sY\"",
    "mtime": "2025-04-13T20:04:28.549Z",
    "size": 2791,
    "path": "../public/app-assets/fonts/flag-icon-css/flags/4x3/ar.svg.gz"
  },
  "/app-assets/fonts/flag-icon-css/flags/4x3/as.svg": {
    "type": "image/svg+xml",
    "etag": "\"2de2-G4bSJzjLr+hM24j6wuulC1Gg7kY\"",
    "mtime": "2025-04-13T20:04:20.432Z",
    "size": 11746,
    "path": "../public/app-assets/fonts/flag-icon-css/flags/4x3/as.svg"
  },
  "/app-assets/fonts/flag-icon-css/flags/4x3/as.svg.br": {
    "type": "image/svg+xml",
    "encoding": "br",
    "etag": "\"10c2-8WC4G5OWqZrqRDfr7ol/POjW23o\"",
    "mtime": "2025-04-13T20:04:28.550Z",
    "size": 4290,
    "path": "../public/app-assets/fonts/flag-icon-css/flags/4x3/as.svg.br"
  },
  "/app-assets/fonts/flag-icon-css/flags/4x3/as.svg.gz": {
    "type": "image/svg+xml",
    "encoding": "gzip",
    "etag": "\"1226-xvexk/4U4Hpmz4Du4UzponZAr8M\"",
    "mtime": "2025-04-13T20:04:28.550Z",
    "size": 4646,
    "path": "../public/app-assets/fonts/flag-icon-css/flags/4x3/as.svg.gz"
  },
  "/app-assets/fonts/flag-icon-css/flags/4x3/at.svg": {
    "type": "image/svg+xml",
    "etag": "\"12a-P8dSz0yqiqRwBrqK6z/GZg2GcFo\"",
    "mtime": "2025-04-13T20:04:20.432Z",
    "size": 298,
    "path": "../public/app-assets/fonts/flag-icon-css/flags/4x3/at.svg"
  },
  "/app-assets/fonts/flag-icon-css/flags/4x3/au.svg": {
    "type": "image/svg+xml",
    "etag": "\"725-NyKerPuIuaf8lLi9UvY/1IiOtmc\"",
    "mtime": "2025-04-13T20:04:20.433Z",
    "size": 1829,
    "path": "../public/app-assets/fonts/flag-icon-css/flags/4x3/au.svg"
  },
  "/app-assets/fonts/flag-icon-css/flags/4x3/au.svg.br": {
    "type": "image/svg+xml",
    "encoding": "br",
    "etag": "\"2ad-0NP2wgVNEw0Vmr0fIBnNt7dvfJo\"",
    "mtime": "2025-04-13T20:04:28.549Z",
    "size": 685,
    "path": "../public/app-assets/fonts/flag-icon-css/flags/4x3/au.svg.br"
  },
  "/app-assets/fonts/flag-icon-css/flags/4x3/au.svg.gz": {
    "type": "image/svg+xml",
    "encoding": "gzip",
    "etag": "\"308-dGx9bclwkYI8Rw811XBpWxc+GLg\"",
    "mtime": "2025-04-13T20:04:28.549Z",
    "size": 776,
    "path": "../public/app-assets/fonts/flag-icon-css/flags/4x3/au.svg.gz"
  },
  "/app-assets/fonts/flag-icon-css/flags/4x3/aw.svg": {
    "type": "image/svg+xml",
    "etag": "\"39a6-gK+DDlqn72IBzgnF5vAz3kRbNwQ\"",
    "mtime": "2025-04-13T20:04:20.432Z",
    "size": 14758,
    "path": "../public/app-assets/fonts/flag-icon-css/flags/4x3/aw.svg"
  },
  "/app-assets/fonts/flag-icon-css/flags/4x3/aw.svg.br": {
    "type": "image/svg+xml",
    "encoding": "br",
    "etag": "\"7be-tc6fPnd0rglBMxbhmLHYaVFjC24\"",
    "mtime": "2025-04-13T20:04:28.550Z",
    "size": 1982,
    "path": "../public/app-assets/fonts/flag-icon-css/flags/4x3/aw.svg.br"
  },
  "/app-assets/fonts/flag-icon-css/flags/4x3/aw.svg.gz": {
    "type": "image/svg+xml",
    "encoding": "gzip",
    "etag": "\"91d-0ol7luycH4846k1tgVFduh6AtUg\"",
    "mtime": "2025-04-13T20:04:28.549Z",
    "size": 2333,
    "path": "../public/app-assets/fonts/flag-icon-css/flags/4x3/aw.svg.gz"
  },
  "/app-assets/fonts/flag-icon-css/flags/4x3/ax.svg": {
    "type": "image/svg+xml",
    "etag": "\"266-AVt/9CvYTKB0prsROHRz5lhTL7k\"",
    "mtime": "2025-04-13T20:04:20.433Z",
    "size": 614,
    "path": "../public/app-assets/fonts/flag-icon-css/flags/4x3/ax.svg"
  },
  "/app-assets/fonts/flag-icon-css/flags/4x3/az.svg": {
    "type": "image/svg+xml",
    "etag": "\"221-ksp0M0Ff79NnIhVcglecIpbSNHo\"",
    "mtime": "2025-04-13T20:04:20.458Z",
    "size": 545,
    "path": "../public/app-assets/fonts/flag-icon-css/flags/4x3/az.svg"
  },
  "/app-assets/fonts/flag-icon-css/flags/4x3/ba.svg": {
    "type": "image/svg+xml",
    "etag": "\"615-vIP2PYbObkLYD+lhHuWuf4HUO2g\"",
    "mtime": "2025-04-13T20:04:20.432Z",
    "size": 1557,
    "path": "../public/app-assets/fonts/flag-icon-css/flags/4x3/ba.svg"
  },
  "/app-assets/fonts/flag-icon-css/flags/4x3/ba.svg.br": {
    "type": "image/svg+xml",
    "encoding": "br",
    "etag": "\"1e8-Nlyl0F03PA6ZjjYdsP2/Uq9XjEQ\"",
    "mtime": "2025-04-13T20:04:28.550Z",
    "size": 488,
    "path": "../public/app-assets/fonts/flag-icon-css/flags/4x3/ba.svg.br"
  },
  "/app-assets/fonts/flag-icon-css/flags/4x3/ba.svg.gz": {
    "type": "image/svg+xml",
    "encoding": "gzip",
    "etag": "\"233-6c9Bj0rI1tutZXy1eXYS6WLGKgM\"",
    "mtime": "2025-04-13T20:04:28.550Z",
    "size": 563,
    "path": "../public/app-assets/fonts/flag-icon-css/flags/4x3/ba.svg.gz"
  },
  "/app-assets/fonts/flag-icon-css/flags/4x3/bb.svg": {
    "type": "image/svg+xml",
    "etag": "\"2e9-dHsijn2BzzlCjDlZozhH4boyHng\"",
    "mtime": "2025-04-13T20:04:20.434Z",
    "size": 745,
    "path": "../public/app-assets/fonts/flag-icon-css/flags/4x3/bb.svg"
  },
  "/app-assets/fonts/flag-icon-css/flags/4x3/bd.svg": {
    "type": "image/svg+xml",
    "etag": "\"16d-mHM1OpNsoTZj00O3k4AOsig5dzo\"",
    "mtime": "2025-04-13T20:04:20.432Z",
    "size": 365,
    "path": "../public/app-assets/fonts/flag-icon-css/flags/4x3/bd.svg"
  },
  "/app-assets/fonts/flag-icon-css/flags/4x3/be.svg": {
    "type": "image/svg+xml",
    "etag": "\"15f-9J2wtkAchHJ9gJ5tACBzbA9ttPw\"",
    "mtime": "2025-04-13T20:04:20.433Z",
    "size": 351,
    "path": "../public/app-assets/fonts/flag-icon-css/flags/4x3/be.svg"
  },
  "/app-assets/fonts/flag-icon-css/flags/4x3/bf.svg": {
    "type": "image/svg+xml",
    "etag": "\"1e0-c7BKObrpiEVRIF40V1bIbX2st6g\"",
    "mtime": "2025-04-13T20:04:20.433Z",
    "size": 480,
    "path": "../public/app-assets/fonts/flag-icon-css/flags/4x3/bf.svg"
  },
  "/app-assets/fonts/flag-icon-css/flags/4x3/bg.svg": {
    "type": "image/svg+xml",
    "etag": "\"152-IoKszMPJkwAfimvjRBCoAd9Cr+E\"",
    "mtime": "2025-04-13T20:04:20.432Z",
    "size": 338,
    "path": "../public/app-assets/fonts/flag-icon-css/flags/4x3/bg.svg"
  },
  "/app-assets/fonts/flag-icon-css/flags/4x3/bh.svg": {
    "type": "image/svg+xml",
    "etag": "\"28f-9okTp23iW5eDxKxK1hhcNCXm51k\"",
    "mtime": "2025-04-13T20:04:20.433Z",
    "size": 655,
    "path": "../public/app-assets/fonts/flag-icon-css/flags/4x3/bh.svg"
  },
  "/app-assets/fonts/flag-icon-css/flags/4x3/bi.svg": {
    "type": "image/svg+xml",
    "etag": "\"556-v3LnscnNfapePa6JnkrgJ5N7IzI\"",
    "mtime": "2025-04-13T20:04:20.433Z",
    "size": 1366,
    "path": "../public/app-assets/fonts/flag-icon-css/flags/4x3/bi.svg"
  },
  "/app-assets/fonts/flag-icon-css/flags/4x3/bi.svg.br": {
    "type": "image/svg+xml",
    "encoding": "br",
    "etag": "\"20a-ichzVOKMcnR4xPvLMiskN0ysV6Y\"",
    "mtime": "2025-04-13T20:04:28.550Z",
    "size": 522,
    "path": "../public/app-assets/fonts/flag-icon-css/flags/4x3/bi.svg.br"
  },
  "/app-assets/fonts/flag-icon-css/flags/4x3/bi.svg.gz": {
    "type": "image/svg+xml",
    "encoding": "gzip",
    "etag": "\"250-//Z5onKeemEt/k5Lo04aP+c/kTI\"",
    "mtime": "2025-04-13T20:04:28.550Z",
    "size": 592,
    "path": "../public/app-assets/fonts/flag-icon-css/flags/4x3/bi.svg.gz"
  },
  "/app-assets/fonts/flag-icon-css/flags/4x3/bj.svg": {
    "type": "image/svg+xml",
    "etag": "\"218-J2JBLTmn/dME8riIp5vFWlXYthw\"",
    "mtime": "2025-04-13T20:04:20.433Z",
    "size": 536,
    "path": "../public/app-assets/fonts/flag-icon-css/flags/4x3/bj.svg"
  },
  "/app-assets/fonts/flag-icon-css/flags/4x3/bl.svg": {
    "type": "image/svg+xml",
    "etag": "\"168-eKagCCt66i6Qsj5GRoMSw8ulF7U\"",
    "mtime": "2025-04-13T20:04:20.433Z",
    "size": 360,
    "path": "../public/app-assets/fonts/flag-icon-css/flags/4x3/bl.svg"
  },
  "/app-assets/fonts/flag-icon-css/flags/4x3/bm.svg": {
    "type": "image/svg+xml",
    "etag": "\"7f34-sezA9zp8NaUUWw3tno/QptVUqJQ\"",
    "mtime": "2025-04-13T20:04:20.434Z",
    "size": 32564,
    "path": "../public/app-assets/fonts/flag-icon-css/flags/4x3/bm.svg"
  },
  "/app-assets/fonts/flag-icon-css/flags/4x3/bm.svg.br": {
    "type": "image/svg+xml",
    "encoding": "br",
    "etag": "\"24d4-8Bz9wv1yXG24vwFadjXckjQNc0s\"",
    "mtime": "2025-04-13T20:04:28.550Z",
    "size": 9428,
    "path": "../public/app-assets/fonts/flag-icon-css/flags/4x3/bm.svg.br"
  },
  "/app-assets/fonts/flag-icon-css/flags/4x3/bm.svg.gz": {
    "type": "image/svg+xml",
    "encoding": "gzip",
    "etag": "\"2cd9-pSPQc1xuC4h4g0WMnnOb5WLPhp4\"",
    "mtime": "2025-04-13T20:04:28.550Z",
    "size": 11481,
    "path": "../public/app-assets/fonts/flag-icon-css/flags/4x3/bm.svg.gz"
  },
  "/app-assets/fonts/flag-icon-css/flags/4x3/bn.svg": {
    "type": "image/svg+xml",
    "etag": "\"5960-P5O2S28sjYCSzA8AO4233ZggPUU\"",
    "mtime": "2025-04-13T20:04:20.433Z",
    "size": 22880,
    "path": "../public/app-assets/fonts/flag-icon-css/flags/4x3/bn.svg"
  },
  "/app-assets/fonts/flag-icon-css/flags/4x3/bn.svg.br": {
    "type": "image/svg+xml",
    "encoding": "br",
    "etag": "\"1b45-SchzbJ2I5X/cXtUae6C3qxkDDew\"",
    "mtime": "2025-04-13T20:04:28.550Z",
    "size": 6981,
    "path": "../public/app-assets/fonts/flag-icon-css/flags/4x3/bn.svg.br"
  },
  "/app-assets/fonts/flag-icon-css/flags/4x3/bn.svg.gz": {
    "type": "image/svg+xml",
    "encoding": "gzip",
    "etag": "\"1f8e-+G6vi+Ikx4xxz91xaHHvb7SRAVI\"",
    "mtime": "2025-04-13T20:04:28.550Z",
    "size": 8078,
    "path": "../public/app-assets/fonts/flag-icon-css/flags/4x3/bn.svg.gz"
  },
  "/app-assets/fonts/flag-icon-css/flags/4x3/bo.svg": {
    "type": "image/svg+xml",
    "etag": "\"148-BtSDbr1OBzpjSX/92p/d7XAhSNo\"",
    "mtime": "2025-04-13T20:04:20.434Z",
    "size": 328,
    "path": "../public/app-assets/fonts/flag-icon-css/flags/4x3/bo.svg"
  },
  "/app-assets/fonts/flag-icon-css/flags/4x3/bq.svg": {
    "type": "image/svg+xml",
    "etag": "\"11a-FWLkIKjnZZTsPB4ZEHsHR3+XIdA\"",
    "mtime": "2025-04-13T20:04:20.436Z",
    "size": 282,
    "path": "../public/app-assets/fonts/flag-icon-css/flags/4x3/bq.svg"
  },
  "/app-assets/fonts/flag-icon-css/flags/4x3/br.svg": {
    "type": "image/svg+xml",
    "etag": "\"3127-yaTfbEj7Z3enRpWALH/vzetODI0\"",
    "mtime": "2025-04-13T20:04:20.435Z",
    "size": 12583,
    "path": "../public/app-assets/fonts/flag-icon-css/flags/4x3/br.svg"
  },
  "/app-assets/fonts/flag-icon-css/flags/4x3/br.svg.br": {
    "type": "image/svg+xml",
    "encoding": "br",
    "etag": "\"111b-7s6Dx0ufnYgf+GO7twhpAJST8x4\"",
    "mtime": "2025-04-13T20:04:28.550Z",
    "size": 4379,
    "path": "../public/app-assets/fonts/flag-icon-css/flags/4x3/br.svg.br"
  },
  "/app-assets/fonts/flag-icon-css/flags/4x3/br.svg.gz": {
    "type": "image/svg+xml",
    "encoding": "gzip",
    "etag": "\"13ba-rWjz50U/c8QNvcim3glUn9vRJxg\"",
    "mtime": "2025-04-13T20:04:28.550Z",
    "size": 5050,
    "path": "../public/app-assets/fonts/flag-icon-css/flags/4x3/br.svg.gz"
  },
  "/app-assets/fonts/flag-icon-css/flags/4x3/bs.svg": {
    "type": "image/svg+xml",
    "etag": "\"286-G0H4CljWisnLCZZlBc1wfKuTjfc\"",
    "mtime": "2025-04-13T20:04:20.433Z",
    "size": 646,
    "path": "../public/app-assets/fonts/flag-icon-css/flags/4x3/bs.svg"
  },
  "/app-assets/fonts/flag-icon-css/flags/4x3/bt.svg": {
    "type": "image/svg+xml",
    "etag": "\"16924-9td2zmyome3upyTzmZFcaeUxrBA\"",
    "mtime": "2025-04-13T20:04:20.434Z",
    "size": 92452,
    "path": "../public/app-assets/fonts/flag-icon-css/flags/4x3/bt.svg"
  },
  "/app-assets/fonts/flag-icon-css/flags/4x3/bt.svg.br": {
    "type": "image/svg+xml",
    "encoding": "br",
    "etag": "\"77e4-DgAo3Fn1epkayZefEjcAU1162n0\"",
    "mtime": "2025-04-13T20:04:28.600Z",
    "size": 30692,
    "path": "../public/app-assets/fonts/flag-icon-css/flags/4x3/bt.svg.br"
  },
  "/app-assets/fonts/flag-icon-css/flags/4x3/bt.svg.gz": {
    "type": "image/svg+xml",
    "encoding": "gzip",
    "etag": "\"8369-YEABTzLyirRloOEoQUk19d5XwqI\"",
    "mtime": "2025-04-13T20:04:28.659Z",
    "size": 33641,
    "path": "../public/app-assets/fonts/flag-icon-css/flags/4x3/bt.svg.gz"
  },
  "/app-assets/fonts/flag-icon-css/flags/4x3/bv.svg": {
    "type": "image/svg+xml",
    "etag": "\"2a8-gKfrlRzeUmWZkhcNa3mK9brlDzI\"",
    "mtime": "2025-04-13T20:04:20.433Z",
    "size": 680,
    "path": "../public/app-assets/fonts/flag-icon-css/flags/4x3/bv.svg"
  },
  "/app-assets/fonts/flag-icon-css/flags/4x3/bw.svg": {
    "type": "image/svg+xml",
    "etag": "\"168-knPmwB+Vt4wBBVDYGqIhjR488Uo\"",
    "mtime": "2025-04-13T20:04:20.433Z",
    "size": 360,
    "path": "../public/app-assets/fonts/flag-icon-css/flags/4x3/bw.svg"
  },
  "/app-assets/fonts/flag-icon-css/flags/4x3/by.svg": {
    "type": "image/svg+xml",
    "etag": "\"2557-ukkSu/zl0syRIXypzvjGi+WTHQo\"",
    "mtime": "2025-04-13T20:04:20.434Z",
    "size": 9559,
    "path": "../public/app-assets/fonts/flag-icon-css/flags/4x3/by.svg"
  },
  "/app-assets/fonts/flag-icon-css/flags/4x3/by.svg.br": {
    "type": "image/svg+xml",
    "encoding": "br",
    "etag": "\"748-3xm6KPkAkL7sWYGI68dKHqb6Qm0\"",
    "mtime": "2025-04-13T20:04:28.550Z",
    "size": 1864,
    "path": "../public/app-assets/fonts/flag-icon-css/flags/4x3/by.svg.br"
  },
  "/app-assets/fonts/flag-icon-css/flags/4x3/by.svg.gz": {
    "type": "image/svg+xml",
    "encoding": "gzip",
    "etag": "\"8ad-UZhXEQF7bwt+JR1PAPL0VnNLE4w\"",
    "mtime": "2025-04-13T20:04:28.550Z",
    "size": 2221,
    "path": "../public/app-assets/fonts/flag-icon-css/flags/4x3/by.svg.gz"
  },
  "/app-assets/fonts/flag-icon-css/flags/4x3/bz.svg": {
    "type": "image/svg+xml",
    "etag": "\"d911-9sTYx9k2m6RqwKtfILLTBPqHyck\"",
    "mtime": "2025-04-13T20:04:20.434Z",
    "size": 55569,
    "path": "../public/app-assets/fonts/flag-icon-css/flags/4x3/bz.svg"
  },
  "/app-assets/fonts/flag-icon-css/flags/4x3/bz.svg.br": {
    "type": "image/svg+xml",
    "encoding": "br",
    "etag": "\"3099-3gb2cI9chRkBXzN/GqKO9EWF3e0\"",
    "mtime": "2025-04-13T20:04:28.550Z",
    "size": 12441,
    "path": "../public/app-assets/fonts/flag-icon-css/flags/4x3/bz.svg.br"
  },
  "/app-assets/fonts/flag-icon-css/flags/4x3/bz.svg.gz": {
    "type": "image/svg+xml",
    "encoding": "gzip",
    "etag": "\"38a2-75aL75bcbsMF5F0mb1ecRs1XTL0\"",
    "mtime": "2025-04-13T20:04:28.550Z",
    "size": 14498,
    "path": "../public/app-assets/fonts/flag-icon-css/flags/4x3/bz.svg.gz"
  },
  "/app-assets/fonts/flag-icon-css/flags/4x3/ca.svg": {
    "type": "image/svg+xml",
    "etag": "\"498-sSyy+Pr7mERZNd7qaf5Z3nxjSfY\"",
    "mtime": "2025-04-13T20:04:20.434Z",
    "size": 1176,
    "path": "../public/app-assets/fonts/flag-icon-css/flags/4x3/ca.svg"
  },
  "/app-assets/fonts/flag-icon-css/flags/4x3/ca.svg.br": {
    "type": "image/svg+xml",
    "encoding": "br",
    "etag": "\"25f-2WXDOa6EtJn1FM8IA9y4aKhIgtw\"",
    "mtime": "2025-04-13T20:04:28.550Z",
    "size": 607,
    "path": "../public/app-assets/fonts/flag-icon-css/flags/4x3/ca.svg.br"
  },
  "/app-assets/fonts/flag-icon-css/flags/4x3/ca.svg.gz": {
    "type": "image/svg+xml",
    "encoding": "gzip",
    "etag": "\"2bf-XMwi/StydoFiwnPW7Q4EHjflAOc\"",
    "mtime": "2025-04-13T20:04:28.550Z",
    "size": 703,
    "path": "../public/app-assets/fonts/flag-icon-css/flags/4x3/ca.svg.gz"
  },
  "/app-assets/fonts/flag-icon-css/flags/4x3/cc.svg": {
    "type": "image/svg+xml",
    "etag": "\"10f3-h5wVgZwLjqJgg6gfxsE9+ha2834\"",
    "mtime": "2025-04-13T20:04:20.434Z",
    "size": 4339,
    "path": "../public/app-assets/fonts/flag-icon-css/flags/4x3/cc.svg"
  },
  "/app-assets/fonts/flag-icon-css/flags/4x3/cc.svg.br": {
    "type": "image/svg+xml",
    "encoding": "br",
    "etag": "\"6d6-6yf0r8CKVzV4nrNCAA98iCWZZeg\"",
    "mtime": "2025-04-13T20:04:28.550Z",
    "size": 1750,
    "path": "../public/app-assets/fonts/flag-icon-css/flags/4x3/cc.svg.br"
  },
  "/app-assets/fonts/flag-icon-css/flags/4x3/cc.svg.gz": {
    "type": "image/svg+xml",
    "encoding": "gzip",
    "etag": "\"7d3-6iw/j7o2QcnXbFjSRVdOeXjibMM\"",
    "mtime": "2025-04-13T20:04:28.550Z",
    "size": 2003,
    "path": "../public/app-assets/fonts/flag-icon-css/flags/4x3/cc.svg.gz"
  },
  "/app-assets/fonts/flag-icon-css/flags/4x3/cd.svg": {
    "type": "image/svg+xml",
    "etag": "\"181-qANYC5kkF5nks9inUIfZob1WB2k\"",
    "mtime": "2025-04-13T20:04:20.435Z",
    "size": 385,
    "path": "../public/app-assets/fonts/flag-icon-css/flags/4x3/cd.svg"
  },
  "/app-assets/fonts/flag-icon-css/flags/4x3/cf.svg": {
    "type": "image/svg+xml",
    "etag": "\"316-0SdtGTEa9mJRnEESJvZC3eSknS8\"",
    "mtime": "2025-04-13T20:04:20.434Z",
    "size": 790,
    "path": "../public/app-assets/fonts/flag-icon-css/flags/4x3/cf.svg"
  },
  "/app-assets/fonts/flag-icon-css/flags/4x3/cg.svg": {
    "type": "image/svg+xml",
    "etag": "\"20d-YKWatShopn5HkFXFzmJB1FUT1ZA\"",
    "mtime": "2025-04-13T20:04:20.434Z",
    "size": 525,
    "path": "../public/app-assets/fonts/flag-icon-css/flags/4x3/cg.svg"
  },
  "/app-assets/fonts/flag-icon-css/flags/4x3/ch.svg": {
    "type": "image/svg+xml",
    "etag": "\"171-Bz6lEseTjVx+NPDrZbB13Eh8ZG8\"",
    "mtime": "2025-04-13T20:04:20.434Z",
    "size": 369,
    "path": "../public/app-assets/fonts/flag-icon-css/flags/4x3/ch.svg"
  },
  "/app-assets/fonts/flag-icon-css/flags/4x3/ci.svg": {
    "type": "image/svg+xml",
    "etag": "\"17b-Ph6Bbj08fwfXseDpAqFY0Tvp1ko\"",
    "mtime": "2025-04-13T20:04:20.435Z",
    "size": 379,
    "path": "../public/app-assets/fonts/flag-icon-css/flags/4x3/ci.svg"
  },
  "/app-assets/fonts/flag-icon-css/flags/4x3/ck.svg": {
    "type": "image/svg+xml",
    "etag": "\"a97-mMbd5HAuMXtTZaf2tdiG3TPXGPE\"",
    "mtime": "2025-04-13T20:04:20.435Z",
    "size": 2711,
    "path": "../public/app-assets/fonts/flag-icon-css/flags/4x3/ck.svg"
  },
  "/app-assets/fonts/flag-icon-css/flags/4x3/ck.svg.br": {
    "type": "image/svg+xml",
    "encoding": "br",
    "etag": "\"4ea-XTZuP4ogwkCO0/H7Cfk0rBQA2cA\"",
    "mtime": "2025-04-13T20:04:28.550Z",
    "size": 1258,
    "path": "../public/app-assets/fonts/flag-icon-css/flags/4x3/ck.svg.br"
  },
  "/app-assets/fonts/flag-icon-css/flags/4x3/ck.svg.gz": {
    "type": "image/svg+xml",
    "encoding": "gzip",
    "etag": "\"55a-9RXCTHqesdSLXO9gkaE+vpAMLeI\"",
    "mtime": "2025-04-13T20:04:28.550Z",
    "size": 1370,
    "path": "../public/app-assets/fonts/flag-icon-css/flags/4x3/ck.svg.gz"
  },
  "/app-assets/fonts/flag-icon-css/flags/4x3/cl.svg": {
    "type": "image/svg+xml",
    "etag": "\"29c-Mk4XgU6DcKhMDgFlG8q2mz+EIiI\"",
    "mtime": "2025-04-13T20:04:20.435Z",
    "size": 668,
    "path": "../public/app-assets/fonts/flag-icon-css/flags/4x3/cl.svg"
  },
  "/app-assets/fonts/flag-icon-css/flags/4x3/cm.svg": {
    "type": "image/svg+xml",
    "etag": "\"339-F5HlDjayDRU57SDfIsB4qgSe9Uw\"",
    "mtime": "2025-04-13T20:04:20.436Z",
    "size": 825,
    "path": "../public/app-assets/fonts/flag-icon-css/flags/4x3/cm.svg"
  },
  "/app-assets/fonts/flag-icon-css/flags/4x3/cn.svg": {
    "type": "image/svg+xml",
    "etag": "\"3ed-sLMexvYaW2Tz6ZlsV70NUsfqYwQ\"",
    "mtime": "2025-04-13T20:04:20.435Z",
    "size": 1005,
    "path": "../public/app-assets/fonts/flag-icon-css/flags/4x3/cn.svg"
  },
  "/app-assets/fonts/flag-icon-css/flags/4x3/co.svg": {
    "type": "image/svg+xml",
    "etag": "\"151-S73bBpa9+Vn51mP7/iy8iEzxysQ\"",
    "mtime": "2025-04-13T20:04:20.435Z",
    "size": 337,
    "path": "../public/app-assets/fonts/flag-icon-css/flags/4x3/co.svg"
  },
  "/app-assets/fonts/flag-icon-css/flags/4x3/cr.svg": {
    "type": "image/svg+xml",
    "etag": "\"150-zL+3v/fee1bG4u8HIARTYdJGexI\"",
    "mtime": "2025-04-13T20:04:20.435Z",
    "size": 336,
    "path": "../public/app-assets/fonts/flag-icon-css/flags/4x3/cr.svg"
  },
  "/app-assets/fonts/flag-icon-css/flags/4x3/cu.svg": {
    "type": "image/svg+xml",
    "etag": "\"2cd-x53hthsBdXsAuejUEzmKDSeY1ZE\"",
    "mtime": "2025-04-13T20:04:20.435Z",
    "size": 717,
    "path": "../public/app-assets/fonts/flag-icon-css/flags/4x3/cu.svg"
  },
  "/app-assets/fonts/flag-icon-css/flags/4x3/cv.svg": {
    "type": "image/svg+xml",
    "etag": "\"728-T+FcpRCFWrIrvMiO7zOXFRlTQGM\"",
    "mtime": "2025-04-13T20:04:20.436Z",
    "size": 1832,
    "path": "../public/app-assets/fonts/flag-icon-css/flags/4x3/cv.svg"
  },
  "/app-assets/fonts/flag-icon-css/flags/4x3/cv.svg.br": {
    "type": "image/svg+xml",
    "encoding": "br",
    "etag": "\"1ec-Eg95Tn3y7CetvyaP9mrwJ7C0WKY\"",
    "mtime": "2025-04-13T20:04:28.550Z",
    "size": 492,
    "path": "../public/app-assets/fonts/flag-icon-css/flags/4x3/cv.svg.br"
  },
  "/app-assets/fonts/flag-icon-css/flags/4x3/cv.svg.gz": {
    "type": "image/svg+xml",
    "encoding": "gzip",
    "etag": "\"249-7td+B67kMxy1y/HeSHSYQ3rRqUo\"",
    "mtime": "2025-04-13T20:04:28.550Z",
    "size": 585,
    "path": "../public/app-assets/fonts/flag-icon-css/flags/4x3/cv.svg.gz"
  },
  "/app-assets/fonts/flag-icon-css/flags/4x3/cw.svg": {
    "type": "image/svg+xml",
    "etag": "\"2ef-d+O5CuaTC89fgAUYIoYXvoUjxoU\"",
    "mtime": "2025-04-13T20:04:20.436Z",
    "size": 751,
    "path": "../public/app-assets/fonts/flag-icon-css/flags/4x3/cw.svg"
  },
  "/app-assets/fonts/flag-icon-css/flags/4x3/cx.svg": {
    "type": "image/svg+xml",
    "etag": "\"d8a-EIdhTrqh3lCiu+gH6EtdomQuWNg\"",
    "mtime": "2025-04-13T20:04:20.435Z",
    "size": 3466,
    "path": "../public/app-assets/fonts/flag-icon-css/flags/4x3/cx.svg"
  },
  "/app-assets/fonts/flag-icon-css/flags/4x3/cx.svg.br": {
    "type": "image/svg+xml",
    "encoding": "br",
    "etag": "\"5c3-2mlsrkLu6pHNhyZ8a6LG5eE11cU\"",
    "mtime": "2025-04-13T20:04:28.551Z",
    "size": 1475,
    "path": "../public/app-assets/fonts/flag-icon-css/flags/4x3/cx.svg.br"
  },
  "/app-assets/fonts/flag-icon-css/flags/4x3/cx.svg.gz": {
    "type": "image/svg+xml",
    "encoding": "gzip",
    "etag": "\"65d-gPXr+sl6rQON/uvQfs39Ww26axI\"",
    "mtime": "2025-04-13T20:04:28.551Z",
    "size": 1629,
    "path": "../public/app-assets/fonts/flag-icon-css/flags/4x3/cx.svg.gz"
  },
  "/app-assets/fonts/flag-icon-css/flags/4x3/cy.svg": {
    "type": "image/svg+xml",
    "etag": "\"2742-6cCkR2ls+cJOUNa9XAMl08JqYos\"",
    "mtime": "2025-04-13T20:04:20.435Z",
    "size": 10050,
    "path": "../public/app-assets/fonts/flag-icon-css/flags/4x3/cy.svg"
  },
  "/app-assets/fonts/flag-icon-css/flags/4x3/cy.svg.br": {
    "type": "image/svg+xml",
    "encoding": "br",
    "etag": "\"faa-kWobbEZtxK7hDCeE0YfF2MKd2QM\"",
    "mtime": "2025-04-13T20:04:28.550Z",
    "size": 4010,
    "path": "../public/app-assets/fonts/flag-icon-css/flags/4x3/cy.svg.br"
  },
  "/app-assets/fonts/flag-icon-css/flags/4x3/cy.svg.gz": {
    "type": "image/svg+xml",
    "encoding": "gzip",
    "etag": "\"11cb-6wII+rg3VTSjy+uLJGS8xbXA83g\"",
    "mtime": "2025-04-13T20:04:28.550Z",
    "size": 4555,
    "path": "../public/app-assets/fonts/flag-icon-css/flags/4x3/cy.svg.gz"
  },
  "/app-assets/fonts/flag-icon-css/flags/4x3/cz.svg": {
    "type": "image/svg+xml",
    "etag": "\"216-w4b/ZHwYmyhTL8TOFttDpLQa4rc\"",
    "mtime": "2025-04-13T20:04:20.436Z",
    "size": 534,
    "path": "../public/app-assets/fonts/flag-icon-css/flags/4x3/cz.svg"
  },
  "/app-assets/fonts/flag-icon-css/flags/4x3/de.svg": {
    "type": "image/svg+xml",
    "etag": "\"140-od0myBAw4MnRlh9rhAwJ8uZq2rk\"",
    "mtime": "2025-04-13T20:04:20.436Z",
    "size": 320,
    "path": "../public/app-assets/fonts/flag-icon-css/flags/4x3/de.svg"
  },
  "/app-assets/fonts/flag-icon-css/flags/4x3/dj.svg": {
    "type": "image/svg+xml",
    "etag": "\"2a2-nCeh8D635/cd3JM6ETfVKX63FkQ\"",
    "mtime": "2025-04-13T20:04:20.436Z",
    "size": 674,
    "path": "../public/app-assets/fonts/flag-icon-css/flags/4x3/dj.svg"
  },
  "/app-assets/fonts/flag-icon-css/flags/4x3/dk.svg": {
    "type": "image/svg+xml",
    "etag": "\"e3-593Kd6zs96yw6G3yho7xEkuNGXs\"",
    "mtime": "2025-04-13T20:04:20.436Z",
    "size": 227,
    "path": "../public/app-assets/fonts/flag-icon-css/flags/4x3/dk.svg"
  },
  "/app-assets/fonts/flag-icon-css/flags/4x3/dm.svg": {
    "type": "image/svg+xml",
    "etag": "\"507e-rci6n04EJigXyqXBSQiNDFxiGQU\"",
    "mtime": "2025-04-13T20:04:20.436Z",
    "size": 20606,
    "path": "../public/app-assets/fonts/flag-icon-css/flags/4x3/dm.svg"
  },
  "/app-assets/fonts/flag-icon-css/flags/4x3/dm.svg.br": {
    "type": "image/svg+xml",
    "encoding": "br",
    "etag": "\"b78-4wY/qnP8QOYjxNlKnQkf4TIZV5E\"",
    "mtime": "2025-04-13T20:04:28.550Z",
    "size": 2936,
    "path": "../public/app-assets/fonts/flag-icon-css/flags/4x3/dm.svg.br"
  },
  "/app-assets/fonts/flag-icon-css/flags/4x3/dm.svg.gz": {
    "type": "image/svg+xml",
    "encoding": "gzip",
    "etag": "\"de5-SfQsrcNgXdYOsKGITy+cLIHuzoM\"",
    "mtime": "2025-04-13T20:04:28.550Z",
    "size": 3557,
    "path": "../public/app-assets/fonts/flag-icon-css/flags/4x3/dm.svg.gz"
  },
  "/app-assets/fonts/flag-icon-css/flags/4x3/do.svg": {
    "type": "image/svg+xml",
    "etag": "\"72208-MPlAxoT8OP+kHpV08JAXOjYI3zI\"",
    "mtime": "2025-04-13T20:04:20.437Z",
    "size": 467464,
    "path": "../public/app-assets/fonts/flag-icon-css/flags/4x3/do.svg"
  },
  "/app-assets/fonts/flag-icon-css/flags/4x3/do.svg.br": {
    "type": "image/svg+xml",
    "encoding": "br",
    "etag": "\"c2f4-My4rRDKwOZBCQ7W6Tcfx9AGpc0g\"",
    "mtime": "2025-04-13T20:04:28.707Z",
    "size": 49908,
    "path": "../public/app-assets/fonts/flag-icon-css/flags/4x3/do.svg.br"
  },
  "/app-assets/fonts/flag-icon-css/flags/4x3/do.svg.gz": {
    "type": "image/svg+xml",
    "encoding": "gzip",
    "etag": "\"f2ca-kWj8YzJ9IGauD8gIEjgB2LIe3CQ\"",
    "mtime": "2025-04-13T20:04:28.700Z",
    "size": 62154,
    "path": "../public/app-assets/fonts/flag-icon-css/flags/4x3/do.svg.gz"
  },
  "/app-assets/fonts/flag-icon-css/flags/4x3/dz.svg": {
    "type": "image/svg+xml",
    "etag": "\"123-n6qQ9Ju14KEACHHbSlz+IYM7p3g\"",
    "mtime": "2025-04-13T20:04:20.436Z",
    "size": 291,
    "path": "../public/app-assets/fonts/flag-icon-css/flags/4x3/dz.svg"
  },
  "/app-assets/fonts/flag-icon-css/flags/4x3/ec.svg": {
    "type": "image/svg+xml",
    "etag": "\"97d6-H/nAdqMOai7JpyXou9OGTBjQPbg\"",
    "mtime": "2025-04-13T20:04:20.440Z",
    "size": 38870,
    "path": "../public/app-assets/fonts/flag-icon-css/flags/4x3/ec.svg"
  },
  "/app-assets/fonts/flag-icon-css/flags/4x3/ec.svg.br": {
    "type": "image/svg+xml",
    "encoding": "br",
    "etag": "\"20dc-wPDVe0GhGn+Vd+P+lfzWO+xBoeU\"",
    "mtime": "2025-04-13T20:04:28.551Z",
    "size": 8412,
    "path": "../public/app-assets/fonts/flag-icon-css/flags/4x3/ec.svg.br"
  },
  "/app-assets/fonts/flag-icon-css/flags/4x3/ec.svg.gz": {
    "type": "image/svg+xml",
    "encoding": "gzip",
    "etag": "\"253d-kGqA4QE6JuGiTY4Ck/e1vgbyjGk\"",
    "mtime": "2025-04-13T20:04:28.550Z",
    "size": 9533,
    "path": "../public/app-assets/fonts/flag-icon-css/flags/4x3/ec.svg.gz"
  },
  "/app-assets/fonts/flag-icon-css/flags/4x3/ee.svg": {
    "type": "image/svg+xml",
    "etag": "\"171-BAnZSQpPPpdP9rygjtS8Epom1tM\"",
    "mtime": "2025-04-13T20:04:20.437Z",
    "size": 369,
    "path": "../public/app-assets/fonts/flag-icon-css/flags/4x3/ee.svg"
  },
  "/app-assets/fonts/flag-icon-css/flags/4x3/eg.svg": {
    "type": "image/svg+xml",
    "etag": "\"4023-iPQhs3FX23geRI1AVkQ31Tu5Ves\"",
    "mtime": "2025-04-13T20:04:20.436Z",
    "size": 16419,
    "path": "../public/app-assets/fonts/flag-icon-css/flags/4x3/eg.svg"
  },
  "/app-assets/fonts/flag-icon-css/flags/4x3/eg.svg.br": {
    "type": "image/svg+xml",
    "encoding": "br",
    "etag": "\"1801-mI86iXyIThTtNtCvoUFNVWjfIYg\"",
    "mtime": "2025-04-13T20:04:28.553Z",
    "size": 6145,
    "path": "../public/app-assets/fonts/flag-icon-css/flags/4x3/eg.svg.br"
  },
  "/app-assets/fonts/flag-icon-css/flags/4x3/eg.svg.gz": {
    "type": "image/svg+xml",
    "encoding": "gzip",
    "etag": "\"1b21-FRJnFUh80LLhsHFr860U2dQmRvA\"",
    "mtime": "2025-04-13T20:04:28.552Z",
    "size": 6945,
    "path": "../public/app-assets/fonts/flag-icon-css/flags/4x3/eg.svg.gz"
  },
  "/app-assets/fonts/flag-icon-css/flags/4x3/eh.svg": {
    "type": "image/svg+xml",
    "etag": "\"45a-wIQlhFGMHFoiYscawla7gpYnH/8\"",
    "mtime": "2025-04-13T20:04:20.438Z",
    "size": 1114,
    "path": "../public/app-assets/fonts/flag-icon-css/flags/4x3/eh.svg"
  },
  "/app-assets/fonts/flag-icon-css/flags/4x3/eh.svg.br": {
    "type": "image/svg+xml",
    "encoding": "br",
    "etag": "\"228-dEskH0HEFIhHTAqBNtTKCUw73wg\"",
    "mtime": "2025-04-13T20:04:28.550Z",
    "size": 552,
    "path": "../public/app-assets/fonts/flag-icon-css/flags/4x3/eh.svg.br"
  },
  "/app-assets/fonts/flag-icon-css/flags/4x3/eh.svg.gz": {
    "type": "image/svg+xml",
    "encoding": "gzip",
    "etag": "\"288-koW545tRBUGa72aoUzCKwSNY4lY\"",
    "mtime": "2025-04-13T20:04:28.550Z",
    "size": 648,
    "path": "../public/app-assets/fonts/flag-icon-css/flags/4x3/eh.svg.gz"
  },
  "/app-assets/fonts/flag-icon-css/flags/4x3/er.svg": {
    "type": "image/svg+xml",
    "etag": "\"12e1-B07DRnvxknvzw+TL/21tvH/OCEA\"",
    "mtime": "2025-04-13T20:04:20.437Z",
    "size": 4833,
    "path": "../public/app-assets/fonts/flag-icon-css/flags/4x3/er.svg"
  },
  "/app-assets/fonts/flag-icon-css/flags/4x3/er.svg.br": {
    "type": "image/svg+xml",
    "encoding": "br",
    "etag": "\"7fb-k7VqhDbdCJ0fc49/ZHihlW6P1sw\"",
    "mtime": "2025-04-13T20:04:28.550Z",
    "size": 2043,
    "path": "../public/app-assets/fonts/flag-icon-css/flags/4x3/er.svg.br"
  },
  "/app-assets/fonts/flag-icon-css/flags/4x3/er.svg.gz": {
    "type": "image/svg+xml",
    "encoding": "gzip",
    "etag": "\"93b-zvvKuDN27XUxiu1onKdoQgzbdRw\"",
    "mtime": "2025-04-13T20:04:28.550Z",
    "size": 2363,
    "path": "../public/app-assets/fonts/flag-icon-css/flags/4x3/er.svg.gz"
  },
  "/app-assets/fonts/flag-icon-css/flags/4x3/es.svg": {
    "type": "image/svg+xml",
    "etag": "\"23824-CXjAa5Sfwlc/kPnWF7IR1BNbfmQ\"",
    "mtime": "2025-04-13T20:04:20.437Z",
    "size": 145444,
    "path": "../public/app-assets/fonts/flag-icon-css/flags/4x3/es.svg"
  },
  "/app-assets/fonts/flag-icon-css/flags/4x3/es.svg.br": {
    "type": "image/svg+xml",
    "encoding": "br",
    "etag": "\"63ff-dKXBzuEJ+lQF5WBVHvlPVTPnYo4\"",
    "mtime": "2025-04-13T20:04:28.600Z",
    "size": 25599,
    "path": "../public/app-assets/fonts/flag-icon-css/flags/4x3/es.svg.br"
  },
  "/app-assets/fonts/flag-icon-css/flags/4x3/es.svg.gz": {
    "type": "image/svg+xml",
    "encoding": "gzip",
    "etag": "\"7d18-GX9sH+DXRiyFT7E6c3tNNEODBGc\"",
    "mtime": "2025-04-13T20:04:28.600Z",
    "size": 32024,
    "path": "../public/app-assets/fonts/flag-icon-css/flags/4x3/es.svg.gz"
  },
  "/app-assets/fonts/flag-icon-css/flags/4x3/et.svg": {
    "type": "image/svg+xml",
    "etag": "\"647-1neJIqzbbI+ZatgT0UxRSyh9kUo\"",
    "mtime": "2025-04-13T20:04:20.437Z",
    "size": 1607,
    "path": "../public/app-assets/fonts/flag-icon-css/flags/4x3/et.svg"
  },
  "/app-assets/fonts/flag-icon-css/flags/4x3/et.svg.br": {
    "type": "image/svg+xml",
    "encoding": "br",
    "etag": "\"32e-6Hbeat8d1GmPRUHE6F8q/Gy0nIc\"",
    "mtime": "2025-04-13T20:04:28.550Z",
    "size": 814,
    "path": "../public/app-assets/fonts/flag-icon-css/flags/4x3/et.svg.br"
  },
  "/app-assets/fonts/flag-icon-css/flags/4x3/et.svg.gz": {
    "type": "image/svg+xml",
    "encoding": "gzip",
    "etag": "\"392-gp0DO8DN7CcKtmHbNu2I23gc1MM\"",
    "mtime": "2025-04-13T20:04:28.550Z",
    "size": 914,
    "path": "../public/app-assets/fonts/flag-icon-css/flags/4x3/et.svg.gz"
  },
  "/app-assets/fonts/flag-icon-css/flags/4x3/eu.svg": {
    "type": "image/svg+xml",
    "etag": "\"4f5-IjjFuqsLIWI4p69vja9+hh6pfB8\"",
    "mtime": "2025-04-13T20:04:20.439Z",
    "size": 1269,
    "path": "../public/app-assets/fonts/flag-icon-css/flags/4x3/eu.svg"
  },
  "/app-assets/fonts/flag-icon-css/flags/4x3/eu.svg.br": {
    "type": "image/svg+xml",
    "encoding": "br",
    "etag": "\"165-YXT2rD0CsFBtrx1mczGxCP3vYys\"",
    "mtime": "2025-04-13T20:04:28.550Z",
    "size": 357,
    "path": "../public/app-assets/fonts/flag-icon-css/flags/4x3/eu.svg.br"
  },
  "/app-assets/fonts/flag-icon-css/flags/4x3/eu.svg.gz": {
    "type": "image/svg+xml",
    "encoding": "gzip",
    "etag": "\"191-n4x7uELZqNwqNgOBsEkqbD156YA\"",
    "mtime": "2025-04-13T20:04:28.550Z",
    "size": 401,
    "path": "../public/app-assets/fonts/flag-icon-css/flags/4x3/eu.svg.gz"
  },
  "/app-assets/fonts/flag-icon-css/flags/4x3/fi.svg": {
    "type": "image/svg+xml",
    "etag": "\"398-70XkK4lMj2IPH17Q3jWh/nS+u1o\"",
    "mtime": "2025-04-13T20:04:20.437Z",
    "size": 920,
    "path": "../public/app-assets/fonts/flag-icon-css/flags/4x3/fi.svg"
  },
  "/app-assets/fonts/flag-icon-css/flags/4x3/fj.svg": {
    "type": "image/svg+xml",
    "etag": "\"5a38-aI6HjPB6gTAMfQebWyKnOGxWhTY\"",
    "mtime": "2025-04-13T20:04:20.438Z",
    "size": 23096,
    "path": "../public/app-assets/fonts/flag-icon-css/flags/4x3/fj.svg"
  },
  "/app-assets/fonts/flag-icon-css/flags/4x3/fj.svg.br": {
    "type": "image/svg+xml",
    "encoding": "br",
    "etag": "\"1461-B2LZaaJj6vf/Fy4lKAL+TCs7AT8\"",
    "mtime": "2025-04-13T20:04:28.551Z",
    "size": 5217,
    "path": "../public/app-assets/fonts/flag-icon-css/flags/4x3/fj.svg.br"
  },
  "/app-assets/fonts/flag-icon-css/flags/4x3/fj.svg.gz": {
    "type": "image/svg+xml",
    "encoding": "gzip",
    "etag": "\"1734-BRkmJ8NSthhaHMgS0bHNfEhc7BU\"",
    "mtime": "2025-04-13T20:04:28.551Z",
    "size": 5940,
    "path": "../public/app-assets/fonts/flag-icon-css/flags/4x3/fj.svg.gz"
  },
  "/app-assets/fonts/flag-icon-css/flags/4x3/fk.svg": {
    "type": "image/svg+xml",
    "etag": "\"afbf-u1hIv66eqUAEo9CSvgZUzSOHMEo\"",
    "mtime": "2025-04-13T20:04:20.437Z",
    "size": 44991,
    "path": "../public/app-assets/fonts/flag-icon-css/flags/4x3/fk.svg"
  },
  "/app-assets/fonts/flag-icon-css/flags/4x3/fk.svg.br": {
    "type": "image/svg+xml",
    "encoding": "br",
    "etag": "\"34eb-1cDZuHJXTyhfj/2CAf615i9gx+g\"",
    "mtime": "2025-04-13T20:04:28.551Z",
    "size": 13547,
    "path": "../public/app-assets/fonts/flag-icon-css/flags/4x3/fk.svg.br"
  },
  "/app-assets/fonts/flag-icon-css/flags/4x3/fk.svg.gz": {
    "type": "image/svg+xml",
    "encoding": "gzip",
    "etag": "\"3b4f-iGvuKTej4Xz5mruDMSqiXuwRKVc\"",
    "mtime": "2025-04-13T20:04:28.551Z",
    "size": 15183,
    "path": "../public/app-assets/fonts/flag-icon-css/flags/4x3/fk.svg.gz"
  },
  "/app-assets/fonts/flag-icon-css/flags/4x3/fm.svg": {
    "type": "image/svg+xml",
    "etag": "\"3cb-93Hew8Fw6wz9U3TKyWB2522AEP4\"",
    "mtime": "2025-04-13T20:04:20.437Z",
    "size": 971,
    "path": "../public/app-assets/fonts/flag-icon-css/flags/4x3/fm.svg"
  },
  "/app-assets/fonts/flag-icon-css/flags/4x3/fo.svg": {
    "type": "image/svg+xml",
    "etag": "\"2ab-R4zFfCRX4bkMbdcLFFlObXFpaqM\"",
    "mtime": "2025-04-13T20:04:20.437Z",
    "size": 683,
    "path": "../public/app-assets/fonts/flag-icon-css/flags/4x3/fo.svg"
  },
  "/app-assets/fonts/flag-icon-css/flags/4x3/fr.svg": {
    "type": "image/svg+xml",
    "etag": "\"15a-S8+dnbT5Ra/qxiMRTjhUi3V0lVs\"",
    "mtime": "2025-04-13T20:04:20.437Z",
    "size": 346,
    "path": "../public/app-assets/fonts/flag-icon-css/flags/4x3/fr.svg"
  },
  "/app-assets/fonts/flag-icon-css/flags/4x3/ga.svg": {
    "type": "image/svg+xml",
    "etag": "\"14a-4UbjpzMQCnkUGVW0WHnj0scahBk\"",
    "mtime": "2025-04-13T20:04:20.438Z",
    "size": 330,
    "path": "../public/app-assets/fonts/flag-icon-css/flags/4x3/ga.svg"
  },
  "/app-assets/fonts/flag-icon-css/flags/4x3/gb-eng.svg": {
    "type": "image/svg+xml",
    "etag": "\"e7-vepxmI8d6QGD+ytm5ryj1CdRGwI\"",
    "mtime": "2025-04-13T20:04:20.438Z",
    "size": 231,
    "path": "../public/app-assets/fonts/flag-icon-css/flags/4x3/gb-eng.svg"
  },
  "/app-assets/fonts/flag-icon-css/flags/4x3/gb-sct.svg": {
    "type": "image/svg+xml",
    "etag": "\"dd-AazqBn9+W7b4N919DRGkFI7lNjM\"",
    "mtime": "2025-04-13T20:04:20.442Z",
    "size": 221,
    "path": "../public/app-assets/fonts/flag-icon-css/flags/4x3/gb-sct.svg"
  },
  "/app-assets/fonts/flag-icon-css/flags/4x3/gb-wls.svg": {
    "type": "image/svg+xml",
    "etag": "\"38c9-gw38d5mUz75RsDjpxtHCRcvoSo4\"",
    "mtime": "2025-04-13T20:04:20.438Z",
    "size": 14537,
    "path": "../public/app-assets/fonts/flag-icon-css/flags/4x3/gb-wls.svg"
  },
  "/app-assets/fonts/flag-icon-css/flags/4x3/gb-wls.svg.br": {
    "type": "image/svg+xml",
    "encoding": "br",
    "etag": "\"17c5-DNdnO2sG1iCubPRmPfJf08s15cc\"",
    "mtime": "2025-04-13T20:04:28.551Z",
    "size": 6085,
    "path": "../public/app-assets/fonts/flag-icon-css/flags/4x3/gb-wls.svg.br"
  },
  "/app-assets/fonts/flag-icon-css/flags/4x3/gb-wls.svg.gz": {
    "type": "image/svg+xml",
    "encoding": "gzip",
    "etag": "\"1a42-/gM6Nsgz/L4MuzitEQDzCQZbsvs\"",
    "mtime": "2025-04-13T20:04:28.551Z",
    "size": 6722,
    "path": "../public/app-assets/fonts/flag-icon-css/flags/4x3/gb-wls.svg.gz"
  },
  "/app-assets/fonts/flag-icon-css/flags/4x3/gb.svg": {
    "type": "image/svg+xml",
    "etag": "\"3dd-fYCRJS2jhrpzLIsQg5TxIK3bcx4\"",
    "mtime": "2025-04-13T20:04:20.440Z",
    "size": 989,
    "path": "../public/app-assets/fonts/flag-icon-css/flags/4x3/gb.svg"
  },
  "/app-assets/fonts/flag-icon-css/flags/4x3/gd.svg": {
    "type": "image/svg+xml",
    "etag": "\"7cc-wmz62zmzdlwe6sZegiYC4iLNkDI\"",
    "mtime": "2025-04-13T20:04:20.439Z",
    "size": 1996,
    "path": "../public/app-assets/fonts/flag-icon-css/flags/4x3/gd.svg"
  },
  "/app-assets/fonts/flag-icon-css/flags/4x3/gd.svg.br": {
    "type": "image/svg+xml",
    "encoding": "br",
    "etag": "\"2ad-jUxQUIK1Wj8XkFpCyLaH0G/R1RQ\"",
    "mtime": "2025-04-13T20:04:28.551Z",
    "size": 685,
    "path": "../public/app-assets/fonts/flag-icon-css/flags/4x3/gd.svg.br"
  },
  "/app-assets/fonts/flag-icon-css/flags/4x3/gd.svg.gz": {
    "type": "image/svg+xml",
    "encoding": "gzip",
    "etag": "\"310-jhHjgUWor0E1VPTCLkNfA+HMzd0\"",
    "mtime": "2025-04-13T20:04:28.551Z",
    "size": 784,
    "path": "../public/app-assets/fonts/flag-icon-css/flags/4x3/gd.svg.gz"
  },
  "/app-assets/fonts/flag-icon-css/flags/4x3/ge.svg": {
    "type": "image/svg+xml",
    "etag": "\"49e-gKmbBu7C9IO3dO0ytvDhomA8BBk\"",
    "mtime": "2025-04-13T20:04:20.438Z",
    "size": 1182,
    "path": "../public/app-assets/fonts/flag-icon-css/flags/4x3/ge.svg"
  },
  "/app-assets/fonts/flag-icon-css/flags/4x3/ge.svg.br": {
    "type": "image/svg+xml",
    "encoding": "br",
    "etag": "\"1ad-VgIhEzQu+ShPP7G86CJsBhJytaw\"",
    "mtime": "2025-04-13T20:04:28.551Z",
    "size": 429,
    "path": "../public/app-assets/fonts/flag-icon-css/flags/4x3/ge.svg.br"
  },
  "/app-assets/fonts/flag-icon-css/flags/4x3/ge.svg.gz": {
    "type": "image/svg+xml",
    "encoding": "gzip",
    "etag": "\"1e9-dc5ReszXTy3VOd2rgeiOp/+vWeU\"",
    "mtime": "2025-04-13T20:04:28.551Z",
    "size": 489,
    "path": "../public/app-assets/fonts/flag-icon-css/flags/4x3/ge.svg.gz"
  },
  "/app-assets/fonts/flag-icon-css/flags/4x3/gf.svg": {
    "type": "image/svg+xml",
    "etag": "\"10a-UpSeuTPytOy4+CvQJZ0vRxv+obw\"",
    "mtime": "2025-04-13T20:04:20.438Z",
    "size": 266,
    "path": "../public/app-assets/fonts/flag-icon-css/flags/4x3/gf.svg"
  },
  "/app-assets/fonts/flag-icon-css/flags/4x3/gg.svg": {
    "type": "image/svg+xml",
    "etag": "\"375-Y+/K0zeWLQB33ettHlB66oeAVKo\"",
    "mtime": "2025-04-13T20:04:20.438Z",
    "size": 885,
    "path": "../public/app-assets/fonts/flag-icon-css/flags/4x3/gg.svg"
  },
  "/app-assets/fonts/flag-icon-css/flags/4x3/gh.svg": {
    "type": "image/svg+xml",
    "etag": "\"122-A5kiLpH+/tqTuOn3ZmPqoBVpx8E\"",
    "mtime": "2025-04-13T20:04:20.439Z",
    "size": 290,
    "path": "../public/app-assets/fonts/flag-icon-css/flags/4x3/gh.svg"
  },
  "/app-assets/fonts/flag-icon-css/flags/4x3/gi.svg": {
    "type": "image/svg+xml",
    "etag": "\"1041-uCewQ0S9ilyMJaOraATPsPWG87g\"",
    "mtime": "2025-04-13T20:04:20.438Z",
    "size": 4161,
    "path": "../public/app-assets/fonts/flag-icon-css/flags/4x3/gi.svg"
  },
  "/app-assets/fonts/flag-icon-css/flags/4x3/gi.svg.br": {
    "type": "image/svg+xml",
    "encoding": "br",
    "etag": "\"6be-iHjX9Lzu31Sx1YPVg6ghEkg+zuk\"",
    "mtime": "2025-04-13T20:04:28.551Z",
    "size": 1726,
    "path": "../public/app-assets/fonts/flag-icon-css/flags/4x3/gi.svg.br"
  },
  "/app-assets/fonts/flag-icon-css/flags/4x3/gi.svg.gz": {
    "type": "image/svg+xml",
    "encoding": "gzip",
    "etag": "\"759-mu0s2g9VU0HVLNG6BhR4XER98UQ\"",
    "mtime": "2025-04-13T20:04:28.551Z",
    "size": 1881,
    "path": "../public/app-assets/fonts/flag-icon-css/flags/4x3/gi.svg.gz"
  },
  "/app-assets/fonts/flag-icon-css/flags/4x3/gl.svg": {
    "type": "image/svg+xml",
    "etag": "\"2b7-J8l/1qIbHsy3TGcYVBogWtBeWys\"",
    "mtime": "2025-04-13T20:04:20.438Z",
    "size": 695,
    "path": "../public/app-assets/fonts/flag-icon-css/flags/4x3/gl.svg"
  },
  "/app-assets/fonts/flag-icon-css/flags/4x3/gm.svg": {
    "type": "image/svg+xml",
    "etag": "\"24f-RGxo9ededjLK0BBG4MzDa6yyIOc\"",
    "mtime": "2025-04-13T20:04:20.438Z",
    "size": 591,
    "path": "../public/app-assets/fonts/flag-icon-css/flags/4x3/gm.svg"
  },
  "/app-assets/fonts/flag-icon-css/flags/4x3/gn.svg": {
    "type": "image/svg+xml",
    "etag": "\"157-L4lFiYNz0PI7X0MtzJQ0EQOiZ64\"",
    "mtime": "2025-04-13T20:04:20.439Z",
    "size": 343,
    "path": "../public/app-assets/fonts/flag-icon-css/flags/4x3/gn.svg"
  },
  "/app-assets/fonts/flag-icon-css/flags/4x3/gp.svg": {
    "type": "image/svg+xml",
    "etag": "\"15a-S8+dnbT5Ra/qxiMRTjhUi3V0lVs\"",
    "mtime": "2025-04-13T20:04:20.440Z",
    "size": 346,
    "path": "../public/app-assets/fonts/flag-icon-css/flags/4x3/gp.svg"
  },
  "/app-assets/fonts/flag-icon-css/flags/4x3/gq.svg": {
    "type": "image/svg+xml",
    "etag": "\"455a-u6k+iFRTwx4ZtJ+lw0CpDlkki+M\"",
    "mtime": "2025-04-13T20:04:20.439Z",
    "size": 17754,
    "path": "../public/app-assets/fonts/flag-icon-css/flags/4x3/gq.svg"
  },
  "/app-assets/fonts/flag-icon-css/flags/4x3/gq.svg.br": {
    "type": "image/svg+xml",
    "encoding": "br",
    "etag": "\"1728-d0uxRNaRcg0HeR1aGvEPQb4pHOQ\"",
    "mtime": "2025-04-13T20:04:28.551Z",
    "size": 5928,
    "path": "../public/app-assets/fonts/flag-icon-css/flags/4x3/gq.svg.br"
  },
  "/app-assets/fonts/flag-icon-css/flags/4x3/gq.svg.gz": {
    "type": "image/svg+xml",
    "encoding": "gzip",
    "etag": "\"19ef-SnmrftfYITrr4kmYdVXRkuiOOC0\"",
    "mtime": "2025-04-13T20:04:28.551Z",
    "size": 6639,
    "path": "../public/app-assets/fonts/flag-icon-css/flags/4x3/gq.svg.gz"
  },
  "/app-assets/fonts/flag-icon-css/flags/4x3/gr.svg": {
    "type": "image/svg+xml",
    "etag": "\"354-EpFgmiIhuiEbboutd4JuC5j6C6Y\"",
    "mtime": "2025-04-13T20:04:20.439Z",
    "size": 852,
    "path": "../public/app-assets/fonts/flag-icon-css/flags/4x3/gr.svg"
  },
  "/app-assets/fonts/flag-icon-css/flags/4x3/gs.svg": {
    "type": "image/svg+xml",
    "etag": "\"b737-ylzHHwxYFA4fPX9FWvb1V2PCnuk\"",
    "mtime": "2025-04-13T20:04:20.440Z",
    "size": 46903,
    "path": "../public/app-assets/fonts/flag-icon-css/flags/4x3/gs.svg"
  },
  "/app-assets/fonts/flag-icon-css/flags/4x3/gs.svg.br": {
    "type": "image/svg+xml",
    "encoding": "br",
    "etag": "\"3770-C2Anfxn+BFZE1zKG7uNZKNda5lo\"",
    "mtime": "2025-04-13T20:04:28.551Z",
    "size": 14192,
    "path": "../public/app-assets/fonts/flag-icon-css/flags/4x3/gs.svg.br"
  },
  "/app-assets/fonts/flag-icon-css/flags/4x3/gs.svg.gz": {
    "type": "image/svg+xml",
    "encoding": "gzip",
    "etag": "\"3f06-3vyUSvZGFx3pFrOEEC/pouosp04\"",
    "mtime": "2025-04-13T20:04:28.551Z",
    "size": 16134,
    "path": "../public/app-assets/fonts/flag-icon-css/flags/4x3/gs.svg.gz"
  },
  "/app-assets/fonts/flag-icon-css/flags/4x3/gt.svg": {
    "type": "image/svg+xml",
    "etag": "\"f079-XHH7O23B0BN8tA11C093MIh9fuU\"",
    "mtime": "2025-04-13T20:04:20.439Z",
    "size": 61561,
    "path": "../public/app-assets/fonts/flag-icon-css/flags/4x3/gt.svg"
  },
  "/app-assets/fonts/flag-icon-css/flags/4x3/gt.svg.br": {
    "type": "image/svg+xml",
    "encoding": "br",
    "etag": "\"531b-zqQVv7DakGGSgjbNTSUbnpeXYFg\"",
    "mtime": "2025-04-13T20:04:28.600Z",
    "size": 21275,
    "path": "../public/app-assets/fonts/flag-icon-css/flags/4x3/gt.svg.br"
  },
  "/app-assets/fonts/flag-icon-css/flags/4x3/gt.svg.gz": {
    "type": "image/svg+xml",
    "encoding": "gzip",
    "etag": "\"613d-KhRi/IOTFklxWx17CN0yYmNLjuQ\"",
    "mtime": "2025-04-13T20:04:28.600Z",
    "size": 24893,
    "path": "../public/app-assets/fonts/flag-icon-css/flags/4x3/gt.svg.gz"
  },
  "/app-assets/fonts/flag-icon-css/flags/4x3/gu.svg": {
    "type": "image/svg+xml",
    "etag": "\"18ef-Gyp9waXEaT5A6ESkbjb0Rumuugk\"",
    "mtime": "2025-04-13T20:04:20.439Z",
    "size": 6383,
    "path": "../public/app-assets/fonts/flag-icon-css/flags/4x3/gu.svg"
  },
  "/app-assets/fonts/flag-icon-css/flags/4x3/gu.svg.br": {
    "type": "image/svg+xml",
    "encoding": "br",
    "etag": "\"8ab-YSjPNDyvhqemSbkhN3z05GZ7M7g\"",
    "mtime": "2025-04-13T20:04:28.551Z",
    "size": 2219,
    "path": "../public/app-assets/fonts/flag-icon-css/flags/4x3/gu.svg.br"
  },
  "/app-assets/fonts/flag-icon-css/flags/4x3/gu.svg.gz": {
    "type": "image/svg+xml",
    "encoding": "gzip",
    "etag": "\"9db-X3V9SO3PaJl4lrdmDqUaAhiCqGs\"",
    "mtime": "2025-04-13T20:04:28.551Z",
    "size": 2523,
    "path": "../public/app-assets/fonts/flag-icon-css/flags/4x3/gu.svg.gz"
  },
  "/app-assets/fonts/flag-icon-css/flags/4x3/gw.svg": {
    "type": "image/svg+xml",
    "etag": "\"2ba-GE/3bqfbFhE5YwRsvjFUGtmQfn4\"",
    "mtime": "2025-04-13T20:04:20.439Z",
    "size": 698,
    "path": "../public/app-assets/fonts/flag-icon-css/flags/4x3/gw.svg"
  },
  "/app-assets/fonts/flag-icon-css/flags/4x3/gy.svg": {
    "type": "image/svg+xml",
    "etag": "\"25e-xApgB06anrCm2lx8J0K8ndzjWVk\"",
    "mtime": "2025-04-13T20:04:20.446Z",
    "size": 606,
    "path": "../public/app-assets/fonts/flag-icon-css/flags/4x3/gy.svg"
  },
  "/app-assets/fonts/flag-icon-css/flags/4x3/hk.svg": {
    "type": "image/svg+xml",
    "etag": "\"1278-qEX4YXplyJJyuGRhzwCuebR/9dg\"",
    "mtime": "2025-04-13T20:04:20.441Z",
    "size": 4728,
    "path": "../public/app-assets/fonts/flag-icon-css/flags/4x3/hk.svg"
  },
  "/app-assets/fonts/flag-icon-css/flags/4x3/hk.svg.br": {
    "type": "image/svg+xml",
    "encoding": "br",
    "etag": "\"644-YnFEkj/Q95PrCOzqj+wnVoPd8EU\"",
    "mtime": "2025-04-13T20:04:28.551Z",
    "size": 1604,
    "path": "../public/app-assets/fonts/flag-icon-css/flags/4x3/hk.svg.br"
  },
  "/app-assets/fonts/flag-icon-css/flags/4x3/hk.svg.gz": {
    "type": "image/svg+xml",
    "encoding": "gzip",
    "etag": "\"73b-/1dS0IRigZ/0jjFW/2jivNYWnJk\"",
    "mtime": "2025-04-13T20:04:28.551Z",
    "size": 1851,
    "path": "../public/app-assets/fonts/flag-icon-css/flags/4x3/hk.svg.gz"
  },
  "/app-assets/fonts/flag-icon-css/flags/4x3/hm.svg": {
    "type": "image/svg+xml",
    "etag": "\"77e-hHqkDQ4qD7W6Hl9zV43AK96UQ7w\"",
    "mtime": "2025-04-13T20:04:20.440Z",
    "size": 1918,
    "path": "../public/app-assets/fonts/flag-icon-css/flags/4x3/hm.svg"
  },
  "/app-assets/fonts/flag-icon-css/flags/4x3/hm.svg.br": {
    "type": "image/svg+xml",
    "encoding": "br",
    "etag": "\"2b9-EDv0lMnbFTFTD8ZFPKVMeJMU1Uo\"",
    "mtime": "2025-04-13T20:04:28.551Z",
    "size": 697,
    "path": "../public/app-assets/fonts/flag-icon-css/flags/4x3/hm.svg.br"
  },
  "/app-assets/fonts/flag-icon-css/flags/4x3/hm.svg.gz": {
    "type": "image/svg+xml",
    "encoding": "gzip",
    "etag": "\"313-j8QMtUXqAjpvJM6ujVYnCARVruM\"",
    "mtime": "2025-04-13T20:04:28.551Z",
    "size": 787,
    "path": "../public/app-assets/fonts/flag-icon-css/flags/4x3/hm.svg.gz"
  },
  "/app-assets/fonts/flag-icon-css/flags/4x3/hn.svg": {
    "type": "image/svg+xml",
    "etag": "\"4a7-X33uH8mC9FbsO6apN4Hu5W1V7rE\"",
    "mtime": "2025-04-13T20:04:20.441Z",
    "size": 1191,
    "path": "../public/app-assets/fonts/flag-icon-css/flags/4x3/hn.svg"
  },
  "/app-assets/fonts/flag-icon-css/flags/4x3/hn.svg.br": {
    "type": "image/svg+xml",
    "encoding": "br",
    "etag": "\"146-BOBKwENUDBBxYJBYNzCIB+y8GYE\"",
    "mtime": "2025-04-13T20:04:28.551Z",
    "size": 326,
    "path": "../public/app-assets/fonts/flag-icon-css/flags/4x3/hn.svg.br"
  },
  "/app-assets/fonts/flag-icon-css/flags/4x3/hn.svg.gz": {
    "type": "image/svg+xml",
    "encoding": "gzip",
    "etag": "\"170-v4EAe92ji4hfMk2zAu26T4wgK+c\"",
    "mtime": "2025-04-13T20:04:28.551Z",
    "size": 368,
    "path": "../public/app-assets/fonts/flag-icon-css/flags/4x3/hn.svg.gz"
  },
  "/app-assets/fonts/flag-icon-css/flags/4x3/hr.svg": {
    "type": "image/svg+xml",
    "etag": "\"13b39-VaOB5yL35d+bFoIGYfNkODu1nYQ\"",
    "mtime": "2025-04-13T20:04:20.441Z",
    "size": 80697,
    "path": "../public/app-assets/fonts/flag-icon-css/flags/4x3/hr.svg"
  },
  "/app-assets/fonts/flag-icon-css/flags/4x3/hr.svg.br": {
    "type": "image/svg+xml",
    "encoding": "br",
    "etag": "\"6d86-7Hz0nMk/HPTgAU1XPZnh0TBJmX8\"",
    "mtime": "2025-04-13T20:04:28.601Z",
    "size": 28038,
    "path": "../public/app-assets/fonts/flag-icon-css/flags/4x3/hr.svg.br"
  },
  "/app-assets/fonts/flag-icon-css/flags/4x3/hr.svg.gz": {
    "type": "image/svg+xml",
    "encoding": "gzip",
    "etag": "\"809f-MFcnzPdX/AAURbrrLXxxDWnGsK4\"",
    "mtime": "2025-04-13T20:04:28.659Z",
    "size": 32927,
    "path": "../public/app-assets/fonts/flag-icon-css/flags/4x3/hr.svg.gz"
  },
  "/app-assets/fonts/flag-icon-css/flags/4x3/ht.svg": {
    "type": "image/svg+xml",
    "etag": "\"59bb-DPieJry1XK8qA6vHT2P+s8kGqXc\"",
    "mtime": "2025-04-13T20:04:20.441Z",
    "size": 22971,
    "path": "../public/app-assets/fonts/flag-icon-css/flags/4x3/ht.svg"
  },
  "/app-assets/fonts/flag-icon-css/flags/4x3/ht.svg.br": {
    "type": "image/svg+xml",
    "encoding": "br",
    "etag": "\"1f2d-BbAc2MpzRhRe7iqGZQXLCWEgT0A\"",
    "mtime": "2025-04-13T20:04:28.552Z",
    "size": 7981,
    "path": "../public/app-assets/fonts/flag-icon-css/flags/4x3/ht.svg.br"
  },
  "/app-assets/fonts/flag-icon-css/flags/4x3/ht.svg.gz": {
    "type": "image/svg+xml",
    "encoding": "gzip",
    "etag": "\"2386-i6oAj+vQI8YOgv+r6aSCDC/L1QI\"",
    "mtime": "2025-04-13T20:04:28.552Z",
    "size": 9094,
    "path": "../public/app-assets/fonts/flag-icon-css/flags/4x3/ht.svg.gz"
  },
  "/app-assets/fonts/flag-icon-css/flags/4x3/hu.svg": {
    "type": "image/svg+xml",
    "etag": "\"169-WzCtk0FIMwP6xqSs3UxLgsKZLAs\"",
    "mtime": "2025-04-13T20:04:20.441Z",
    "size": 361,
    "path": "../public/app-assets/fonts/flag-icon-css/flags/4x3/hu.svg"
  },
  "/app-assets/fonts/flag-icon-css/flags/4x3/id.svg": {
    "type": "image/svg+xml",
    "etag": "\"129-IfI+RIAHJ6EKlUqLXb72tCV/4Cw\"",
    "mtime": "2025-04-13T20:04:20.443Z",
    "size": 297,
    "path": "../public/app-assets/fonts/flag-icon-css/flags/4x3/id.svg"
  },
  "/app-assets/fonts/flag-icon-css/flags/4x3/ie.svg": {
    "type": "image/svg+xml",
    "etag": "\"16e-GY8Jqk8JPRzNBJ8u9e0k4NAeuUo\"",
    "mtime": "2025-04-13T20:04:20.440Z",
    "size": 366,
    "path": "../public/app-assets/fonts/flag-icon-css/flags/4x3/ie.svg"
  },
  "/app-assets/fonts/flag-icon-css/flags/4x3/il.svg": {
    "type": "image/svg+xml",
    "etag": "\"447-WvuRLeCMS+60jyM1aBxu3Kg5y80\"",
    "mtime": "2025-04-13T20:04:20.441Z",
    "size": 1095,
    "path": "../public/app-assets/fonts/flag-icon-css/flags/4x3/il.svg"
  },
  "/app-assets/fonts/flag-icon-css/flags/4x3/il.svg.br": {
    "type": "image/svg+xml",
    "encoding": "br",
    "etag": "\"205-EQ4P5j+8Im9euoog3ry1p48W6l4\"",
    "mtime": "2025-04-13T20:04:28.551Z",
    "size": 517,
    "path": "../public/app-assets/fonts/flag-icon-css/flags/4x3/il.svg.br"
  },
  "/app-assets/fonts/flag-icon-css/flags/4x3/il.svg.gz": {
    "type": "image/svg+xml",
    "encoding": "gzip",
    "etag": "\"250-lyJ0j6Dg619WemZkP5M7u/fi330\"",
    "mtime": "2025-04-13T20:04:28.551Z",
    "size": 592,
    "path": "../public/app-assets/fonts/flag-icon-css/flags/4x3/il.svg.gz"
  },
  "/app-assets/fonts/flag-icon-css/flags/4x3/im.svg": {
    "type": "image/svg+xml",
    "etag": "\"3bed-0YUmsBx8J5fP2ODvhuJIGEDzcr4\"",
    "mtime": "2025-04-13T20:04:20.441Z",
    "size": 15341,
    "path": "../public/app-assets/fonts/flag-icon-css/flags/4x3/im.svg"
  },
  "/app-assets/fonts/flag-icon-css/flags/4x3/im.svg.br": {
    "type": "image/svg+xml",
    "encoding": "br",
    "etag": "\"164b-X4jQQ6+VEeMnp3k9rfsARFvELXg\"",
    "mtime": "2025-04-13T20:04:28.552Z",
    "size": 5707,
    "path": "../public/app-assets/fonts/flag-icon-css/flags/4x3/im.svg.br"
  },
  "/app-assets/fonts/flag-icon-css/flags/4x3/im.svg.gz": {
    "type": "image/svg+xml",
    "encoding": "gzip",
    "etag": "\"196b-R2xXr176vQyxQ+kgPp9alUVbXmA\"",
    "mtime": "2025-04-13T20:04:28.551Z",
    "size": 6507,
    "path": "../public/app-assets/fonts/flag-icon-css/flags/4x3/im.svg.gz"
  },
  "/app-assets/fonts/flag-icon-css/flags/4x3/in.svg": {
    "type": "image/svg+xml",
    "etag": "\"464-k+8ZDfhEuZPchqZG6FoEgO/EIGw\"",
    "mtime": "2025-04-13T20:04:20.441Z",
    "size": 1124,
    "path": "../public/app-assets/fonts/flag-icon-css/flags/4x3/in.svg"
  },
  "/app-assets/fonts/flag-icon-css/flags/4x3/in.svg.br": {
    "type": "image/svg+xml",
    "encoding": "br",
    "etag": "\"14c-S+PE6oaL6/RzsH3nl/SFw+624cU\"",
    "mtime": "2025-04-13T20:04:28.551Z",
    "size": 332,
    "path": "../public/app-assets/fonts/flag-icon-css/flags/4x3/in.svg.br"
  },
  "/app-assets/fonts/flag-icon-css/flags/4x3/in.svg.gz": {
    "type": "image/svg+xml",
    "encoding": "gzip",
    "etag": "\"17b-zSgNkKWCk2XlgmKYrfF9Nm4Q1ag\"",
    "mtime": "2025-04-13T20:04:28.551Z",
    "size": 379,
    "path": "../public/app-assets/fonts/flag-icon-css/flags/4x3/in.svg.gz"
  },
  "/app-assets/fonts/flag-icon-css/flags/4x3/io.svg": {
    "type": "image/svg+xml",
    "etag": "\"9867-ZigDbo/VOs15oh9hWcTv8/2sW0w\"",
    "mtime": "2025-04-13T20:04:20.442Z",
    "size": 39015,
    "path": "../public/app-assets/fonts/flag-icon-css/flags/4x3/io.svg"
  },
  "/app-assets/fonts/flag-icon-css/flags/4x3/io.svg.br": {
    "type": "image/svg+xml",
    "encoding": "br",
    "etag": "\"f43-cdqk3zAGg6hSV64iXu6yaekuKSQ\"",
    "mtime": "2025-04-13T20:04:28.552Z",
    "size": 3907,
    "path": "../public/app-assets/fonts/flag-icon-css/flags/4x3/io.svg.br"
  },
  "/app-assets/fonts/flag-icon-css/flags/4x3/io.svg.gz": {
    "type": "image/svg+xml",
    "encoding": "gzip",
    "etag": "\"120b-p2vONGVQX3V8SLEjZDpLgc5qFeI\"",
    "mtime": "2025-04-13T20:04:28.552Z",
    "size": 4619,
    "path": "../public/app-assets/fonts/flag-icon-css/flags/4x3/io.svg.gz"
  },
  "/app-assets/fonts/flag-icon-css/flags/4x3/iq.svg": {
    "type": "image/svg+xml",
    "etag": "\"8f7-B+Tv+XsXcp0vdanl/ByiD0IsQ5k\"",
    "mtime": "2025-04-13T20:04:20.441Z",
    "size": 2295,
    "path": "../public/app-assets/fonts/flag-icon-css/flags/4x3/iq.svg"
  },
  "/app-assets/fonts/flag-icon-css/flags/4x3/iq.svg.br": {
    "type": "image/svg+xml",
    "encoding": "br",
    "etag": "\"422-88R36JViPTJWti/qVsSRn2T+TXo\"",
    "mtime": "2025-04-13T20:04:28.552Z",
    "size": 1058,
    "path": "../public/app-assets/fonts/flag-icon-css/flags/4x3/iq.svg.br"
  },
  "/app-assets/fonts/flag-icon-css/flags/4x3/iq.svg.gz": {
    "type": "image/svg+xml",
    "encoding": "gzip",
    "etag": "\"475-dON9xVWWmjmMkoBOIy2pYavSjcE\"",
    "mtime": "2025-04-13T20:04:28.552Z",
    "size": 1141,
    "path": "../public/app-assets/fonts/flag-icon-css/flags/4x3/iq.svg.gz"
  },
  "/app-assets/fonts/flag-icon-css/flags/4x3/ir.svg": {
    "type": "image/svg+xml",
    "etag": "\"b737-gf6Mw3DQUJ0DKTduW+DbiK5UrBg\"",
    "mtime": "2025-04-13T20:04:20.442Z",
    "size": 46903,
    "path": "../public/app-assets/fonts/flag-icon-css/flags/4x3/ir.svg"
  },
  "/app-assets/fonts/flag-icon-css/flags/4x3/ir.svg.br": {
    "type": "image/svg+xml",
    "encoding": "br",
    "etag": "\"9e2-fHJJUwV5ZUgDCeNMtAI4swNYS/E\"",
    "mtime": "2025-04-13T20:04:28.552Z",
    "size": 2530,
    "path": "../public/app-assets/fonts/flag-icon-css/flags/4x3/ir.svg.br"
  },
  "/app-assets/fonts/flag-icon-css/flags/4x3/ir.svg.gz": {
    "type": "image/svg+xml",
    "encoding": "gzip",
    "etag": "\"e00-orpuiGGFvqpfoNVtaiktlBtvxRo\"",
    "mtime": "2025-04-13T20:04:28.552Z",
    "size": 3584,
    "path": "../public/app-assets/fonts/flag-icon-css/flags/4x3/ir.svg.gz"
  },
  "/app-assets/fonts/flag-icon-css/flags/4x3/is.svg": {
    "type": "image/svg+xml",
    "etag": "\"4ab-EDAZ2XOBNsiygu9+0jGcEy5+FnY\"",
    "mtime": "2025-04-13T20:04:20.442Z",
    "size": 1195,
    "path": "../public/app-assets/fonts/flag-icon-css/flags/4x3/is.svg"
  },
  "/app-assets/fonts/flag-icon-css/flags/4x3/is.svg.br": {
    "type": "image/svg+xml",
    "encoding": "br",
    "etag": "\"215-73luvK783wWifirPFhv4f6EI23U\"",
    "mtime": "2025-04-13T20:04:28.552Z",
    "size": 533,
    "path": "../public/app-assets/fonts/flag-icon-css/flags/4x3/is.svg.br"
  },
  "/app-assets/fonts/flag-icon-css/flags/4x3/is.svg.gz": {
    "type": "image/svg+xml",
    "encoding": "gzip",
    "etag": "\"25c-M6xiLhlQw1gwSI+9zN9OjdZgw3c\"",
    "mtime": "2025-04-13T20:04:28.552Z",
    "size": 604,
    "path": "../public/app-assets/fonts/flag-icon-css/flags/4x3/is.svg.gz"
  },
  "/app-assets/fonts/flag-icon-css/flags/4x3/it.svg": {
    "type": "image/svg+xml",
    "etag": "\"358-9/x4NX+AkT2qpAwTarFe8YiYxhY\"",
    "mtime": "2025-04-13T20:04:20.442Z",
    "size": 856,
    "path": "../public/app-assets/fonts/flag-icon-css/flags/4x3/it.svg"
  },
  "/app-assets/fonts/flag-icon-css/flags/4x3/je.svg": {
    "type": "image/svg+xml",
    "etag": "\"2b1e-SmXenewuN9SHmYn2lseeLDMEP+E\"",
    "mtime": "2025-04-13T20:04:20.442Z",
    "size": 11038,
    "path": "../public/app-assets/fonts/flag-icon-css/flags/4x3/je.svg"
  },
  "/app-assets/fonts/flag-icon-css/flags/4x3/je.svg.br": {
    "type": "image/svg+xml",
    "encoding": "br",
    "etag": "\"ec4-oVW0PqWUu/3FnyPboLadVvJpF5I\"",
    "mtime": "2025-04-13T20:04:28.552Z",
    "size": 3780,
    "path": "../public/app-assets/fonts/flag-icon-css/flags/4x3/je.svg.br"
  },
  "/app-assets/fonts/flag-icon-css/flags/4x3/je.svg.gz": {
    "type": "image/svg+xml",
    "encoding": "gzip",
    "etag": "\"10db-4S+moM3L06FHyLluCvPtj6I4N8Q\"",
    "mtime": "2025-04-13T20:04:28.552Z",
    "size": 4315,
    "path": "../public/app-assets/fonts/flag-icon-css/flags/4x3/je.svg.gz"
  },
  "/app-assets/fonts/flag-icon-css/flags/4x3/jm.svg": {
    "type": "image/svg+xml",
    "etag": "\"3f9-eckpcz0Y6lCta3pBXc5ejY+VemY\"",
    "mtime": "2025-04-13T20:04:20.443Z",
    "size": 1017,
    "path": "../public/app-assets/fonts/flag-icon-css/flags/4x3/jm.svg"
  },
  "/app-assets/fonts/flag-icon-css/flags/4x3/jo.svg": {
    "type": "image/svg+xml",
    "etag": "\"5bc-Xmkz1MOgWJz5lAKfEENvBde0FTE\"",
    "mtime": "2025-04-13T20:04:20.443Z",
    "size": 1468,
    "path": "../public/app-assets/fonts/flag-icon-css/flags/4x3/jo.svg"
  },
  "/app-assets/fonts/flag-icon-css/flags/4x3/jo.svg.br": {
    "type": "image/svg+xml",
    "encoding": "br",
    "etag": "\"26c-vtAufq1m4pjtnIx8UdABZV6NQ6g\"",
    "mtime": "2025-04-13T20:04:28.552Z",
    "size": 620,
    "path": "../public/app-assets/fonts/flag-icon-css/flags/4x3/jo.svg.br"
  },
  "/app-assets/fonts/flag-icon-css/flags/4x3/jo.svg.gz": {
    "type": "image/svg+xml",
    "encoding": "gzip",
    "etag": "\"2d8-LWNdTNKCtGuGDFI2ov/4iy3KSEg\"",
    "mtime": "2025-04-13T20:04:28.552Z",
    "size": 728,
    "path": "../public/app-assets/fonts/flag-icon-css/flags/4x3/jo.svg.gz"
  },
  "/app-assets/fonts/flag-icon-css/flags/4x3/jp.svg": {
    "type": "image/svg+xml",
    "etag": "\"515-SoRSxnki42FYRZ/CN+LbNXNHiFE\"",
    "mtime": "2025-04-13T20:04:20.443Z",
    "size": 1301,
    "path": "../public/app-assets/fonts/flag-icon-css/flags/4x3/jp.svg"
  },
  "/app-assets/fonts/flag-icon-css/flags/4x3/jp.svg.br": {
    "type": "image/svg+xml",
    "encoding": "br",
    "etag": "\"23c-U5QtxSRiq8beLjkkp0BzEFZNeZE\"",
    "mtime": "2025-04-13T20:04:28.552Z",
    "size": 572,
    "path": "../public/app-assets/fonts/flag-icon-css/flags/4x3/jp.svg.br"
  },
  "/app-assets/fonts/flag-icon-css/flags/4x3/jp.svg.gz": {
    "type": "image/svg+xml",
    "encoding": "gzip",
    "etag": "\"297-KFlxZN9wFlwP4vVl2hDjPuPK6bE\"",
    "mtime": "2025-04-13T20:04:28.552Z",
    "size": 663,
    "path": "../public/app-assets/fonts/flag-icon-css/flags/4x3/jp.svg.gz"
  },
  "/app-assets/fonts/flag-icon-css/flags/4x3/ke.svg": {
    "type": "image/svg+xml",
    "etag": "\"582-SA3CCwBkgN3C2pR2lHAizo5FoP4\"",
    "mtime": "2025-04-13T20:04:20.443Z",
    "size": 1410,
    "path": "../public/app-assets/fonts/flag-icon-css/flags/4x3/ke.svg"
  },
  "/app-assets/fonts/flag-icon-css/flags/4x3/ke.svg.br": {
    "type": "image/svg+xml",
    "encoding": "br",
    "etag": "\"1fa-vFkEerTUaWZebYb6WGYU0CxXaq8\"",
    "mtime": "2025-04-13T20:04:28.552Z",
    "size": 506,
    "path": "../public/app-assets/fonts/flag-icon-css/flags/4x3/ke.svg.br"
  },
  "/app-assets/fonts/flag-icon-css/flags/4x3/ke.svg.gz": {
    "type": "image/svg+xml",
    "encoding": "gzip",
    "etag": "\"234-omODmA/WdedxBsLgc3Yqvyt9guk\"",
    "mtime": "2025-04-13T20:04:28.552Z",
    "size": 564,
    "path": "../public/app-assets/fonts/flag-icon-css/flags/4x3/ke.svg.gz"
  },
  "/app-assets/fonts/flag-icon-css/flags/4x3/kg.svg": {
    "type": "image/svg+xml",
    "etag": "\"180c-JBZJVcnECXoGumS+1kj5yWsYEu8\"",
    "mtime": "2025-04-13T20:04:20.443Z",
    "size": 6156,
    "path": "../public/app-assets/fonts/flag-icon-css/flags/4x3/kg.svg"
  },
  "/app-assets/fonts/flag-icon-css/flags/4x3/kg.svg.br": {
    "type": "image/svg+xml",
    "encoding": "br",
    "etag": "\"9a5-Xlc7yvQEzu//lCShp61aV0Xgla8\"",
    "mtime": "2025-04-13T20:04:28.552Z",
    "size": 2469,
    "path": "../public/app-assets/fonts/flag-icon-css/flags/4x3/kg.svg.br"
  },
  "/app-assets/fonts/flag-icon-css/flags/4x3/kg.svg.gz": {
    "type": "image/svg+xml",
    "encoding": "gzip",
    "etag": "\"b3a-wA1OSnlGSDOcctc4pnUBFfUqIT4\"",
    "mtime": "2025-04-13T20:04:28.552Z",
    "size": 2874,
    "path": "../public/app-assets/fonts/flag-icon-css/flags/4x3/kg.svg.gz"
  },
  "/app-assets/fonts/flag-icon-css/flags/4x3/kh.svg": {
    "type": "image/svg+xml",
    "etag": "\"4d15-C7xOvbyYOz7dUIU/smlZYmSNbNQ\"",
    "mtime": "2025-04-13T20:04:20.443Z",
    "size": 19733,
    "path": "../public/app-assets/fonts/flag-icon-css/flags/4x3/kh.svg"
  },
  "/app-assets/fonts/flag-icon-css/flags/4x3/kh.svg.br": {
    "type": "image/svg+xml",
    "encoding": "br",
    "etag": "\"a29-lOp5Jt40INFbqp0hnw4j3ZJz+ks\"",
    "mtime": "2025-04-13T20:04:28.552Z",
    "size": 2601,
    "path": "../public/app-assets/fonts/flag-icon-css/flags/4x3/kh.svg.br"
  },
  "/app-assets/fonts/flag-icon-css/flags/4x3/kh.svg.gz": {
    "type": "image/svg+xml",
    "encoding": "gzip",
    "etag": "\"c34-pjKNYChLCFDF0DGM0VmcVNE7zc8\"",
    "mtime": "2025-04-13T20:04:28.552Z",
    "size": 3124,
    "path": "../public/app-assets/fonts/flag-icon-css/flags/4x3/kh.svg.gz"
  },
  "/app-assets/fonts/flag-icon-css/flags/4x3/ki.svg": {
    "type": "image/svg+xml",
    "etag": "\"23ff-OBoxex8StmwfaKaafcYX11Md8V0\"",
    "mtime": "2025-04-13T20:04:20.444Z",
    "size": 9215,
    "path": "../public/app-assets/fonts/flag-icon-css/flags/4x3/ki.svg"
  },
  "/app-assets/fonts/flag-icon-css/flags/4x3/ki.svg.br": {
    "type": "image/svg+xml",
    "encoding": "br",
    "etag": "\"98a-Gjz2bX2r+E/Q1kbAqw4oEhknGMA\"",
    "mtime": "2025-04-13T20:04:28.552Z",
    "size": 2442,
    "path": "../public/app-assets/fonts/flag-icon-css/flags/4x3/ki.svg.br"
  },
  "/app-assets/fonts/flag-icon-css/flags/4x3/ki.svg.gz": {
    "type": "image/svg+xml",
    "encoding": "gzip",
    "etag": "\"b6c-MOYYFdDzzIoATLmwmW6491rURGM\"",
    "mtime": "2025-04-13T20:04:28.552Z",
    "size": 2924,
    "path": "../public/app-assets/fonts/flag-icon-css/flags/4x3/ki.svg.gz"
  },
  "/app-assets/fonts/flag-icon-css/flags/4x3/km.svg": {
    "type": "image/svg+xml",
    "etag": "\"cb0-9sJm5wL2Nxc38Yaf/MWnsDb/Lfk\"",
    "mtime": "2025-04-13T20:04:20.443Z",
    "size": 3248,
    "path": "../public/app-assets/fonts/flag-icon-css/flags/4x3/km.svg"
  },
  "/app-assets/fonts/flag-icon-css/flags/4x3/km.svg.br": {
    "type": "image/svg+xml",
    "encoding": "br",
    "etag": "\"354-yrDs+1WOgqGVkjimZHKmIrPUY3M\"",
    "mtime": "2025-04-13T20:04:28.552Z",
    "size": 852,
    "path": "../public/app-assets/fonts/flag-icon-css/flags/4x3/km.svg.br"
  },
  "/app-assets/fonts/flag-icon-css/flags/4x3/km.svg.gz": {
    "type": "image/svg+xml",
    "encoding": "gzip",
    "etag": "\"3e4-1gR6s9Cwvz4V0GxCkTdZak4krT0\"",
    "mtime": "2025-04-13T20:04:28.552Z",
    "size": 996,
    "path": "../public/app-assets/fonts/flag-icon-css/flags/4x3/km.svg.gz"
  },
  "/app-assets/fonts/flag-icon-css/flags/4x3/kn.svg": {
    "type": "image/svg+xml",
    "etag": "\"707-hmaSkBmlXAS/z6IyAV5oeQvMn2I\"",
    "mtime": "2025-04-13T20:04:20.443Z",
    "size": 1799,
    "path": "../public/app-assets/fonts/flag-icon-css/flags/4x3/kn.svg"
  },
  "/app-assets/fonts/flag-icon-css/flags/4x3/kn.svg.br": {
    "type": "image/svg+xml",
    "encoding": "br",
    "etag": "\"2d2-YM3kIhieBohRRPrqEVGvhHiAFiM\"",
    "mtime": "2025-04-13T20:04:28.552Z",
    "size": 722,
    "path": "../public/app-assets/fonts/flag-icon-css/flags/4x3/kn.svg.br"
  },
  "/app-assets/fonts/flag-icon-css/flags/4x3/kn.svg.gz": {
    "type": "image/svg+xml",
    "encoding": "gzip",
    "etag": "\"344-/HM7AomLhgYYasS/9LBU0CVt3Q8\"",
    "mtime": "2025-04-13T20:04:28.552Z",
    "size": 836,
    "path": "../public/app-assets/fonts/flag-icon-css/flags/4x3/kn.svg.gz"
  },
  "/app-assets/fonts/flag-icon-css/flags/4x3/kp.svg": {
    "type": "image/svg+xml",
    "etag": "\"785-AZ3wo3WYLZrg14vqipw9TUy3uoc\"",
    "mtime": "2025-04-13T20:04:20.443Z",
    "size": 1925,
    "path": "../public/app-assets/fonts/flag-icon-css/flags/4x3/kp.svg"
  },
  "/app-assets/fonts/flag-icon-css/flags/4x3/kp.svg.br": {
    "type": "image/svg+xml",
    "encoding": "br",
    "etag": "\"2de-aDMA1U0s3hHR9RcABUPQDdfDfoQ\"",
    "mtime": "2025-04-13T20:04:28.552Z",
    "size": 734,
    "path": "../public/app-assets/fonts/flag-icon-css/flags/4x3/kp.svg.br"
  },
  "/app-assets/fonts/flag-icon-css/flags/4x3/kp.svg.gz": {
    "type": "image/svg+xml",
    "encoding": "gzip",
    "etag": "\"35a-jrH12hF2+5+P3DvKBcDShalKjx0\"",
    "mtime": "2025-04-13T20:04:28.552Z",
    "size": 858,
    "path": "../public/app-assets/fonts/flag-icon-css/flags/4x3/kp.svg.gz"
  },
  "/app-assets/fonts/flag-icon-css/flags/4x3/kr.svg": {
    "type": "image/svg+xml",
    "etag": "\"10f1-VF2CPWW55eIgpjb9ZDKRPHRS5c0\"",
    "mtime": "2025-04-13T20:04:20.443Z",
    "size": 4337,
    "path": "../public/app-assets/fonts/flag-icon-css/flags/4x3/kr.svg"
  },
  "/app-assets/fonts/flag-icon-css/flags/4x3/kr.svg.br": {
    "type": "image/svg+xml",
    "encoding": "br",
    "etag": "\"423-gIvFspl1TU8cp9m6wigF2K655Mk\"",
    "mtime": "2025-04-13T20:04:28.552Z",
    "size": 1059,
    "path": "../public/app-assets/fonts/flag-icon-css/flags/4x3/kr.svg.br"
  },
  "/app-assets/fonts/flag-icon-css/flags/4x3/kr.svg.gz": {
    "type": "image/svg+xml",
    "encoding": "gzip",
    "etag": "\"4e0-V+jC5l7WACCeFYdJgkLQqYFxDS8\"",
    "mtime": "2025-04-13T20:04:28.552Z",
    "size": 1248,
    "path": "../public/app-assets/fonts/flag-icon-css/flags/4x3/kr.svg.gz"
  },
  "/app-assets/fonts/flag-icon-css/flags/4x3/kw.svg": {
    "type": "image/svg+xml",
    "etag": "\"4a3-0EZ54+5aWVZDGuFl8CS3nrOtBog\"",
    "mtime": "2025-04-13T20:04:20.444Z",
    "size": 1187,
    "path": "../public/app-assets/fonts/flag-icon-css/flags/4x3/kw.svg"
  },
  "/app-assets/fonts/flag-icon-css/flags/4x3/kw.svg.br": {
    "type": "image/svg+xml",
    "encoding": "br",
    "etag": "\"202-xHi7OGQP9mCoQUN9p7ZudT53B+4\"",
    "mtime": "2025-04-13T20:04:28.552Z",
    "size": 514,
    "path": "../public/app-assets/fonts/flag-icon-css/flags/4x3/kw.svg.br"
  },
  "/app-assets/fonts/flag-icon-css/flags/4x3/kw.svg.gz": {
    "type": "image/svg+xml",
    "encoding": "gzip",
    "etag": "\"262-/LwGM3WDTvQ/KQUxQskr+ItJ4ig\"",
    "mtime": "2025-04-13T20:04:28.552Z",
    "size": 610,
    "path": "../public/app-assets/fonts/flag-icon-css/flags/4x3/kw.svg.gz"
  },
  "/app-assets/fonts/flag-icon-css/flags/4x3/ky.svg": {
    "type": "image/svg+xml",
    "etag": "\"b0c5-gduH6IlOyYrYwkncsWabRso18kk\"",
    "mtime": "2025-04-13T20:04:20.443Z",
    "size": 45253,
    "path": "../public/app-assets/fonts/flag-icon-css/flags/4x3/ky.svg"
  },
  "/app-assets/fonts/flag-icon-css/flags/4x3/ky.svg.br": {
    "type": "image/svg+xml",
    "encoding": "br",
    "etag": "\"331d-3fEUmu6F5H35CGT0pkoTQKW7X1E\"",
    "mtime": "2025-04-13T20:04:28.552Z",
    "size": 13085,
    "path": "../public/app-assets/fonts/flag-icon-css/flags/4x3/ky.svg.br"
  },
  "/app-assets/fonts/flag-icon-css/flags/4x3/ky.svg.gz": {
    "type": "image/svg+xml",
    "encoding": "gzip",
    "etag": "\"3a48-gNtj4gVpbogc6Luq9LHN/XbNfMU\"",
    "mtime": "2025-04-13T20:04:28.552Z",
    "size": 14920,
    "path": "../public/app-assets/fonts/flag-icon-css/flags/4x3/ky.svg.gz"
  },
  "/app-assets/fonts/flag-icon-css/flags/4x3/kz.svg": {
    "type": "image/svg+xml",
    "etag": "\"5184-YiIHvqVgtvElFMt792yb5TXd+zM\"",
    "mtime": "2025-04-13T20:04:20.444Z",
    "size": 20868,
    "path": "../public/app-assets/fonts/flag-icon-css/flags/4x3/kz.svg"
  },
  "/app-assets/fonts/flag-icon-css/flags/4x3/kz.svg.br": {
    "type": "image/svg+xml",
    "encoding": "br",
    "etag": "\"1395-sWmL5hOwHApRD/Hj3B0TJ/cVd8o\"",
    "mtime": "2025-04-13T20:04:28.552Z",
    "size": 5013,
    "path": "../public/app-assets/fonts/flag-icon-css/flags/4x3/kz.svg.br"
  },
  "/app-assets/fonts/flag-icon-css/flags/4x3/kz.svg.gz": {
    "type": "image/svg+xml",
    "encoding": "gzip",
    "etag": "\"1642-Lv8rDaCdPoH5MkzwBSqt55AxKOY\"",
    "mtime": "2025-04-13T20:04:28.552Z",
    "size": 5698,
    "path": "../public/app-assets/fonts/flag-icon-css/flags/4x3/kz.svg.gz"
  },
  "/app-assets/fonts/flag-icon-css/flags/4x3/la.svg": {
    "type": "image/svg+xml",
    "etag": "\"45f-q4IuIWDnsMA1si+hzKjATMrwUic\"",
    "mtime": "2025-04-13T20:04:20.443Z",
    "size": 1119,
    "path": "../public/app-assets/fonts/flag-icon-css/flags/4x3/la.svg"
  },
  "/app-assets/fonts/flag-icon-css/flags/4x3/la.svg.br": {
    "type": "image/svg+xml",
    "encoding": "br",
    "etag": "\"1f5-OGCSg3yghDAlODKSbKh+GMsunHc\"",
    "mtime": "2025-04-13T20:04:28.552Z",
    "size": 501,
    "path": "../public/app-assets/fonts/flag-icon-css/flags/4x3/la.svg.br"
  },
  "/app-assets/fonts/flag-icon-css/flags/4x3/la.svg.gz": {
    "type": "image/svg+xml",
    "encoding": "gzip",
    "etag": "\"24c-6b+A8Qg6kAWUZ3gEYCmP/QjVuZ4\"",
    "mtime": "2025-04-13T20:04:28.552Z",
    "size": 588,
    "path": "../public/app-assets/fonts/flag-icon-css/flags/4x3/la.svg.gz"
  },
  "/app-assets/fonts/flag-icon-css/flags/4x3/lb.svg": {
    "type": "image/svg+xml",
    "etag": "\"1e7b-n62Br3kTnhULzfFGGGgfodCFHSw\"",
    "mtime": "2025-04-13T20:04:20.444Z",
    "size": 7803,
    "path": "../public/app-assets/fonts/flag-icon-css/flags/4x3/lb.svg"
  },
  "/app-assets/fonts/flag-icon-css/flags/4x3/lb.svg.br": {
    "type": "image/svg+xml",
    "encoding": "br",
    "etag": "\"865-SCD/cqF0c5Gy1Ff6RTPDGlngno0\"",
    "mtime": "2025-04-13T20:04:28.552Z",
    "size": 2149,
    "path": "../public/app-assets/fonts/flag-icon-css/flags/4x3/lb.svg.br"
  },
  "/app-assets/fonts/flag-icon-css/flags/4x3/lb.svg.gz": {
    "type": "image/svg+xml",
    "encoding": "gzip",
    "etag": "\"9bf-S9xOprvpQc/jZIklVGrnPQdfCQU\"",
    "mtime": "2025-04-13T20:04:28.552Z",
    "size": 2495,
    "path": "../public/app-assets/fonts/flag-icon-css/flags/4x3/lb.svg.gz"
  },
  "/app-assets/fonts/flag-icon-css/flags/4x3/lc.svg": {
    "type": "image/svg+xml",
    "etag": "\"37f-kDS9e9QoueiD6GDtZxyhY4Xc/PQ\"",
    "mtime": "2025-04-13T20:04:20.444Z",
    "size": 895,
    "path": "../public/app-assets/fonts/flag-icon-css/flags/4x3/lc.svg"
  },
  "/app-assets/fonts/flag-icon-css/flags/4x3/li.svg": {
    "type": "image/svg+xml",
    "etag": "\"30ac-pwPjIdvFXCHEFjbXeHiRmT7cPbg\"",
    "mtime": "2025-04-13T20:04:20.444Z",
    "size": 12460,
    "path": "../public/app-assets/fonts/flag-icon-css/flags/4x3/li.svg"
  },
  "/app-assets/fonts/flag-icon-css/flags/4x3/li.svg.br": {
    "type": "image/svg+xml",
    "encoding": "br",
    "etag": "\"1281-v8uHf642R/07FSCV50deCjqC1PU\"",
    "mtime": "2025-04-13T20:04:28.552Z",
    "size": 4737,
    "path": "../public/app-assets/fonts/flag-icon-css/flags/4x3/li.svg.br"
  },
  "/app-assets/fonts/flag-icon-css/flags/4x3/li.svg.gz": {
    "type": "image/svg+xml",
    "encoding": "gzip",
    "etag": "\"14c4-g4Rn3tRf/zjWo0vXCV8QZaDOF/g\"",
    "mtime": "2025-04-13T20:04:28.552Z",
    "size": 5316,
    "path": "../public/app-assets/fonts/flag-icon-css/flags/4x3/li.svg.gz"
  },
  "/app-assets/fonts/flag-icon-css/flags/4x3/lk.svg": {
    "type": "image/svg+xml",
    "etag": "\"44db-2OwTDj9Tu292XGjpgkGGgiWOLPU\"",
    "mtime": "2025-04-13T20:04:20.444Z",
    "size": 17627,
    "path": "../public/app-assets/fonts/flag-icon-css/flags/4x3/lk.svg"
  },
  "/app-assets/fonts/flag-icon-css/flags/4x3/lk.svg.br": {
    "type": "image/svg+xml",
    "encoding": "br",
    "etag": "\"1b62-MNbiKRe+7FRP3JWaqr9pW0VPi04\"",
    "mtime": "2025-04-13T20:04:28.552Z",
    "size": 7010,
    "path": "../public/app-assets/fonts/flag-icon-css/flags/4x3/lk.svg.br"
  },
  "/app-assets/fonts/flag-icon-css/flags/4x3/lk.svg.gz": {
    "type": "image/svg+xml",
    "encoding": "gzip",
    "etag": "\"1f02-txjTGNgsdKudo897YT5CTBxy5H4\"",
    "mtime": "2025-04-13T20:04:28.552Z",
    "size": 7938,
    "path": "../public/app-assets/fonts/flag-icon-css/flags/4x3/lk.svg.gz"
  },
  "/app-assets/fonts/flag-icon-css/flags/4x3/lr.svg": {
    "type": "image/svg+xml",
    "etag": "\"7e5-4Q4LcS28U+nGMSAlmb3FbsHal0k\"",
    "mtime": "2025-04-13T20:04:20.445Z",
    "size": 2021,
    "path": "../public/app-assets/fonts/flag-icon-css/flags/4x3/lr.svg"
  },
  "/app-assets/fonts/flag-icon-css/flags/4x3/lr.svg.br": {
    "type": "image/svg+xml",
    "encoding": "br",
    "etag": "\"2ac-h1MSbe0987tH4RkShQDK4SlqYY4\"",
    "mtime": "2025-04-13T20:04:28.552Z",
    "size": 684,
    "path": "../public/app-assets/fonts/flag-icon-css/flags/4x3/lr.svg.br"
  },
  "/app-assets/fonts/flag-icon-css/flags/4x3/lr.svg.gz": {
    "type": "image/svg+xml",
    "encoding": "gzip",
    "etag": "\"324-QjzqiOwZUeqPdBHoJ9tYGr425i8\"",
    "mtime": "2025-04-13T20:04:28.552Z",
    "size": 804,
    "path": "../public/app-assets/fonts/flag-icon-css/flags/4x3/lr.svg.gz"
  },
  "/app-assets/fonts/flag-icon-css/flags/4x3/ls.svg": {
    "type": "image/svg+xml",
    "etag": "\"1819-uHwDkeSXC2cZn0V+cqHM8+rlD8Y\"",
    "mtime": "2025-04-13T20:04:20.445Z",
    "size": 6169,
    "path": "../public/app-assets/fonts/flag-icon-css/flags/4x3/ls.svg"
  },
  "/app-assets/fonts/flag-icon-css/flags/4x3/ls.svg.br": {
    "type": "image/svg+xml",
    "encoding": "br",
    "etag": "\"6e3-MPesZrLTGXyVRyRlsvEst6Pr0sg\"",
    "mtime": "2025-04-13T20:04:28.552Z",
    "size": 1763,
    "path": "../public/app-assets/fonts/flag-icon-css/flags/4x3/ls.svg.br"
  },
  "/app-assets/fonts/flag-icon-css/flags/4x3/ls.svg.gz": {
    "type": "image/svg+xml",
    "encoding": "gzip",
    "etag": "\"7ee-f6c0TYpcj92A+B+VNzLo2YIOhMI\"",
    "mtime": "2025-04-13T20:04:28.552Z",
    "size": 2030,
    "path": "../public/app-assets/fonts/flag-icon-css/flags/4x3/ls.svg.gz"
  },
  "/app-assets/fonts/flag-icon-css/flags/4x3/lt.svg": {
    "type": "image/svg+xml",
    "etag": "\"3f6-hu4wXnKNN1fRfByd7tLvHXL8Cqc\"",
    "mtime": "2025-04-13T20:04:20.446Z",
    "size": 1014,
    "path": "../public/app-assets/fonts/flag-icon-css/flags/4x3/lt.svg"
  },
  "/app-assets/fonts/flag-icon-css/flags/4x3/lu.svg": {
    "type": "image/svg+xml",
    "etag": "\"391-1BD93vAXwKBtpK4x+6bwmwMsbFM\"",
    "mtime": "2025-04-13T20:04:20.445Z",
    "size": 913,
    "path": "../public/app-assets/fonts/flag-icon-css/flags/4x3/lu.svg"
  },
  "/app-assets/fonts/flag-icon-css/flags/4x3/lv.svg": {
    "type": "image/svg+xml",
    "etag": "\"37a-DAy3e+yt39ZAOg1KLJ0Nhgbaf9s\"",
    "mtime": "2025-04-13T20:04:20.445Z",
    "size": 890,
    "path": "../public/app-assets/fonts/flag-icon-css/flags/4x3/lv.svg"
  },
  "/app-assets/fonts/flag-icon-css/flags/4x3/ly.svg": {
    "type": "image/svg+xml",
    "etag": "\"477-BneAbij9G6wQKtC5wJhswefm5Nk\"",
    "mtime": "2025-04-13T20:04:20.446Z",
    "size": 1143,
    "path": "../public/app-assets/fonts/flag-icon-css/flags/4x3/ly.svg"
  },
  "/app-assets/fonts/flag-icon-css/flags/4x3/ly.svg.br": {
    "type": "image/svg+xml",
    "encoding": "br",
    "etag": "\"1f3-PKE/gzp1AoDGfCnHCPxaVJuOm/o\"",
    "mtime": "2025-04-13T20:04:28.560Z",
    "size": 499,
    "path": "../public/app-assets/fonts/flag-icon-css/flags/4x3/ly.svg.br"
  },
  "/app-assets/fonts/flag-icon-css/flags/4x3/ly.svg.gz": {
    "type": "image/svg+xml",
    "encoding": "gzip",
    "etag": "\"248-59t2PgqbPUdndKz+YXBkl+Y2sps\"",
    "mtime": "2025-04-13T20:04:28.560Z",
    "size": 584,
    "path": "../public/app-assets/fonts/flag-icon-css/flags/4x3/ly.svg.gz"
  },
  "/app-assets/fonts/flag-icon-css/flags/4x3/ma.svg": {
    "type": "image/svg+xml",
    "etag": "\"106-WLyJnXHu1EyS+kIcsSyhZPGW9x8\"",
    "mtime": "2025-04-13T20:04:20.444Z",
    "size": 262,
    "path": "../public/app-assets/fonts/flag-icon-css/flags/4x3/ma.svg"
  },
  "/app-assets/fonts/flag-icon-css/flags/4x3/mc.svg": {
    "type": "image/svg+xml",
    "etag": "\"30a-78oKBebeRzhXaTw73srkt7tBNsg\"",
    "mtime": "2025-04-13T20:04:20.444Z",
    "size": 778,
    "path": "../public/app-assets/fonts/flag-icon-css/flags/4x3/mc.svg"
  },
  "/app-assets/fonts/flag-icon-css/flags/4x3/md.svg": {
    "type": "image/svg+xml",
    "etag": "\"4adc-0iTkpiwohcmSTt/Y8K18ZYEMBcg\"",
    "mtime": "2025-04-13T20:04:20.444Z",
    "size": 19164,
    "path": "../public/app-assets/fonts/flag-icon-css/flags/4x3/md.svg"
  },
  "/app-assets/fonts/flag-icon-css/flags/4x3/md.svg.br": {
    "type": "image/svg+xml",
    "encoding": "br",
    "etag": "\"e35-WbTcxsvWsLoCOEjAJp3NSz8ZVEs\"",
    "mtime": "2025-04-13T20:04:28.553Z",
    "size": 3637,
    "path": "../public/app-assets/fonts/flag-icon-css/flags/4x3/md.svg.br"
  },
  "/app-assets/fonts/flag-icon-css/flags/4x3/md.svg.gz": {
    "type": "image/svg+xml",
    "encoding": "gzip",
    "etag": "\"1038-nmb0td9GSKrVS2wqYWTF4JKl70o\"",
    "mtime": "2025-04-13T20:04:28.552Z",
    "size": 4152,
    "path": "../public/app-assets/fonts/flag-icon-css/flags/4x3/md.svg.gz"
  },
  "/app-assets/fonts/flag-icon-css/flags/4x3/me.svg": {
    "type": "image/svg+xml",
    "etag": "\"2641e-TxmuKZP+0PQ6gJ1BhJBnUbxyP4w\"",
    "mtime": "2025-04-13T20:04:20.447Z",
    "size": 156702,
    "path": "../public/app-assets/fonts/flag-icon-css/flags/4x3/me.svg"
  },
  "/app-assets/fonts/flag-icon-css/flags/4x3/me.svg.br": {
    "type": "image/svg+xml",
    "encoding": "br",
    "etag": "\"c498-oh34tKLmIuTOwVYcxepGjmAhcXg\"",
    "mtime": "2025-04-13T20:04:28.701Z",
    "size": 50328,
    "path": "../public/app-assets/fonts/flag-icon-css/flags/4x3/me.svg.br"
  },
  "/app-assets/fonts/flag-icon-css/flags/4x3/me.svg.gz": {
    "type": "image/svg+xml",
    "encoding": "gzip",
    "etag": "\"d8f6-JSCvcMCyTMD7gv8uKnFSt6d2+zw\"",
    "mtime": "2025-04-13T20:04:28.700Z",
    "size": 55542,
    "path": "../public/app-assets/fonts/flag-icon-css/flags/4x3/me.svg.gz"
  },
  "/app-assets/fonts/flag-icon-css/flags/4x3/mf.svg": {
    "type": "image/svg+xml",
    "etag": "\"364-LgwoU5AZwPOgqhvWvhfZe2PtimY\"",
    "mtime": "2025-04-13T20:04:20.446Z",
    "size": 868,
    "path": "../public/app-assets/fonts/flag-icon-css/flags/4x3/mf.svg"
  },
  "/app-assets/fonts/flag-icon-css/flags/4x3/mg.svg": {
    "type": "image/svg+xml",
    "etag": "\"349-bcrbuNk8XHtZfgE7MW0hVE/bmD0\"",
    "mtime": "2025-04-13T20:04:20.448Z",
    "size": 841,
    "path": "../public/app-assets/fonts/flag-icon-css/flags/4x3/mg.svg"
  },
  "/app-assets/fonts/flag-icon-css/flags/4x3/mh.svg": {
    "type": "image/svg+xml",
    "etag": "\"650-GbftK/eEVFRVKlMbwjEgusIF1lk\"",
    "mtime": "2025-04-13T20:04:20.446Z",
    "size": 1616,
    "path": "../public/app-assets/fonts/flag-icon-css/flags/4x3/mh.svg"
  },
  "/app-assets/fonts/flag-icon-css/flags/4x3/mh.svg.br": {
    "type": "image/svg+xml",
    "encoding": "br",
    "etag": "\"2f1-WQYzqjr1VVdjdDSHJf52bMiqk2g\"",
    "mtime": "2025-04-13T20:04:28.553Z",
    "size": 753,
    "path": "../public/app-assets/fonts/flag-icon-css/flags/4x3/mh.svg.br"
  },
  "/app-assets/fonts/flag-icon-css/flags/4x3/mh.svg.gz": {
    "type": "image/svg+xml",
    "encoding": "gzip",
    "etag": "\"379-byL/XUzrdDgFZOZvYLrD7VFUO+Y\"",
    "mtime": "2025-04-13T20:04:28.553Z",
    "size": 889,
    "path": "../public/app-assets/fonts/flag-icon-css/flags/4x3/mh.svg.gz"
  },
  "/app-assets/fonts/flag-icon-css/flags/4x3/mk.svg": {
    "type": "image/svg+xml",
    "etag": "\"175-T0WtHzY3lQkuFHccy1xtGr6xGfw\"",
    "mtime": "2025-04-13T20:04:20.445Z",
    "size": 373,
    "path": "../public/app-assets/fonts/flag-icon-css/flags/4x3/mk.svg"
  },
  "/app-assets/fonts/flag-icon-css/flags/4x3/ml.svg": {
    "type": "image/svg+xml",
    "etag": "\"36b-pWs2XWkdDE0B1i7fXWP/mHxwY78\"",
    "mtime": "2025-04-13T20:04:20.446Z",
    "size": 875,
    "path": "../public/app-assets/fonts/flag-icon-css/flags/4x3/ml.svg"
  },
  "/app-assets/fonts/flag-icon-css/flags/4x3/mm.svg": {
    "type": "image/svg+xml",
    "etag": "\"cc0-BCxPtDqlc9HOLN4XK7hjM3NzYaI\"",
    "mtime": "2025-04-13T20:04:20.447Z",
    "size": 3264,
    "path": "../public/app-assets/fonts/flag-icon-css/flags/4x3/mm.svg"
  },
  "/app-assets/fonts/flag-icon-css/flags/4x3/mm.svg.br": {
    "type": "image/svg+xml",
    "encoding": "br",
    "etag": "\"3a1-FyddPRMlEDeKVaHNFwhqAqB2Vfo\"",
    "mtime": "2025-04-13T20:04:28.553Z",
    "size": 929,
    "path": "../public/app-assets/fonts/flag-icon-css/flags/4x3/mm.svg.br"
  },
  "/app-assets/fonts/flag-icon-css/flags/4x3/mm.svg.gz": {
    "type": "image/svg+xml",
    "encoding": "gzip",
    "etag": "\"434-s05YNi+s5S0btqZ5RAXLaWUUX1Q\"",
    "mtime": "2025-04-13T20:04:28.553Z",
    "size": 1076,
    "path": "../public/app-assets/fonts/flag-icon-css/flags/4x3/mm.svg.gz"
  },
  "/app-assets/fonts/flag-icon-css/flags/4x3/mn.svg": {
    "type": "image/svg+xml",
    "etag": "\"447-qY4GH0f/lm/xFIpVPWTjnzH9z3U\"",
    "mtime": "2025-04-13T20:04:20.446Z",
    "size": 1095,
    "path": "../public/app-assets/fonts/flag-icon-css/flags/4x3/mn.svg"
  },
  "/app-assets/fonts/flag-icon-css/flags/4x3/mn.svg.br": {
    "type": "image/svg+xml",
    "encoding": "br",
    "etag": "\"1a2-anVpn9KoNd8ms+E8IV7Gxd6nOkg\"",
    "mtime": "2025-04-13T20:04:28.553Z",
    "size": 418,
    "path": "../public/app-assets/fonts/flag-icon-css/flags/4x3/mn.svg.br"
  },
  "/app-assets/fonts/flag-icon-css/flags/4x3/mn.svg.gz": {
    "type": "image/svg+xml",
    "encoding": "gzip",
    "etag": "\"1c4-IMjYLK2CpGu028KiCwM4ZIhhHwA\"",
    "mtime": "2025-04-13T20:04:28.553Z",
    "size": 452,
    "path": "../public/app-assets/fonts/flag-icon-css/flags/4x3/mn.svg.gz"
  },
  "/app-assets/fonts/flag-icon-css/flags/4x3/mo.svg": {
    "type": "image/svg+xml",
    "etag": "\"7ec-Wp55af9LRlFvzyGH1lGpJq+dI20\"",
    "mtime": "2025-04-13T20:04:20.446Z",
    "size": 2028,
    "path": "../public/app-assets/fonts/flag-icon-css/flags/4x3/mo.svg"
  },
  "/app-assets/fonts/flag-icon-css/flags/4x3/mo.svg.br": {
    "type": "image/svg+xml",
    "encoding": "br",
    "etag": "\"3c7-pdFj5pXWCxTK6qlJukLqM75mjOc\"",
    "mtime": "2025-04-13T20:04:28.553Z",
    "size": 967,
    "path": "../public/app-assets/fonts/flag-icon-css/flags/4x3/mo.svg.br"
  },
  "/app-assets/fonts/flag-icon-css/flags/4x3/mo.svg.gz": {
    "type": "image/svg+xml",
    "encoding": "gzip",
    "etag": "\"412-uI/Pcz77m5U9Fm2UYl8P5cXltP8\"",
    "mtime": "2025-04-13T20:04:28.553Z",
    "size": 1042,
    "path": "../public/app-assets/fonts/flag-icon-css/flags/4x3/mo.svg.gz"
  },
  "/app-assets/fonts/flag-icon-css/flags/4x3/mp.svg": {
    "type": "image/svg+xml",
    "etag": "\"c3a1-V1CC7qI0zQ0cjGwywTglWbl803w\"",
    "mtime": "2025-04-13T20:04:20.446Z",
    "size": 50081,
    "path": "../public/app-assets/fonts/flag-icon-css/flags/4x3/mp.svg"
  },
  "/app-assets/fonts/flag-icon-css/flags/4x3/mp.svg.br": {
    "type": "image/svg+xml",
    "encoding": "br",
    "etag": "\"2b5c-JVTv1ipQUwuKr39qk14Oq2WGQNo\"",
    "mtime": "2025-04-13T20:04:28.553Z",
    "size": 11100,
    "path": "../public/app-assets/fonts/flag-icon-css/flags/4x3/mp.svg.br"
  },
  "/app-assets/fonts/flag-icon-css/flags/4x3/mp.svg.gz": {
    "type": "image/svg+xml",
    "encoding": "gzip",
    "etag": "\"346d-PEakSiTYSORREMXop/bg3oLTJ8Y\"",
    "mtime": "2025-04-13T20:04:28.553Z",
    "size": 13421,
    "path": "../public/app-assets/fonts/flag-icon-css/flags/4x3/mp.svg.gz"
  },
  "/app-assets/fonts/flag-icon-css/flags/4x3/mq.svg": {
    "type": "image/svg+xml",
    "etag": "\"32d-42+CzxHY8s81gg0J7vLHGCFrWQ0\"",
    "mtime": "2025-04-13T20:04:20.447Z",
    "size": 813,
    "path": "../public/app-assets/fonts/flag-icon-css/flags/4x3/mq.svg"
  },
  "/app-assets/fonts/flag-icon-css/flags/4x3/mr.svg": {
    "type": "image/svg+xml",
    "etag": "\"391-4ea5YszWoJtGCZ6y+RMtNpIZQoQ\"",
    "mtime": "2025-04-13T20:04:20.446Z",
    "size": 913,
    "path": "../public/app-assets/fonts/flag-icon-css/flags/4x3/mr.svg"
  },
  "/app-assets/fonts/flag-icon-css/flags/4x3/ms.svg": {
    "type": "image/svg+xml",
    "etag": "\"2a0d-QO7TC5BEbOZTqgnk6Ex4nh0e/Lc\"",
    "mtime": "2025-04-13T20:04:20.447Z",
    "size": 10765,
    "path": "../public/app-assets/fonts/flag-icon-css/flags/4x3/ms.svg"
  },
  "/app-assets/fonts/flag-icon-css/flags/4x3/ms.svg.br": {
    "type": "image/svg+xml",
    "encoding": "br",
    "etag": "\"bfa-ycEU43RJ/fnS0Qz4KqItWTjiy+A\"",
    "mtime": "2025-04-13T20:04:28.553Z",
    "size": 3066,
    "path": "../public/app-assets/fonts/flag-icon-css/flags/4x3/ms.svg.br"
  },
  "/app-assets/fonts/flag-icon-css/flags/4x3/ms.svg.gz": {
    "type": "image/svg+xml",
    "encoding": "gzip",
    "etag": "\"d81-pQQSsYoEE6FDATyX6cU/8kKnmVQ\"",
    "mtime": "2025-04-13T20:04:28.553Z",
    "size": 3457,
    "path": "../public/app-assets/fonts/flag-icon-css/flags/4x3/ms.svg.gz"
  },
  "/app-assets/fonts/flag-icon-css/flags/4x3/mt.svg": {
    "type": "image/svg+xml",
    "etag": "\"5624-z5Qckx/GdgDMnj1BtNGUC9PtMY4\"",
    "mtime": "2025-04-13T20:04:20.448Z",
    "size": 22052,
    "path": "../public/app-assets/fonts/flag-icon-css/flags/4x3/mt.svg"
  },
  "/app-assets/fonts/flag-icon-css/flags/4x3/mt.svg.br": {
    "type": "image/svg+xml",
    "encoding": "br",
    "etag": "\"174d-qxg5x+6+8ct7ROoCnFTvjNnFFk0\"",
    "mtime": "2025-04-13T20:04:28.553Z",
    "size": 5965,
    "path": "../public/app-assets/fonts/flag-icon-css/flags/4x3/mt.svg.br"
  },
  "/app-assets/fonts/flag-icon-css/flags/4x3/mt.svg.gz": {
    "type": "image/svg+xml",
    "encoding": "gzip",
    "etag": "\"1a6d-rMDK7APFOqpA4F0fOQU4Tdc3/T8\"",
    "mtime": "2025-04-13T20:04:28.553Z",
    "size": 6765,
    "path": "../public/app-assets/fonts/flag-icon-css/flags/4x3/mt.svg.gz"
  },
  "/app-assets/fonts/flag-icon-css/flags/4x3/mu.svg": {
    "type": "image/svg+xml",
    "etag": "\"3c0-YBigc30asGImvmdbAl+jg+9wPRA\"",
    "mtime": "2025-04-13T20:04:20.447Z",
    "size": 960,
    "path": "../public/app-assets/fonts/flag-icon-css/flags/4x3/mu.svg"
  },
  "/app-assets/fonts/flag-icon-css/flags/4x3/mv.svg": {
    "type": "image/svg+xml",
    "etag": "\"458-IDgNvHytR4JcvumBDeW8YV2E9iA\"",
    "mtime": "2025-04-13T20:04:20.447Z",
    "size": 1112,
    "path": "../public/app-assets/fonts/flag-icon-css/flags/4x3/mv.svg"
  },
  "/app-assets/fonts/flag-icon-css/flags/4x3/mv.svg.br": {
    "type": "image/svg+xml",
    "encoding": "br",
    "etag": "\"1c5-pUnC5TIeWICOvCo6XPw2uDQxBRE\"",
    "mtime": "2025-04-13T20:04:28.553Z",
    "size": 453,
    "path": "../public/app-assets/fonts/flag-icon-css/flags/4x3/mv.svg.br"
  },
  "/app-assets/fonts/flag-icon-css/flags/4x3/mv.svg.gz": {
    "type": "image/svg+xml",
    "encoding": "gzip",
    "etag": "\"21a-zfWaYGJ3cusvHEIu4xnv4ZcL+Ns\"",
    "mtime": "2025-04-13T20:04:28.553Z",
    "size": 538,
    "path": "../public/app-assets/fonts/flag-icon-css/flags/4x3/mv.svg.gz"
  },
  "/app-assets/fonts/flag-icon-css/flags/4x3/mw.svg": {
    "type": "image/svg+xml",
    "etag": "\"2102-T+HBzLO+2WyzUpbl4N/LeGiS/ko\"",
    "mtime": "2025-04-13T20:04:20.449Z",
    "size": 8450,
    "path": "../public/app-assets/fonts/flag-icon-css/flags/4x3/mw.svg"
  },
  "/app-assets/fonts/flag-icon-css/flags/4x3/mw.svg.br": {
    "type": "image/svg+xml",
    "encoding": "br",
    "etag": "\"bd9-K3dGM5zf+blNGx6E+WacrkZ7F5w\"",
    "mtime": "2025-04-13T20:04:28.553Z",
    "size": 3033,
    "path": "../public/app-assets/fonts/flag-icon-css/flags/4x3/mw.svg.br"
  },
  "/app-assets/fonts/flag-icon-css/flags/4x3/mw.svg.gz": {
    "type": "image/svg+xml",
    "encoding": "gzip",
    "etag": "\"dee-+PbSKcLvMpXlqpY9h4RM5Q44wnc\"",
    "mtime": "2025-04-13T20:04:28.553Z",
    "size": 3566,
    "path": "../public/app-assets/fonts/flag-icon-css/flags/4x3/mw.svg.gz"
  },
  "/app-assets/fonts/flag-icon-css/flags/4x3/mx.svg": {
    "type": "image/svg+xml",
    "etag": "\"132a9-AYqFHR4x3OF9845GJhQV9Rjopvw\"",
    "mtime": "2025-04-13T20:04:20.447Z",
    "size": 78505,
    "path": "../public/app-assets/fonts/flag-icon-css/flags/4x3/mx.svg"
  },
  "/app-assets/fonts/flag-icon-css/flags/4x3/mx.svg.br": {
    "type": "image/svg+xml",
    "encoding": "br",
    "etag": "\"4ab3-MQFBjbm2fAvnmbsFe6ATV9rSFSk\"",
    "mtime": "2025-04-13T20:04:28.601Z",
    "size": 19123,
    "path": "../public/app-assets/fonts/flag-icon-css/flags/4x3/mx.svg.br"
  },
  "/app-assets/fonts/flag-icon-css/flags/4x3/mx.svg.gz": {
    "type": "image/svg+xml",
    "encoding": "gzip",
    "etag": "\"5666-vwyTvCDkq3TIiHfSZt/6yG7DGC0\"",
    "mtime": "2025-04-13T20:04:28.601Z",
    "size": 22118,
    "path": "../public/app-assets/fonts/flag-icon-css/flags/4x3/mx.svg.gz"
  },
  "/app-assets/fonts/flag-icon-css/flags/4x3/my.svg": {
    "type": "image/svg+xml",
    "etag": "\"5f0-5nytTDUi7/zZdLcQK8FqSh4o8s0\"",
    "mtime": "2025-04-13T20:04:20.447Z",
    "size": 1520,
    "path": "../public/app-assets/fonts/flag-icon-css/flags/4x3/my.svg"
  },
  "/app-assets/fonts/flag-icon-css/flags/4x3/my.svg.br": {
    "type": "image/svg+xml",
    "encoding": "br",
    "etag": "\"21e-Xhdb1rZ9ZybHo0a+ZJha0GzlHdc\"",
    "mtime": "2025-04-13T20:04:28.553Z",
    "size": 542,
    "path": "../public/app-assets/fonts/flag-icon-css/flags/4x3/my.svg.br"
  },
  "/app-assets/fonts/flag-icon-css/flags/4x3/my.svg.gz": {
    "type": "image/svg+xml",
    "encoding": "gzip",
    "etag": "\"270-hqQLqo4S1etqgwfPnl1tmIXdEJE\"",
    "mtime": "2025-04-13T20:04:28.553Z",
    "size": 624,
    "path": "../public/app-assets/fonts/flag-icon-css/flags/4x3/my.svg.gz"
  },
  "/app-assets/fonts/flag-icon-css/flags/4x3/mz.svg": {
    "type": "image/svg+xml",
    "etag": "\"141b-FaGUdZ+aDSfOnxMOSzz+dsmX7f8\"",
    "mtime": "2025-04-13T20:04:20.448Z",
    "size": 5147,
    "path": "../public/app-assets/fonts/flag-icon-css/flags/4x3/mz.svg"
  },
  "/app-assets/fonts/flag-icon-css/flags/4x3/mz.svg.br": {
    "type": "image/svg+xml",
    "encoding": "br",
    "etag": "\"770-ECJzv84g001Fb1bwEwGFVVJudTw\"",
    "mtime": "2025-04-13T20:04:28.553Z",
    "size": 1904,
    "path": "../public/app-assets/fonts/flag-icon-css/flags/4x3/mz.svg.br"
  },
  "/app-assets/fonts/flag-icon-css/flags/4x3/mz.svg.gz": {
    "type": "image/svg+xml",
    "encoding": "gzip",
    "etag": "\"856-9V4ok0mU+dFj8xnjX2dFOsffxCs\"",
    "mtime": "2025-04-13T20:04:28.553Z",
    "size": 2134,
    "path": "../public/app-assets/fonts/flag-icon-css/flags/4x3/mz.svg.gz"
  },
  "/app-assets/fonts/flag-icon-css/flags/4x3/na.svg": {
    "type": "image/svg+xml",
    "etag": "\"ac1-0EO5pw3TaEBUJ9KYY9YPpn3Pl6s\"",
    "mtime": "2025-04-13T20:04:20.448Z",
    "size": 2753,
    "path": "../public/app-assets/fonts/flag-icon-css/flags/4x3/na.svg"
  },
  "/app-assets/fonts/flag-icon-css/flags/4x3/na.svg.br": {
    "type": "image/svg+xml",
    "encoding": "br",
    "etag": "\"42a-mNeQ/ro55oY44gd5YfKET2gjLYU\"",
    "mtime": "2025-04-13T20:04:28.553Z",
    "size": 1066,
    "path": "../public/app-assets/fonts/flag-icon-css/flags/4x3/na.svg.br"
  },
  "/app-assets/fonts/flag-icon-css/flags/4x3/na.svg.gz": {
    "type": "image/svg+xml",
    "encoding": "gzip",
    "etag": "\"4c3-FuqKe+RfEGXWL31tugILZrzdnTs\"",
    "mtime": "2025-04-13T20:04:28.553Z",
    "size": 1219,
    "path": "../public/app-assets/fonts/flag-icon-css/flags/4x3/na.svg.gz"
  },
  "/app-assets/fonts/flag-icon-css/flags/4x3/nc.svg": {
    "type": "image/svg+xml",
    "etag": "\"355-dkPKiBel9KVPLp5ojltUTUr25KQ\"",
    "mtime": "2025-04-13T20:04:20.450Z",
    "size": 853,
    "path": "../public/app-assets/fonts/flag-icon-css/flags/4x3/nc.svg"
  },
  "/app-assets/fonts/flag-icon-css/flags/4x3/ne.svg": {
    "type": "image/svg+xml",
    "etag": "\"10d-BDXTblD8OAPWRJOlB2NhZ+yR9AA\"",
    "mtime": "2025-04-13T20:04:20.449Z",
    "size": 269,
    "path": "../public/app-assets/fonts/flag-icon-css/flags/4x3/ne.svg"
  },
  "/app-assets/fonts/flag-icon-css/flags/4x3/nf.svg": {
    "type": "image/svg+xml",
    "etag": "\"3a11-gJ2CwrZgpLp6rk/Fh1Fo02UBUt4\"",
    "mtime": "2025-04-13T20:04:20.449Z",
    "size": 14865,
    "path": "../public/app-assets/fonts/flag-icon-css/flags/4x3/nf.svg"
  },
  "/app-assets/fonts/flag-icon-css/flags/4x3/nf.svg.br": {
    "type": "image/svg+xml",
    "encoding": "br",
    "etag": "\"1140-qBGDQcb+H7BQ2GOEz3yXi9IRjZo\"",
    "mtime": "2025-04-13T20:04:28.553Z",
    "size": 4416,
    "path": "../public/app-assets/fonts/flag-icon-css/flags/4x3/nf.svg.br"
  },
  "/app-assets/fonts/flag-icon-css/flags/4x3/nf.svg.gz": {
    "type": "image/svg+xml",
    "encoding": "gzip",
    "etag": "\"1317-prUkWM22rdLHf42GYQW/n4r+JvE\"",
    "mtime": "2025-04-13T20:04:28.553Z",
    "size": 4887,
    "path": "../public/app-assets/fonts/flag-icon-css/flags/4x3/nf.svg.gz"
  },
  "/app-assets/fonts/flag-icon-css/flags/4x3/ng.svg": {
    "type": "image/svg+xml",
    "etag": "\"3bd-FWMwYfD6E/D+bbpQxwDSBlYR2OA\"",
    "mtime": "2025-04-13T20:04:20.449Z",
    "size": 957,
    "path": "../public/app-assets/fonts/flag-icon-css/flags/4x3/ng.svg"
  },
  "/app-assets/fonts/flag-icon-css/flags/4x3/ni.svg": {
    "type": "image/svg+xml",
    "etag": "\"71aa-TdJypg9NFih0iOmKHa+h9OTbR3s\"",
    "mtime": "2025-04-13T20:04:20.449Z",
    "size": 29098,
    "path": "../public/app-assets/fonts/flag-icon-css/flags/4x3/ni.svg"
  },
  "/app-assets/fonts/flag-icon-css/flags/4x3/ni.svg.br": {
    "type": "image/svg+xml",
    "encoding": "br",
    "etag": "\"24bf-de/YCeibGNiMyIsYPJUrsUfNcYI\"",
    "mtime": "2025-04-13T20:04:28.553Z",
    "size": 9407,
    "path": "../public/app-assets/fonts/flag-icon-css/flags/4x3/ni.svg.br"
  },
  "/app-assets/fonts/flag-icon-css/flags/4x3/ni.svg.gz": {
    "type": "image/svg+xml",
    "encoding": "gzip",
    "etag": "\"2ae8-JO+5IUr9M6n7KhPt9uFTFiltf8c\"",
    "mtime": "2025-04-13T20:04:28.553Z",
    "size": 10984,
    "path": "../public/app-assets/fonts/flag-icon-css/flags/4x3/ni.svg.gz"
  },
  "/app-assets/fonts/flag-icon-css/flags/4x3/nl.svg": {
    "type": "image/svg+xml",
    "etag": "\"380-0FvgP+BpgaU03yzATGQesv69DlE\"",
    "mtime": "2025-04-13T20:04:20.448Z",
    "size": 896,
    "path": "../public/app-assets/fonts/flag-icon-css/flags/4x3/nl.svg"
  },
  "/app-assets/fonts/flag-icon-css/flags/4x3/no.svg": {
    "type": "image/svg+xml",
    "etag": "\"13a-TRJfLCDSXdiSEZ/goj6wQnAb8Gw\"",
    "mtime": "2025-04-13T20:04:20.450Z",
    "size": 314,
    "path": "../public/app-assets/fonts/flag-icon-css/flags/4x3/no.svg"
  },
  "/app-assets/fonts/flag-icon-css/flags/4x3/np.svg": {
    "type": "image/svg+xml",
    "etag": "\"ad0-/LSp8xBjfL+yVT+NavA99AUCHnI\"",
    "mtime": "2025-04-13T20:04:20.449Z",
    "size": 2768,
    "path": "../public/app-assets/fonts/flag-icon-css/flags/4x3/np.svg"
  },
  "/app-assets/fonts/flag-icon-css/flags/4x3/np.svg.br": {
    "type": "image/svg+xml",
    "encoding": "br",
    "etag": "\"47d-53cVA2rflox9L2GICQejdnTxGP4\"",
    "mtime": "2025-04-13T20:04:28.554Z",
    "size": 1149,
    "path": "../public/app-assets/fonts/flag-icon-css/flags/4x3/np.svg.br"
  },
  "/app-assets/fonts/flag-icon-css/flags/4x3/np.svg.gz": {
    "type": "image/svg+xml",
    "encoding": "gzip",
    "etag": "\"547-bcvjEdz6vY/tAbQeOLfSeo21rmw\"",
    "mtime": "2025-04-13T20:04:28.554Z",
    "size": 1351,
    "path": "../public/app-assets/fonts/flag-icon-css/flags/4x3/np.svg.gz"
  },
  "/app-assets/fonts/flag-icon-css/flags/4x3/nr.svg": {
    "type": "image/svg+xml",
    "etag": "\"7a4-KN7lMi2oBINKO9jyhyv1zOJmaEw\"",
    "mtime": "2025-04-13T20:04:20.449Z",
    "size": 1956,
    "path": "../public/app-assets/fonts/flag-icon-css/flags/4x3/nr.svg"
  },
  "/app-assets/fonts/flag-icon-css/flags/4x3/nr.svg.br": {
    "type": "image/svg+xml",
    "encoding": "br",
    "etag": "\"344-dql44VxlVbI9lxuZvcs1v3nJKWI\"",
    "mtime": "2025-04-13T20:04:28.554Z",
    "size": 836,
    "path": "../public/app-assets/fonts/flag-icon-css/flags/4x3/nr.svg.br"
  },
  "/app-assets/fonts/flag-icon-css/flags/4x3/nr.svg.gz": {
    "type": "image/svg+xml",
    "encoding": "gzip",
    "etag": "\"3d7-zw37m5KCLT4gHMdSgoHo5WKzvUM\"",
    "mtime": "2025-04-13T20:04:28.554Z",
    "size": 983,
    "path": "../public/app-assets/fonts/flag-icon-css/flags/4x3/nr.svg.gz"
  },
  "/app-assets/fonts/flag-icon-css/flags/4x3/nu.svg": {
    "type": "image/svg+xml",
    "etag": "\"f9c-3BYsXKScsQT2DVrWJ+XCArkmExg\"",
    "mtime": "2025-04-13T20:04:20.449Z",
    "size": 3996,
    "path": "../public/app-assets/fonts/flag-icon-css/flags/4x3/nu.svg"
  },
  "/app-assets/fonts/flag-icon-css/flags/4x3/nu.svg.br": {
    "type": "image/svg+xml",
    "encoding": "br",
    "etag": "\"4b2-6SbxB7k3sY2CmprwhryLhXyJ4jI\"",
    "mtime": "2025-04-13T20:04:28.553Z",
    "size": 1202,
    "path": "../public/app-assets/fonts/flag-icon-css/flags/4x3/nu.svg.br"
  },
  "/app-assets/fonts/flag-icon-css/flags/4x3/nu.svg.gz": {
    "type": "image/svg+xml",
    "encoding": "gzip",
    "etag": "\"54d-8sEP03G4CbPl+V6ntyt7dGmRKh0\"",
    "mtime": "2025-04-13T20:04:28.553Z",
    "size": 1357,
    "path": "../public/app-assets/fonts/flag-icon-css/flags/4x3/nu.svg.gz"
  },
  "/app-assets/fonts/flag-icon-css/flags/4x3/nz.svg": {
    "type": "image/svg+xml",
    "etag": "\"15dd-rm8yaOnkufN8ubIzl6QyX0Hc55g\"",
    "mtime": "2025-04-13T20:04:20.449Z",
    "size": 5597,
    "path": "../public/app-assets/fonts/flag-icon-css/flags/4x3/nz.svg"
  },
  "/app-assets/fonts/flag-icon-css/flags/4x3/nz.svg.br": {
    "type": "image/svg+xml",
    "encoding": "br",
    "etag": "\"45b-UsCkfaW0yAsGHPMC+uuk5xHZqzM\"",
    "mtime": "2025-04-13T20:04:28.554Z",
    "size": 1115,
    "path": "../public/app-assets/fonts/flag-icon-css/flags/4x3/nz.svg.br"
  },
  "/app-assets/fonts/flag-icon-css/flags/4x3/nz.svg.gz": {
    "type": "image/svg+xml",
    "encoding": "gzip",
    "etag": "\"518-zisEpjYFXKv4q9FgfpQ8Vt4ZqPc\"",
    "mtime": "2025-04-13T20:04:28.553Z",
    "size": 1304,
    "path": "../public/app-assets/fonts/flag-icon-css/flags/4x3/nz.svg.gz"
  },
  "/app-assets/fonts/flag-icon-css/flags/4x3/om.svg": {
    "type": "image/svg+xml",
    "etag": "\"cee2-D6Nmj2Kg1eFVx0kYyl3M17Eh0Q8\"",
    "mtime": "2025-04-13T20:04:20.450Z",
    "size": 52962,
    "path": "../public/app-assets/fonts/flag-icon-css/flags/4x3/om.svg"
  },
  "/app-assets/fonts/flag-icon-css/flags/4x3/om.svg.br": {
    "type": "image/svg+xml",
    "encoding": "br",
    "etag": "\"1907-9HC1kmudU+RrYpChD31dPlBbEvw\"",
    "mtime": "2025-04-13T20:04:28.554Z",
    "size": 6407,
    "path": "../public/app-assets/fonts/flag-icon-css/flags/4x3/om.svg.br"
  },
  "/app-assets/fonts/flag-icon-css/flags/4x3/om.svg.gz": {
    "type": "image/svg+xml",
    "encoding": "gzip",
    "etag": "\"1e6a-0vHT4mVToPXKI/HSGsDq6q/zAas\"",
    "mtime": "2025-04-13T20:04:28.554Z",
    "size": 7786,
    "path": "../public/app-assets/fonts/flag-icon-css/flags/4x3/om.svg.gz"
  },
  "/app-assets/fonts/flag-icon-css/flags/4x3/pa.svg": {
    "type": "image/svg+xml",
    "etag": "\"69d-HSNV7WbKfG1bb6C7R6KcnSi7z+Y\"",
    "mtime": "2025-04-13T20:04:20.451Z",
    "size": 1693,
    "path": "../public/app-assets/fonts/flag-icon-css/flags/4x3/pa.svg"
  },
  "/app-assets/fonts/flag-icon-css/flags/4x3/pa.svg.br": {
    "type": "image/svg+xml",
    "encoding": "br",
    "etag": "\"29b-78VLWIZ6C74g+mv6qCwM4XHMbT0\"",
    "mtime": "2025-04-13T20:04:28.554Z",
    "size": 667,
    "path": "../public/app-assets/fonts/flag-icon-css/flags/4x3/pa.svg.br"
  },
  "/app-assets/fonts/flag-icon-css/flags/4x3/pa.svg.gz": {
    "type": "image/svg+xml",
    "encoding": "gzip",
    "etag": "\"30d-SuPlaTJU5aDqTTjuY5JuL66ovYY\"",
    "mtime": "2025-04-13T20:04:28.554Z",
    "size": 781,
    "path": "../public/app-assets/fonts/flag-icon-css/flags/4x3/pa.svg.gz"
  },
  "/app-assets/fonts/flag-icon-css/flags/4x3/pe.svg": {
    "type": "image/svg+xml",
    "etag": "\"392-8MCllDe/Op0x6awx/52V5/kQyyk\"",
    "mtime": "2025-04-13T20:04:20.450Z",
    "size": 914,
    "path": "../public/app-assets/fonts/flag-icon-css/flags/4x3/pe.svg"
  },
  "/app-assets/fonts/flag-icon-css/flags/4x3/pf.svg": {
    "type": "image/svg+xml",
    "etag": "\"2a20-LYyheP/weQjFMgyTyStjehryfi4\"",
    "mtime": "2025-04-13T20:04:20.449Z",
    "size": 10784,
    "path": "../public/app-assets/fonts/flag-icon-css/flags/4x3/pf.svg"
  },
  "/app-assets/fonts/flag-icon-css/flags/4x3/pf.svg.br": {
    "type": "image/svg+xml",
    "encoding": "br",
    "etag": "\"b74-v10jIFUHB2a/fAKFS+DFt7hj74I\"",
    "mtime": "2025-04-13T20:04:28.554Z",
    "size": 2932,
    "path": "../public/app-assets/fonts/flag-icon-css/flags/4x3/pf.svg.br"
  },
  "/app-assets/fonts/flag-icon-css/flags/4x3/pf.svg.gz": {
    "type": "image/svg+xml",
    "encoding": "gzip",
    "etag": "\"d5c-5Aavt+ZY00lzQYJD2UNGfY6cFac\"",
    "mtime": "2025-04-13T20:04:28.554Z",
    "size": 3420,
    "path": "../public/app-assets/fonts/flag-icon-css/flags/4x3/pf.svg.gz"
  },
  "/app-assets/fonts/flag-icon-css/flags/4x3/pg.svg": {
    "type": "image/svg+xml",
    "etag": "\"1133-pTbtEGIADm2yiS3Svvb0UpHSdKI\"",
    "mtime": "2025-04-13T20:04:20.451Z",
    "size": 4403,
    "path": "../public/app-assets/fonts/flag-icon-css/flags/4x3/pg.svg"
  },
  "/app-assets/fonts/flag-icon-css/flags/4x3/pg.svg.br": {
    "type": "image/svg+xml",
    "encoding": "br",
    "etag": "\"718-ftQtxXbr6y9eMLtrXSR6Gm1n8jo\"",
    "mtime": "2025-04-13T20:04:28.554Z",
    "size": 1816,
    "path": "../public/app-assets/fonts/flag-icon-css/flags/4x3/pg.svg.br"
  },
  "/app-assets/fonts/flag-icon-css/flags/4x3/pg.svg.gz": {
    "type": "image/svg+xml",
    "encoding": "gzip",
    "etag": "\"7fa-eZSIAEN5O2N7gK9+oJ7jSUNnK8E\"",
    "mtime": "2025-04-13T20:04:28.554Z",
    "size": 2042,
    "path": "../public/app-assets/fonts/flag-icon-css/flags/4x3/pg.svg.gz"
  },
  "/app-assets/fonts/flag-icon-css/flags/4x3/ph.svg": {
    "type": "image/svg+xml",
    "etag": "\"11bd-I4bYdY0GbdzaGnrliPwE+wmVTwg\"",
    "mtime": "2025-04-13T20:04:20.454Z",
    "size": 4541,
    "path": "../public/app-assets/fonts/flag-icon-css/flags/4x3/ph.svg"
  },
  "/app-assets/fonts/flag-icon-css/flags/4x3/ph.svg.br": {
    "type": "image/svg+xml",
    "encoding": "br",
    "etag": "\"6a9-S0Dv/ucvb5e/QuNMCrXD8NXf4c8\"",
    "mtime": "2025-04-13T20:04:28.554Z",
    "size": 1705,
    "path": "../public/app-assets/fonts/flag-icon-css/flags/4x3/ph.svg.br"
  },
  "/app-assets/fonts/flag-icon-css/flags/4x3/ph.svg.gz": {
    "type": "image/svg+xml",
    "encoding": "gzip",
    "etag": "\"7c8-W03hWuSX7hytseHYSJka2qoQ2zA\"",
    "mtime": "2025-04-13T20:04:28.554Z",
    "size": 1992,
    "path": "../public/app-assets/fonts/flag-icon-css/flags/4x3/ph.svg.gz"
  },
  "/app-assets/fonts/flag-icon-css/flags/4x3/pk.svg": {
    "type": "image/svg+xml",
    "etag": "\"644-FyRqdXzjIPiuVRidoGLVETAUq14\"",
    "mtime": "2025-04-13T20:04:20.450Z",
    "size": 1604,
    "path": "../public/app-assets/fonts/flag-icon-css/flags/4x3/pk.svg"
  },
  "/app-assets/fonts/flag-icon-css/flags/4x3/pk.svg.br": {
    "type": "image/svg+xml",
    "encoding": "br",
    "etag": "\"2df-nTm9PFl0SRuLCrAxmC1WoBtY4Xg\"",
    "mtime": "2025-04-13T20:04:28.554Z",
    "size": 735,
    "path": "../public/app-assets/fonts/flag-icon-css/flags/4x3/pk.svg.br"
  },
  "/app-assets/fonts/flag-icon-css/flags/4x3/pk.svg.gz": {
    "type": "image/svg+xml",
    "encoding": "gzip",
    "etag": "\"357-AJNrCO0dYx34sSPtADYXK59Dweg\"",
    "mtime": "2025-04-13T20:04:28.554Z",
    "size": 855,
    "path": "../public/app-assets/fonts/flag-icon-css/flags/4x3/pk.svg.gz"
  },
  "/app-assets/fonts/flag-icon-css/flags/4x3/pl.svg": {
    "type": "image/svg+xml",
    "etag": "\"32d-V8JotpbzBixKS3OdWwi7lntJyxY\"",
    "mtime": "2025-04-13T20:04:20.450Z",
    "size": 813,
    "path": "../public/app-assets/fonts/flag-icon-css/flags/4x3/pl.svg"
  },
  "/app-assets/fonts/flag-icon-css/flags/4x3/pm.svg": {
    "type": "image/svg+xml",
    "etag": "\"358-/okmVkITqv/xowV7fh7yTr7nmeo\"",
    "mtime": "2025-04-13T20:04:20.450Z",
    "size": 856,
    "path": "../public/app-assets/fonts/flag-icon-css/flags/4x3/pm.svg"
  },
  "/app-assets/fonts/flag-icon-css/flags/4x3/pn.svg": {
    "type": "image/svg+xml",
    "etag": "\"633c-8RYsb/BfSeYpRb1ZAEnrP7AuN+o\"",
    "mtime": "2025-04-13T20:04:20.450Z",
    "size": 25404,
    "path": "../public/app-assets/fonts/flag-icon-css/flags/4x3/pn.svg"
  },
  "/app-assets/fonts/flag-icon-css/flags/4x3/pn.svg.br": {
    "type": "image/svg+xml",
    "encoding": "br",
    "etag": "\"1fed-oWAUoyjz5aTgtX4Sg15GtyHwH+M\"",
    "mtime": "2025-04-13T20:04:28.554Z",
    "size": 8173,
    "path": "../public/app-assets/fonts/flag-icon-css/flags/4x3/pn.svg.br"
  },
  "/app-assets/fonts/flag-icon-css/flags/4x3/pn.svg.gz": {
    "type": "image/svg+xml",
    "encoding": "gzip",
    "etag": "\"23d5-CY6t3ubwCNIenWCL4600lFMeylE\"",
    "mtime": "2025-04-13T20:04:28.554Z",
    "size": 9173,
    "path": "../public/app-assets/fonts/flag-icon-css/flags/4x3/pn.svg.gz"
  },
  "/app-assets/fonts/flag-icon-css/flags/4x3/pr.svg": {
    "type": "image/svg+xml",
    "etag": "\"5e5-GTAgkANfASGLzOOg6IDeVByAfS4\"",
    "mtime": "2025-04-13T20:04:20.451Z",
    "size": 1509,
    "path": "../public/app-assets/fonts/flag-icon-css/flags/4x3/pr.svg"
  },
  "/app-assets/fonts/flag-icon-css/flags/4x3/pr.svg.br": {
    "type": "image/svg+xml",
    "encoding": "br",
    "etag": "\"26b-VcfYwPigSS0WGWUILbTdMWye27E\"",
    "mtime": "2025-04-13T20:04:28.554Z",
    "size": 619,
    "path": "../public/app-assets/fonts/flag-icon-css/flags/4x3/pr.svg.br"
  },
  "/app-assets/fonts/flag-icon-css/flags/4x3/pr.svg.gz": {
    "type": "image/svg+xml",
    "encoding": "gzip",
    "etag": "\"2ce-TvN0ehC687lsE9sEfj0Z7L4WaIM\"",
    "mtime": "2025-04-13T20:04:28.554Z",
    "size": 718,
    "path": "../public/app-assets/fonts/flag-icon-css/flags/4x3/pr.svg.gz"
  },
  "/app-assets/fonts/flag-icon-css/flags/4x3/ps.svg": {
    "type": "image/svg+xml",
    "etag": "\"4bc-b1IYOTJEbHHKiELOrAL5iVfFQSE\"",
    "mtime": "2025-04-13T20:04:20.452Z",
    "size": 1212,
    "path": "../public/app-assets/fonts/flag-icon-css/flags/4x3/ps.svg"
  },
  "/app-assets/fonts/flag-icon-css/flags/4x3/ps.svg.br": {
    "type": "image/svg+xml",
    "encoding": "br",
    "etag": "\"20a-gxT4HWRGcF+qckIbrcGqNjdA0Cg\"",
    "mtime": "2025-04-13T20:04:28.554Z",
    "size": 522,
    "path": "../public/app-assets/fonts/flag-icon-css/flags/4x3/ps.svg.br"
  },
  "/app-assets/fonts/flag-icon-css/flags/4x3/ps.svg.gz": {
    "type": "image/svg+xml",
    "encoding": "gzip",
    "etag": "\"265-M9DYFx09vbU+w9lJahJG06GDUoY\"",
    "mtime": "2025-04-13T20:04:28.554Z",
    "size": 613,
    "path": "../public/app-assets/fonts/flag-icon-css/flags/4x3/ps.svg.gz"
  },
  "/app-assets/fonts/flag-icon-css/flags/4x3/pt.svg": {
    "type": "image/svg+xml",
    "etag": "\"3091-tFDBOMj+1LkoUBSGplejv22LGc4\"",
    "mtime": "2025-04-13T20:04:20.450Z",
    "size": 12433,
    "path": "../public/app-assets/fonts/flag-icon-css/flags/4x3/pt.svg"
  },
  "/app-assets/fonts/flag-icon-css/flags/4x3/pt.svg.br": {
    "type": "image/svg+xml",
    "encoding": "br",
    "etag": "\"1196-LCOg16groqOXNonCcg5qcnLIoVc\"",
    "mtime": "2025-04-13T20:04:28.554Z",
    "size": 4502,
    "path": "../public/app-assets/fonts/flag-icon-css/flags/4x3/pt.svg.br"
  },
  "/app-assets/fonts/flag-icon-css/flags/4x3/pt.svg.gz": {
    "type": "image/svg+xml",
    "encoding": "gzip",
    "etag": "\"1432-EHtj+Jc8DNKmD6GzAsS9Qn+y5ig\"",
    "mtime": "2025-04-13T20:04:28.554Z",
    "size": 5170,
    "path": "../public/app-assets/fonts/flag-icon-css/flags/4x3/pt.svg.gz"
  },
  "/app-assets/fonts/flag-icon-css/flags/4x3/pw.svg": {
    "type": "image/svg+xml",
    "etag": "\"457-PYaXLRdJrDTLUMYNPFPA1ZrTgxs\"",
    "mtime": "2025-04-13T20:04:20.452Z",
    "size": 1111,
    "path": "../public/app-assets/fonts/flag-icon-css/flags/4x3/pw.svg"
  },
  "/app-assets/fonts/flag-icon-css/flags/4x3/pw.svg.br": {
    "type": "image/svg+xml",
    "encoding": "br",
    "etag": "\"1fb-vW6F+K3WEOKnzSKsq3fKAWrgv/8\"",
    "mtime": "2025-04-13T20:04:28.554Z",
    "size": 507,
    "path": "../public/app-assets/fonts/flag-icon-css/flags/4x3/pw.svg.br"
  },
  "/app-assets/fonts/flag-icon-css/flags/4x3/pw.svg.gz": {
    "type": "image/svg+xml",
    "encoding": "gzip",
    "etag": "\"253-E6az8XgigfTQ3zYhi7scyTrV7Ao\"",
    "mtime": "2025-04-13T20:04:28.554Z",
    "size": 595,
    "path": "../public/app-assets/fonts/flag-icon-css/flags/4x3/pw.svg.gz"
  },
  "/app-assets/fonts/flag-icon-css/flags/4x3/py.svg": {
    "type": "image/svg+xml",
    "etag": "\"78c4-WtjnXlkUsNcKzN9rnxL/2wmzJE8\"",
    "mtime": "2025-04-13T20:04:20.453Z",
    "size": 30916,
    "path": "../public/app-assets/fonts/flag-icon-css/flags/4x3/py.svg"
  },
  "/app-assets/fonts/flag-icon-css/flags/4x3/py.svg.br": {
    "type": "image/svg+xml",
    "encoding": "br",
    "etag": "\"256b-kFrpVzZt39LW/xBzqOZZFk/4VdQ\"",
    "mtime": "2025-04-13T20:04:28.554Z",
    "size": 9579,
    "path": "../public/app-assets/fonts/flag-icon-css/flags/4x3/py.svg.br"
  },
  "/app-assets/fonts/flag-icon-css/flags/4x3/py.svg.gz": {
    "type": "image/svg+xml",
    "encoding": "gzip",
    "etag": "\"2bfe-SGuuya7KrSnwYALuNojh8gDb3Jk\"",
    "mtime": "2025-04-13T20:04:28.554Z",
    "size": 11262,
    "path": "../public/app-assets/fonts/flag-icon-css/flags/4x3/py.svg.gz"
  },
  "/app-assets/fonts/flag-icon-css/flags/4x3/qa.svg": {
    "type": "image/svg+xml",
    "etag": "\"4f9-efc4wNmDMtzqdiXVfldOoCv/c5c\"",
    "mtime": "2025-04-13T20:04:20.452Z",
    "size": 1273,
    "path": "../public/app-assets/fonts/flag-icon-css/flags/4x3/qa.svg"
  },
  "/app-assets/fonts/flag-icon-css/flags/4x3/qa.svg.br": {
    "type": "image/svg+xml",
    "encoding": "br",
    "etag": "\"213-/5yEenU1s1WJ08aHvHxUZN1kwWA\"",
    "mtime": "2025-04-13T20:04:28.554Z",
    "size": 531,
    "path": "../public/app-assets/fonts/flag-icon-css/flags/4x3/qa.svg.br"
  },
  "/app-assets/fonts/flag-icon-css/flags/4x3/qa.svg.gz": {
    "type": "image/svg+xml",
    "encoding": "gzip",
    "etag": "\"271-hHYXBp8YCsOYdaXABYkjrBpn7iA\"",
    "mtime": "2025-04-13T20:04:28.554Z",
    "size": 625,
    "path": "../public/app-assets/fonts/flag-icon-css/flags/4x3/qa.svg.gz"
  },
  "/app-assets/fonts/flag-icon-css/flags/4x3/re.svg": {
    "type": "image/svg+xml",
    "etag": "\"358-gSKGbcIqj4goVR69tsLQEafPgJE\"",
    "mtime": "2025-04-13T20:04:20.451Z",
    "size": 856,
    "path": "../public/app-assets/fonts/flag-icon-css/flags/4x3/re.svg"
  },
  "/app-assets/fonts/flag-icon-css/flags/4x3/ro.svg": {
    "type": "image/svg+xml",
    "etag": "\"36b-aVAAqillh3XbzDcsnbD226V7fqI\"",
    "mtime": "2025-04-13T20:04:20.451Z",
    "size": 875,
    "path": "../public/app-assets/fonts/flag-icon-css/flags/4x3/ro.svg"
  },
  "/app-assets/fonts/flag-icon-css/flags/4x3/rs.svg": {
    "type": "image/svg+xml",
    "etag": "\"d5bf8-kXtYV0xIPjEvchFAbyG5XRP9i/M\"",
    "mtime": "2025-04-13T20:04:20.452Z",
    "size": 875512,
    "path": "../public/app-assets/fonts/flag-icon-css/flags/4x3/rs.svg"
  },
  "/app-assets/fonts/flag-icon-css/flags/4x3/rs.svg.br": {
    "type": "image/svg+xml",
    "encoding": "br",
    "etag": "\"319fb-+NN2Ve1HuSu9voHW4vvLmpCO11Y\"",
    "mtime": "2025-04-13T20:04:28.807Z",
    "size": 203259,
    "path": "../public/app-assets/fonts/flag-icon-css/flags/4x3/rs.svg.br"
  },
  "/app-assets/fonts/flag-icon-css/flags/4x3/rs.svg.gz": {
    "type": "image/svg+xml",
    "encoding": "gzip",
    "etag": "\"3fcb5-U7WK9xTj+zKE2yZEHHHUYSibbAg\"",
    "mtime": "2025-04-13T20:04:28.815Z",
    "size": 261301,
    "path": "../public/app-assets/fonts/flag-icon-css/flags/4x3/rs.svg.gz"
  },
  "/app-assets/fonts/flag-icon-css/flags/4x3/ru.svg": {
    "type": "image/svg+xml",
    "etag": "\"36f-1ghk6oY1rhrHroAo/xt5j8NtFk8\"",
    "mtime": "2025-04-13T20:04:20.451Z",
    "size": 879,
    "path": "../public/app-assets/fonts/flag-icon-css/flags/4x3/ru.svg"
  },
  "/app-assets/fonts/flag-icon-css/flags/4x3/rw.svg": {
    "type": "image/svg+xml",
    "etag": "\"304-YHZ9RBXXrvOULeTtI3HU3CIc4IQ\"",
    "mtime": "2025-04-13T20:04:20.452Z",
    "size": 772,
    "path": "../public/app-assets/fonts/flag-icon-css/flags/4x3/rw.svg"
  },
  "/app-assets/fonts/flag-icon-css/flags/4x3/sa.svg": {
    "type": "image/svg+xml",
    "etag": "\"5448-WdtMjgjqvGoR1AlYfWv4Kr8qRas\"",
    "mtime": "2025-04-13T20:04:20.451Z",
    "size": 21576,
    "path": "../public/app-assets/fonts/flag-icon-css/flags/4x3/sa.svg"
  },
  "/app-assets/fonts/flag-icon-css/flags/4x3/sa.svg.br": {
    "type": "image/svg+xml",
    "encoding": "br",
    "etag": "\"1f6a-+s9GL1Ry7bPbCxbfhe4wyhaOX5k\"",
    "mtime": "2025-04-13T20:04:28.555Z",
    "size": 8042,
    "path": "../public/app-assets/fonts/flag-icon-css/flags/4x3/sa.svg.br"
  },
  "/app-assets/fonts/flag-icon-css/flags/4x3/sa.svg.gz": {
    "type": "image/svg+xml",
    "encoding": "gzip",
    "etag": "\"23a1-Pzj6SNCJpkQpVtyuYIO2OykLXNw\"",
    "mtime": "2025-04-13T20:04:28.554Z",
    "size": 9121,
    "path": "../public/app-assets/fonts/flag-icon-css/flags/4x3/sa.svg.gz"
  },
  "/app-assets/fonts/flag-icon-css/flags/4x3/sb.svg": {
    "type": "image/svg+xml",
    "etag": "\"957-x0viTxCoTEzxL1gta0arCVhGajk\"",
    "mtime": "2025-04-13T20:04:20.453Z",
    "size": 2391,
    "path": "../public/app-assets/fonts/flag-icon-css/flags/4x3/sb.svg"
  },
  "/app-assets/fonts/flag-icon-css/flags/4x3/sb.svg.br": {
    "type": "image/svg+xml",
    "encoding": "br",
    "etag": "\"2aa-nicu6Cl7NSUHfn8TU3ARV39sDFE\"",
    "mtime": "2025-04-13T20:04:28.554Z",
    "size": 682,
    "path": "../public/app-assets/fonts/flag-icon-css/flags/4x3/sb.svg.br"
  },
  "/app-assets/fonts/flag-icon-css/flags/4x3/sb.svg.gz": {
    "type": "image/svg+xml",
    "encoding": "gzip",
    "etag": "\"314-/7ZnHqeL2a4od6Z9vH0jBWxAdNs\"",
    "mtime": "2025-04-13T20:04:28.554Z",
    "size": 788,
    "path": "../public/app-assets/fonts/flag-icon-css/flags/4x3/sb.svg.gz"
  },
  "/app-assets/fonts/flag-icon-css/flags/4x3/sc.svg": {
    "type": "image/svg+xml",
    "etag": "\"4e9-p/xra+dfOIqXufmliMeQf+aN1JY\"",
    "mtime": "2025-04-13T20:04:20.452Z",
    "size": 1257,
    "path": "../public/app-assets/fonts/flag-icon-css/flags/4x3/sc.svg"
  },
  "/app-assets/fonts/flag-icon-css/flags/4x3/sc.svg.br": {
    "type": "image/svg+xml",
    "encoding": "br",
    "etag": "\"217-cIpzzwmAANusdjsAYluRZHEJERU\"",
    "mtime": "2025-04-13T20:04:28.554Z",
    "size": 535,
    "path": "../public/app-assets/fonts/flag-icon-css/flags/4x3/sc.svg.br"
  },
  "/app-assets/fonts/flag-icon-css/flags/4x3/sc.svg.gz": {
    "type": "image/svg+xml",
    "encoding": "gzip",
    "etag": "\"272-9DzbUX8ITMbpbLuc6WHzJ5JH95A\"",
    "mtime": "2025-04-13T20:04:28.554Z",
    "size": 626,
    "path": "../public/app-assets/fonts/flag-icon-css/flags/4x3/sc.svg.gz"
  },
  "/app-assets/fonts/flag-icon-css/flags/4x3/sd.svg": {
    "type": "image/svg+xml",
    "etag": "\"498-66+kPnCh30SdXezeSDcrEaQ8tpE\"",
    "mtime": "2025-04-13T20:04:20.452Z",
    "size": 1176,
    "path": "../public/app-assets/fonts/flag-icon-css/flags/4x3/sd.svg"
  },
  "/app-assets/fonts/flag-icon-css/flags/4x3/sd.svg.br": {
    "type": "image/svg+xml",
    "encoding": "br",
    "etag": "\"1f7-pTuh+WcZ1c5ASQxIr3k9ISWcmB4\"",
    "mtime": "2025-04-13T20:04:28.554Z",
    "size": 503,
    "path": "../public/app-assets/fonts/flag-icon-css/flags/4x3/sd.svg.br"
  },
  "/app-assets/fonts/flag-icon-css/flags/4x3/sd.svg.gz": {
    "type": "image/svg+xml",
    "encoding": "gzip",
    "etag": "\"253-r+s5S869uFkYGBcJSIZskM/0G3E\"",
    "mtime": "2025-04-13T20:04:28.554Z",
    "size": 595,
    "path": "../public/app-assets/fonts/flag-icon-css/flags/4x3/sd.svg.gz"
  },
  "/app-assets/fonts/flag-icon-css/flags/4x3/se.svg": {
    "type": "image/svg+xml",
    "etag": "\"60b-8e+HzWvAOxR/ggl7GmpbbdSdqXs\"",
    "mtime": "2025-04-13T20:04:20.452Z",
    "size": 1547,
    "path": "../public/app-assets/fonts/flag-icon-css/flags/4x3/se.svg"
  },
  "/app-assets/fonts/flag-icon-css/flags/4x3/se.svg.br": {
    "type": "image/svg+xml",
    "encoding": "br",
    "etag": "\"237-NI5SCf5DNN1mxxmuX2HV3c6kN4I\"",
    "mtime": "2025-04-13T20:04:28.554Z",
    "size": 567,
    "path": "../public/app-assets/fonts/flag-icon-css/flags/4x3/se.svg.br"
  },
  "/app-assets/fonts/flag-icon-css/flags/4x3/se.svg.gz": {
    "type": "image/svg+xml",
    "encoding": "gzip",
    "etag": "\"29a-+m8VHc2xxiPR2QqDyJML0enCrwc\"",
    "mtime": "2025-04-13T20:04:28.554Z",
    "size": 666,
    "path": "../public/app-assets/fonts/flag-icon-css/flags/4x3/se.svg.gz"
  },
  "/app-assets/fonts/flag-icon-css/flags/4x3/sg.svg": {
    "type": "image/svg+xml",
    "etag": "\"ab6-HdDh+Q1xeX54LMRdt8PmPq0WmuA\"",
    "mtime": "2025-04-13T20:04:20.452Z",
    "size": 2742,
    "path": "../public/app-assets/fonts/flag-icon-css/flags/4x3/sg.svg"
  },
  "/app-assets/fonts/flag-icon-css/flags/4x3/sg.svg.br": {
    "type": "image/svg+xml",
    "encoding": "br",
    "etag": "\"2e5-uc0Vc5agiEgeJw2fAINtGKKfJMw\"",
    "mtime": "2025-04-13T20:04:28.554Z",
    "size": 741,
    "path": "../public/app-assets/fonts/flag-icon-css/flags/4x3/sg.svg.br"
  },
  "/app-assets/fonts/flag-icon-css/flags/4x3/sg.svg.gz": {
    "type": "image/svg+xml",
    "encoding": "gzip",
    "etag": "\"36f-rovW4CD2AC9f4xFLEwv367mbED0\"",
    "mtime": "2025-04-13T20:04:28.554Z",
    "size": 879,
    "path": "../public/app-assets/fonts/flag-icon-css/flags/4x3/sg.svg.gz"
  },
  "/app-assets/fonts/flag-icon-css/flags/4x3/sh.svg": {
    "type": "image/svg+xml",
    "etag": "\"133fd-a8irnu8O9uH8MDHIRm+DX1N5MsI\"",
    "mtime": "2025-04-13T20:04:20.454Z",
    "size": 78845,
    "path": "../public/app-assets/fonts/flag-icon-css/flags/4x3/sh.svg"
  },
  "/app-assets/fonts/flag-icon-css/flags/4x3/sh.svg.br": {
    "type": "image/svg+xml",
    "encoding": "br",
    "etag": "\"4603-++7KwKM8beBTnaeXAcyDokoriQo\"",
    "mtime": "2025-04-13T20:04:28.613Z",
    "size": 17923,
    "path": "../public/app-assets/fonts/flag-icon-css/flags/4x3/sh.svg.br"
  },
  "/app-assets/fonts/flag-icon-css/flags/4x3/sh.svg.gz": {
    "type": "image/svg+xml",
    "encoding": "gzip",
    "etag": "\"51be-nY9kYBNSIrtyw4hxo2HkMj8CeJU\"",
    "mtime": "2025-04-13T20:04:28.602Z",
    "size": 20926,
    "path": "../public/app-assets/fonts/flag-icon-css/flags/4x3/sh.svg.gz"
  },
  "/app-assets/fonts/flag-icon-css/flags/4x3/si.svg": {
    "type": "image/svg+xml",
    "etag": "\"fe2-WAMGrKbwQGr2zD8aWa8vGZIHdh0\"",
    "mtime": "2025-04-13T20:04:20.455Z",
    "size": 4066,
    "path": "../public/app-assets/fonts/flag-icon-css/flags/4x3/si.svg"
  },
  "/app-assets/fonts/flag-icon-css/flags/4x3/si.svg.br": {
    "type": "image/svg+xml",
    "encoding": "br",
    "etag": "\"54c-nvgqDF0eZdcI9RjhOFFeeIQHs1c\"",
    "mtime": "2025-04-13T20:04:28.555Z",
    "size": 1356,
    "path": "../public/app-assets/fonts/flag-icon-css/flags/4x3/si.svg.br"
  },
  "/app-assets/fonts/flag-icon-css/flags/4x3/si.svg.gz": {
    "type": "image/svg+xml",
    "encoding": "gzip",
    "etag": "\"64a-OTQOykXtulcuDnirYUXscKYtlkQ\"",
    "mtime": "2025-04-13T20:04:28.554Z",
    "size": 1610,
    "path": "../public/app-assets/fonts/flag-icon-css/flags/4x3/si.svg.gz"
  },
  "/app-assets/fonts/flag-icon-css/flags/4x3/sj.svg": {
    "type": "image/svg+xml",
    "etag": "\"716-Q+N8SNdJR26dvVqMN6KQld9ceTY\"",
    "mtime": "2025-04-13T20:04:20.452Z",
    "size": 1814,
    "path": "../public/app-assets/fonts/flag-icon-css/flags/4x3/sj.svg"
  },
  "/app-assets/fonts/flag-icon-css/flags/4x3/sj.svg.br": {
    "type": "image/svg+xml",
    "encoding": "br",
    "etag": "\"25c-eU1agqHAH05lzE876XhK52Eapx8\"",
    "mtime": "2025-04-13T20:04:28.554Z",
    "size": 604,
    "path": "../public/app-assets/fonts/flag-icon-css/flags/4x3/sj.svg.br"
  },
  "/app-assets/fonts/flag-icon-css/flags/4x3/sj.svg.gz": {
    "type": "image/svg+xml",
    "encoding": "gzip",
    "etag": "\"2d1-Ga7TGBxp2B4dbid3dCGek/wlV44\"",
    "mtime": "2025-04-13T20:04:28.554Z",
    "size": 721,
    "path": "../public/app-assets/fonts/flag-icon-css/flags/4x3/sj.svg.gz"
  },
  "/app-assets/fonts/flag-icon-css/flags/4x3/sk.svg": {
    "type": "image/svg+xml",
    "etag": "\"913-n6/6jhTfEUFewmDepZ6DJ1sDchc\"",
    "mtime": "2025-04-13T20:04:20.453Z",
    "size": 2323,
    "path": "../public/app-assets/fonts/flag-icon-css/flags/4x3/sk.svg"
  },
  "/app-assets/fonts/flag-icon-css/flags/4x3/sk.svg.br": {
    "type": "image/svg+xml",
    "encoding": "br",
    "etag": "\"400-OHfXrdJuEsT8n0xXuET0R6Q0POk\"",
    "mtime": "2025-04-13T20:04:28.554Z",
    "size": 1024,
    "path": "../public/app-assets/fonts/flag-icon-css/flags/4x3/sk.svg.br"
  },
  "/app-assets/fonts/flag-icon-css/flags/4x3/sk.svg.gz": {
    "type": "image/svg+xml",
    "encoding": "gzip",
    "etag": "\"486-rC978zRqRg9+5waOmF10ZOHDIQ8\"",
    "mtime": "2025-04-13T20:04:28.554Z",
    "size": 1158,
    "path": "../public/app-assets/fonts/flag-icon-css/flags/4x3/sk.svg.gz"
  },
  "/app-assets/fonts/flag-icon-css/flags/4x3/sl.svg": {
    "type": "image/svg+xml",
    "etag": "\"384-kb0ErBzzkUcUo472lqkdSk4iGjw\"",
    "mtime": "2025-04-13T20:04:20.454Z",
    "size": 900,
    "path": "../public/app-assets/fonts/flag-icon-css/flags/4x3/sl.svg"
  },
  "/app-assets/fonts/flag-icon-css/flags/4x3/sm.svg": {
    "type": "image/svg+xml",
    "etag": "\"8ed2-r5vauWTdGM5r5vkVBDP54Fekbxc\"",
    "mtime": "2025-04-13T20:04:20.453Z",
    "size": 36562,
    "path": "../public/app-assets/fonts/flag-icon-css/flags/4x3/sm.svg"
  },
  "/app-assets/fonts/flag-icon-css/flags/4x3/sm.svg.br": {
    "type": "image/svg+xml",
    "encoding": "br",
    "etag": "\"1c76-6jILwxqHpoQbRohCmUc3l5m/GA8\"",
    "mtime": "2025-04-13T20:04:28.555Z",
    "size": 7286,
    "path": "../public/app-assets/fonts/flag-icon-css/flags/4x3/sm.svg.br"
  },
  "/app-assets/fonts/flag-icon-css/flags/4x3/sm.svg.gz": {
    "type": "image/svg+xml",
    "encoding": "gzip",
    "etag": "\"2172-z9RCBhiIjK0TUt8xTG5SRArX7bY\"",
    "mtime": "2025-04-13T20:04:28.555Z",
    "size": 8562,
    "path": "../public/app-assets/fonts/flag-icon-css/flags/4x3/sm.svg.gz"
  },
  "/app-assets/fonts/flag-icon-css/flags/4x3/sn.svg": {
    "type": "image/svg+xml",
    "etag": "\"461-FOR7XHgazlytJ1GZNgHbT3w6jI4\"",
    "mtime": "2025-04-13T20:04:20.453Z",
    "size": 1121,
    "path": "../public/app-assets/fonts/flag-icon-css/flags/4x3/sn.svg"
  },
  "/app-assets/fonts/flag-icon-css/flags/4x3/sn.svg.br": {
    "type": "image/svg+xml",
    "encoding": "br",
    "etag": "\"1ea-odAotXr6vVXktr0JuzAqy7i4Hqc\"",
    "mtime": "2025-04-13T20:04:28.555Z",
    "size": 490,
    "path": "../public/app-assets/fonts/flag-icon-css/flags/4x3/sn.svg.br"
  },
  "/app-assets/fonts/flag-icon-css/flags/4x3/sn.svg.gz": {
    "type": "image/svg+xml",
    "encoding": "gzip",
    "etag": "\"23b-iLOKiF8mM9uNcKV52b0aLREbHt8\"",
    "mtime": "2025-04-13T20:04:28.555Z",
    "size": 571,
    "path": "../public/app-assets/fonts/flag-icon-css/flags/4x3/sn.svg.gz"
  },
  "/app-assets/fonts/flag-icon-css/flags/4x3/so.svg": {
    "type": "image/svg+xml",
    "etag": "\"499-Hu1O5kL9EeywBQHryJbNb8qNf0E\"",
    "mtime": "2025-04-13T20:04:20.456Z",
    "size": 1177,
    "path": "../public/app-assets/fonts/flag-icon-css/flags/4x3/so.svg"
  },
  "/app-assets/fonts/flag-icon-css/flags/4x3/so.svg.br": {
    "type": "image/svg+xml",
    "encoding": "br",
    "etag": "\"232-FqgKyG/SX5zLfUvIckhTFzg0sHM\"",
    "mtime": "2025-04-13T20:04:28.555Z",
    "size": 562,
    "path": "../public/app-assets/fonts/flag-icon-css/flags/4x3/so.svg.br"
  },
  "/app-assets/fonts/flag-icon-css/flags/4x3/so.svg.gz": {
    "type": "image/svg+xml",
    "encoding": "gzip",
    "etag": "\"28c-VlhRD7F2Xn5ouDwoUerTgVLYNgU\"",
    "mtime": "2025-04-13T20:04:28.555Z",
    "size": 652,
    "path": "../public/app-assets/fonts/flag-icon-css/flags/4x3/so.svg.gz"
  },
  "/app-assets/fonts/flag-icon-css/flags/4x3/sr.svg": {
    "type": "image/svg+xml",
    "etag": "\"13d-DwnfQeAsxEcUc5hFEwwJJY69ey4\"",
    "mtime": "2025-04-13T20:04:20.454Z",
    "size": 317,
    "path": "../public/app-assets/fonts/flag-icon-css/flags/4x3/sr.svg"
  },
  "/app-assets/fonts/flag-icon-css/flags/4x3/ss.svg": {
    "type": "image/svg+xml",
    "etag": "\"4d2-+J4fceSAzeNeVilE3SuGDtqLpcg\"",
    "mtime": "2025-04-13T20:04:20.452Z",
    "size": 1234,
    "path": "../public/app-assets/fonts/flag-icon-css/flags/4x3/ss.svg"
  },
  "/app-assets/fonts/flag-icon-css/flags/4x3/ss.svg.br": {
    "type": "image/svg+xml",
    "encoding": "br",
    "etag": "\"1f8-r8+8JT4MmUKjTkXcATGRNqHSiM0\"",
    "mtime": "2025-04-13T20:04:28.555Z",
    "size": 504,
    "path": "../public/app-assets/fonts/flag-icon-css/flags/4x3/ss.svg.br"
  },
  "/app-assets/fonts/flag-icon-css/flags/4x3/ss.svg.gz": {
    "type": "image/svg+xml",
    "encoding": "gzip",
    "etag": "\"24f-W3qpk8L6kwmq/tbwezi6VBP1yRs\"",
    "mtime": "2025-04-13T20:04:28.555Z",
    "size": 591,
    "path": "../public/app-assets/fonts/flag-icon-css/flags/4x3/ss.svg.gz"
  },
  "/app-assets/fonts/flag-icon-css/flags/4x3/st.svg": {
    "type": "image/svg+xml",
    "etag": "\"74d-W1sS9ahgqeCN9xQvNSeKPnrEy/k\"",
    "mtime": "2025-04-13T20:04:20.453Z",
    "size": 1869,
    "path": "../public/app-assets/fonts/flag-icon-css/flags/4x3/st.svg"
  },
  "/app-assets/fonts/flag-icon-css/flags/4x3/st.svg.br": {
    "type": "image/svg+xml",
    "encoding": "br",
    "etag": "\"2ab-9x9QpKrl9kILWp64Ol2G6+YH/tE\"",
    "mtime": "2025-04-13T20:04:28.555Z",
    "size": 683,
    "path": "../public/app-assets/fonts/flag-icon-css/flags/4x3/st.svg.br"
  },
  "/app-assets/fonts/flag-icon-css/flags/4x3/st.svg.gz": {
    "type": "image/svg+xml",
    "encoding": "gzip",
    "etag": "\"321-IYy7Y6omNvbOzVSo5VOgXF8m6t4\"",
    "mtime": "2025-04-13T20:04:28.555Z",
    "size": 801,
    "path": "../public/app-assets/fonts/flag-icon-css/flags/4x3/st.svg.gz"
  },
  "/app-assets/fonts/flag-icon-css/flags/4x3/sv.svg": {
    "type": "image/svg+xml",
    "etag": "\"21801-JfDpRqbmyQVnFMdu2r7tJpj2Z0w\"",
    "mtime": "2025-04-13T20:04:20.453Z",
    "size": 137217,
    "path": "../public/app-assets/fonts/flag-icon-css/flags/4x3/sv.svg"
  },
  "/app-assets/fonts/flag-icon-css/flags/4x3/sv.svg.br": {
    "type": "image/svg+xml",
    "encoding": "br",
    "etag": "\"9170-kpMbiE216Y0F+It9YxSGuF7j4L8\"",
    "mtime": "2025-04-13T20:04:28.667Z",
    "size": 37232,
    "path": "../public/app-assets/fonts/flag-icon-css/flags/4x3/sv.svg.br"
  },
  "/app-assets/fonts/flag-icon-css/flags/4x3/sv.svg.gz": {
    "type": "image/svg+xml",
    "encoding": "gzip",
    "etag": "\"a6d7-gDdDfxOhADQibeNDNIbGtzfOIXE\"",
    "mtime": "2025-04-13T20:04:28.667Z",
    "size": 42711,
    "path": "../public/app-assets/fonts/flag-icon-css/flags/4x3/sv.svg.gz"
  },
  "/app-assets/fonts/flag-icon-css/flags/4x3/sx.svg": {
    "type": "image/svg+xml",
    "etag": "\"6d72-BH1VklMBOPynAVOP02JBHxLkSZM\"",
    "mtime": "2025-04-13T20:04:20.453Z",
    "size": 28018,
    "path": "../public/app-assets/fonts/flag-icon-css/flags/4x3/sx.svg"
  },
  "/app-assets/fonts/flag-icon-css/flags/4x3/sx.svg.br": {
    "type": "image/svg+xml",
    "encoding": "br",
    "etag": "\"20de-nrbjz9eHStUEh4iXQZKQ3N8lrQk\"",
    "mtime": "2025-04-13T20:04:28.555Z",
    "size": 8414,
    "path": "../public/app-assets/fonts/flag-icon-css/flags/4x3/sx.svg.br"
  },
  "/app-assets/fonts/flag-icon-css/flags/4x3/sx.svg.gz": {
    "type": "image/svg+xml",
    "encoding": "gzip",
    "etag": "\"24fe-dqTqnh4P5nAnM3S+zzVgk50wakQ\"",
    "mtime": "2025-04-13T20:04:28.555Z",
    "size": 9470,
    "path": "../public/app-assets/fonts/flag-icon-css/flags/4x3/sx.svg.gz"
  },
  "/app-assets/fonts/flag-icon-css/flags/4x3/sy.svg": {
    "type": "image/svg+xml",
    "etag": "\"758-jl6iIdN6Lx0iG5+OyYoeb82jXl0\"",
    "mtime": "2025-04-13T20:04:20.453Z",
    "size": 1880,
    "path": "../public/app-assets/fonts/flag-icon-css/flags/4x3/sy.svg"
  },
  "/app-assets/fonts/flag-icon-css/flags/4x3/sy.svg.br": {
    "type": "image/svg+xml",
    "encoding": "br",
    "etag": "\"21a-KcV1+d/zWf9XjymtgEEmgRMnhjM\"",
    "mtime": "2025-04-13T20:04:28.555Z",
    "size": 538,
    "path": "../public/app-assets/fonts/flag-icon-css/flags/4x3/sy.svg.br"
  },
  "/app-assets/fonts/flag-icon-css/flags/4x3/sy.svg.gz": {
    "type": "image/svg+xml",
    "encoding": "gzip",
    "etag": "\"26f-J/+HD7gurGJsa2PaWiM3UpAIAaM\"",
    "mtime": "2025-04-13T20:04:28.555Z",
    "size": 623,
    "path": "../public/app-assets/fonts/flag-icon-css/flags/4x3/sy.svg.gz"
  },
  "/app-assets/fonts/flag-icon-css/flags/4x3/sz.svg": {
    "type": "image/svg+xml",
    "etag": "\"352d-pgfLFOyzo6Kltp+nYgXbzfNbsiQ\"",
    "mtime": "2025-04-13T20:04:20.454Z",
    "size": 13613,
    "path": "../public/app-assets/fonts/flag-icon-css/flags/4x3/sz.svg"
  },
  "/app-assets/fonts/flag-icon-css/flags/4x3/sz.svg.br": {
    "type": "image/svg+xml",
    "encoding": "br",
    "etag": "\"aac-A0GXu6DlfMe+9SmsgnKEZGeaG6Q\"",
    "mtime": "2025-04-13T20:04:28.555Z",
    "size": 2732,
    "path": "../public/app-assets/fonts/flag-icon-css/flags/4x3/sz.svg.br"
  },
  "/app-assets/fonts/flag-icon-css/flags/4x3/sz.svg.gz": {
    "type": "image/svg+xml",
    "encoding": "gzip",
    "etag": "\"c95-+F1YYjkm2sBcz1JnzG9f5OsD8mE\"",
    "mtime": "2025-04-13T20:04:28.555Z",
    "size": 3221,
    "path": "../public/app-assets/fonts/flag-icon-css/flags/4x3/sz.svg.gz"
  },
  "/app-assets/fonts/flag-icon-css/flags/4x3/tc.svg": {
    "type": "image/svg+xml",
    "etag": "\"599c-EKOBLqseBfzC/uoUvN6BGQW9iok\"",
    "mtime": "2025-04-13T20:04:20.453Z",
    "size": 22940,
    "path": "../public/app-assets/fonts/flag-icon-css/flags/4x3/tc.svg"
  },
  "/app-assets/fonts/flag-icon-css/flags/4x3/tc.svg.br": {
    "type": "image/svg+xml",
    "encoding": "br",
    "etag": "\"12d6-4K8+CXmPpaRiBRVhLaVgouBLvCg\"",
    "mtime": "2025-04-13T20:04:28.555Z",
    "size": 4822,
    "path": "../public/app-assets/fonts/flag-icon-css/flags/4x3/tc.svg.br"
  },
  "/app-assets/fonts/flag-icon-css/flags/4x3/tc.svg.gz": {
    "type": "image/svg+xml",
    "encoding": "gzip",
    "etag": "\"1580-yk2Ras3p3ORezsHA2u+LN5lGtFM\"",
    "mtime": "2025-04-13T20:04:28.555Z",
    "size": 5504,
    "path": "../public/app-assets/fonts/flag-icon-css/flags/4x3/tc.svg.gz"
  },
  "/app-assets/fonts/flag-icon-css/flags/4x3/td.svg": {
    "type": "image/svg+xml",
    "etag": "\"34b-wU0sxGb23c5K/0BusMk3qagIdjA\"",
    "mtime": "2025-04-13T20:04:20.454Z",
    "size": 843,
    "path": "../public/app-assets/fonts/flag-icon-css/flags/4x3/td.svg"
  },
  "/app-assets/fonts/flag-icon-css/flags/4x3/tf.svg": {
    "type": "image/svg+xml",
    "etag": "\"454-IZ8c10OTXnAWWfjA8P5txE3NqPM\"",
    "mtime": "2025-04-13T20:04:20.454Z",
    "size": 1108,
    "path": "../public/app-assets/fonts/flag-icon-css/flags/4x3/tf.svg"
  },
  "/app-assets/fonts/flag-icon-css/flags/4x3/tf.svg.br": {
    "type": "image/svg+xml",
    "encoding": "br",
    "etag": "\"18e-DD0Zby+j5GusqvbshfpvvAv0yWU\"",
    "mtime": "2025-04-13T20:04:28.555Z",
    "size": 398,
    "path": "../public/app-assets/fonts/flag-icon-css/flags/4x3/tf.svg.br"
  },
  "/app-assets/fonts/flag-icon-css/flags/4x3/tf.svg.gz": {
    "type": "image/svg+xml",
    "encoding": "gzip",
    "etag": "\"1c5-FhNBV0HQMfgVMGfOrQYPp7uP7Ak\"",
    "mtime": "2025-04-13T20:04:28.555Z",
    "size": 453,
    "path": "../public/app-assets/fonts/flag-icon-css/flags/4x3/tf.svg.gz"
  },
  "/app-assets/fonts/flag-icon-css/flags/4x3/tg.svg": {
    "type": "image/svg+xml",
    "etag": "\"69c-P75S35wfq3ZrK6T/rCR22DBlC3I\"",
    "mtime": "2025-04-13T20:04:20.455Z",
    "size": 1692,
    "path": "../public/app-assets/fonts/flag-icon-css/flags/4x3/tg.svg"
  },
  "/app-assets/fonts/flag-icon-css/flags/4x3/tg.svg.br": {
    "type": "image/svg+xml",
    "encoding": "br",
    "etag": "\"281-dMTiScFeh+d+2wu3pICSufXSviU\"",
    "mtime": "2025-04-13T20:04:28.555Z",
    "size": 641,
    "path": "../public/app-assets/fonts/flag-icon-css/flags/4x3/tg.svg.br"
  },
  "/app-assets/fonts/flag-icon-css/flags/4x3/tg.svg.gz": {
    "type": "image/svg+xml",
    "encoding": "gzip",
    "etag": "\"2ec-xMb5s+YaK8LZxx9qTMgv4cbtYy4\"",
    "mtime": "2025-04-13T20:04:28.555Z",
    "size": 748,
    "path": "../public/app-assets/fonts/flag-icon-css/flags/4x3/tg.svg.gz"
  },
  "/app-assets/fonts/flag-icon-css/flags/4x3/th.svg": {
    "type": "image/svg+xml",
    "etag": "\"3a9-EjO/JWqflJRndzNX8gXy1S5aWC4\"",
    "mtime": "2025-04-13T20:04:20.455Z",
    "size": 937,
    "path": "../public/app-assets/fonts/flag-icon-css/flags/4x3/th.svg"
  },
  "/app-assets/fonts/flag-icon-css/flags/4x3/tj.svg": {
    "type": "image/svg+xml",
    "etag": "\"13c2-37NJ1fAti4NzYliKUBbo5PyK3GQ\"",
    "mtime": "2025-04-13T20:04:20.455Z",
    "size": 5058,
    "path": "../public/app-assets/fonts/flag-icon-css/flags/4x3/tj.svg"
  },
  "/app-assets/fonts/flag-icon-css/flags/4x3/tj.svg.br": {
    "type": "image/svg+xml",
    "encoding": "br",
    "etag": "\"593-fudlxPUjVQb4/yxbD8M+Wuku2PY\"",
    "mtime": "2025-04-13T20:04:28.555Z",
    "size": 1427,
    "path": "../public/app-assets/fonts/flag-icon-css/flags/4x3/tj.svg.br"
  },
  "/app-assets/fonts/flag-icon-css/flags/4x3/tj.svg.gz": {
    "type": "image/svg+xml",
    "encoding": "gzip",
    "etag": "\"667-qJSoXVgZYe+U5NW3VRIPSCKQZ2I\"",
    "mtime": "2025-04-13T20:04:28.555Z",
    "size": 1639,
    "path": "../public/app-assets/fonts/flag-icon-css/flags/4x3/tj.svg.gz"
  },
  "/app-assets/fonts/flag-icon-css/flags/4x3/tk.svg": {
    "type": "image/svg+xml",
    "etag": "\"665-ZFpNDK8zHUsL52MMf3Wsz+Yas6E\"",
    "mtime": "2025-04-13T20:04:20.455Z",
    "size": 1637,
    "path": "../public/app-assets/fonts/flag-icon-css/flags/4x3/tk.svg"
  },
  "/app-assets/fonts/flag-icon-css/flags/4x3/tk.svg.br": {
    "type": "image/svg+xml",
    "encoding": "br",
    "etag": "\"2b5-T6xg8OAXBM/vLXuxYsQrojP94Jw\"",
    "mtime": "2025-04-13T20:04:28.555Z",
    "size": 693,
    "path": "../public/app-assets/fonts/flag-icon-css/flags/4x3/tk.svg.br"
  },
  "/app-assets/fonts/flag-icon-css/flags/4x3/tk.svg.gz": {
    "type": "image/svg+xml",
    "encoding": "gzip",
    "etag": "\"344-NiTYqnt3rPnoV7bQvck8FHcUZiM\"",
    "mtime": "2025-04-13T20:04:28.555Z",
    "size": 836,
    "path": "../public/app-assets/fonts/flag-icon-css/flags/4x3/tk.svg.gz"
  },
  "/app-assets/fonts/flag-icon-css/flags/4x3/tl.svg": {
    "type": "image/svg+xml",
    "etag": "\"53b-20+wJCXWPnRkRnth++dcK80PqkM\"",
    "mtime": "2025-04-13T20:04:20.456Z",
    "size": 1339,
    "path": "../public/app-assets/fonts/flag-icon-css/flags/4x3/tl.svg"
  },
  "/app-assets/fonts/flag-icon-css/flags/4x3/tl.svg.br": {
    "type": "image/svg+xml",
    "encoding": "br",
    "etag": "\"25d-j5WHEk9SrM2kNgbLNiPLWRTXsWc\"",
    "mtime": "2025-04-13T20:04:28.555Z",
    "size": 605,
    "path": "../public/app-assets/fonts/flag-icon-css/flags/4x3/tl.svg.br"
  },
  "/app-assets/fonts/flag-icon-css/flags/4x3/tl.svg.gz": {
    "type": "image/svg+xml",
    "encoding": "gzip",
    "etag": "\"2c0-KTIRWeUkY/rPBNto6z+IyQbFMZA\"",
    "mtime": "2025-04-13T20:04:28.555Z",
    "size": 704,
    "path": "../public/app-assets/fonts/flag-icon-css/flags/4x3/tl.svg.gz"
  },
  "/app-assets/fonts/flag-icon-css/flags/4x3/tm.svg": {
    "type": "image/svg+xml",
    "etag": "\"12161-lqTuS1CUQbzumm4InsSF3/cR/yE\"",
    "mtime": "2025-04-13T20:04:20.455Z",
    "size": 74081,
    "path": "../public/app-assets/fonts/flag-icon-css/flags/4x3/tm.svg"
  },
  "/app-assets/fonts/flag-icon-css/flags/4x3/tm.svg.br": {
    "type": "image/svg+xml",
    "encoding": "br",
    "etag": "\"1a9e-i8OM0Sty0yqEYPCRB6EYyoih3QA\"",
    "mtime": "2025-04-13T20:04:28.555Z",
    "size": 6814,
    "path": "../public/app-assets/fonts/flag-icon-css/flags/4x3/tm.svg.br"
  },
  "/app-assets/fonts/flag-icon-css/flags/4x3/tm.svg.gz": {
    "type": "image/svg+xml",
    "encoding": "gzip",
    "etag": "\"1fe7-P+TGTW4/bQxUptCa5NtrMRi+UjM\"",
    "mtime": "2025-04-13T20:04:28.555Z",
    "size": 8167,
    "path": "../public/app-assets/fonts/flag-icon-css/flags/4x3/tm.svg.gz"
  },
  "/app-assets/fonts/flag-icon-css/flags/4x3/tn.svg": {
    "type": "image/svg+xml",
    "etag": "\"79c-b4AoB1oXQL7+zNbEe/6UGaGvUvc\"",
    "mtime": "2025-04-13T20:04:20.454Z",
    "size": 1948,
    "path": "../public/app-assets/fonts/flag-icon-css/flags/4x3/tn.svg"
  },
  "/app-assets/fonts/flag-icon-css/flags/4x3/tn.svg.br": {
    "type": "image/svg+xml",
    "encoding": "br",
    "etag": "\"35b-Y1bxNKyQ16GFytrZSM7kjuoQypw\"",
    "mtime": "2025-04-13T20:04:28.555Z",
    "size": 859,
    "path": "../public/app-assets/fonts/flag-icon-css/flags/4x3/tn.svg.br"
  },
  "/app-assets/fonts/flag-icon-css/flags/4x3/tn.svg.gz": {
    "type": "image/svg+xml",
    "encoding": "gzip",
    "etag": "\"3d0-+SfJSdCXoDbNmOo8YLFcEhHE8/w\"",
    "mtime": "2025-04-13T20:04:28.555Z",
    "size": 976,
    "path": "../public/app-assets/fonts/flag-icon-css/flags/4x3/tn.svg.gz"
  },
  "/app-assets/fonts/flag-icon-css/flags/4x3/to.svg": {
    "type": "image/svg+xml",
    "etag": "\"435-MkO+HULXM/ARVGuWO1Q5QFmxysM\"",
    "mtime": "2025-04-13T20:04:20.456Z",
    "size": 1077,
    "path": "../public/app-assets/fonts/flag-icon-css/flags/4x3/to.svg"
  },
  "/app-assets/fonts/flag-icon-css/flags/4x3/to.svg.br": {
    "type": "image/svg+xml",
    "encoding": "br",
    "etag": "\"1c8-m6sGQ3UUZWKy4zyAt24eCXdxRwA\"",
    "mtime": "2025-04-13T20:04:28.555Z",
    "size": 456,
    "path": "../public/app-assets/fonts/flag-icon-css/flags/4x3/to.svg.br"
  },
  "/app-assets/fonts/flag-icon-css/flags/4x3/to.svg.gz": {
    "type": "image/svg+xml",
    "encoding": "gzip",
    "etag": "\"21b-8nUuD/Gbs2ikVwbzMxXzKTNkf18\"",
    "mtime": "2025-04-13T20:04:28.555Z",
    "size": 539,
    "path": "../public/app-assets/fonts/flag-icon-css/flags/4x3/to.svg.gz"
  },
  "/app-assets/fonts/flag-icon-css/flags/4x3/tr.svg": {
    "type": "image/svg+xml",
    "etag": "\"2d1-uomQEKEDcrokGVdOAlPZaBFYwFs\"",
    "mtime": "2025-04-13T20:04:20.456Z",
    "size": 721,
    "path": "../public/app-assets/fonts/flag-icon-css/flags/4x3/tr.svg"
  },
  "/app-assets/fonts/flag-icon-css/flags/4x3/tt.svg": {
    "type": "image/svg+xml",
    "etag": "\"416-uBTV12aGQg2bPTuOcA8d+8Sx/98\"",
    "mtime": "2025-04-13T20:04:20.455Z",
    "size": 1046,
    "path": "../public/app-assets/fonts/flag-icon-css/flags/4x3/tt.svg"
  },
  "/app-assets/fonts/flag-icon-css/flags/4x3/tt.svg.br": {
    "type": "image/svg+xml",
    "encoding": "br",
    "etag": "\"1d1-ezcq2PFqZMuKk/ODmDDThb5jtzQ\"",
    "mtime": "2025-04-13T20:04:28.555Z",
    "size": 465,
    "path": "../public/app-assets/fonts/flag-icon-css/flags/4x3/tt.svg.br"
  },
  "/app-assets/fonts/flag-icon-css/flags/4x3/tt.svg.gz": {
    "type": "image/svg+xml",
    "encoding": "gzip",
    "etag": "\"229-xvxM4g+htYjtciFn0Xw4VuN3ttg\"",
    "mtime": "2025-04-13T20:04:28.555Z",
    "size": 553,
    "path": "../public/app-assets/fonts/flag-icon-css/flags/4x3/tt.svg.gz"
  },
  "/app-assets/fonts/flag-icon-css/flags/4x3/tv.svg": {
    "type": "image/svg+xml",
    "etag": "\"1354-raYJwYtw4r/1BuTgWoYV2kVdtaY\"",
    "mtime": "2025-04-13T20:04:20.458Z",
    "size": 4948,
    "path": "../public/app-assets/fonts/flag-icon-css/flags/4x3/tv.svg"
  },
  "/app-assets/fonts/flag-icon-css/flags/4x3/tv.svg.br": {
    "type": "image/svg+xml",
    "encoding": "br",
    "etag": "\"4f3-jLmzzjOGUIapKPSMfgd/IMCgWT8\"",
    "mtime": "2025-04-13T20:04:28.555Z",
    "size": 1267,
    "path": "../public/app-assets/fonts/flag-icon-css/flags/4x3/tv.svg.br"
  },
  "/app-assets/fonts/flag-icon-css/flags/4x3/tv.svg.gz": {
    "type": "image/svg+xml",
    "encoding": "gzip",
    "etag": "\"5a1-7DeDlW5RXnN1H89b+Uoo5ccMW5A\"",
    "mtime": "2025-04-13T20:04:28.555Z",
    "size": 1441,
    "path": "../public/app-assets/fonts/flag-icon-css/flags/4x3/tv.svg.gz"
  },
  "/app-assets/fonts/flag-icon-css/flags/4x3/tw.svg": {
    "type": "image/svg+xml",
    "etag": "\"be5-7HDvN0ZZ1UVXYke61XvBV6Z4yHw\"",
    "mtime": "2025-04-13T20:04:20.455Z",
    "size": 3045,
    "path": "../public/app-assets/fonts/flag-icon-css/flags/4x3/tw.svg"
  },
  "/app-assets/fonts/flag-icon-css/flags/4x3/tw.svg.br": {
    "type": "image/svg+xml",
    "encoding": "br",
    "etag": "\"4af-2lgM4+q6bIW9HWYzs2sHfAYhPok\"",
    "mtime": "2025-04-13T20:04:28.555Z",
    "size": 1199,
    "path": "../public/app-assets/fonts/flag-icon-css/flags/4x3/tw.svg.br"
  },
  "/app-assets/fonts/flag-icon-css/flags/4x3/tw.svg.gz": {
    "type": "image/svg+xml",
    "encoding": "gzip",
    "etag": "\"575-aVex/rfELKn9MpvuM0wCh0pIur0\"",
    "mtime": "2025-04-13T20:04:28.555Z",
    "size": 1397,
    "path": "../public/app-assets/fonts/flag-icon-css/flags/4x3/tw.svg.gz"
  },
  "/app-assets/fonts/flag-icon-css/flags/4x3/tz.svg": {
    "type": "image/svg+xml",
    "etag": "\"4f3-rypnUM/VohhJSBQ3MH+i0wKwj3w\"",
    "mtime": "2025-04-13T20:04:20.456Z",
    "size": 1267,
    "path": "../public/app-assets/fonts/flag-icon-css/flags/4x3/tz.svg"
  },
  "/app-assets/fonts/flag-icon-css/flags/4x3/tz.svg.br": {
    "type": "image/svg+xml",
    "encoding": "br",
    "etag": "\"23b-fp/7bw5Jm/Ct1OoxGUIsixgvE0E\"",
    "mtime": "2025-04-13T20:04:28.555Z",
    "size": 571,
    "path": "../public/app-assets/fonts/flag-icon-css/flags/4x3/tz.svg.br"
  },
  "/app-assets/fonts/flag-icon-css/flags/4x3/tz.svg.gz": {
    "type": "image/svg+xml",
    "encoding": "gzip",
    "etag": "\"29a-NBn7AOZ7BvHzWXpulE5JfxcB99w\"",
    "mtime": "2025-04-13T20:04:28.555Z",
    "size": 666,
    "path": "../public/app-assets/fonts/flag-icon-css/flags/4x3/tz.svg.gz"
  },
  "/app-assets/fonts/flag-icon-css/flags/4x3/ua.svg": {
    "type": "image/svg+xml",
    "etag": "\"320-OnB46GTN+9YAyeZnTfQPGHH0c6U\"",
    "mtime": "2025-04-13T20:04:20.456Z",
    "size": 800,
    "path": "../public/app-assets/fonts/flag-icon-css/flags/4x3/ua.svg"
  },
  "/app-assets/fonts/flag-icon-css/flags/4x3/ug.svg": {
    "type": "image/svg+xml",
    "etag": "\"1abc-vgfcvEdVp9X22brTSJSb8dXSMXk\"",
    "mtime": "2025-04-13T20:04:20.456Z",
    "size": 6844,
    "path": "../public/app-assets/fonts/flag-icon-css/flags/4x3/ug.svg"
  },
  "/app-assets/fonts/flag-icon-css/flags/4x3/ug.svg.br": {
    "type": "image/svg+xml",
    "encoding": "br",
    "etag": "\"85a-4H5w665V+Rq1/iHNW51bcsAM2wY\"",
    "mtime": "2025-04-13T20:04:28.555Z",
    "size": 2138,
    "path": "../public/app-assets/fonts/flag-icon-css/flags/4x3/ug.svg.br"
  },
  "/app-assets/fonts/flag-icon-css/flags/4x3/ug.svg.gz": {
    "type": "image/svg+xml",
    "encoding": "gzip",
    "etag": "\"958-f1XzwA4ugUq7c0vfsIOy/qKEyNE\"",
    "mtime": "2025-04-13T20:04:28.555Z",
    "size": 2392,
    "path": "../public/app-assets/fonts/flag-icon-css/flags/4x3/ug.svg.gz"
  },
  "/app-assets/fonts/flag-icon-css/flags/4x3/um.svg": {
    "type": "image/svg+xml",
    "etag": "\"5bd9-HlqWh4uSlKHtkA1OITosztkJjNk\"",
    "mtime": "2025-04-13T20:04:20.455Z",
    "size": 23513,
    "path": "../public/app-assets/fonts/flag-icon-css/flags/4x3/um.svg"
  },
  "/app-assets/fonts/flag-icon-css/flags/4x3/um.svg.br": {
    "type": "image/svg+xml",
    "encoding": "br",
    "etag": "\"42e-9R5mFEGUNy8rgbPZsMzupuJpHNY\"",
    "mtime": "2025-04-13T20:04:28.555Z",
    "size": 1070,
    "path": "../public/app-assets/fonts/flag-icon-css/flags/4x3/um.svg.br"
  },
  "/app-assets/fonts/flag-icon-css/flags/4x3/um.svg.gz": {
    "type": "image/svg+xml",
    "encoding": "gzip",
    "etag": "\"578-jxJM/W4tVvj4apw9w+Ojy6HU/GY\"",
    "mtime": "2025-04-13T20:04:28.555Z",
    "size": 1400,
    "path": "../public/app-assets/fonts/flag-icon-css/flags/4x3/um.svg.gz"
  },
  "/app-assets/fonts/flag-icon-css/flags/4x3/us.svg": {
    "type": "image/svg+xml",
    "etag": "\"5be0-g/sBBzfL9ikqZUJwkZd1ENyiY8k\"",
    "mtime": "2025-04-13T20:04:20.456Z",
    "size": 23520,
    "path": "../public/app-assets/fonts/flag-icon-css/flags/4x3/us.svg"
  },
  "/app-assets/fonts/flag-icon-css/flags/4x3/us.svg.br": {
    "type": "image/svg+xml",
    "encoding": "br",
    "etag": "\"437-Wb+neb/Ze6ZB4JmZml/1axqrYyY\"",
    "mtime": "2025-04-13T20:04:28.555Z",
    "size": 1079,
    "path": "../public/app-assets/fonts/flag-icon-css/flags/4x3/us.svg.br"
  },
  "/app-assets/fonts/flag-icon-css/flags/4x3/us.svg.gz": {
    "type": "image/svg+xml",
    "encoding": "gzip",
    "etag": "\"57e-jkHpolqm7Huohe7SkMREYLIiEdc\"",
    "mtime": "2025-04-13T20:04:28.555Z",
    "size": 1406,
    "path": "../public/app-assets/fonts/flag-icon-css/flags/4x3/us.svg.gz"
  },
  "/app-assets/fonts/flag-icon-css/flags/4x3/uy.svg": {
    "type": "image/svg+xml",
    "etag": "\"2db7-QA5AHlozemojH4H3piJwI3ynvGk\"",
    "mtime": "2025-04-13T20:04:20.459Z",
    "size": 11703,
    "path": "../public/app-assets/fonts/flag-icon-css/flags/4x3/uy.svg"
  },
  "/app-assets/fonts/flag-icon-css/flags/4x3/uy.svg.br": {
    "type": "image/svg+xml",
    "encoding": "br",
    "etag": "\"6e4-kTWMBl1a/wzQ68zk/GlXT3BW6WU\"",
    "mtime": "2025-04-13T20:04:28.555Z",
    "size": 1764,
    "path": "../public/app-assets/fonts/flag-icon-css/flags/4x3/uy.svg.br"
  },
  "/app-assets/fonts/flag-icon-css/flags/4x3/uy.svg.gz": {
    "type": "image/svg+xml",
    "encoding": "gzip",
    "etag": "\"7f7-fWK8/7GtmBVHe48Hcvu0YPSS9DE\"",
    "mtime": "2025-04-13T20:04:28.555Z",
    "size": 2039,
    "path": "../public/app-assets/fonts/flag-icon-css/flags/4x3/uy.svg.gz"
  },
  "/app-assets/fonts/flag-icon-css/flags/4x3/uz.svg": {
    "type": "image/svg+xml",
    "etag": "\"5a3-JKlAuac3pSEEVEqs7psz8iFw5g0\"",
    "mtime": "2025-04-13T20:04:20.457Z",
    "size": 1443,
    "path": "../public/app-assets/fonts/flag-icon-css/flags/4x3/uz.svg"
  },
  "/app-assets/fonts/flag-icon-css/flags/4x3/uz.svg.br": {
    "type": "image/svg+xml",
    "encoding": "br",
    "etag": "\"17d-h/zLZp2um0+txS82+++7gnkhM+c\"",
    "mtime": "2025-04-13T20:04:28.555Z",
    "size": 381,
    "path": "../public/app-assets/fonts/flag-icon-css/flags/4x3/uz.svg.br"
  },
  "/app-assets/fonts/flag-icon-css/flags/4x3/uz.svg.gz": {
    "type": "image/svg+xml",
    "encoding": "gzip",
    "etag": "\"1ad-XkfzbO3sLaQ8bzPEk8YFz+YGLgw\"",
    "mtime": "2025-04-13T20:04:28.555Z",
    "size": 429,
    "path": "../public/app-assets/fonts/flag-icon-css/flags/4x3/uz.svg.gz"
  },
  "/app-assets/fonts/flag-icon-css/flags/4x3/va.svg": {
    "type": "image/svg+xml",
    "etag": "\"1e691-9y6p9UDVLe0/TRapBEOcJJSAXK4\"",
    "mtime": "2025-04-13T20:04:20.458Z",
    "size": 124561,
    "path": "../public/app-assets/fonts/flag-icon-css/flags/4x3/va.svg"
  },
  "/app-assets/fonts/flag-icon-css/flags/4x3/va.svg.br": {
    "type": "image/svg+xml",
    "encoding": "br",
    "etag": "\"21aa-BzWdVdWLekR4XvLv0yG31R7VNGg\"",
    "mtime": "2025-04-13T20:04:28.556Z",
    "size": 8618,
    "path": "../public/app-assets/fonts/flag-icon-css/flags/4x3/va.svg.br"
  },
  "/app-assets/fonts/flag-icon-css/flags/4x3/va.svg.gz": {
    "type": "image/svg+xml",
    "encoding": "gzip",
    "etag": "\"2d66-prKBvJA1r9c4jFYfSZoZwnpnb9U\"",
    "mtime": "2025-04-13T20:04:28.556Z",
    "size": 11622,
    "path": "../public/app-assets/fonts/flag-icon-css/flags/4x3/va.svg.gz"
  },
  "/app-assets/fonts/flag-icon-css/flags/4x3/vc.svg": {
    "type": "image/svg+xml",
    "etag": "\"4b3-oAhwcMgMdOp9/rIC/i6emwsn8hg\"",
    "mtime": "2025-04-13T20:04:20.456Z",
    "size": 1203,
    "path": "../public/app-assets/fonts/flag-icon-css/flags/4x3/vc.svg"
  },
  "/app-assets/fonts/flag-icon-css/flags/4x3/vc.svg.br": {
    "type": "image/svg+xml",
    "encoding": "br",
    "etag": "\"1bd-DCFEVjB/2MzEttU4ZGaCFL8+eo4\"",
    "mtime": "2025-04-13T20:04:28.555Z",
    "size": 445,
    "path": "../public/app-assets/fonts/flag-icon-css/flags/4x3/vc.svg.br"
  },
  "/app-assets/fonts/flag-icon-css/flags/4x3/vc.svg.gz": {
    "type": "image/svg+xml",
    "encoding": "gzip",
    "etag": "\"206-+8Jsb795xfPPfk2iEDPKZiQmBzc\"",
    "mtime": "2025-04-13T20:04:28.555Z",
    "size": 518,
    "path": "../public/app-assets/fonts/flag-icon-css/flags/4x3/vc.svg.gz"
  },
  "/app-assets/fonts/flag-icon-css/flags/4x3/ve.svg": {
    "type": "image/svg+xml",
    "etag": "\"4d2-nEoGEDn1wTuSbtuFL4qMSLkczfY\"",
    "mtime": "2025-04-13T20:04:20.457Z",
    "size": 1234,
    "path": "../public/app-assets/fonts/flag-icon-css/flags/4x3/ve.svg"
  },
  "/app-assets/fonts/flag-icon-css/flags/4x3/ve.svg.br": {
    "type": "image/svg+xml",
    "encoding": "br",
    "etag": "\"179-wA7MWErVg99DisU2rByAot0nWew\"",
    "mtime": "2025-04-13T20:04:28.555Z",
    "size": 377,
    "path": "../public/app-assets/fonts/flag-icon-css/flags/4x3/ve.svg.br"
  },
  "/app-assets/fonts/flag-icon-css/flags/4x3/ve.svg.gz": {
    "type": "image/svg+xml",
    "encoding": "gzip",
    "etag": "\"1ba-ceEjfXlASYOnfNdcdgRP5URwCRs\"",
    "mtime": "2025-04-13T20:04:28.555Z",
    "size": 442,
    "path": "../public/app-assets/fonts/flag-icon-css/flags/4x3/ve.svg.gz"
  },
  "/app-assets/fonts/flag-icon-css/flags/4x3/vg.svg": {
    "type": "image/svg+xml",
    "etag": "\"c473-5An+EfpFdEh+fcCSProHqnwGXbQ\"",
    "mtime": "2025-04-13T20:04:20.457Z",
    "size": 50291,
    "path": "../public/app-assets/fonts/flag-icon-css/flags/4x3/vg.svg"
  },
  "/app-assets/fonts/flag-icon-css/flags/4x3/vg.svg.br": {
    "type": "image/svg+xml",
    "encoding": "br",
    "etag": "\"22e6-spheWh0a3bLje80K7bsgRYHDJX4\"",
    "mtime": "2025-04-13T20:04:28.556Z",
    "size": 8934,
    "path": "../public/app-assets/fonts/flag-icon-css/flags/4x3/vg.svg.br"
  },
  "/app-assets/fonts/flag-icon-css/flags/4x3/vg.svg.gz": {
    "type": "image/svg+xml",
    "encoding": "gzip",
    "etag": "\"2941-PYW6a3S8F7EH6T+aCBBwrApub7g\"",
    "mtime": "2025-04-13T20:04:28.556Z",
    "size": 10561,
    "path": "../public/app-assets/fonts/flag-icon-css/flags/4x3/vg.svg.gz"
  },
  "/app-assets/fonts/flag-icon-css/flags/4x3/vi.svg": {
    "type": "image/svg+xml",
    "etag": "\"3131-ZWfHyUe6G9S/0YCTszkYR/19WEQ\"",
    "mtime": "2025-04-13T20:04:20.457Z",
    "size": 12593,
    "path": "../public/app-assets/fonts/flag-icon-css/flags/4x3/vi.svg"
  },
  "/app-assets/fonts/flag-icon-css/flags/4x3/vi.svg.br": {
    "type": "image/svg+xml",
    "encoding": "br",
    "etag": "\"12e3-coXiGH+fibQmyjyCVplozXXdKBE\"",
    "mtime": "2025-04-13T20:04:28.555Z",
    "size": 4835,
    "path": "../public/app-assets/fonts/flag-icon-css/flags/4x3/vi.svg.br"
  },
  "/app-assets/fonts/flag-icon-css/flags/4x3/vi.svg.gz": {
    "type": "image/svg+xml",
    "encoding": "gzip",
    "etag": "\"14f3-zRDCKVOBfZDelf9En0Md0+cywHA\"",
    "mtime": "2025-04-13T20:04:28.555Z",
    "size": 5363,
    "path": "../public/app-assets/fonts/flag-icon-css/flags/4x3/vi.svg.gz"
  },
  "/app-assets/fonts/flag-icon-css/flags/4x3/vn.svg": {
    "type": "image/svg+xml",
    "etag": "\"49c-1L2tmXbIUo91I1NMKbzC9rU0JGA\"",
    "mtime": "2025-04-13T20:04:20.456Z",
    "size": 1180,
    "path": "../public/app-assets/fonts/flag-icon-css/flags/4x3/vn.svg"
  },
  "/app-assets/fonts/flag-icon-css/flags/4x3/vn.svg.br": {
    "type": "image/svg+xml",
    "encoding": "br",
    "etag": "\"22d-LhAqBmQamgQ7uYTR1vMro/FZkG8\"",
    "mtime": "2025-04-13T20:04:28.555Z",
    "size": 557,
    "path": "../public/app-assets/fonts/flag-icon-css/flags/4x3/vn.svg.br"
  },
  "/app-assets/fonts/flag-icon-css/flags/4x3/vn.svg.gz": {
    "type": "image/svg+xml",
    "encoding": "gzip",
    "etag": "\"28e-dcJRpvGNNLJiQgvuziP92SIXleI\"",
    "mtime": "2025-04-13T20:04:28.555Z",
    "size": 654,
    "path": "../public/app-assets/fonts/flag-icon-css/flags/4x3/vn.svg.gz"
  },
  "/app-assets/fonts/flag-icon-css/flags/4x3/vu.svg": {
    "type": "image/svg+xml",
    "etag": "\"1b22-AmBqbT3jgOH3RtfsPbB1i+qBMow\"",
    "mtime": "2025-04-13T20:04:20.457Z",
    "size": 6946,
    "path": "../public/app-assets/fonts/flag-icon-css/flags/4x3/vu.svg"
  },
  "/app-assets/fonts/flag-icon-css/flags/4x3/vu.svg.br": {
    "type": "image/svg+xml",
    "encoding": "br",
    "etag": "\"73a-YoKwGzRJHsPBw+gWgXD06FldDN8\"",
    "mtime": "2025-04-13T20:04:28.555Z",
    "size": 1850,
    "path": "../public/app-assets/fonts/flag-icon-css/flags/4x3/vu.svg.br"
  },
  "/app-assets/fonts/flag-icon-css/flags/4x3/vu.svg.gz": {
    "type": "image/svg+xml",
    "encoding": "gzip",
    "etag": "\"83c-j5fvPc7HMSI1pv+cQ7yuv5P1+6A\"",
    "mtime": "2025-04-13T20:04:28.555Z",
    "size": 2108,
    "path": "../public/app-assets/fonts/flag-icon-css/flags/4x3/vu.svg.gz"
  },
  "/app-assets/fonts/flag-icon-css/flags/4x3/wf.svg": {
    "type": "image/svg+xml",
    "etag": "\"369-6nZwmH6lssZOeY9Yigd7+cAHMJo\"",
    "mtime": "2025-04-13T20:04:20.457Z",
    "size": 873,
    "path": "../public/app-assets/fonts/flag-icon-css/flags/4x3/wf.svg"
  },
  "/app-assets/fonts/flag-icon-css/flags/4x3/ws.svg": {
    "type": "image/svg+xml",
    "etag": "\"bd8-yGXvsdcl3D/HdCQ5VlroSY2ZIxY\"",
    "mtime": "2025-04-13T20:04:20.457Z",
    "size": 3032,
    "path": "../public/app-assets/fonts/flag-icon-css/flags/4x3/ws.svg"
  },
  "/app-assets/fonts/flag-icon-css/flags/4x3/ws.svg.br": {
    "type": "image/svg+xml",
    "encoding": "br",
    "etag": "\"4c1-oAWKRaSkQOfpdkW2Vv1G0HmIe8Y\"",
    "mtime": "2025-04-13T20:04:28.555Z",
    "size": 1217,
    "path": "../public/app-assets/fonts/flag-icon-css/flags/4x3/ws.svg.br"
  },
  "/app-assets/fonts/flag-icon-css/flags/4x3/ws.svg.gz": {
    "type": "image/svg+xml",
    "encoding": "gzip",
    "etag": "\"5b5-r09PnARpEWg914vdKY7CfiALHCw\"",
    "mtime": "2025-04-13T20:04:28.555Z",
    "size": 1461,
    "path": "../public/app-assets/fonts/flag-icon-css/flags/4x3/ws.svg.gz"
  },
  "/app-assets/fonts/flag-icon-css/flags/4x3/ye.svg": {
    "type": "image/svg+xml",
    "etag": "\"369-BZAICdyJNi2+AL8bP9iZrjgrfjo\"",
    "mtime": "2025-04-13T20:04:20.457Z",
    "size": 873,
    "path": "../public/app-assets/fonts/flag-icon-css/flags/4x3/ye.svg"
  },
  "/app-assets/fonts/flag-icon-css/flags/4x3/yt.svg": {
    "type": "image/svg+xml",
    "etag": "\"358-Bn2DSLaw5uJC/QJOHEgLaGRrSj8\"",
    "mtime": "2025-04-13T20:04:20.457Z",
    "size": 856,
    "path": "../public/app-assets/fonts/flag-icon-css/flags/4x3/yt.svg"
  },
  "/app-assets/fonts/flag-icon-css/flags/4x3/za.svg": {
    "type": "image/svg+xml",
    "etag": "\"6cd-L6fGh0H7QDbhb6iaTMXkkHqfdGQ\"",
    "mtime": "2025-04-13T20:04:20.457Z",
    "size": 1741,
    "path": "../public/app-assets/fonts/flag-icon-css/flags/4x3/za.svg"
  },
  "/app-assets/fonts/flag-icon-css/flags/4x3/za.svg.br": {
    "type": "image/svg+xml",
    "encoding": "br",
    "etag": "\"2c7-o397D7OsNar3n+EcFoCZQxCTbzk\"",
    "mtime": "2025-04-13T20:04:28.556Z",
    "size": 711,
    "path": "../public/app-assets/fonts/flag-icon-css/flags/4x3/za.svg.br"
  },
  "/app-assets/fonts/flag-icon-css/flags/4x3/za.svg.gz": {
    "type": "image/svg+xml",
    "encoding": "gzip",
    "etag": "\"337-tRdeHIBUstipjLPWV+a4VX1y83Q\"",
    "mtime": "2025-04-13T20:04:28.556Z",
    "size": 823,
    "path": "../public/app-assets/fonts/flag-icon-css/flags/4x3/za.svg.gz"
  },
  "/app-assets/fonts/flag-icon-css/flags/4x3/zm.svg": {
    "type": "image/svg+xml",
    "etag": "\"2a42-AePoC1SFAHc8/jni3WEz5oxxtoQ\"",
    "mtime": "2025-04-13T20:04:20.457Z",
    "size": 10818,
    "path": "../public/app-assets/fonts/flag-icon-css/flags/4x3/zm.svg"
  },
  "/app-assets/fonts/flag-icon-css/flags/4x3/zm.svg.br": {
    "type": "image/svg+xml",
    "encoding": "br",
    "etag": "\"ecf-61i7eckQPbyaw9bz+iPJZz3IVFA\"",
    "mtime": "2025-04-13T20:04:28.556Z",
    "size": 3791,
    "path": "../public/app-assets/fonts/flag-icon-css/flags/4x3/zm.svg.br"
  },
  "/app-assets/fonts/flag-icon-css/flags/4x3/zm.svg.gz": {
    "type": "image/svg+xml",
    "encoding": "gzip",
    "etag": "\"10bf-5KtRRPPFhB6kxuL89+ORvnOwCrE\"",
    "mtime": "2025-04-13T20:04:28.556Z",
    "size": 4287,
    "path": "../public/app-assets/fonts/flag-icon-css/flags/4x3/zm.svg.gz"
  },
  "/app-assets/fonts/flag-icon-css/flags/4x3/zw.svg": {
    "type": "image/svg+xml",
    "etag": "\"170a-wrXZHF0j6U0TwAQaX3n4ZOhI4fE\"",
    "mtime": "2025-04-13T20:04:20.457Z",
    "size": 5898,
    "path": "../public/app-assets/fonts/flag-icon-css/flags/4x3/zw.svg"
  },
  "/app-assets/fonts/flag-icon-css/flags/4x3/zw.svg.br": {
    "type": "image/svg+xml",
    "encoding": "br",
    "etag": "\"647-Uw1SBKGwm8HsJRPOTpQ1P8/RK04\"",
    "mtime": "2025-04-13T20:04:28.556Z",
    "size": 1607,
    "path": "../public/app-assets/fonts/flag-icon-css/flags/4x3/zw.svg.br"
  },
  "/app-assets/fonts/flag-icon-css/flags/4x3/zw.svg.gz": {
    "type": "image/svg+xml",
    "encoding": "gzip",
    "etag": "\"722-/GsNSnANwMK2p7+QucKsaTeWr0k\"",
    "mtime": "2025-04-13T20:04:28.556Z",
    "size": 1826,
    "path": "../public/app-assets/fonts/flag-icon-css/flags/4x3/zw.svg.gz"
  },
  "/app-assets/fonts/flag-icon-css/flags/4x3/zz.svg": {
    "type": "image/svg+xml",
    "etag": "\"120-RSZV9TGNQ9343RptQKTBtyF0KY0\"",
    "mtime": "2025-04-13T20:04:20.458Z",
    "size": 288,
    "path": "../public/app-assets/fonts/flag-icon-css/flags/4x3/zz.svg"
  },
  "/app-assets/js/scripts/forms/select/form-select2.min.js": {
    "type": "text/javascript; charset=utf-8",
    "etag": "\"11cb-h+pinQOH7YBuTqK+My02AJi44m4\"",
    "mtime": "2025-04-13T20:04:20.318Z",
    "size": 4555,
    "path": "../public/app-assets/js/scripts/forms/select/form-select2.min.js"
  },
  "/app-assets/js/scripts/forms/select/form-select2.min.js.br": {
    "type": "text/javascript; charset=utf-8",
    "encoding": "br",
    "etag": "\"47c-GWdFjErEDHJC08pBmnzHuHKa758\"",
    "mtime": "2025-04-13T20:04:28.569Z",
    "size": 1148,
    "path": "../public/app-assets/js/scripts/forms/select/form-select2.min.js.br"
  },
  "/app-assets/js/scripts/forms/select/form-select2.min.js.gz": {
    "type": "text/javascript; charset=utf-8",
    "encoding": "gzip",
    "etag": "\"538-OEvTECjyJ0nwUTVM61JLizE51Bo\"",
    "mtime": "2025-04-13T20:04:28.569Z",
    "size": 1336,
    "path": "../public/app-assets/js/scripts/forms/select/form-select2.min.js.gz"
  },
  "/app-assets/js/scripts/forms/validation/form-validation.js": {
    "type": "text/javascript; charset=utf-8",
    "etag": "\"2ce-hK1Rzfwbe1hr/bEICfr/YEGGSZM\"",
    "mtime": "2025-04-13T20:04:20.329Z",
    "size": 718,
    "path": "../public/app-assets/js/scripts/forms/validation/form-validation.js"
  },
  "/app-assets/js/scripts/pickers/dateTime/pick-a-datetime.min.js": {
    "type": "text/javascript; charset=utf-8",
    "etag": "\"669-HNELmEQi836NWQmxP/zwLuVa//g\"",
    "mtime": "2025-04-13T20:04:20.318Z",
    "size": 1641,
    "path": "../public/app-assets/js/scripts/pickers/dateTime/pick-a-datetime.min.js"
  },
  "/app-assets/js/scripts/pickers/dateTime/pick-a-datetime.min.js.br": {
    "type": "text/javascript; charset=utf-8",
    "encoding": "br",
    "etag": "\"29b-0HnGeziTsQflCAS30VTXNXoYGuA\"",
    "mtime": "2025-04-13T20:04:28.570Z",
    "size": 667,
    "path": "../public/app-assets/js/scripts/pickers/dateTime/pick-a-datetime.min.js.br"
  },
  "/app-assets/js/scripts/pickers/dateTime/pick-a-datetime.min.js.gz": {
    "type": "text/javascript; charset=utf-8",
    "encoding": "gzip",
    "etag": "\"2ec-9Jw9qbDn4Zf8EmyPd8f+idTwALs\"",
    "mtime": "2025-04-13T20:04:28.570Z",
    "size": 748,
    "path": "../public/app-assets/js/scripts/pickers/dateTime/pick-a-datetime.min.js.gz"
  },
  "/app-assets/vendors/css/editors/quill/katex.min.css": {
    "type": "text/css; charset=utf-8",
    "etag": "\"5135-xpRlKWEVM3z0ij1FUSvhMLYGr3A\"",
    "mtime": "2025-04-13T20:04:20.329Z",
    "size": 20789,
    "path": "../public/app-assets/vendors/css/editors/quill/katex.min.css"
  },
  "/app-assets/vendors/css/editors/quill/katex.min.css.br": {
    "type": "text/css; charset=utf-8",
    "encoding": "br",
    "etag": "\"884-ahPTkaMf/oje8q4khPPyycMkrSk\"",
    "mtime": "2025-04-13T20:04:28.556Z",
    "size": 2180,
    "path": "../public/app-assets/vendors/css/editors/quill/katex.min.css.br"
  },
  "/app-assets/vendors/css/editors/quill/katex.min.css.gz": {
    "type": "text/css; charset=utf-8",
    "encoding": "gzip",
    "etag": "\"a62-a2OFB5d5Mrrl4OEKJTWtt3keyO4\"",
    "mtime": "2025-04-13T20:04:28.556Z",
    "size": 2658,
    "path": "../public/app-assets/vendors/css/editors/quill/katex.min.css.gz"
  },
  "/app-assets/vendors/css/editors/quill/monokai-sublime.min.css": {
    "type": "text/css; charset=utf-8",
    "etag": "\"30d-UB117w9Dhb6iTZubTMQ0umjUvic\"",
    "mtime": "2025-04-13T20:04:20.374Z",
    "size": 781,
    "path": "../public/app-assets/vendors/css/editors/quill/monokai-sublime.min.css"
  },
  "/app-assets/vendors/css/editors/quill/quill.bubble.css": {
    "type": "text/css; charset=utf-8",
    "etag": "\"62b8-uDxzv7oBKuxaNPXev0OMOOAS5Y4\"",
    "mtime": "2025-04-13T20:04:20.374Z",
    "size": 25272,
    "path": "../public/app-assets/vendors/css/editors/quill/quill.bubble.css"
  },
  "/app-assets/vendors/css/editors/quill/quill.bubble.css.br": {
    "type": "text/css; charset=utf-8",
    "encoding": "br",
    "etag": "\"c36-QKziBjNefFA9uUKMj8GReNgtGjw\"",
    "mtime": "2025-04-13T20:04:28.556Z",
    "size": 3126,
    "path": "../public/app-assets/vendors/css/editors/quill/quill.bubble.css.br"
  },
  "/app-assets/vendors/css/editors/quill/quill.bubble.css.gz": {
    "type": "text/css; charset=utf-8",
    "encoding": "gzip",
    "etag": "\"e2b-T8rYjW17c0GOQrG048is4z5LnZM\"",
    "mtime": "2025-04-13T20:04:28.556Z",
    "size": 3627,
    "path": "../public/app-assets/vendors/css/editors/quill/quill.bubble.css.gz"
  },
  "/app-assets/vendors/css/editors/quill/quill.snow.css": {
    "type": "text/css; charset=utf-8",
    "etag": "\"60a6-sQE7qThTYGo6ptBsN4UuGT2j10s\"",
    "mtime": "2025-04-13T20:04:20.374Z",
    "size": 24742,
    "path": "../public/app-assets/vendors/css/editors/quill/quill.snow.css"
  },
  "/app-assets/vendors/css/editors/quill/quill.snow.css.br": {
    "type": "text/css; charset=utf-8",
    "encoding": "br",
    "etag": "\"c29-S5VgI/P1u8FpzHAHAFQ9qgNdHMA\"",
    "mtime": "2025-04-13T20:04:28.556Z",
    "size": 3113,
    "path": "../public/app-assets/vendors/css/editors/quill/quill.snow.css.br"
  },
  "/app-assets/vendors/css/editors/quill/quill.snow.css.gz": {
    "type": "text/css; charset=utf-8",
    "encoding": "gzip",
    "etag": "\"e24-1boxzms8Yom8cL8O/b7P6fwWxk0\"",
    "mtime": "2025-04-13T20:04:28.556Z",
    "size": 3620,
    "path": "../public/app-assets/vendors/css/editors/quill/quill.snow.css.gz"
  },
  "/app-assets/vendors/css/calendars/extensions/daygrid.min.css": {
    "type": "text/css; charset=utf-8",
    "etag": "\"453-yxnZE+RgNxHfqvCwcnp6wkBgXM0\"",
    "mtime": "2025-04-13T20:04:20.374Z",
    "size": 1107,
    "path": "../public/app-assets/vendors/css/calendars/extensions/daygrid.min.css"
  },
  "/app-assets/vendors/css/calendars/extensions/daygrid.min.css.br": {
    "type": "text/css; charset=utf-8",
    "encoding": "br",
    "etag": "\"14c-/A7EoYAQO6eCEuzONBsKQPbzBbo\"",
    "mtime": "2025-04-13T20:04:28.556Z",
    "size": 332,
    "path": "../public/app-assets/vendors/css/calendars/extensions/daygrid.min.css.br"
  },
  "/app-assets/vendors/css/calendars/extensions/daygrid.min.css.gz": {
    "type": "text/css; charset=utf-8",
    "encoding": "gzip",
    "etag": "\"1b9-NqVmJzuN+P6ZBAftEIWPZcU01aE\"",
    "mtime": "2025-04-13T20:04:28.556Z",
    "size": 441,
    "path": "../public/app-assets/vendors/css/calendars/extensions/daygrid.min.css.gz"
  },
  "/app-assets/vendors/css/calendars/extensions/timegrid.min.css": {
    "type": "text/css; charset=utf-8",
    "etag": "\"d99-YvncwFCERyR8GwHdNBk3PgNMTyI\"",
    "mtime": "2025-04-13T20:04:20.317Z",
    "size": 3481,
    "path": "../public/app-assets/vendors/css/calendars/extensions/timegrid.min.css"
  },
  "/app-assets/vendors/css/calendars/extensions/timegrid.min.css.br": {
    "type": "text/css; charset=utf-8",
    "encoding": "br",
    "etag": "\"331-VzA80UXlQhD/+cOb3LsvWP48SLI\"",
    "mtime": "2025-04-13T20:04:28.556Z",
    "size": 817,
    "path": "../public/app-assets/vendors/css/calendars/extensions/timegrid.min.css.br"
  },
  "/app-assets/vendors/css/calendars/extensions/timegrid.min.css.gz": {
    "type": "text/css; charset=utf-8",
    "encoding": "gzip",
    "etag": "\"3e7-7NjqfT7xfa2TP1Rbls31/wxeBWw\"",
    "mtime": "2025-04-13T20:04:28.556Z",
    "size": 999,
    "path": "../public/app-assets/vendors/css/calendars/extensions/timegrid.min.css.gz"
  },
  "/app-assets/vendors/css/extensions/font/context-menu-icons6a65-2.html": {
    "type": "text/html; charset=utf-8",
    "etag": "\"ab-Qwr3igcCwLiUYlmJhoKMamlAxz4\"",
    "mtime": "2025-04-13T20:04:20.318Z",
    "size": 171,
    "path": "../public/app-assets/vendors/css/extensions/font/context-menu-icons6a65-2.html"
  },
  "/app-assets/vendors/css/extensions/font/context-menu-icons6a65.html": {
    "type": "text/html; charset=utf-8",
    "etag": "\"ab-Qwr3igcCwLiUYlmJhoKMamlAxz4\"",
    "mtime": "2025-04-13T20:04:20.374Z",
    "size": 171,
    "path": "../public/app-assets/vendors/css/extensions/font/context-menu-icons6a65.html"
  },
  "/app-assets/vendors/css/forms/select/select2.min.css": {
    "type": "text/css; charset=utf-8",
    "etag": "\"3a76-rlc1Vi+qvRotmAO7179MUCteT1E\"",
    "mtime": "2025-04-13T20:04:20.318Z",
    "size": 14966,
    "path": "../public/app-assets/vendors/css/forms/select/select2.min.css"
  },
  "/app-assets/vendors/css/forms/select/select2.min.css.br": {
    "type": "text/css; charset=utf-8",
    "encoding": "br",
    "etag": "\"668-eR6AIgP+10wQsdc8j5qqQ2TnUyo\"",
    "mtime": "2025-04-13T20:04:28.556Z",
    "size": 1640,
    "path": "../public/app-assets/vendors/css/forms/select/select2.min.css.br"
  },
  "/app-assets/vendors/css/forms/select/select2.min.css.gz": {
    "type": "text/css; charset=utf-8",
    "encoding": "gzip",
    "etag": "\"7b8-Kx9A7IWqt5xNwEvZ/XW6vFBTE/4\"",
    "mtime": "2025-04-13T20:04:28.556Z",
    "size": 1976,
    "path": "../public/app-assets/vendors/css/forms/select/select2.min.css.gz"
  },
  "/app-assets/vendors/css/forms/spinner/jquery.bootstrap-touchspin.css": {
    "type": "text/css; charset=utf-8",
    "etag": "\"35c-H3LIxmh60qgvFHFEOJH9Iv9leBc\"",
    "mtime": "2025-04-13T20:04:20.329Z",
    "size": 860,
    "path": "../public/app-assets/vendors/css/forms/spinner/jquery.bootstrap-touchspin.css"
  },
  "/app-assets/vendors/css/pickers/pickadate/pickadate.css": {
    "type": "text/css; charset=utf-8",
    "etag": "\"1910-o+2dsdwt2B3wuKsylwy4LvZ4Js8\"",
    "mtime": "2025-04-13T20:04:20.318Z",
    "size": 6416,
    "path": "../public/app-assets/vendors/css/pickers/pickadate/pickadate.css"
  },
  "/app-assets/vendors/css/pickers/pickadate/pickadate.css.br": {
    "type": "text/css; charset=utf-8",
    "encoding": "br",
    "etag": "\"498-jsPkrxpj6jZiZsjgrgNwBWv+Un8\"",
    "mtime": "2025-04-13T20:04:28.556Z",
    "size": 1176,
    "path": "../public/app-assets/vendors/css/pickers/pickadate/pickadate.css.br"
  },
  "/app-assets/vendors/css/pickers/pickadate/pickadate.css.gz": {
    "type": "text/css; charset=utf-8",
    "encoding": "gzip",
    "etag": "\"595-Y6bly1FmCH/XBnm/NW2NlrUZ0Hc\"",
    "mtime": "2025-04-13T20:04:28.556Z",
    "size": 1429,
    "path": "../public/app-assets/vendors/css/pickers/pickadate/pickadate.css.gz"
  },
  "/app-assets/vendors/css/tables/datatable/datatables.min.css": {
    "type": "text/css; charset=utf-8",
    "etag": "\"3794-VPkOXOFnm6/T3ng+zJVV6Ubpgyk\"",
    "mtime": "2025-04-13T20:04:20.375Z",
    "size": 14228,
    "path": "../public/app-assets/vendors/css/tables/datatable/datatables.min.css"
  },
  "/app-assets/vendors/css/tables/datatable/datatables.min.css.br": {
    "type": "text/css; charset=utf-8",
    "encoding": "br",
    "etag": "\"7fe-D+wQYX9XYx+DMB4L77VNOta2nec\"",
    "mtime": "2025-04-13T20:04:28.566Z",
    "size": 2046,
    "path": "../public/app-assets/vendors/css/tables/datatable/datatables.min.css.br"
  },
  "/app-assets/vendors/css/tables/datatable/datatables.min.css.gz": {
    "type": "text/css; charset=utf-8",
    "encoding": "gzip",
    "etag": "\"96d-3N8RW6PssHR2rS4vFKtjK0aT97k\"",
    "mtime": "2025-04-13T20:04:28.566Z",
    "size": 2413,
    "path": "../public/app-assets/vendors/css/tables/datatable/datatables.min.css.gz"
  },
  "/app-assets/vendors/css/tables/ag-grid/ag-grid.css": {
    "type": "text/css; charset=utf-8",
    "etag": "\"fff5-RSWhSVsW1IPIZWne/saAlKjCup0\"",
    "mtime": "2025-04-13T20:04:20.318Z",
    "size": 65525,
    "path": "../public/app-assets/vendors/css/tables/ag-grid/ag-grid.css"
  },
  "/app-assets/vendors/css/tables/ag-grid/ag-grid.css.br": {
    "type": "text/css; charset=utf-8",
    "encoding": "br",
    "etag": "\"208c-WfPM3CG/wqDedz5dftQiejpKaUI\"",
    "mtime": "2025-04-13T20:04:28.566Z",
    "size": 8332,
    "path": "../public/app-assets/vendors/css/tables/ag-grid/ag-grid.css.br"
  },
  "/app-assets/vendors/css/tables/ag-grid/ag-grid.css.gz": {
    "type": "text/css; charset=utf-8",
    "encoding": "gzip",
    "etag": "\"27c6-KAGgI0H+59tmKxehStEWbyPmIlU\"",
    "mtime": "2025-04-13T20:04:28.566Z",
    "size": 10182,
    "path": "../public/app-assets/vendors/css/tables/ag-grid/ag-grid.css.gz"
  },
  "/app-assets/vendors/css/tables/ag-grid/ag-theme-material.css": {
    "type": "text/css; charset=utf-8",
    "etag": "\"1329d-ev4YSmEDe5I8lmTHhexURnVbgpA\"",
    "mtime": "2025-04-13T20:04:20.374Z",
    "size": 78493,
    "path": "../public/app-assets/vendors/css/tables/ag-grid/ag-theme-material.css"
  },
  "/app-assets/vendors/css/tables/ag-grid/ag-theme-material.css.br": {
    "type": "text/css; charset=utf-8",
    "encoding": "br",
    "etag": "\"2b70-rro4IEeQIAto8sTL9tM58HhQg6M\"",
    "mtime": "2025-04-13T20:04:28.567Z",
    "size": 11120,
    "path": "../public/app-assets/vendors/css/tables/ag-grid/ag-theme-material.css.br"
  },
  "/app-assets/vendors/css/tables/ag-grid/ag-theme-material.css.gz": {
    "type": "text/css; charset=utf-8",
    "encoding": "gzip",
    "etag": "\"3444-Bobvm8+GrL1c9STFcfs5HNY2CdA\"",
    "mtime": "2025-04-13T20:04:28.567Z",
    "size": 13380,
    "path": "../public/app-assets/vendors/css/tables/ag-grid/ag-theme-material.css.gz"
  },
  "/app-assets/vendors/js/calendar/extensions/daygrid.min.js": {
    "type": "text/javascript; charset=utf-8",
    "etag": "\"69f9-bOxuLKg/vzAEt8SdaqIEB8at4Yg\"",
    "mtime": "2025-04-13T20:04:20.318Z",
    "size": 27129,
    "path": "../public/app-assets/vendors/js/calendar/extensions/daygrid.min.js"
  },
  "/app-assets/vendors/js/calendar/extensions/daygrid.min.js.br": {
    "type": "text/javascript; charset=utf-8",
    "encoding": "br",
    "etag": "\"1cdc-7bPf0b/7ZQLB5ZLrsCz7NpJMMfI\"",
    "mtime": "2025-04-13T20:04:28.566Z",
    "size": 7388,
    "path": "../public/app-assets/vendors/js/calendar/extensions/daygrid.min.js.br"
  },
  "/app-assets/vendors/js/calendar/extensions/daygrid.min.js.gz": {
    "type": "text/javascript; charset=utf-8",
    "encoding": "gzip",
    "etag": "\"200e-D/Ag1SVaD6Ae8QrC+aZHFJih/A4\"",
    "mtime": "2025-04-13T20:04:28.566Z",
    "size": 8206,
    "path": "../public/app-assets/vendors/js/calendar/extensions/daygrid.min.js.gz"
  },
  "/app-assets/vendors/js/calendar/extensions/interactions.min.js": {
    "type": "text/javascript; charset=utf-8",
    "etag": "\"8c90-BU+fuUnUu7eEl7WiutJfaGTgDu4\"",
    "mtime": "2025-04-13T20:04:20.375Z",
    "size": 35984,
    "path": "../public/app-assets/vendors/js/calendar/extensions/interactions.min.js"
  },
  "/app-assets/vendors/js/calendar/extensions/interactions.min.js.br": {
    "type": "text/javascript; charset=utf-8",
    "encoding": "br",
    "etag": "\"2092-OlBCp59aKYBroYWN2TdKoi9nWuc\"",
    "mtime": "2025-04-13T20:04:28.566Z",
    "size": 8338,
    "path": "../public/app-assets/vendors/js/calendar/extensions/interactions.min.js.br"
  },
  "/app-assets/vendors/js/calendar/extensions/interactions.min.js.gz": {
    "type": "text/javascript; charset=utf-8",
    "encoding": "gzip",
    "etag": "\"243e-q3wzBfIDEhoFqFu19w5XQLCpJmQ\"",
    "mtime": "2025-04-13T20:04:28.566Z",
    "size": 9278,
    "path": "../public/app-assets/vendors/js/calendar/extensions/interactions.min.js.gz"
  },
  "/app-assets/vendors/js/calendar/extensions/timegrid.min.js": {
    "type": "text/javascript; charset=utf-8",
    "etag": "\"5d81-QBqa3KLFIVOa/bz8S3nH8OX2fb8\"",
    "mtime": "2025-04-13T20:04:20.375Z",
    "size": 23937,
    "path": "../public/app-assets/vendors/js/calendar/extensions/timegrid.min.js"
  },
  "/app-assets/vendors/js/calendar/extensions/timegrid.min.js.br": {
    "type": "text/javascript; charset=utf-8",
    "encoding": "br",
    "etag": "\"18a4-KyjoDbc9rZG9YZboMVoeweIcxkk\"",
    "mtime": "2025-04-13T20:04:28.566Z",
    "size": 6308,
    "path": "../public/app-assets/vendors/js/calendar/extensions/timegrid.min.js.br"
  },
  "/app-assets/vendors/js/calendar/extensions/timegrid.min.js.gz": {
    "type": "text/javascript; charset=utf-8",
    "encoding": "gzip",
    "etag": "\"1b3f-3ImcBsO2i+xCyLD6D6QKwsS4DGA\"",
    "mtime": "2025-04-13T20:04:28.566Z",
    "size": 6975,
    "path": "../public/app-assets/vendors/js/calendar/extensions/timegrid.min.js.gz"
  },
  "/app-assets/vendors/js/charts/echarts/echarts.min.js": {
    "type": "text/javascript; charset=utf-8",
    "etag": "\"b78cd-4YctmAOKdN1HDqUotRwKiMv6uNE\"",
    "mtime": "2025-04-13T20:04:20.320Z",
    "size": 751821,
    "path": "../public/app-assets/vendors/js/charts/echarts/echarts.min.js"
  },
  "/app-assets/vendors/js/charts/echarts/echarts.min.js.br": {
    "type": "text/javascript; charset=utf-8",
    "encoding": "br",
    "etag": "\"31b4d-j4Pt0IKFrOaQLFAZmme2aFiy3E0\"",
    "mtime": "2025-04-13T20:04:28.815Z",
    "size": 203597,
    "path": "../public/app-assets/vendors/js/charts/echarts/echarts.min.js.br"
  },
  "/app-assets/vendors/js/charts/echarts/echarts.min.js.gz": {
    "type": "text/javascript; charset=utf-8",
    "encoding": "gzip",
    "etag": "\"3d078-0RVBVrBMZjwbUW4sBUaSREmpX1M\"",
    "mtime": "2025-04-13T20:04:28.811Z",
    "size": 249976,
    "path": "../public/app-assets/vendors/js/charts/echarts/echarts.min.js.gz"
  },
  "/app-assets/vendors/js/forms/select/select2.full.min.js": {
    "type": "text/javascript; charset=utf-8",
    "etag": "\"132dc-+bAjhcakkmUbOogfcsBvZ2D5in0\"",
    "mtime": "2025-04-13T20:04:20.330Z",
    "size": 78556,
    "path": "../public/app-assets/vendors/js/forms/select/select2.full.min.js"
  },
  "/app-assets/vendors/js/forms/select/select2.full.min.js.br": {
    "type": "text/javascript; charset=utf-8",
    "encoding": "br",
    "etag": "\"46cf-xPRybzXjg/yC3KmXllsUdo1PRek\"",
    "mtime": "2025-04-13T20:04:28.646Z",
    "size": 18127,
    "path": "../public/app-assets/vendors/js/forms/select/select2.full.min.js.br"
  },
  "/app-assets/vendors/js/forms/select/select2.full.min.js.gz": {
    "type": "text/javascript; charset=utf-8",
    "encoding": "gzip",
    "etag": "\"5549-hJZcMBwG0t6rHrYLlGQn1dEOyio\"",
    "mtime": "2025-04-13T20:04:28.646Z",
    "size": 21833,
    "path": "../public/app-assets/vendors/js/forms/select/select2.full.min.js.gz"
  },
  "/app-assets/vendors/js/editors/quill/highlight.min.js": {
    "type": "text/javascript; charset=utf-8",
    "etag": "\"c344-nzVUi/yixbpL2KWXtxQWzVIpbMk\"",
    "mtime": "2025-04-13T20:04:20.377Z",
    "size": 49988,
    "path": "../public/app-assets/vendors/js/editors/quill/highlight.min.js"
  },
  "/app-assets/vendors/js/editors/quill/highlight.min.js.br": {
    "type": "text/javascript; charset=utf-8",
    "encoding": "br",
    "etag": "\"4607-CaY050ttFMZB66vl9/HuWQebQF0\"",
    "mtime": "2025-04-13T20:04:28.643Z",
    "size": 17927,
    "path": "../public/app-assets/vendors/js/editors/quill/highlight.min.js.br"
  },
  "/app-assets/vendors/js/editors/quill/highlight.min.js.gz": {
    "type": "text/javascript; charset=utf-8",
    "encoding": "gzip",
    "etag": "\"4f81-XLGkaQdRAKZQi2caAzgAxXowJRc\"",
    "mtime": "2025-04-13T20:04:28.643Z",
    "size": 20353,
    "path": "../public/app-assets/vendors/js/editors/quill/highlight.min.js.gz"
  },
  "/app-assets/vendors/js/editors/quill/katex.min.js": {
    "type": "text/javascript; charset=utf-8",
    "etag": "\"1c636-XcwNIJGRspeZyQvdcfLBQmsXVb8\"",
    "mtime": "2025-04-13T20:04:20.319Z",
    "size": 116278,
    "path": "../public/app-assets/vendors/js/editors/quill/katex.min.js"
  },
  "/app-assets/vendors/js/editors/quill/katex.min.js.br": {
    "type": "text/javascript; charset=utf-8",
    "encoding": "br",
    "etag": "\"5c95-BJYI5cg1YWJ1RfNv8yAUVKduQjI\"",
    "mtime": "2025-04-13T20:04:28.643Z",
    "size": 23701,
    "path": "../public/app-assets/vendors/js/editors/quill/katex.min.js.br"
  },
  "/app-assets/vendors/js/editors/quill/katex.min.js.gz": {
    "type": "text/javascript; charset=utf-8",
    "encoding": "gzip",
    "etag": "\"7061-ynRjK36CEPoEbXN4xJNUT/gsRBM\"",
    "mtime": "2025-04-13T20:04:28.643Z",
    "size": 28769,
    "path": "../public/app-assets/vendors/js/editors/quill/katex.min.js.gz"
  },
  "/app-assets/vendors/js/editors/quill/quill.min.js": {
    "type": "text/javascript; charset=utf-8",
    "etag": "\"34934-JurAbJI/RGuaLq+PcCMD++Y8cfs\"",
    "mtime": "2025-04-13T20:04:20.378Z",
    "size": 215348,
    "path": "../public/app-assets/vendors/js/editors/quill/quill.min.js"
  },
  "/app-assets/vendors/js/editors/quill/quill.min.js.br": {
    "type": "text/javascript; charset=utf-8",
    "encoding": "br",
    "etag": "\"92e4-FPDJK7cbx492IeRcYAn4oU81Jxs\"",
    "mtime": "2025-04-13T20:04:28.679Z",
    "size": 37604,
    "path": "../public/app-assets/vendors/js/editors/quill/quill.min.js.br"
  },
  "/app-assets/vendors/js/editors/quill/quill.min.js.gz": {
    "type": "text/javascript; charset=utf-8",
    "encoding": "gzip",
    "etag": "\"b5bc-04zMVxPAigFmeLfh3yClLDsUJWE\"",
    "mtime": "2025-04-13T20:04:28.676Z",
    "size": 46524,
    "path": "../public/app-assets/vendors/js/editors/quill/quill.min.js.gz"
  },
  "/app-assets/vendors/js/forms/spinner/jquery.bootstrap-touchspin.js": {
    "type": "text/javascript; charset=utf-8",
    "etag": "\"57ec-U0+d12sflQ6INf+upNXJZwIi+78\"",
    "mtime": "2025-04-13T20:04:20.330Z",
    "size": 22508,
    "path": "../public/app-assets/vendors/js/forms/spinner/jquery.bootstrap-touchspin.js"
  },
  "/app-assets/vendors/js/forms/spinner/jquery.bootstrap-touchspin.js.br": {
    "type": "text/javascript; charset=utf-8",
    "encoding": "br",
    "etag": "\"d1f-24PwyzCGT7j+pX5cptG5uuG4t9Y\"",
    "mtime": "2025-04-13T20:04:28.569Z",
    "size": 3359,
    "path": "../public/app-assets/vendors/js/forms/spinner/jquery.bootstrap-touchspin.js.br"
  },
  "/app-assets/vendors/js/forms/spinner/jquery.bootstrap-touchspin.js.gz": {
    "type": "text/javascript; charset=utf-8",
    "encoding": "gzip",
    "etag": "\"f23-9qmwk13OgAKvgNDipSIGb6byOc4\"",
    "mtime": "2025-04-13T20:04:28.569Z",
    "size": 3875,
    "path": "../public/app-assets/vendors/js/forms/spinner/jquery.bootstrap-touchspin.js.gz"
  },
  "/app-assets/vendors/js/pickers/pickadate/legacy.js": {
    "type": "text/javascript; charset=utf-8",
    "etag": "\"1028-yPw3mUiOW1P5jxI6KcY/AgnCh70\"",
    "mtime": "2025-04-13T20:04:20.377Z",
    "size": 4136,
    "path": "../public/app-assets/vendors/js/pickers/pickadate/legacy.js"
  },
  "/app-assets/vendors/js/pickers/pickadate/legacy.js.br": {
    "type": "text/javascript; charset=utf-8",
    "encoding": "br",
    "etag": "\"47a-/TUlhzJ/R+5PluN7UOdoSLk5Rvo\"",
    "mtime": "2025-04-13T20:04:28.567Z",
    "size": 1146,
    "path": "../public/app-assets/vendors/js/pickers/pickadate/legacy.js.br"
  },
  "/app-assets/vendors/js/pickers/pickadate/legacy.js.gz": {
    "type": "text/javascript; charset=utf-8",
    "encoding": "gzip",
    "etag": "\"531-tDa/LcN26Sw7ZBDF5ljjDQK3vuk\"",
    "mtime": "2025-04-13T20:04:28.567Z",
    "size": 1329,
    "path": "../public/app-assets/vendors/js/pickers/pickadate/legacy.js.gz"
  },
  "/app-assets/vendors/js/pickers/pickadate/picker.date.js": {
    "type": "text/javascript; charset=utf-8",
    "etag": "\"bcfc-uQOlO4i2GgNBuaIF0WLk7gRvGHA\"",
    "mtime": "2025-04-13T20:04:20.319Z",
    "size": 48380,
    "path": "../public/app-assets/vendors/js/pickers/pickadate/picker.date.js"
  },
  "/app-assets/vendors/js/pickers/pickadate/picker.date.js.br": {
    "type": "text/javascript; charset=utf-8",
    "encoding": "br",
    "etag": "\"23fe-5bQc6K2CBGLwjt17cSo0I/DXSW4\"",
    "mtime": "2025-04-13T20:04:28.569Z",
    "size": 9214,
    "path": "../public/app-assets/vendors/js/pickers/pickadate/picker.date.js.br"
  },
  "/app-assets/vendors/js/pickers/pickadate/picker.date.js.gz": {
    "type": "text/javascript; charset=utf-8",
    "encoding": "gzip",
    "etag": "\"296a-DYq/DgR/f2IKVmQxfk+ZwIcWW9c\"",
    "mtime": "2025-04-13T20:04:28.569Z",
    "size": 10602,
    "path": "../public/app-assets/vendors/js/pickers/pickadate/picker.date.js.gz"
  },
  "/app-assets/vendors/js/pickers/pickadate/picker.js": {
    "type": "text/javascript; charset=utf-8",
    "etag": "\"9a0e-mRCjiXOZEO/kb6+P9YRx3MmL+0E\"",
    "mtime": "2025-04-13T20:04:20.377Z",
    "size": 39438,
    "path": "../public/app-assets/vendors/js/pickers/pickadate/picker.js"
  },
  "/app-assets/vendors/js/pickers/pickadate/picker.js.br": {
    "type": "text/javascript; charset=utf-8",
    "encoding": "br",
    "etag": "\"1fd8-olb/PJ3dVnvssdiiW9OcYM6dDwg\"",
    "mtime": "2025-04-13T20:04:28.569Z",
    "size": 8152,
    "path": "../public/app-assets/vendors/js/pickers/pickadate/picker.js.br"
  },
  "/app-assets/vendors/js/pickers/pickadate/picker.js.gz": {
    "type": "text/javascript; charset=utf-8",
    "encoding": "gzip",
    "etag": "\"251e-hXQPVWcxCALqJ5EjDF/MNujt+s0\"",
    "mtime": "2025-04-13T20:04:28.569Z",
    "size": 9502,
    "path": "../public/app-assets/vendors/js/pickers/pickadate/picker.js.gz"
  },
  "/app-assets/vendors/js/pickers/pickadate/picker.time.js": {
    "type": "text/javascript; charset=utf-8",
    "etag": "\"7ce7-FQSDF7Qt+z3w2xWfk79Aws8JBKc\"",
    "mtime": "2025-04-13T20:04:20.377Z",
    "size": 31975,
    "path": "../public/app-assets/vendors/js/pickers/pickadate/picker.time.js"
  },
  "/app-assets/vendors/js/pickers/pickadate/picker.time.js.br": {
    "type": "text/javascript; charset=utf-8",
    "encoding": "br",
    "etag": "\"19c3-T7PxInGbYLlZ+fp3yUfIxjE077U\"",
    "mtime": "2025-04-13T20:04:28.569Z",
    "size": 6595,
    "path": "../public/app-assets/vendors/js/pickers/pickadate/picker.time.js.br"
  },
  "/app-assets/vendors/js/pickers/pickadate/picker.time.js.gz": {
    "type": "text/javascript; charset=utf-8",
    "encoding": "gzip",
    "etag": "\"1dc1-5hKvuFnFmMADm9BUN+CB4r/i+Vs\"",
    "mtime": "2025-04-13T20:04:28.569Z",
    "size": 7617,
    "path": "../public/app-assets/vendors/js/pickers/pickadate/picker.time.js.gz"
  },
  "/app-assets/vendors/js/tables/ag-grid/ag-grid-community.min.noStyle.js": {
    "type": "text/javascript; charset=utf-8",
    "etag": "\"e4061-k9bdaGNIsh6azK2CaXr5t0ijiVs\"",
    "mtime": "2025-04-13T20:04:20.332Z",
    "size": 933985,
    "path": "../public/app-assets/vendors/js/tables/ag-grid/ag-grid-community.min.noStyle.js"
  },
  "/app-assets/vendors/js/tables/ag-grid/ag-grid-community.min.noStyle.js.br": {
    "type": "text/javascript; charset=utf-8",
    "encoding": "br",
    "etag": "\"21e46-4lAfC4/LZX2w2R1JN2gppV6gzwI\"",
    "mtime": "2025-04-13T20:04:28.790Z",
    "size": 138822,
    "path": "../public/app-assets/vendors/js/tables/ag-grid/ag-grid-community.min.noStyle.js.br"
  },
  "/app-assets/vendors/js/tables/ag-grid/ag-grid-community.min.noStyle.js.gz": {
    "type": "text/javascript; charset=utf-8",
    "encoding": "gzip",
    "etag": "\"2de22-h8RurabnbxWYLXyOLEHLxK0ku68\"",
    "mtime": "2025-04-13T20:04:28.802Z",
    "size": 187938,
    "path": "../public/app-assets/vendors/js/tables/ag-grid/ag-grid-community.min.noStyle.js.gz"
  },
  "/app-assets/vendors/js/forms/validation/jqBootstrapValidation.js": {
    "type": "text/javascript; charset=utf-8",
    "etag": "\"eb51-9QRL/MOhjzUIJqXQtnhuLh/ASRk\"",
    "mtime": "2025-04-13T20:04:20.319Z",
    "size": 60241,
    "path": "../public/app-assets/vendors/js/forms/validation/jqBootstrapValidation.js"
  },
  "/app-assets/vendors/js/forms/validation/jqBootstrapValidation.js.br": {
    "type": "text/javascript; charset=utf-8",
    "encoding": "br",
    "etag": "\"1d06-6PEg0f2rYWyP9PyHLxMzmViu39Y\"",
    "mtime": "2025-04-13T20:04:28.569Z",
    "size": 7430,
    "path": "../public/app-assets/vendors/js/forms/validation/jqBootstrapValidation.js.br"
  },
  "/app-assets/vendors/js/forms/validation/jqBootstrapValidation.js.gz": {
    "type": "text/javascript; charset=utf-8",
    "encoding": "gzip",
    "etag": "\"21d7-TxkVgy1ZR7herG1RIIzVsfxW7vI\"",
    "mtime": "2025-04-13T20:04:28.571Z",
    "size": 8663,
    "path": "../public/app-assets/vendors/js/forms/validation/jqBootstrapValidation.js.gz"
  },
  "/app-assets/vendors/js/forms/validation/jquery.validate.min.js": {
    "type": "text/javascript; charset=utf-8",
    "etag": "\"5f39-gSgo50pchC5djLXKh/HlyjVLUK0\"",
    "mtime": "2025-04-13T20:04:20.377Z",
    "size": 24377,
    "path": "../public/app-assets/vendors/js/forms/validation/jquery.validate.min.js"
  },
  "/app-assets/vendors/js/forms/validation/jquery.validate.min.js.br": {
    "type": "text/javascript; charset=utf-8",
    "encoding": "br",
    "etag": "\"1b23-AdkbcHeYMCCsdmg2OI4UgElfrn8\"",
    "mtime": "2025-04-13T20:04:28.570Z",
    "size": 6947,
    "path": "../public/app-assets/vendors/js/forms/validation/jquery.validate.min.js.br"
  },
  "/app-assets/vendors/js/forms/validation/jquery.validate.min.js.gz": {
    "type": "text/javascript; charset=utf-8",
    "encoding": "gzip",
    "etag": "\"1e8d-y049xbAR1s5tcMI4O3cvRC2lmFE\"",
    "mtime": "2025-04-13T20:04:28.570Z",
    "size": 7821,
    "path": "../public/app-assets/vendors/js/forms/validation/jquery.validate.min.js.gz"
  },
  "/app-assets/vendors/js/tables/datatable/buttons.bootstrap.min.js": {
    "type": "text/javascript; charset=utf-8",
    "etag": "\"3c6-m1AeM0NtbsPQPEoo13u7PYKS1nE\"",
    "mtime": "2025-04-13T20:04:20.386Z",
    "size": 966,
    "path": "../public/app-assets/vendors/js/tables/datatable/buttons.bootstrap.min.js"
  },
  "/app-assets/vendors/js/tables/datatable/buttons.html5.min.js": {
    "type": "text/javascript; charset=utf-8",
    "etag": "\"60be-g1YH/vSyoTONSAj5hYR3CTKRTV8\"",
    "mtime": "2025-04-13T20:04:20.377Z",
    "size": 24766,
    "path": "../public/app-assets/vendors/js/tables/datatable/buttons.html5.min.js"
  },
  "/app-assets/vendors/js/tables/datatable/buttons.html5.min.js.br": {
    "type": "text/javascript; charset=utf-8",
    "encoding": "br",
    "etag": "\"16c2-i0QuNctDJ2MvIJjLk/yKszUG5LE\"",
    "mtime": "2025-04-13T20:04:28.566Z",
    "size": 5826,
    "path": "../public/app-assets/vendors/js/tables/datatable/buttons.html5.min.js.br"
  },
  "/app-assets/vendors/js/tables/datatable/buttons.html5.min.js.gz": {
    "type": "text/javascript; charset=utf-8",
    "encoding": "gzip",
    "etag": "\"19e7-alFOfB2XZD3dWMt8sMNP0NACmWw\"",
    "mtime": "2025-04-13T20:04:28.566Z",
    "size": 6631,
    "path": "../public/app-assets/vendors/js/tables/datatable/buttons.html5.min.js.gz"
  },
  "/app-assets/vendors/js/tables/datatable/buttons.print.min.js": {
    "type": "text/javascript; charset=utf-8",
    "etag": "\"8fe-4DfFLqLpdmp3hbBJSfSZ8YtoZSg\"",
    "mtime": "2025-04-13T20:04:20.319Z",
    "size": 2302,
    "path": "../public/app-assets/vendors/js/tables/datatable/buttons.print.min.js"
  },
  "/app-assets/vendors/js/tables/datatable/buttons.print.min.js.br": {
    "type": "text/javascript; charset=utf-8",
    "encoding": "br",
    "etag": "\"3dc-LnzDSSAjfSXDMpeg25bZes6EZ4c\"",
    "mtime": "2025-04-13T20:04:28.566Z",
    "size": 988,
    "path": "../public/app-assets/vendors/js/tables/datatable/buttons.print.min.js.br"
  },
  "/app-assets/vendors/js/tables/datatable/buttons.print.min.js.gz": {
    "type": "text/javascript; charset=utf-8",
    "encoding": "gzip",
    "etag": "\"48a-3W4cNkZDr3EKwvtYiRHnQ8m8TSk\"",
    "mtime": "2025-04-13T20:04:28.566Z",
    "size": 1162,
    "path": "../public/app-assets/vendors/js/tables/datatable/buttons.print.min.js.gz"
  },
  "/app-assets/vendors/js/tables/datatable/dataTables.select.min.js": {
    "type": "text/javascript; charset=utf-8",
    "etag": "\"2fd4-PNPOmst20VPjJg2JzG2A2TRmrC4\"",
    "mtime": "2025-04-13T20:04:20.379Z",
    "size": 12244,
    "path": "../public/app-assets/vendors/js/tables/datatable/dataTables.select.min.js"
  },
  "/app-assets/vendors/js/tables/datatable/dataTables.select.min.js.br": {
    "type": "text/javascript; charset=utf-8",
    "encoding": "br",
    "etag": "\"d14-vsjJVvNUbANrAFHmrqHIsKN7FJs\"",
    "mtime": "2025-04-13T20:04:28.566Z",
    "size": 3348,
    "path": "../public/app-assets/vendors/js/tables/datatable/dataTables.select.min.js.br"
  },
  "/app-assets/vendors/js/tables/datatable/dataTables.select.min.js.gz": {
    "type": "text/javascript; charset=utf-8",
    "encoding": "gzip",
    "etag": "\"f08-f3pPQ3xMEAA5P5fTqZxco9nbugw\"",
    "mtime": "2025-04-13T20:04:28.567Z",
    "size": 3848,
    "path": "../public/app-assets/vendors/js/tables/datatable/dataTables.select.min.js.gz"
  },
  "/app-assets/vendors/js/tables/datatable/datatables.bootstrap4.min.js": {
    "type": "text/javascript; charset=utf-8",
    "etag": "\"825-n4+ykK7Oq3rIE7Pjh8mF7J0dUIU\"",
    "mtime": "2025-04-13T20:04:20.378Z",
    "size": 2085,
    "path": "../public/app-assets/vendors/js/tables/datatable/datatables.bootstrap4.min.js"
  },
  "/app-assets/vendors/js/tables/datatable/datatables.bootstrap4.min.js.br": {
    "type": "text/javascript; charset=utf-8",
    "encoding": "br",
    "etag": "\"3ac-fKu905fX8hOrgnhdZ4mf3n05ApM\"",
    "mtime": "2025-04-13T20:04:28.567Z",
    "size": 940,
    "path": "../public/app-assets/vendors/js/tables/datatable/datatables.bootstrap4.min.js.br"
  },
  "/app-assets/vendors/js/tables/datatable/datatables.bootstrap4.min.js.gz": {
    "type": "text/javascript; charset=utf-8",
    "encoding": "gzip",
    "etag": "\"449-2ISbVBFWFCvOTE5QCqhbsB/MaQM\"",
    "mtime": "2025-04-13T20:04:28.567Z",
    "size": 1097,
    "path": "../public/app-assets/vendors/js/tables/datatable/datatables.bootstrap4.min.js.gz"
  },
  "/app-assets/vendors/js/tables/datatable/datatables.buttons.min.js": {
    "type": "text/javascript; charset=utf-8",
    "etag": "\"45dd-CRE1kwNu7Ik//KNexWu+SLCeO4g\"",
    "mtime": "2025-04-13T20:04:20.378Z",
    "size": 17885,
    "path": "../public/app-assets/vendors/js/tables/datatable/datatables.buttons.min.js"
  },
  "/app-assets/vendors/js/tables/datatable/datatables.buttons.min.js.br": {
    "type": "text/javascript; charset=utf-8",
    "encoding": "br",
    "etag": "\"1470-rf3zPklsY3ncZ0qMK0ydZCtY3vQ\"",
    "mtime": "2025-04-13T20:04:28.567Z",
    "size": 5232,
    "path": "../public/app-assets/vendors/js/tables/datatable/datatables.buttons.min.js.br"
  },
  "/app-assets/vendors/js/tables/datatable/datatables.buttons.min.js.gz": {
    "type": "text/javascript; charset=utf-8",
    "encoding": "gzip",
    "etag": "\"16e0-msd6gdroKxQV0z+S7IVICKzBpPM\"",
    "mtime": "2025-04-13T20:04:28.567Z",
    "size": 5856,
    "path": "../public/app-assets/vendors/js/tables/datatable/datatables.buttons.min.js.gz"
  },
  "/app-assets/vendors/js/tables/datatable/datatables.checkboxes.min.js": {
    "type": "text/javascript; charset=utf-8",
    "etag": "\"4717-w4V3LFM1znoFD0djIZHs14fmIGY\"",
    "mtime": "2025-04-13T20:04:20.378Z",
    "size": 18199,
    "path": "../public/app-assets/vendors/js/tables/datatable/datatables.checkboxes.min.js"
  },
  "/app-assets/vendors/js/tables/datatable/datatables.checkboxes.min.js.br": {
    "type": "text/javascript; charset=utf-8",
    "encoding": "br",
    "etag": "\"d91-j1YIEftrAXd8fIjN2K4dWJkyfVg\"",
    "mtime": "2025-04-13T20:04:28.567Z",
    "size": 3473,
    "path": "../public/app-assets/vendors/js/tables/datatable/datatables.checkboxes.min.js.br"
  },
  "/app-assets/vendors/js/tables/datatable/datatables.checkboxes.min.js.gz": {
    "type": "text/javascript; charset=utf-8",
    "encoding": "gzip",
    "etag": "\"f40-0e99mHQwBKPDhFHtaVRVUVYQ5WU\"",
    "mtime": "2025-04-13T20:04:28.567Z",
    "size": 3904,
    "path": "../public/app-assets/vendors/js/tables/datatable/datatables.checkboxes.min.js.gz"
  },
  "/app-assets/vendors/js/tables/datatable/datatables.min.js": {
    "type": "text/javascript; charset=utf-8",
    "etag": "\"141eb-BamptdYNh0/ujvTu8hJTeWKLJcs\"",
    "mtime": "2025-04-13T20:04:20.379Z",
    "size": 82411,
    "path": "../public/app-assets/vendors/js/tables/datatable/datatables.min.js"
  },
  "/app-assets/vendors/js/tables/datatable/datatables.min.js.br": {
    "type": "text/javascript; charset=utf-8",
    "encoding": "br",
    "etag": "\"61bb-pFA6yrMI/3Ccn2gtfiTg5jy1e24\"",
    "mtime": "2025-04-13T20:04:28.646Z",
    "size": 25019,
    "path": "../public/app-assets/vendors/js/tables/datatable/datatables.min.js.br"
  },
  "/app-assets/vendors/js/tables/datatable/datatables.min.js.gz": {
    "type": "text/javascript; charset=utf-8",
    "encoding": "gzip",
    "etag": "\"6dc3-Q9sCXpxB389gcPB5B7RN0OzuBaI\"",
    "mtime": "2025-04-13T20:04:28.643Z",
    "size": 28099,
    "path": "../public/app-assets/vendors/js/tables/datatable/datatables.min.js.gz"
  },
  "/app-assets/vendors/js/tables/datatable/pdfmake.min.js": {
    "type": "text/javascript; charset=utf-8",
    "etag": "\"ece93-ffMUYsRDY35lbMj4vqTzyDWuJK8\"",
    "mtime": "2025-04-13T20:04:20.383Z",
    "size": 970387,
    "path": "../public/app-assets/vendors/js/tables/datatable/pdfmake.min.js"
  },
  "/app-assets/vendors/js/tables/datatable/pdfmake.min.js.br": {
    "type": "text/javascript; charset=utf-8",
    "encoding": "br",
    "etag": "\"4d1e2-MX0uArbiCe8J2/wF9B/gzSP22Ck\"",
    "mtime": "2025-04-13T20:04:28.947Z",
    "size": 315874,
    "path": "../public/app-assets/vendors/js/tables/datatable/pdfmake.min.js.br"
  },
  "/app-assets/vendors/js/tables/datatable/pdfmake.min.js.gz": {
    "type": "text/javascript; charset=utf-8",
    "encoding": "gzip",
    "etag": "\"63c11-ndLcVKMPE/uwIpxRsZHu6nIMioA\"",
    "mtime": "2025-04-13T20:04:28.819Z",
    "size": 408593,
    "path": "../public/app-assets/vendors/js/tables/datatable/pdfmake.min.js.gz"
  },
  "/app-assets/vendors/js/tables/datatable/vfs_fonts.js": {
    "type": "text/javascript; charset=utf-8",
    "etag": "\"d478c-kUwdt4BG7WdyNwLeZxsyoLWRIG8\"",
    "mtime": "2025-04-13T20:04:20.384Z",
    "size": 870284,
    "path": "../public/app-assets/vendors/js/tables/datatable/vfs_fonts.js"
  },
  "/app-assets/vendors/js/tables/datatable/vfs_fonts.js.br": {
    "type": "text/javascript; charset=utf-8",
    "encoding": "br",
    "etag": "\"4ccfa-SS1LD0NXAxoHMV9JDFDy5FaQldA\"",
    "mtime": "2025-04-13T20:04:28.821Z",
    "size": 314618,
    "path": "../public/app-assets/vendors/js/tables/datatable/vfs_fonts.js.br"
  },
  "/app-assets/vendors/js/tables/datatable/vfs_fonts.js.gz": {
    "type": "text/javascript; charset=utf-8",
    "encoding": "gzip",
    "etag": "\"6732d-i7flPXOYZ3jCnXkT9tEFU7O24JU\"",
    "mtime": "2025-04-13T20:04:28.822Z",
    "size": 422701,
    "path": "../public/app-assets/vendors/js/tables/datatable/vfs_fonts.js.gz"
  },
  "/app-assets/vendors/css/editors/quill/fonts/KaTeX_AMS-Regular-2.html": {
    "type": "text/html; charset=utf-8",
    "etag": "\"ab-Qwr3igcCwLiUYlmJhoKMamlAxz4\"",
    "mtime": "2025-04-13T20:04:20.428Z",
    "size": 171,
    "path": "../public/app-assets/vendors/css/editors/quill/fonts/KaTeX_AMS-Regular-2.html"
  },
  "/app-assets/vendors/css/editors/quill/fonts/KaTeX_AMS-Regular.html": {
    "type": "text/html; charset=utf-8",
    "etag": "\"ab-Qwr3igcCwLiUYlmJhoKMamlAxz4\"",
    "mtime": "2025-04-13T20:04:20.320Z",
    "size": 171,
    "path": "../public/app-assets/vendors/css/editors/quill/fonts/KaTeX_AMS-Regular.html"
  },
  "/app-assets/vendors/css/editors/quill/fonts/KaTeX_Caligraphic-Bold-2.html": {
    "type": "text/html; charset=utf-8",
    "etag": "\"ab-Qwr3igcCwLiUYlmJhoKMamlAxz4\"",
    "mtime": "2025-04-13T20:04:20.428Z",
    "size": 171,
    "path": "../public/app-assets/vendors/css/editors/quill/fonts/KaTeX_Caligraphic-Bold-2.html"
  },
  "/app-assets/vendors/css/editors/quill/fonts/KaTeX_Caligraphic-Bold.html": {
    "type": "text/html; charset=utf-8",
    "etag": "\"ab-Qwr3igcCwLiUYlmJhoKMamlAxz4\"",
    "mtime": "2025-04-13T20:04:20.428Z",
    "size": 171,
    "path": "../public/app-assets/vendors/css/editors/quill/fonts/KaTeX_Caligraphic-Bold.html"
  },
  "/app-assets/vendors/css/editors/quill/fonts/KaTeX_Caligraphic-Regular-2.html": {
    "type": "text/html; charset=utf-8",
    "etag": "\"ab-Qwr3igcCwLiUYlmJhoKMamlAxz4\"",
    "mtime": "2025-04-13T20:04:20.429Z",
    "size": 171,
    "path": "../public/app-assets/vendors/css/editors/quill/fonts/KaTeX_Caligraphic-Regular-2.html"
  },
  "/app-assets/vendors/css/editors/quill/fonts/KaTeX_Caligraphic-Regular.html": {
    "type": "text/html; charset=utf-8",
    "etag": "\"ab-Qwr3igcCwLiUYlmJhoKMamlAxz4\"",
    "mtime": "2025-04-13T20:04:20.428Z",
    "size": 171,
    "path": "../public/app-assets/vendors/css/editors/quill/fonts/KaTeX_Caligraphic-Regular.html"
  },
  "/app-assets/vendors/css/editors/quill/fonts/KaTeX_Fraktur-Bold-2.html": {
    "type": "text/html; charset=utf-8",
    "etag": "\"ab-Qwr3igcCwLiUYlmJhoKMamlAxz4\"",
    "mtime": "2025-04-13T20:04:20.429Z",
    "size": 171,
    "path": "../public/app-assets/vendors/css/editors/quill/fonts/KaTeX_Fraktur-Bold-2.html"
  },
  "/app-assets/vendors/css/editors/quill/fonts/KaTeX_Fraktur-Bold.html": {
    "type": "text/html; charset=utf-8",
    "etag": "\"ab-Qwr3igcCwLiUYlmJhoKMamlAxz4\"",
    "mtime": "2025-04-13T20:04:20.428Z",
    "size": 171,
    "path": "../public/app-assets/vendors/css/editors/quill/fonts/KaTeX_Fraktur-Bold.html"
  },
  "/app-assets/vendors/css/editors/quill/fonts/KaTeX_Fraktur-Regular-2.html": {
    "type": "text/html; charset=utf-8",
    "etag": "\"ab-Qwr3igcCwLiUYlmJhoKMamlAxz4\"",
    "mtime": "2025-04-13T20:04:20.429Z",
    "size": 171,
    "path": "../public/app-assets/vendors/css/editors/quill/fonts/KaTeX_Fraktur-Regular-2.html"
  },
  "/app-assets/vendors/css/editors/quill/fonts/KaTeX_Fraktur-Regular.html": {
    "type": "text/html; charset=utf-8",
    "etag": "\"ab-Qwr3igcCwLiUYlmJhoKMamlAxz4\"",
    "mtime": "2025-04-13T20:04:20.430Z",
    "size": 171,
    "path": "../public/app-assets/vendors/css/editors/quill/fonts/KaTeX_Fraktur-Regular.html"
  },
  "/app-assets/vendors/css/editors/quill/fonts/KaTeX_Main-Bold-2.html": {
    "type": "text/html; charset=utf-8",
    "etag": "\"ab-Qwr3igcCwLiUYlmJhoKMamlAxz4\"",
    "mtime": "2025-04-13T20:04:20.429Z",
    "size": 171,
    "path": "../public/app-assets/vendors/css/editors/quill/fonts/KaTeX_Main-Bold-2.html"
  },
  "/app-assets/vendors/css/editors/quill/fonts/KaTeX_Main-Bold.html": {
    "type": "text/html; charset=utf-8",
    "etag": "\"ab-Qwr3igcCwLiUYlmJhoKMamlAxz4\"",
    "mtime": "2025-04-13T20:04:20.429Z",
    "size": 171,
    "path": "../public/app-assets/vendors/css/editors/quill/fonts/KaTeX_Main-Bold.html"
  },
  "/app-assets/vendors/css/editors/quill/fonts/KaTeX_Main-Italic-2.html": {
    "type": "text/html; charset=utf-8",
    "etag": "\"ab-Qwr3igcCwLiUYlmJhoKMamlAxz4\"",
    "mtime": "2025-04-13T20:04:20.429Z",
    "size": 171,
    "path": "../public/app-assets/vendors/css/editors/quill/fonts/KaTeX_Main-Italic-2.html"
  },
  "/app-assets/vendors/css/editors/quill/fonts/KaTeX_Main-Italic.html": {
    "type": "text/html; charset=utf-8",
    "etag": "\"ab-Qwr3igcCwLiUYlmJhoKMamlAxz4\"",
    "mtime": "2025-04-13T20:04:20.429Z",
    "size": 171,
    "path": "../public/app-assets/vendors/css/editors/quill/fonts/KaTeX_Main-Italic.html"
  },
  "/app-assets/vendors/css/editors/quill/fonts/KaTeX_Main-Regular-2.html": {
    "type": "text/html; charset=utf-8",
    "etag": "\"ab-Qwr3igcCwLiUYlmJhoKMamlAxz4\"",
    "mtime": "2025-04-13T20:04:20.431Z",
    "size": 171,
    "path": "../public/app-assets/vendors/css/editors/quill/fonts/KaTeX_Main-Regular-2.html"
  },
  "/app-assets/vendors/css/editors/quill/fonts/KaTeX_Main-Regular.html": {
    "type": "text/html; charset=utf-8",
    "etag": "\"ab-Qwr3igcCwLiUYlmJhoKMamlAxz4\"",
    "mtime": "2025-04-13T20:04:20.429Z",
    "size": 171,
    "path": "../public/app-assets/vendors/css/editors/quill/fonts/KaTeX_Main-Regular.html"
  },
  "/app-assets/vendors/css/editors/quill/fonts/KaTeX_Main-Regular.woff2": {
    "type": "font/woff2",
    "etag": "\"79f4-tK2Jz2K6OJqf4nPjFU8MUJs295w\"",
    "mtime": "2025-04-13T20:04:20.430Z",
    "size": 31220,
    "path": "../public/app-assets/vendors/css/editors/quill/fonts/KaTeX_Main-Regular.woff2"
  },
  "/app-assets/vendors/css/editors/quill/fonts/KaTeX_Math-Italic-2.html": {
    "type": "text/html; charset=utf-8",
    "etag": "\"ab-Qwr3igcCwLiUYlmJhoKMamlAxz4\"",
    "mtime": "2025-04-13T20:04:20.429Z",
    "size": 171,
    "path": "../public/app-assets/vendors/css/editors/quill/fonts/KaTeX_Math-Italic-2.html"
  },
  "/app-assets/vendors/css/editors/quill/fonts/KaTeX_Math-Italic.html": {
    "type": "text/html; charset=utf-8",
    "etag": "\"ab-Qwr3igcCwLiUYlmJhoKMamlAxz4\"",
    "mtime": "2025-04-13T20:04:20.429Z",
    "size": 171,
    "path": "../public/app-assets/vendors/css/editors/quill/fonts/KaTeX_Math-Italic.html"
  },
  "/app-assets/vendors/css/editors/quill/fonts/KaTeX_Math-Italic.woff2": {
    "type": "font/woff2",
    "etag": "\"4fd0-kyrnptnLo+7Yb0avKaJTENFTOyg\"",
    "mtime": "2025-04-13T20:04:20.430Z",
    "size": 20432,
    "path": "../public/app-assets/vendors/css/editors/quill/fonts/KaTeX_Math-Italic.woff2"
  },
  "/app-assets/vendors/css/editors/quill/fonts/KaTeX_SansSerif-Regular-2.html": {
    "type": "text/html; charset=utf-8",
    "etag": "\"ab-Qwr3igcCwLiUYlmJhoKMamlAxz4\"",
    "mtime": "2025-04-13T20:04:20.430Z",
    "size": 171,
    "path": "../public/app-assets/vendors/css/editors/quill/fonts/KaTeX_SansSerif-Regular-2.html"
  },
  "/app-assets/vendors/css/editors/quill/fonts/KaTeX_SansSerif-Regular.html": {
    "type": "text/html; charset=utf-8",
    "etag": "\"ab-Qwr3igcCwLiUYlmJhoKMamlAxz4\"",
    "mtime": "2025-04-13T20:04:20.429Z",
    "size": 171,
    "path": "../public/app-assets/vendors/css/editors/quill/fonts/KaTeX_SansSerif-Regular.html"
  },
  "/app-assets/vendors/css/editors/quill/fonts/KaTeX_Script-Regular-2.html": {
    "type": "text/html; charset=utf-8",
    "etag": "\"ab-Qwr3igcCwLiUYlmJhoKMamlAxz4\"",
    "mtime": "2025-04-13T20:04:20.430Z",
    "size": 171,
    "path": "../public/app-assets/vendors/css/editors/quill/fonts/KaTeX_Script-Regular-2.html"
  },
  "/app-assets/vendors/css/editors/quill/fonts/KaTeX_Script-Regular.html": {
    "type": "text/html; charset=utf-8",
    "etag": "\"ab-Qwr3igcCwLiUYlmJhoKMamlAxz4\"",
    "mtime": "2025-04-13T20:04:20.429Z",
    "size": 171,
    "path": "../public/app-assets/vendors/css/editors/quill/fonts/KaTeX_Script-Regular.html"
  },
  "/app-assets/vendors/css/editors/quill/fonts/KaTeX_Size1-Regular-2.html": {
    "type": "text/html; charset=utf-8",
    "etag": "\"ab-Qwr3igcCwLiUYlmJhoKMamlAxz4\"",
    "mtime": "2025-04-13T20:04:20.430Z",
    "size": 171,
    "path": "../public/app-assets/vendors/css/editors/quill/fonts/KaTeX_Size1-Regular-2.html"
  },
  "/app-assets/vendors/css/editors/quill/fonts/KaTeX_Size1-Regular.html": {
    "type": "text/html; charset=utf-8",
    "etag": "\"ab-Qwr3igcCwLiUYlmJhoKMamlAxz4\"",
    "mtime": "2025-04-13T20:04:20.431Z",
    "size": 171,
    "path": "../public/app-assets/vendors/css/editors/quill/fonts/KaTeX_Size1-Regular.html"
  },
  "/app-assets/vendors/css/editors/quill/fonts/KaTeX_Size2-Regular-2.html": {
    "type": "text/html; charset=utf-8",
    "etag": "\"ab-Qwr3igcCwLiUYlmJhoKMamlAxz4\"",
    "mtime": "2025-04-13T20:04:20.431Z",
    "size": 171,
    "path": "../public/app-assets/vendors/css/editors/quill/fonts/KaTeX_Size2-Regular-2.html"
  },
  "/app-assets/vendors/css/editors/quill/fonts/KaTeX_Size2-Regular.html": {
    "type": "text/html; charset=utf-8",
    "etag": "\"ab-Qwr3igcCwLiUYlmJhoKMamlAxz4\"",
    "mtime": "2025-04-13T20:04:20.431Z",
    "size": 171,
    "path": "../public/app-assets/vendors/css/editors/quill/fonts/KaTeX_Size2-Regular.html"
  },
  "/app-assets/vendors/css/editors/quill/fonts/KaTeX_Size3-Regular-2.html": {
    "type": "text/html; charset=utf-8",
    "etag": "\"ab-Qwr3igcCwLiUYlmJhoKMamlAxz4\"",
    "mtime": "2025-04-13T20:04:20.431Z",
    "size": 171,
    "path": "../public/app-assets/vendors/css/editors/quill/fonts/KaTeX_Size3-Regular-2.html"
  },
  "/app-assets/vendors/css/editors/quill/fonts/KaTeX_Size3-Regular.html": {
    "type": "text/html; charset=utf-8",
    "etag": "\"ab-Qwr3igcCwLiUYlmJhoKMamlAxz4\"",
    "mtime": "2025-04-13T20:04:20.431Z",
    "size": 171,
    "path": "../public/app-assets/vendors/css/editors/quill/fonts/KaTeX_Size3-Regular.html"
  },
  "/app-assets/vendors/css/editors/quill/fonts/KaTeX_Size4-Regular-2.html": {
    "type": "text/html; charset=utf-8",
    "etag": "\"ab-Qwr3igcCwLiUYlmJhoKMamlAxz4\"",
    "mtime": "2025-04-13T20:04:20.430Z",
    "size": 171,
    "path": "../public/app-assets/vendors/css/editors/quill/fonts/KaTeX_Size4-Regular-2.html"
  },
  "/app-assets/vendors/css/editors/quill/fonts/KaTeX_Size4-Regular.html": {
    "type": "text/html; charset=utf-8",
    "etag": "\"ab-Qwr3igcCwLiUYlmJhoKMamlAxz4\"",
    "mtime": "2025-04-13T20:04:20.431Z",
    "size": 171,
    "path": "../public/app-assets/vendors/css/editors/quill/fonts/KaTeX_Size4-Regular.html"
  },
  "/app-assets/vendors/css/editors/quill/fonts/KaTeX_Typewriter-Regular-2.html": {
    "type": "text/html; charset=utf-8",
    "etag": "\"ab-Qwr3igcCwLiUYlmJhoKMamlAxz4\"",
    "mtime": "2025-04-13T20:04:20.431Z",
    "size": 171,
    "path": "../public/app-assets/vendors/css/editors/quill/fonts/KaTeX_Typewriter-Regular-2.html"
  },
  "/app-assets/vendors/css/editors/quill/fonts/KaTeX_Typewriter-Regular.html": {
    "type": "text/html; charset=utf-8",
    "etag": "\"ab-Qwr3igcCwLiUYlmJhoKMamlAxz4\"",
    "mtime": "2025-04-13T20:04:20.431Z",
    "size": 171,
    "path": "../public/app-assets/vendors/css/editors/quill/fonts/KaTeX_Typewriter-Regular.html"
  },
  "/app-assets/vendors/css/tables/datatable/extensions/dataTables.checkboxes.css": {
    "type": "text/css; charset=utf-8",
    "etag": "\"238-cbvtW7GSrwL5l1aGAJGQDfXgRoM\"",
    "mtime": "2025-04-13T20:04:20.319Z",
    "size": 568,
    "path": "../public/app-assets/vendors/css/tables/datatable/extensions/dataTables.checkboxes.css"
  }
};

const _DRIVE_LETTER_START_RE = /^[A-Za-z]:\//;
function normalizeWindowsPath(input = "") {
  if (!input) {
    return input;
  }
  return input.replace(/\\/g, "/").replace(_DRIVE_LETTER_START_RE, (r) => r.toUpperCase());
}
const _IS_ABSOLUTE_RE = /^[/\\](?![/\\])|^[/\\]{2}(?!\.)|^[A-Za-z]:[/\\]/;
const _DRIVE_LETTER_RE = /^[A-Za-z]:$/;
function cwd() {
  if (typeof process !== "undefined" && typeof process.cwd === "function") {
    return process.cwd().replace(/\\/g, "/");
  }
  return "/";
}
const resolve = function(...arguments_) {
  arguments_ = arguments_.map((argument) => normalizeWindowsPath(argument));
  let resolvedPath = "";
  let resolvedAbsolute = false;
  for (let index = arguments_.length - 1; index >= -1 && !resolvedAbsolute; index--) {
    const path = index >= 0 ? arguments_[index] : cwd();
    if (!path || path.length === 0) {
      continue;
    }
    resolvedPath = `${path}/${resolvedPath}`;
    resolvedAbsolute = isAbsolute(path);
  }
  resolvedPath = normalizeString(resolvedPath, !resolvedAbsolute);
  if (resolvedAbsolute && !isAbsolute(resolvedPath)) {
    return `/${resolvedPath}`;
  }
  return resolvedPath.length > 0 ? resolvedPath : ".";
};
function normalizeString(path, allowAboveRoot) {
  let res = "";
  let lastSegmentLength = 0;
  let lastSlash = -1;
  let dots = 0;
  let char = null;
  for (let index = 0; index <= path.length; ++index) {
    if (index < path.length) {
      char = path[index];
    } else if (char === "/") {
      break;
    } else {
      char = "/";
    }
    if (char === "/") {
      if (lastSlash === index - 1 || dots === 1) ; else if (dots === 2) {
        if (res.length < 2 || lastSegmentLength !== 2 || res[res.length - 1] !== "." || res[res.length - 2] !== ".") {
          if (res.length > 2) {
            const lastSlashIndex = res.lastIndexOf("/");
            if (lastSlashIndex === -1) {
              res = "";
              lastSegmentLength = 0;
            } else {
              res = res.slice(0, lastSlashIndex);
              lastSegmentLength = res.length - 1 - res.lastIndexOf("/");
            }
            lastSlash = index;
            dots = 0;
            continue;
          } else if (res.length > 0) {
            res = "";
            lastSegmentLength = 0;
            lastSlash = index;
            dots = 0;
            continue;
          }
        }
        if (allowAboveRoot) {
          res += res.length > 0 ? "/.." : "..";
          lastSegmentLength = 2;
        }
      } else {
        if (res.length > 0) {
          res += `/${path.slice(lastSlash + 1, index)}`;
        } else {
          res = path.slice(lastSlash + 1, index);
        }
        lastSegmentLength = index - lastSlash - 1;
      }
      lastSlash = index;
      dots = 0;
    } else if (char === "." && dots !== -1) {
      ++dots;
    } else {
      dots = -1;
    }
  }
  return res;
}
const isAbsolute = function(p) {
  return _IS_ABSOLUTE_RE.test(p);
};
const dirname = function(p) {
  const segments = normalizeWindowsPath(p).replace(/\/$/, "").split("/").slice(0, -1);
  if (segments.length === 1 && _DRIVE_LETTER_RE.test(segments[0])) {
    segments[0] += "/";
  }
  return segments.join("/") || (isAbsolute(p) ? "/" : ".");
};
const basename = function(p, extension) {
  const segments = normalizeWindowsPath(p).split("/");
  let lastSegment = "";
  for (let i = segments.length - 1; i >= 0; i--) {
    const val = segments[i];
    if (val) {
      lastSegment = val;
      break;
    }
  }
  return extension && lastSegment.endsWith(extension) ? lastSegment.slice(0, -extension.length) : lastSegment;
};

function readAsset (id) {
  const serverDir = dirname(fileURLToPath(globalThis._importMeta_.url));
  return promises.readFile(resolve(serverDir, assets[id].path))
}

const publicAssetBases = {"/_nuxt/builds/meta/":{"maxAge":31536000},"/_nuxt/builds/":{"maxAge":1},"/_fonts/":{"maxAge":31536000},"/_scripts/":{"maxAge":31536000},"/_nuxt/":{"maxAge":31536000}};

function isPublicAssetURL(id = '') {
  if (assets[id]) {
    return true
  }
  for (const base in publicAssetBases) {
    if (id.startsWith(base)) { return true }
  }
  return false
}

function getAsset (id) {
  return assets[id]
}

const METHODS = /* @__PURE__ */ new Set(["HEAD", "GET"]);
const EncodingMap = { gzip: ".gz", br: ".br" };
const _uXbpN5 = eventHandler((event) => {
  if (event.method && !METHODS.has(event.method)) {
    return;
  }
  let id = decodePath(
    withLeadingSlash(withoutTrailingSlash(parseURL(event.path).pathname))
  );
  let asset;
  const encodingHeader = String(
    getRequestHeader(event, "accept-encoding") || ""
  );
  const encodings = [
    ...encodingHeader.split(",").map((e) => EncodingMap[e.trim()]).filter(Boolean).sort(),
    ""
  ];
  if (encodings.length > 1) {
    appendResponseHeader(event, "Vary", "Accept-Encoding");
  }
  for (const encoding of encodings) {
    for (const _id of [id + encoding, joinURL(id, "index.html" + encoding)]) {
      const _asset = getAsset(_id);
      if (_asset) {
        asset = _asset;
        id = _id;
        break;
      }
    }
  }
  if (!asset) {
    if (isPublicAssetURL(id)) {
      removeResponseHeader(event, "Cache-Control");
      throw createError$1({
        statusMessage: "Cannot find static asset " + id,
        statusCode: 404
      });
    }
    return;
  }
  const ifNotMatch = getRequestHeader(event, "if-none-match") === asset.etag;
  if (ifNotMatch) {
    setResponseStatus(event, 304, "Not Modified");
    return "";
  }
  const ifModifiedSinceH = getRequestHeader(event, "if-modified-since");
  const mtimeDate = new Date(asset.mtime);
  if (ifModifiedSinceH && asset.mtime && new Date(ifModifiedSinceH) >= mtimeDate) {
    setResponseStatus(event, 304, "Not Modified");
    return "";
  }
  if (asset.type && !getResponseHeader(event, "Content-Type")) {
    setResponseHeader(event, "Content-Type", asset.type);
  }
  if (asset.etag && !getResponseHeader(event, "ETag")) {
    setResponseHeader(event, "ETag", asset.etag);
  }
  if (asset.mtime && !getResponseHeader(event, "Last-Modified")) {
    setResponseHeader(event, "Last-Modified", mtimeDate.toUTCString());
  }
  if (asset.encoding && !getResponseHeader(event, "Content-Encoding")) {
    setResponseHeader(event, "Content-Encoding", asset.encoding);
  }
  if (asset.size > 0 && !getResponseHeader(event, "Content-Length")) {
    setResponseHeader(event, "Content-Length", asset.size);
  }
  return readAsset(id);
});

function defineRenderHandler(render) {
  const runtimeConfig = useRuntimeConfig();
  return eventHandler(async (event) => {
    const nitroApp = useNitroApp();
    const ctx = { event, render, response: void 0 };
    await nitroApp.hooks.callHook("render:before", ctx);
    if (!ctx.response) {
      if (event.path === `${runtimeConfig.app.baseURL}favicon.ico`) {
        setResponseHeader(event, "Content-Type", "image/x-icon");
        return send(
          event,
          "data:image/gif;base64,R0lGODlhAQABAIAAAAAAAP///yH5BAEAAAAALAAAAAABAAEAAAIBRAA7"
        );
      }
      ctx.response = await ctx.render(event);
      if (!ctx.response) {
        const _currentStatus = getResponseStatus(event);
        setResponseStatus(event, _currentStatus === 200 ? 500 : _currentStatus);
        return send(
          event,
          "No response returned from render handler: " + event.path
        );
      }
    }
    await nitroApp.hooks.callHook("render:response", ctx.response, ctx);
    if (ctx.response.headers) {
      setResponseHeaders(event, ctx.response.headers);
    }
    if (ctx.response.statusCode || ctx.response.statusMessage) {
      setResponseStatus(
        event,
        ctx.response.statusCode,
        ctx.response.statusMessage
      );
    }
    return ctx.response.body;
  });
}

function buildAssetsDir() {
  return useRuntimeConfig().app.buildAssetsDir;
}
function buildAssetsURL(...path) {
  return joinRelativeURL(publicAssetsURL(), buildAssetsDir(), ...path);
}
function publicAssetsURL(...path) {
  const app = useRuntimeConfig().app;
  const publicBase = app.cdnURL || app.baseURL;
  return path.length ? joinRelativeURL(publicBase, ...path) : publicBase;
}

const checksums = {
  "content": "v3.3.0--bgIYhpjRuV8zbHJE_CfelwKpJ_Td6YuGJwixiek8lmI"
};
const checksumsStructure = {
  "content": "bgIYhpjRuV8zbHJE_CfelwKpJ_Td6YuGJwixiek8lmI"
};
const tables = {
  "content": "_content_content",
  "info": "_content_info"
};
const contentManifest = {
  "content": {
    "type": "page",
    "fields": {
      "id": "string",
      "stem": "string",
      "extension": "string",
      "meta": "json",
      "path": "string",
      "title": "string",
      "description": "string",
      "seo": "json",
      "body": "json",
      "navigation": "json"
    }
  },
  "info": {
    "type": "data",
    "fields": {}
  }
};

async function fetchDatabase(event, collection) {
  return await $fetch(`/__nuxt_content/${collection}/sql_dump`, {
    context: event ? { cloudflare: event.context.cloudflare } : {},
    responseType: "text",
    headers: { "content-type": "text/plain" },
    query: { v: checksums[String(collection)], t: void 0 }
  });
}

const collections = {
};

const DEFAULT_ENDPOINT = "https://api.iconify.design";
const _BFa_A1 = defineCachedEventHandler(async (event) => {
  const url = getRequestURL(event);
  if (!url)
    return createError$1({ status: 400, message: "Invalid icon request" });
  const options = useAppConfig().icon;
  const collectionName = event.context.params?.collection?.replace(/\.json$/, "");
  const collection = collectionName ? await collections[collectionName]?.() : null;
  const apiEndPoint = options.iconifyApiEndpoint || DEFAULT_ENDPOINT;
  const icons = url.searchParams.get("icons")?.split(",");
  if (collection) {
    if (icons?.length) {
      const data = getIcons(
        collection,
        icons
      );
      consola.debug(`[Icon] serving ${(icons || []).map((i) => "`" + collectionName + ":" + i + "`").join(",")} from bundled collection`);
      return data;
    }
  }
  if (options.fallbackToApi === true || options.fallbackToApi === "server-only") {
    const apiUrl = new URL("./" + basename(url.pathname) + url.search, apiEndPoint);
    consola.debug(`[Icon] fetching ${(icons || []).map((i) => "`" + collectionName + ":" + i + "`").join(",")} from iconify api`);
    if (apiUrl.host !== new URL(apiEndPoint).host) {
      return createError$1({ status: 400, message: "Invalid icon request" });
    }
    try {
      const data = await $fetch(apiUrl.href);
      return data;
    } catch (e) {
      consola.error(e);
      if (e.status === 404)
        return createError$1({ status: 404 });
      else
        return createError$1({ status: 500, message: "Failed to fetch fallback icon" });
    }
  }
  return createError$1({ status: 404 });
}, {
  group: "nuxt",
  name: "icon",
  getKey(event) {
    const collection = event.context.params?.collection?.replace(/\.json$/, "") || "unknown";
    const icons = String(getQuery(event).icons || "");
    return `${collection}_${icons.split(",")[0]}_${icons.length}_${hash$1(icons)}`;
  },
  swr: true,
  maxAge: 60 * 60 * 24 * 7
  // 1 week
});

const _uXkUz6 = eventHandler(async (event) => {
  const collection = getRouterParam(event, "collection");
  const data = await useStorage().getItem(`build:content:database.compressed.mjs`) || "";
  if (data) {
    const lineStart = `export const ${collection} = "`;
    const content = String(data).split("\n").find((line) => line.startsWith(lineStart));
    if (content) {
      return content.substring(lineStart.length, content.length - 1);
    }
  }
  return await import('../build/database.compressed.mjs').then((m) => m[collection]);
});

async function decompressSQLDump(base64Str, compressionType = "gzip") {
  const binaryData = Uint8Array.from(atob(base64Str), (c) => c.charCodeAt(0));
  const response = new Response(new Blob([binaryData]));
  const decompressedStream = response.body?.pipeThrough(new DecompressionStream(compressionType));
  const decompressedText = await new Response(decompressedStream).text();
  return decompressedText.split("\n");
}

function refineContentFields(sql, doc) {
  const fields = findCollectionFields(sql);
  const item = { ...doc };
  for (const key in item) {
    if (fields[key] === "json" && item[key] && item[key] !== "undefined") {
      item[key] = JSON.parse(item[key]);
    }
    if (fields[key] === "boolean" && item[key] !== "undefined") {
      item[key] = Boolean(item[key]);
    }
  }
  for (const key in item) {
    if (item[key] === "NULL") {
      item[key] = void 0;
    }
  }
  return item;
}
function findCollectionFields(sql) {
  const table = sql.match(/FROM\s+(\w+)/);
  if (!table) {
    return {};
  }
  const info = contentManifest[getCollectionName(table[1])];
  return info?.fields || {};
}
function getCollectionName(table) {
  return table.replace(/^_content_/, "");
}

class BoundableStatement {
  _statement;
  constructor(rawStmt) {
    this._statement = rawStmt;
  }
  bind(...params) {
    return new BoundStatement(this, params);
  }
}
class BoundStatement {
  #statement;
  #params;
  constructor(statement, params) {
    this.#statement = statement;
    this.#params = params;
  }
  bind(...params) {
    return new BoundStatement(this.#statement, params);
  }
  all() {
    return this.#statement.all(...this.#params);
  }
  run() {
    return this.#statement.run(...this.#params);
  }
  get() {
    return this.#statement.get(...this.#params);
  }
}

function sqliteConnector(opts) {
  let _db;
  const getDB = () => {
    if (_db) {
      return _db;
    }
    if (opts.name === ":memory:") {
      _db = new Database(":memory:");
      return _db;
    }
    const filePath = resolve$1(
      opts.cwd || ".",
      opts.path || `.data/${opts.name || "db"}.sqlite3`
    );
    mkdirSync(dirname$1(filePath), { recursive: true });
    _db = new Database(filePath);
    return _db;
  };
  return {
    name: "sqlite",
    dialect: "sqlite",
    getInstance: () => getDB(),
    exec: (sql) => getDB().exec(sql),
    prepare: (sql) => new StatementWrapper(getDB().prepare(sql))
  };
}
class StatementWrapper extends BoundableStatement {
  all(...params) {
    return Promise.resolve(this._statement.all(...params));
  }
  run(...params) {
    const res = this._statement.run(...params);
    return Promise.resolve({ success: res.changes > 0, ...res });
  }
  get(...params) {
    return Promise.resolve(this._statement.get(...params));
  }
}

let db;
function loadDatabaseAdapter(config) {
  const { database, localDatabase } = config;
  if (!db) {
    if (["nitro-prerender", "nitro-dev"].includes("node-server")) {
      db = sqliteConnector(refineDatabaseConfig(localDatabase));
    } else {
      db = sqliteConnector(refineDatabaseConfig(database));
    }
  }
  return {
    all: async (sql, params = []) => {
      return db.prepare(sql).all(...params).then((result) => (result || []).map((item) => refineContentFields(sql, item)));
    },
    first: async (sql, params = []) => {
      return db.prepare(sql).get(...params).then((item) => item ? refineContentFields(sql, item) : item);
    },
    exec: async (sql, params = []) => {
      return db.prepare(sql).run(...params);
    }
  };
}
const checkDatabaseIntegrity = {};
const integrityCheckPromise = {};
async function checkAndImportDatabaseIntegrity(event, collection, config) {
  if (checkDatabaseIntegrity[String(collection)] !== false) {
    checkDatabaseIntegrity[String(collection)] = false;
    integrityCheckPromise[String(collection)] = integrityCheckPromise[String(collection)] || _checkAndImportDatabaseIntegrity(event, collection, checksums[String(collection)], checksumsStructure[String(collection)], config).then((isValid) => {
      checkDatabaseIntegrity[String(collection)] = !isValid;
    }).catch((error) => {
      console.error("Database integrity check failed", error);
      checkDatabaseIntegrity[String(collection)] = true;
      integrityCheckPromise[String(collection)] = null;
    });
  }
  if (integrityCheckPromise[String(collection)]) {
    await integrityCheckPromise[String(collection)];
  }
}
async function _checkAndImportDatabaseIntegrity(event, collection, integrityVersion, structureIntegrityVersion, config) {
  const db2 = loadDatabaseAdapter(config);
  const before = await db2.first(`SELECT * FROM ${tables.info} WHERE id = ?`, [`checksum_${collection}`]).catch(() => null);
  if (before?.version && !String(before.version)?.startsWith(`${config.databaseVersion}--`)) {
    await db2.exec(`DROP TABLE IF EXISTS ${tables.info}`);
    before.version = "";
  }
  const unchangedStructure = before?.structureVersion === structureIntegrityVersion;
  if (before?.version) {
    if (before.version === integrityVersion) {
      if (before.ready) {
        return true;
      }
      await waitUntilDatabaseIsReady(db2, collection);
      return true;
    }
    await db2.exec(`DELETE FROM ${tables.info} WHERE id = ?`, [`checksum_${collection}`]);
    if (!unchangedStructure) {
      await db2.exec(`DROP TABLE IF EXISTS ${tables[collection]}`);
    }
  }
  const dump = await loadDatabaseDump(event, collection).then(decompressSQLDump);
  const dumpLinesHash = dump.map((row) => row.split(" -- ").pop());
  let hashesInDb = /* @__PURE__ */ new Set();
  if (unchangedStructure) {
    const hashListFromTheDump = new Set(dumpLinesHash);
    const hashesInDbRecords = await db2.all(`SELECT __hash__ FROM ${tables[collection]}`).catch(() => []);
    hashesInDb = new Set(hashesInDbRecords.map((r) => r.__hash__));
    const hashesToDelete = hashesInDb.difference(hashListFromTheDump);
    if (hashesToDelete.size) {
      await db2.exec(`DELETE FROM ${tables[collection]} WHERE __hash__ IN (${Array(hashesToDelete.size).fill("?").join(",")})`, Array.from(hashesToDelete));
    }
  }
  await dump.reduce(async (prev, sql, index) => {
    await prev;
    const hash = dumpLinesHash[index];
    const statement = sql.substring(0, sql.length - hash.length - 4);
    if (unchangedStructure) {
      if (hash === "structure") {
        return Promise.resolve();
      }
      if (hashesInDb.has(hash)) {
        return Promise.resolve();
      }
    }
    await db2.exec(statement).catch((err) => {
      const message = err.message || "Unknown error";
      console.error(`Failed to execute SQL ${sql}: ${message}`);
    });
  }, Promise.resolve());
  const after = await db2.first(`SELECT version FROM ${tables.info} WHERE id = ?`, [`checksum_${collection}`]).catch(() => ({ version: "" }));
  return after?.version === integrityVersion;
}
const REQUEST_TIMEOUT = 90;
async function waitUntilDatabaseIsReady(db2, collection) {
  let iterationCount = 0;
  let interval;
  await new Promise((resolve, reject) => {
    interval = setInterval(async () => {
      const row = await db2.first(`SELECT ready FROM ${tables.info} WHERE id = ?`, [`checksum_${collection}`]).catch(() => ({ ready: true }));
      if (row?.ready) {
        clearInterval(interval);
        resolve(0);
      }
      if (iterationCount++ > REQUEST_TIMEOUT) {
        clearInterval(interval);
        reject(new Error("Waiting for another database initialization timed out"));
      }
    }, 1e3);
  }).catch((e) => {
    throw e;
  }).finally(() => {
    if (interval) {
      clearInterval(interval);
    }
  });
}
async function loadDatabaseDump(event, collection) {
  return await fetchDatabase(event, String(collection)).catch((e) => {
    console.error("Failed to fetch compressed dump", e);
    return "";
  });
}
function refineDatabaseConfig(config) {
  if (config.type === "d1") {
    return { ...config, bindingName: config.bindingName || config.binding };
  }
  if (config.type === "sqlite") {
    const _config = { ...config };
    if (config.filename === ":memory:") {
      return { name: "memory" };
    }
    if ("filename" in config) {
      const filename = isAbsolute(config?.filename || "") || config?.filename === ":memory:" ? config?.filename : new URL(config.filename, globalThis._importMeta_.url).pathname;
      _config.path = process.platform === "win32" && filename.startsWith("/") ? filename.slice(1) : filename;
    }
    return _config;
  }
  return config;
}

const SQL_COMMANDS = /SELECT|INSERT|UPDATE|DELETE|DROP|ALTER|\$/i;
const SQL_COUNT_REGEX = /COUNT\((DISTINCT )?([a-z_]\w+|\*)\)/i;
const SQL_SELECT_REGEX = /^SELECT (.*) FROM (\w+)( WHERE .*)? ORDER BY (["\w,\s]+) (ASC|DESC)( LIMIT \d+)?( OFFSET \d+)?$/;
function assertSafeQuery(sql, collection) {
  if (!sql) {
    throw new Error("Invalid query");
  }
  const cleanedupQuery = cleanupQuery(sql);
  if (cleanedupQuery !== sql) {
    throw new Error("Invalid query");
  }
  const match = sql.match(SQL_SELECT_REGEX);
  if (!match) {
    throw new Error("Invalid query");
  }
  const [_, select, from, where, orderBy, order, limit, offset] = match;
  const columns = select.trim().split(", ");
  if (columns.length === 1) {
    if (columns[0] !== "*" && !columns[0].match(SQL_COUNT_REGEX) && !columns[0].match(/^"[a-z_]\w+"$/i)) {
      throw new Error("Invalid query");
    }
  } else if (!columns.every((column) => column.match(/^"[a-z_]\w+"$/i))) {
    throw new Error("Invalid query");
  }
  if (from !== `_content_${collection}`) {
    throw new Error("Invalid query");
  }
  if (where) {
    if (!where.startsWith(" WHERE (") || !where.endsWith(")")) {
      throw new Error("Invalid query");
    }
    const noString = cleanupQuery(where, { removeString: true });
    if (noString.match(SQL_COMMANDS)) {
      throw new Error("Invalid query");
    }
  }
  const _order = (orderBy + " " + order).split(", ");
  if (!_order.every((column) => column.match(/^("[a-zA-Z_]+"|[a-zA-Z_]+) (ASC|DESC)$/))) {
    throw new Error("Invalid query");
  }
  if (limit !== void 0 && !limit.match(/^ LIMIT \d+$/)) {
    throw new Error("Invalid query");
  }
  if (offset !== void 0 && !offset.match(/^ OFFSET \d+$/)) {
    throw new Error("Invalid query");
  }
  return true;
}
function cleanupQuery(query, options = { removeString: false }) {
  let inString = false;
  let stringFence = "";
  let result = "";
  for (let i = 0; i < query.length; i++) {
    const char = query[i];
    const prevChar = query[i - 1];
    const nextChar = query[i + 1];
    if (char === "'" || char === '"') {
      if (!options?.removeString) {
        result += char;
        continue;
      }
      if (inString) {
        if (char !== stringFence || nextChar === stringFence || prevChar === stringFence) {
          continue;
        }
        inString = false;
        stringFence = "";
        continue;
      } else {
        inString = true;
        stringFence = char;
        continue;
      }
    }
    if (!inString) {
      if (char === "-" && nextChar === "-") {
        return result;
      }
      if (char === "/" && nextChar === "*") {
        i += 2;
        while (i < query.length && !(query[i] === "*" && query[i + 1] === "/")) {
          i += 1;
        }
        i += 2;
        continue;
      }
      result += char;
    }
  }
  return result;
}

const _gQCoPb = eventHandler(async (event) => {
  const { sql } = await readBody(event);
  const collection = getRouterParam(event, "collection");
  assertSafeQuery(sql, collection);
  const conf = useRuntimeConfig().content;
  if (conf.integrityCheck) {
    await checkAndImportDatabaseIntegrity(event, collection, conf);
  }
  return loadDatabaseAdapter(conf).all(sql);
});

const _FePVJT = lazyEventHandler(() => {
  const opts = useRuntimeConfig().ipx || {};
  const fsDir = opts?.fs?.dir ? (Array.isArray(opts.fs.dir) ? opts.fs.dir : [opts.fs.dir]).map((dir) => isAbsolute(dir) ? dir : fileURLToPath(new URL(dir, globalThis._importMeta_.url))) : void 0;
  const fsStorage = opts.fs?.dir ? ipxFSStorage({ ...opts.fs, dir: fsDir }) : void 0;
  const httpStorage = opts.http?.domains ? ipxHttpStorage({ ...opts.http }) : void 0;
  if (!fsStorage && !httpStorage) {
    throw new Error("IPX storage is not configured!");
  }
  const ipxOptions = {
    ...opts,
    storage: fsStorage || httpStorage,
    httpStorage
  };
  const ipx = createIPX(ipxOptions);
  const ipxHandler = createIPXH3Handler(ipx);
  return useBase(opts.baseURL, ipxHandler);
});

const _lazy_K15_yQ = () => import('../routes/renderer.mjs').then(function (n) { return n.r; });

const handlers = [
  { route: '', handler: _uXbpN5, lazy: false, middleware: true, method: undefined },
  { route: '/__nuxt_error', handler: _lazy_K15_yQ, lazy: true, middleware: false, method: undefined },
  { route: '/api/_nuxt_icon/:collection', handler: _BFa_A1, lazy: false, middleware: false, method: undefined },
  { route: '/__nuxt_content/:collection/sql_dump', handler: _uXkUz6, lazy: false, middleware: false, method: undefined },
  { route: '/__nuxt_content/:collection/query', handler: _gQCoPb, lazy: false, middleware: false, method: undefined },
  { route: '/_ipx/**', handler: _FePVJT, lazy: false, middleware: false, method: undefined },
  { route: '/**', handler: _lazy_K15_yQ, lazy: true, middleware: false, method: undefined }
];

function createNitroApp() {
  const config = useRuntimeConfig();
  const hooks = createHooks();
  const captureError = (error, context = {}) => {
    const promise = hooks.callHookParallel("error", error, context).catch((error_) => {
      console.error("Error while capturing another error", error_);
    });
    if (context.event && isEvent(context.event)) {
      const errors = context.event.context.nitro?.errors;
      if (errors) {
        errors.push({ error, context });
      }
      if (context.event.waitUntil) {
        context.event.waitUntil(promise);
      }
    }
  };
  const h3App = createApp({
    debug: destr(false),
    onError: (error, event) => {
      captureError(error, { event, tags: ["request"] });
      return errorHandler(error, event);
    },
    onRequest: async (event) => {
      event.context.nitro = event.context.nitro || { errors: [] };
      const fetchContext = event.node.req?.__unenv__;
      if (fetchContext?._platform) {
        event.context = {
          ...fetchContext._platform,
          ...event.context
        };
      }
      if (!event.context.waitUntil && fetchContext?.waitUntil) {
        event.context.waitUntil = fetchContext.waitUntil;
      }
      event.fetch = (req, init) => fetchWithEvent(event, req, init, { fetch: localFetch });
      event.$fetch = (req, init) => fetchWithEvent(event, req, init, {
        fetch: $fetch
      });
      event.waitUntil = (promise) => {
        if (!event.context.nitro._waitUntilPromises) {
          event.context.nitro._waitUntilPromises = [];
        }
        event.context.nitro._waitUntilPromises.push(promise);
        if (event.context.waitUntil) {
          event.context.waitUntil(promise);
        }
      };
      event.captureError = (error, context) => {
        captureError(error, { event, ...context });
      };
      await nitroApp$1.hooks.callHook("request", event).catch((error) => {
        captureError(error, { event, tags: ["request"] });
      });
    },
    onBeforeResponse: async (event, response) => {
      await nitroApp$1.hooks.callHook("beforeResponse", event, response).catch((error) => {
        captureError(error, { event, tags: ["request", "response"] });
      });
    },
    onAfterResponse: async (event, response) => {
      await nitroApp$1.hooks.callHook("afterResponse", event, response).catch((error) => {
        captureError(error, { event, tags: ["request", "response"] });
      });
    }
  });
  const router = createRouter({
    preemptive: true
  });
  const nodeHandler = toNodeListener(h3App);
  const localCall = (aRequest) => b(nodeHandler, aRequest);
  const localFetch = (input, init) => {
    if (!input.toString().startsWith("/")) {
      return globalThis.fetch(input, init);
    }
    return O(
      nodeHandler,
      input,
      init
    ).then((response) => normalizeFetchResponse(response));
  };
  const $fetch = createFetch({
    fetch: localFetch,
    Headers: Headers$1,
    defaults: { baseURL: config.app.baseURL }
  });
  globalThis.$fetch = $fetch;
  h3App.use(createRouteRulesHandler({ localFetch }));
  for (const h of handlers) {
    let handler = h.lazy ? lazyEventHandler(h.handler) : h.handler;
    if (h.middleware || !h.route) {
      const middlewareBase = (config.app.baseURL + (h.route || "/")).replace(
        /\/+/g,
        "/"
      );
      h3App.use(middlewareBase, handler);
    } else {
      const routeRules = getRouteRulesForPath(
        h.route.replace(/:\w+|\*\*/g, "_")
      );
      if (routeRules.cache) {
        handler = cachedEventHandler(handler, {
          group: "nitro/routes",
          ...routeRules.cache
        });
      }
      router.use(h.route, handler, h.method);
    }
  }
  h3App.use(config.app.baseURL, router.handler);
  const app = {
    hooks,
    h3App,
    router,
    localCall,
    localFetch,
    captureError
  };
  return app;
}
function runNitroPlugins(nitroApp2) {
  for (const plugin of plugins) {
    try {
      plugin(nitroApp2);
    } catch (error) {
      nitroApp2.captureError(error, { tags: ["plugin"] });
      throw error;
    }
  }
}
const nitroApp$1 = createNitroApp();
function useNitroApp() {
  return nitroApp$1;
}
runNitroPlugins(nitroApp$1);

function parse(str, options) {
  if (typeof str !== "string") {
    throw new TypeError("argument str must be a string");
  }
  const obj = {};
  const opt = options || {};
  const dec = opt.decode || decode;
  let index = 0;
  while (index < str.length) {
    const eqIdx = str.indexOf("=", index);
    if (eqIdx === -1) {
      break;
    }
    let endIdx = str.indexOf(";", index);
    if (endIdx === -1) {
      endIdx = str.length;
    } else if (endIdx < eqIdx) {
      index = str.lastIndexOf(";", eqIdx - 1) + 1;
      continue;
    }
    const key = str.slice(index, eqIdx).trim();
    if (opt?.filter && !opt?.filter(key)) {
      index = endIdx + 1;
      continue;
    }
    if (void 0 === obj[key]) {
      let val = str.slice(eqIdx + 1, endIdx).trim();
      if (val.codePointAt(0) === 34) {
        val = val.slice(1, -1);
      }
      obj[key] = tryDecode(val, dec);
    }
    index = endIdx + 1;
  }
  return obj;
}
function decode(str) {
  return str.includes("%") ? decodeURIComponent(str) : str;
}
function tryDecode(str, decode2) {
  try {
    return decode2(str);
  } catch {
    return str;
  }
}

const debug = (...args) => {
};
function GracefulShutdown(server, opts) {
  opts = opts || {};
  const options = Object.assign(
    {
      signals: "SIGINT SIGTERM",
      timeout: 3e4,
      development: false,
      forceExit: true,
      onShutdown: (signal) => Promise.resolve(signal),
      preShutdown: (signal) => Promise.resolve(signal)
    },
    opts
  );
  let isShuttingDown = false;
  const connections = {};
  let connectionCounter = 0;
  const secureConnections = {};
  let secureConnectionCounter = 0;
  let failed = false;
  let finalRun = false;
  function onceFactory() {
    let called = false;
    return (emitter, events, callback) => {
      function call() {
        if (!called) {
          called = true;
          return Reflect.apply(callback, this, arguments);
        }
      }
      for (const e of events) {
        emitter.on(e, call);
      }
    };
  }
  const signals = options.signals.split(" ").map((s) => s.trim()).filter((s) => s.length > 0);
  const once = onceFactory();
  once(process, signals, (signal) => {
    debug("received shut down signal", signal);
    shutdown(signal).then(() => {
      if (options.forceExit) {
        process.exit(failed ? 1 : 0);
      }
    }).catch((error) => {
      debug("server shut down error occurred", error);
      process.exit(1);
    });
  });
  function isFunction(functionToCheck) {
    const getType = Object.prototype.toString.call(functionToCheck);
    return /^\[object\s([A-Za-z]+)?Function]$/.test(getType);
  }
  function destroy(socket, force = false) {
    if (socket._isIdle && isShuttingDown || force) {
      socket.destroy();
      if (socket.server instanceof http.Server) {
        delete connections[socket._connectionId];
      } else {
        delete secureConnections[socket._connectionId];
      }
    }
  }
  function destroyAllConnections(force = false) {
    debug("Destroy Connections : " + (force ? "forced close" : "close"));
    let counter = 0;
    let secureCounter = 0;
    for (const key of Object.keys(connections)) {
      const socket = connections[key];
      const serverResponse = socket._httpMessage;
      if (serverResponse && !force) {
        if (!serverResponse.headersSent) {
          serverResponse.setHeader("connection", "close");
        }
      } else {
        counter++;
        destroy(socket);
      }
    }
    debug("Connections destroyed : " + counter);
    debug("Connection Counter    : " + connectionCounter);
    for (const key of Object.keys(secureConnections)) {
      const socket = secureConnections[key];
      const serverResponse = socket._httpMessage;
      if (serverResponse && !force) {
        if (!serverResponse.headersSent) {
          serverResponse.setHeader("connection", "close");
        }
      } else {
        secureCounter++;
        destroy(socket);
      }
    }
    debug("Secure Connections destroyed : " + secureCounter);
    debug("Secure Connection Counter    : " + secureConnectionCounter);
  }
  server.on("request", (req, res) => {
    req.socket._isIdle = false;
    if (isShuttingDown && !res.headersSent) {
      res.setHeader("connection", "close");
    }
    res.on("finish", () => {
      req.socket._isIdle = true;
      destroy(req.socket);
    });
  });
  server.on("connection", (socket) => {
    if (isShuttingDown) {
      socket.destroy();
    } else {
      const id = connectionCounter++;
      socket._isIdle = true;
      socket._connectionId = id;
      connections[id] = socket;
      socket.once("close", () => {
        delete connections[socket._connectionId];
      });
    }
  });
  server.on("secureConnection", (socket) => {
    if (isShuttingDown) {
      socket.destroy();
    } else {
      const id = secureConnectionCounter++;
      socket._isIdle = true;
      socket._connectionId = id;
      secureConnections[id] = socket;
      socket.once("close", () => {
        delete secureConnections[socket._connectionId];
      });
    }
  });
  process.on("close", () => {
    debug("closed");
  });
  function shutdown(sig) {
    function cleanupHttp() {
      destroyAllConnections();
      debug("Close http server");
      return new Promise((resolve, reject) => {
        server.close((err) => {
          if (err) {
            return reject(err);
          }
          return resolve(true);
        });
      });
    }
    debug("shutdown signal - " + sig);
    if (options.development) {
      debug("DEV-Mode - immediate forceful shutdown");
      return process.exit(0);
    }
    function finalHandler() {
      if (!finalRun) {
        finalRun = true;
        if (options.finally && isFunction(options.finally)) {
          debug("executing finally()");
          options.finally();
        }
      }
      return Promise.resolve();
    }
    function waitForReadyToShutDown(totalNumInterval) {
      debug(`waitForReadyToShutDown... ${totalNumInterval}`);
      if (totalNumInterval === 0) {
        debug(
          `Could not close connections in time (${options.timeout}ms), will forcefully shut down`
        );
        return Promise.resolve(true);
      }
      const allConnectionsClosed = Object.keys(connections).length === 0 && Object.keys(secureConnections).length === 0;
      if (allConnectionsClosed) {
        debug("All connections closed. Continue to shutting down");
        return Promise.resolve(false);
      }
      debug("Schedule the next waitForReadyToShutdown");
      return new Promise((resolve) => {
        setTimeout(() => {
          resolve(waitForReadyToShutDown(totalNumInterval - 1));
        }, 250);
      });
    }
    if (isShuttingDown) {
      return Promise.resolve();
    }
    debug("shutting down");
    return options.preShutdown(sig).then(() => {
      isShuttingDown = true;
      cleanupHttp();
    }).then(() => {
      const pollIterations = options.timeout ? Math.round(options.timeout / 250) : 0;
      return waitForReadyToShutDown(pollIterations);
    }).then((force) => {
      debug("Do onShutdown now");
      if (force) {
        destroyAllConnections(force);
      }
      return options.onShutdown(sig);
    }).then(finalHandler).catch((error) => {
      const errString = typeof error === "string" ? error : JSON.stringify(error);
      debug(errString);
      failed = true;
      throw errString;
    });
  }
  function shutdownManual() {
    return shutdown("manual");
  }
  return shutdownManual;
}

function getGracefulShutdownConfig() {
  return {
    disabled: !!process.env.NITRO_SHUTDOWN_DISABLED,
    signals: (process.env.NITRO_SHUTDOWN_SIGNALS || "SIGTERM SIGINT").split(" ").map((s) => s.trim()),
    timeout: Number.parseInt(process.env.NITRO_SHUTDOWN_TIMEOUT || "", 10) || 3e4,
    forceExit: !process.env.NITRO_SHUTDOWN_NO_FORCE_EXIT
  };
}
function setupGracefulShutdown(listener, nitroApp) {
  const shutdownConfig = getGracefulShutdownConfig();
  if (shutdownConfig.disabled) {
    return;
  }
  GracefulShutdown(listener, {
    signals: shutdownConfig.signals.join(" "),
    timeout: shutdownConfig.timeout,
    forceExit: shutdownConfig.forceExit,
    onShutdown: async () => {
      await new Promise((resolve) => {
        const timeout = setTimeout(() => {
          console.warn("Graceful shutdown timeout, force exiting...");
          resolve();
        }, shutdownConfig.timeout);
        nitroApp.hooks.callHook("close").catch((error) => {
          console.error(error);
        }).finally(() => {
          clearTimeout(timeout);
          resolve();
        });
      });
    }
  });
}

const cert = process.env.NITRO_SSL_CERT;
const key = process.env.NITRO_SSL_KEY;
const nitroApp = useNitroApp();
const server = cert && key ? new Server({ key, cert }, toNodeListener(nitroApp.h3App)) : new Server$1(toNodeListener(nitroApp.h3App));
const port = destr(process.env.NITRO_PORT || process.env.PORT) || 3e3;
const host = process.env.NITRO_HOST || process.env.HOST;
const path = process.env.NITRO_UNIX_SOCKET;
const listener = server.listen(path ? { path } : { port, host }, (err) => {
  if (err) {
    console.error(err);
    process.exit(1);
  }
  const protocol = cert && key ? "https" : "http";
  const addressInfo = listener.address();
  if (typeof addressInfo === "string") {
    console.log(`Listening on unix socket ${addressInfo}`);
    return;
  }
  const baseURL = (useRuntimeConfig().app.baseURL || "").replace(/\/$/, "");
  const url = `${protocol}://${addressInfo.family === "IPv6" ? `[${addressInfo.address}]` : addressInfo.address}:${addressInfo.port}${baseURL}`;
  console.log(`Listening on ${url}`);
});
trapUnhandledNodeErrors();
setupGracefulShutdown(listener, nitroApp);
const nodeServer = {};

export { klona as A, destr as B, parse as C, getRequestHeader as D, isEqual as E, setCookie as F, getCookie as G, deleteCookie as H, withTrailingSlash as I, parseQuery as J, withoutTrailingSlash as K, nodeServer as L, getResponseStatus as a, buildAssetsURL as b, getQuery as c, defineRenderHandler as d, createError$1 as e, getRouteRules as f, getResponseStatusText as g, useNitroApp as h, createHooks as i, getContext as j, createRouter$1 as k, defu as l, hasProtocol as m, joinURL as n, isScriptProtocol as o, publicAssetsURL as p, executeAsync as q, withLeadingSlash as r, sanitizeStatusCode as s, toRouteMatcher as t, useRuntimeConfig as u, parseURL as v, withQuery as w, encodePath as x, encodeParam as y, defuFn as z };
//# sourceMappingURL=nitro.mjs.map
