import{_ as o,c as r,o as s,a5 as t}from"./Bf0wYg_a.js";const c={};function n(e,a){return s(),r("ol",null,[t(e.$slots,"default")])}const _=o(c,[["render",n]]);export{_ as default};
