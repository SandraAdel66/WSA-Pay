import{a2 as a,a3 as e}from"./Bf0wYg_a.js";const o=a(()=>e("/dashboard"));export{o as default};
