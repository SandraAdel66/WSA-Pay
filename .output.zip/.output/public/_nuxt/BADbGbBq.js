import{_ as o,c as r,o as t,a5 as s}from"./Bf0wYg_a.js";const c={};function n(e,a){return t(),r("td",null,[s(e.$slots,"default")])}const _=o(c,[["render",n]]);export{_ as default};
