import{_ as e,c as r,o as c}from"./Bf0wYg_a.js";const o={};function t(n,s){return c(),r("hr")}const a=e(o,[["render",t]]);export{a as default};
