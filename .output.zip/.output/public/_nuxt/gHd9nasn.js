import{_ as o,c as r,o as c,a5 as s}from"./Bf0wYg_a.js";const t={};function n(e,a){return c(),r("code",null,[s(e.$slots,"default")])}const _=o(t,[["render",n]]);export{_ as default};
