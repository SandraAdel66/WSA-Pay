import{_ as r,c as o,o as t,a5 as s}from"./Bf0wYg_a.js";const c={};function n(e,a){return t(),o("tr",null,[s(e.$slots,"default")])}const _=r(c,[["render",n]]);export{_ as default};
