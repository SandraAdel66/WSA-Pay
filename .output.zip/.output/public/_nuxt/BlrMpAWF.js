const _={__name:"index",setup(e){return()=>{}}};export{_ as default};
