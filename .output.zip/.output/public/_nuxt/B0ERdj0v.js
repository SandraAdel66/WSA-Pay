import{_ as o,c as t,o as c,a5 as r}from"./Bf0wYg_a.js";const s={};function n(e,a){return c(),t("blockquote",null,[r(e.$slots,"default")])}const _=o(s,[["render",n]]);export{_ as default};
