import{_ as o,c as r,o as t,a5 as a}from"./Bf0wYg_a.js";const s={};function c(e,n){return t(),r("thead",null,[a(e.$slots,"default")])}const _=o(s,[["render",c]]);export{_ as default};
