import{_ as t,c,o,b as n,aw as _}from"./Bf0wYg_a.js";const a={},s={id:"app",class:""};function r(p,d){const e=_;return o(),c("div",s,[n(e)])}const i=t(a,[["render",r]]);export{i as default};
