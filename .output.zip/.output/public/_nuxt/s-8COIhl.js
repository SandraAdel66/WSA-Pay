import{_ as o,c as r,o as t,a5 as n}from"./Bf0wYg_a.js";const s={};function c(e,a){return t(),r("strong",null,[n(e.$slots,"default")])}const _=o(s,[["render",c]]);export{_ as default};
